﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Login
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Login))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.MetroTabControl1 = New MetroSuite.MetroTabControl()
        Me.Login_TabPage = New System.Windows.Forms.TabPage()
        Me.WithoutLogin_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.CreateNewAccount_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.Login_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.Login_ShowPassword_chkbox = New Xtreme_Clonk_Launcher.MetroTranslatorChecker()
        Me.password_txtbox = New Xtreme_Clonk_Launcher.MetroTranslatorTextbox()
        Me.username_txtbox = New Xtreme_Clonk_Launcher.MetroTranslatorTextbox()
        Me.MetroTranslatorLabel2 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel1 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Register_TabPage = New System.Windows.Forms.TabPage()
        Me.AbortRegistration_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.Register_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.Register_ShowPassword_chkbox = New Xtreme_Clonk_Launcher.MetroTranslatorChecker()
        Me.Register_password_txtbox = New Xtreme_Clonk_Launcher.MetroTranslatorTextbox()
        Me.Register_username_txtbox = New Xtreme_Clonk_Launcher.MetroTranslatorTextbox()
        Me.MetroTranslatorLabel3 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.LoggingIn_TabPage = New System.Windows.Forms.TabPage()
        Me.BackToLogin2_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.LoggingInStatus_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.LoggingIn_picbox = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Registering_TabPage = New System.Windows.Forms.TabPage()
        Me.BackToLogin_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.RegisteringStatus_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.Registering_picbox = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.ServerStatus_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.controlbox_pnl.SuspendLayout()
        Me.MetroTabControl1.SuspendLayout()
        Me.Login_TabPage.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Register_TabPage.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LoggingIn_TabPage.SuspendLayout()
        CType(Me.LoggingIn_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Registering_TabPage.SuspendLayout()
        CType(Me.Registering_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(366, 3)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 1
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Enabled = False
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.AnimationSpeed = 11
        Me.MetroTabControl1.Appearance = System.Windows.Forms.Appearance.Normal
        Me.MetroTabControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MetroTabControl1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.MetroTabControl1.Controls.Add(Me.Login_TabPage)
        Me.MetroTabControl1.Controls.Add(Me.Register_TabPage)
        Me.MetroTabControl1.Controls.Add(Me.LoggingIn_TabPage)
        Me.MetroTabControl1.Controls.Add(Me.Registering_TabPage)
        Me.MetroTabControl1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTabControl1.ForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(106, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.MetroTabControl1.HeaderItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.HotTrack = True
        Me.MetroTabControl1.HoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.HoverColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.ItemSize = New System.Drawing.Size(10, 10)
        Me.MetroTabControl1.Location = New System.Drawing.Point(1, 30)
        Me.MetroTabControl1.Multiline = True
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedForeColor = System.Drawing.Color.White
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.SelectedItemColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedItemLineColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedTabIsBold = False
        Me.MetroTabControl1.Size = New System.Drawing.Size(424, 423)
        Me.MetroTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MetroTabControl1.TabContainerColor = System.Drawing.Color.White
        Me.MetroTabControl1.TabIndex = 21
        '
        'Login_TabPage
        '
        Me.Login_TabPage.BackColor = System.Drawing.Color.White
        Me.Login_TabPage.Controls.Add(Me.WithoutLogin_btn)
        Me.Login_TabPage.Controls.Add(Me.CreateNewAccount_btn)
        Me.Login_TabPage.Controls.Add(Me.Login_btn)
        Me.Login_TabPage.Controls.Add(Me.Login_ShowPassword_chkbox)
        Me.Login_TabPage.Controls.Add(Me.password_txtbox)
        Me.Login_TabPage.Controls.Add(Me.username_txtbox)
        Me.Login_TabPage.Controls.Add(Me.MetroTranslatorLabel2)
        Me.Login_TabPage.Controls.Add(Me.MetroTranslatorLabel1)
        Me.Login_TabPage.Controls.Add(Me.PictureBox1)
        Me.Login_TabPage.ForeColor = System.Drawing.Color.Black
        Me.Login_TabPage.Location = New System.Drawing.Point(14, 4)
        Me.Login_TabPage.Name = "Login_TabPage"
        Me.Login_TabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.Login_TabPage.Size = New System.Drawing.Size(406, 415)
        Me.Login_TabPage.TabIndex = 0
        Me.Login_TabPage.Text = "L"
        '
        'WithoutLogin_btn
        '
        Me.WithoutLogin_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.WithoutLogin_btn.BackColor = System.Drawing.Color.Transparent
        Me.WithoutLogin_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.WithoutLogin_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.WithoutLogin_btn.DefaultColor = System.Drawing.Color.White
        Me.WithoutLogin_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.WithoutLogin_btn.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.WithoutLogin_btn.HoverColor = System.Drawing.Color.White
        Me.WithoutLogin_btn.LanguageKey = "LOGIN:LOGIN_CONTINUEWOLOGIN"
        Me.WithoutLogin_btn.Location = New System.Drawing.Point(67, 381)
        Me.WithoutLogin_btn.Name = "WithoutLogin_btn"
        Me.WithoutLogin_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.WithoutLogin_btn.RoundingArc = 24
        Me.WithoutLogin_btn.Size = New System.Drawing.Size(273, 24)
        Me.WithoutLogin_btn.TabIndex = 28
        Me.WithoutLogin_btn.Text = "Ohne Anmeldung fortfahren"
        '
        'CreateNewAccount_btn
        '
        Me.CreateNewAccount_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CreateNewAccount_btn.BackColor = System.Drawing.Color.Transparent
        Me.CreateNewAccount_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CreateNewAccount_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CreateNewAccount_btn.DefaultColor = System.Drawing.Color.White
        Me.CreateNewAccount_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CreateNewAccount_btn.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.CreateNewAccount_btn.HoverColor = System.Drawing.Color.White
        Me.CreateNewAccount_btn.LanguageKey = "LOGIN:LOGIN_REGISTERBTN"
        Me.CreateNewAccount_btn.Location = New System.Drawing.Point(67, 329)
        Me.CreateNewAccount_btn.Name = "CreateNewAccount_btn"
        Me.CreateNewAccount_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CreateNewAccount_btn.RoundingArc = 24
        Me.CreateNewAccount_btn.Size = New System.Drawing.Size(273, 24)
        Me.CreateNewAccount_btn.TabIndex = 27
        Me.CreateNewAccount_btn.Text = "Neuen Account erstellen"
        '
        'Login_btn
        '
        Me.Login_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Login_btn.BackColor = System.Drawing.Color.Transparent
        Me.Login_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Login_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Login_btn.DefaultColor = System.Drawing.Color.White
        Me.Login_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Login_btn.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.Login_btn.HoverColor = System.Drawing.Color.White
        Me.Login_btn.LanguageKey = "LOGIN:LOGIN_LOGINBTN"
        Me.Login_btn.Location = New System.Drawing.Point(67, 299)
        Me.Login_btn.Name = "Login_btn"
        Me.Login_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Login_btn.RoundingArc = 24
        Me.Login_btn.Size = New System.Drawing.Size(273, 24)
        Me.Login_btn.TabIndex = 26
        Me.Login_btn.Text = "Anmelden"
        '
        'Login_ShowPassword_chkbox
        '
        Me.Login_ShowPassword_chkbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Login_ShowPassword_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.Login_ShowPassword_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Login_ShowPassword_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Login_ShowPassword_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Login_ShowPassword_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Login_ShowPassword_chkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Login_ShowPassword_chkbox.ForeColor = System.Drawing.Color.DarkGray
        Me.Login_ShowPassword_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.Login_ShowPassword_chkbox.LanguageKey = "LOGIN:LOGIN_PWCHECKBOX"
        Me.Login_ShowPassword_chkbox.Location = New System.Drawing.Point(67, 253)
        Me.Login_ShowPassword_chkbox.Name = "Login_ShowPassword_chkbox"
        Me.Login_ShowPassword_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Login_ShowPassword_chkbox.Size = New System.Drawing.Size(121, 14)
        Me.Login_ShowPassword_chkbox.TabIndex = 25
        Me.Login_ShowPassword_chkbox.Text = "Passwort anzeigen"
        '
        'password_txtbox
        '
        Me.password_txtbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.password_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.password_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.password_txtbox.DefaultColor = System.Drawing.Color.White
        Me.password_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.password_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.password_txtbox.ForeColor = System.Drawing.Color.Black
        Me.password_txtbox.HideSelection = False
        Me.password_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.password_txtbox.LanguageKey = "LOGIN:LOGIN_PWTXTBOX"
        Me.password_txtbox.Location = New System.Drawing.Point(67, 224)
        Me.password_txtbox.MaxLength = 60
        Me.password_txtbox.Name = "password_txtbox"
        Me.password_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.password_txtbox.Size = New System.Drawing.Size(273, 23)
        Me.password_txtbox.TabIndex = 24
        Me.password_txtbox.Watermark = "Passwort"
        '
        'username_txtbox
        '
        Me.username_txtbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.username_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.username_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.username_txtbox.DefaultColor = System.Drawing.Color.White
        Me.username_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.username_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.username_txtbox.ForeColor = System.Drawing.Color.Black
        Me.username_txtbox.HideSelection = False
        Me.username_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.username_txtbox.LanguageKey = "LOGIN:LOGIN_UNAMETXTBOX"
        Me.username_txtbox.Location = New System.Drawing.Point(67, 191)
        Me.username_txtbox.MaxLength = 30
        Me.username_txtbox.Name = "username_txtbox"
        Me.username_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.username_txtbox.Size = New System.Drawing.Size(273, 23)
        Me.username_txtbox.TabIndex = 23
        Me.username_txtbox.Watermark = "Benutzername"
        '
        'MetroTranslatorLabel2
        '
        Me.MetroTranslatorLabel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroTranslatorLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel2.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.MetroTranslatorLabel2.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel2.LanguageKey = "LOGIN:LOGIN_MAIN_TEXT"
        Me.MetroTranslatorLabel2.Location = New System.Drawing.Point(2, 105)
        Me.MetroTranslatorLabel2.Name = "MetroTranslatorLabel2"
        Me.MetroTranslatorLabel2.ShowToolTip = True
        Me.MetroTranslatorLabel2.Size = New System.Drawing.Size(402, 71)
        Me.MetroTranslatorLabel2.TabIndex = 22
        Me.MetroTranslatorLabel2.Text = "Herzlich willkommen beim Xtreme-Clonk-Launcher!" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Melde dich jetzt mit deinem Acco" &
    "unt an, oder erstelle dir einen neuen Account." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.MetroTranslatorLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTranslatorLabel1
        '
        Me.MetroTranslatorLabel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroTranslatorLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel1.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel1.LanguageKey = "LOGIN:LOGIN_OR_TEXT"
        Me.MetroTranslatorLabel1.Location = New System.Drawing.Point(178, 359)
        Me.MetroTranslatorLabel1.Name = "MetroTranslatorLabel1"
        Me.MetroTranslatorLabel1.ShowToolTip = True
        Me.MetroTranslatorLabel1.Size = New System.Drawing.Size(50, 15)
        Me.MetroTranslatorLabel1.TabIndex = 21
        Me.MetroTranslatorLabel1.Text = "oder"
        Me.MetroTranslatorLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox1.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.new_logo
        Me.PictureBox1.Location = New System.Drawing.Point(50, 15)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(307, 83)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Register_TabPage
        '
        Me.Register_TabPage.BackColor = System.Drawing.Color.White
        Me.Register_TabPage.Controls.Add(Me.AbortRegistration_btn)
        Me.Register_TabPage.Controls.Add(Me.Register_btn)
        Me.Register_TabPage.Controls.Add(Me.Register_ShowPassword_chkbox)
        Me.Register_TabPage.Controls.Add(Me.Register_password_txtbox)
        Me.Register_TabPage.Controls.Add(Me.Register_username_txtbox)
        Me.Register_TabPage.Controls.Add(Me.MetroTranslatorLabel3)
        Me.Register_TabPage.Controls.Add(Me.PictureBox2)
        Me.Register_TabPage.Location = New System.Drawing.Point(14, 4)
        Me.Register_TabPage.Name = "Register_TabPage"
        Me.Register_TabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.Register_TabPage.Size = New System.Drawing.Size(406, 415)
        Me.Register_TabPage.TabIndex = 1
        Me.Register_TabPage.Text = "R"
        '
        'AbortRegistration_btn
        '
        Me.AbortRegistration_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.AbortRegistration_btn.BackColor = System.Drawing.Color.Transparent
        Me.AbortRegistration_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.AbortRegistration_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.AbortRegistration_btn.DefaultColor = System.Drawing.Color.White
        Me.AbortRegistration_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.AbortRegistration_btn.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.AbortRegistration_btn.HoverColor = System.Drawing.Color.White
        Me.AbortRegistration_btn.LanguageKey = "LOGIN:REGISTER_ABORTBTN"
        Me.AbortRegistration_btn.Location = New System.Drawing.Point(67, 329)
        Me.AbortRegistration_btn.Name = "AbortRegistration_btn"
        Me.AbortRegistration_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.AbortRegistration_btn.RoundingArc = 24
        Me.AbortRegistration_btn.Size = New System.Drawing.Size(273, 24)
        Me.AbortRegistration_btn.TabIndex = 31
        Me.AbortRegistration_btn.Text = "Abbrechen"
        '
        'Register_btn
        '
        Me.Register_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Register_btn.BackColor = System.Drawing.Color.Transparent
        Me.Register_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Register_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Register_btn.DefaultColor = System.Drawing.Color.White
        Me.Register_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Register_btn.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.Register_btn.HoverColor = System.Drawing.Color.White
        Me.Register_btn.LanguageKey = "LOGIN:REGISTER_REGISTERBTN"
        Me.Register_btn.Location = New System.Drawing.Point(67, 299)
        Me.Register_btn.Name = "Register_btn"
        Me.Register_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Register_btn.RoundingArc = 24
        Me.Register_btn.Size = New System.Drawing.Size(273, 24)
        Me.Register_btn.TabIndex = 30
        Me.Register_btn.Text = "Registrieren"
        '
        'Register_ShowPassword_chkbox
        '
        Me.Register_ShowPassword_chkbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Register_ShowPassword_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.Register_ShowPassword_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Register_ShowPassword_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Register_ShowPassword_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Register_ShowPassword_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Register_ShowPassword_chkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Register_ShowPassword_chkbox.ForeColor = System.Drawing.Color.DarkGray
        Me.Register_ShowPassword_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.Register_ShowPassword_chkbox.LanguageKey = "LOGIN:REGISTER_PWCHECKBOX"
        Me.Register_ShowPassword_chkbox.Location = New System.Drawing.Point(67, 253)
        Me.Register_ShowPassword_chkbox.Name = "Register_ShowPassword_chkbox"
        Me.Register_ShowPassword_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Register_ShowPassword_chkbox.Size = New System.Drawing.Size(121, 14)
        Me.Register_ShowPassword_chkbox.TabIndex = 29
        Me.Register_ShowPassword_chkbox.Text = "Passwort anzeigen"
        '
        'Register_password_txtbox
        '
        Me.Register_password_txtbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Register_password_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Register_password_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Register_password_txtbox.DefaultColor = System.Drawing.Color.White
        Me.Register_password_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Register_password_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Register_password_txtbox.ForeColor = System.Drawing.Color.Black
        Me.Register_password_txtbox.HideSelection = False
        Me.Register_password_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Register_password_txtbox.LanguageKey = "LOGIN:REGISTER_PWTXTBOX"
        Me.Register_password_txtbox.Location = New System.Drawing.Point(67, 224)
        Me.Register_password_txtbox.MaxLength = 60
        Me.Register_password_txtbox.Name = "Register_password_txtbox"
        Me.Register_password_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Register_password_txtbox.Size = New System.Drawing.Size(273, 23)
        Me.Register_password_txtbox.TabIndex = 28
        Me.Register_password_txtbox.Watermark = "Neues Passwort"
        '
        'Register_username_txtbox
        '
        Me.Register_username_txtbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Register_username_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Register_username_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Register_username_txtbox.DefaultColor = System.Drawing.Color.White
        Me.Register_username_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Register_username_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Register_username_txtbox.ForeColor = System.Drawing.Color.Black
        Me.Register_username_txtbox.HideSelection = False
        Me.Register_username_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Register_username_txtbox.LanguageKey = "LOGIN:REGISTER_UNAMETXTBOX"
        Me.Register_username_txtbox.Location = New System.Drawing.Point(67, 191)
        Me.Register_username_txtbox.MaxLength = 30
        Me.Register_username_txtbox.Name = "Register_username_txtbox"
        Me.Register_username_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Register_username_txtbox.Size = New System.Drawing.Size(273, 23)
        Me.Register_username_txtbox.TabIndex = 27
        Me.Register_username_txtbox.Watermark = "Neuer Benutzername"
        '
        'MetroTranslatorLabel3
        '
        Me.MetroTranslatorLabel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroTranslatorLabel3.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel3.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.MetroTranslatorLabel3.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel3.LanguageKey = "LOGIN:REGISTER_MAIN_TEXT"
        Me.MetroTranslatorLabel3.Location = New System.Drawing.Point(2, 105)
        Me.MetroTranslatorLabel3.Name = "MetroTranslatorLabel3"
        Me.MetroTranslatorLabel3.ShowToolTip = True
        Me.MetroTranslatorLabel3.Size = New System.Drawing.Size(402, 71)
        Me.MetroTranslatorLabel3.TabIndex = 26
        Me.MetroTranslatorLabel3.Text = "Erstelle dir jetzt einen neuen Account in nur wenigen Sekunden!" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.MetroTranslatorLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(50, 15)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(307, 83)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'LoggingIn_TabPage
        '
        Me.LoggingIn_TabPage.BackColor = System.Drawing.Color.White
        Me.LoggingIn_TabPage.Controls.Add(Me.BackToLogin2_btn)
        Me.LoggingIn_TabPage.Controls.Add(Me.LoggingInStatus_lbl)
        Me.LoggingIn_TabPage.Controls.Add(Me.LoggingIn_picbox)
        Me.LoggingIn_TabPage.Controls.Add(Me.PictureBox3)
        Me.LoggingIn_TabPage.Location = New System.Drawing.Point(14, 4)
        Me.LoggingIn_TabPage.Name = "LoggingIn_TabPage"
        Me.LoggingIn_TabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.LoggingIn_TabPage.Size = New System.Drawing.Size(406, 415)
        Me.LoggingIn_TabPage.TabIndex = 2
        Me.LoggingIn_TabPage.Text = "LT"
        '
        'BackToLogin2_btn
        '
        Me.BackToLogin2_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BackToLogin2_btn.BackColor = System.Drawing.Color.Transparent
        Me.BackToLogin2_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BackToLogin2_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.BackToLogin2_btn.DefaultColor = System.Drawing.Color.White
        Me.BackToLogin2_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.BackToLogin2_btn.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.BackToLogin2_btn.HoverColor = System.Drawing.Color.White
        Me.BackToLogin2_btn.LanguageKey = "LOGIN:OTHER_BACKBUTTONTEXT=Zurück"
        Me.BackToLogin2_btn.Location = New System.Drawing.Point(67, 350)
        Me.BackToLogin2_btn.Name = "BackToLogin2_btn"
        Me.BackToLogin2_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.BackToLogin2_btn.RoundingArc = 24
        Me.BackToLogin2_btn.Size = New System.Drawing.Size(273, 24)
        Me.BackToLogin2_btn.TabIndex = 27
        Me.BackToLogin2_btn.Text = "Zurück"
        Me.BackToLogin2_btn.Visible = False
        '
        'LoggingInStatus_lbl
        '
        Me.LoggingInStatus_lbl.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LoggingInStatus_lbl.BackColor = System.Drawing.Color.Transparent
        Me.LoggingInStatus_lbl.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.LoggingInStatus_lbl.ForeColor = System.Drawing.Color.DarkGray
        Me.LoggingInStatus_lbl.LanguageKey = "LOGIN:LOGINRESULT_LOGGINGIN"
        Me.LoggingInStatus_lbl.Location = New System.Drawing.Point(6, 251)
        Me.LoggingInStatus_lbl.Name = "LoggingInStatus_lbl"
        Me.LoggingInStatus_lbl.ShowToolTip = True
        Me.LoggingInStatus_lbl.Size = New System.Drawing.Size(394, 71)
        Me.LoggingInStatus_lbl.TabIndex = 26
        Me.LoggingInStatus_lbl.Text = "Du wirst eingeloggt..."
        Me.LoggingInStatus_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LoggingIn_picbox
        '
        Me.LoggingIn_picbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LoggingIn_picbox.Image = CType(resources.GetObject("LoggingIn_picbox.Image"), System.Drawing.Image)
        Me.LoggingIn_picbox.Location = New System.Drawing.Point(167, 176)
        Me.LoggingIn_picbox.Name = "LoggingIn_picbox"
        Me.LoggingIn_picbox.Size = New System.Drawing.Size(72, 72)
        Me.LoggingIn_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.LoggingIn_picbox.TabIndex = 7
        Me.LoggingIn_picbox.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(50, 15)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(307, 83)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 4
        Me.PictureBox3.TabStop = False
        '
        'Registering_TabPage
        '
        Me.Registering_TabPage.BackColor = System.Drawing.Color.White
        Me.Registering_TabPage.Controls.Add(Me.BackToLogin_btn)
        Me.Registering_TabPage.Controls.Add(Me.RegisteringStatus_lbl)
        Me.Registering_TabPage.Controls.Add(Me.Registering_picbox)
        Me.Registering_TabPage.Controls.Add(Me.PictureBox4)
        Me.Registering_TabPage.Location = New System.Drawing.Point(14, 4)
        Me.Registering_TabPage.Name = "Registering_TabPage"
        Me.Registering_TabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.Registering_TabPage.Size = New System.Drawing.Size(406, 415)
        Me.Registering_TabPage.TabIndex = 3
        Me.Registering_TabPage.Text = "R"
        '
        'BackToLogin_btn
        '
        Me.BackToLogin_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BackToLogin_btn.BackColor = System.Drawing.Color.Transparent
        Me.BackToLogin_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BackToLogin_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.BackToLogin_btn.DefaultColor = System.Drawing.Color.White
        Me.BackToLogin_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.BackToLogin_btn.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.BackToLogin_btn.HoverColor = System.Drawing.Color.White
        Me.BackToLogin_btn.LanguageKey = "LOGIN:OTHER_BACKBUTTONTEXT=Zurück"
        Me.BackToLogin_btn.Location = New System.Drawing.Point(67, 350)
        Me.BackToLogin_btn.Name = "BackToLogin_btn"
        Me.BackToLogin_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.BackToLogin_btn.RoundingArc = 24
        Me.BackToLogin_btn.Size = New System.Drawing.Size(273, 24)
        Me.BackToLogin_btn.TabIndex = 28
        Me.BackToLogin_btn.Text = "Zurück"
        Me.BackToLogin_btn.Visible = False
        '
        'RegisteringStatus_lbl
        '
        Me.RegisteringStatus_lbl.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.RegisteringStatus_lbl.BackColor = System.Drawing.Color.Transparent
        Me.RegisteringStatus_lbl.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.RegisteringStatus_lbl.ForeColor = System.Drawing.Color.DarkGray
        Me.RegisteringStatus_lbl.LanguageKey = "LOGIN:REGISTERRESULT_REGISTER"
        Me.RegisteringStatus_lbl.Location = New System.Drawing.Point(6, 251)
        Me.RegisteringStatus_lbl.Name = "RegisteringStatus_lbl"
        Me.RegisteringStatus_lbl.ShowToolTip = True
        Me.RegisteringStatus_lbl.Size = New System.Drawing.Size(394, 71)
        Me.RegisteringStatus_lbl.TabIndex = 27
        Me.RegisteringStatus_lbl.Text = "Dein Account wird gerade erstellt..."
        Me.RegisteringStatus_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Registering_picbox
        '
        Me.Registering_picbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Registering_picbox.Image = CType(resources.GetObject("Registering_picbox.Image"), System.Drawing.Image)
        Me.Registering_picbox.Location = New System.Drawing.Point(167, 176)
        Me.Registering_picbox.Name = "Registering_picbox"
        Me.Registering_picbox.Size = New System.Drawing.Size(72, 72)
        Me.Registering_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.Registering_picbox.TabIndex = 6
        Me.Registering_picbox.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(50, 15)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(307, 83)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 5
        Me.PictureBox4.TabStop = False
        '
        'ServerStatus_lbl
        '
        Me.ServerStatus_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ServerStatus_lbl.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ServerStatus_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ServerStatus_lbl.ForeColor = System.Drawing.Color.Red
        Me.ServerStatus_lbl.LanguageKey = "MAIN:CCAN_NOCONNECTIONINFO"
        Me.ServerStatus_lbl.Location = New System.Drawing.Point(0, 452)
        Me.ServerStatus_lbl.Name = "ServerStatus_lbl"
        Me.ServerStatus_lbl.ShowToolTip = True
        Me.ServerStatus_lbl.Size = New System.Drawing.Size(426, 20)
        Me.ServerStatus_lbl.TabIndex = 22
        Me.ServerStatus_lbl.Text = "Keine Verbindung zum Server"
        Me.ServerStatus_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ServerStatus_lbl.Visible = False
        '
        'Login
        '
        Me.AllowResize = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(426, 472)
        Me.Controls.Add(Me.ServerStatus_lbl)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Login"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "Xtreme-Clonk-Launcher"
        Me.controlbox_pnl.ResumeLayout(False)
        Me.MetroTabControl1.ResumeLayout(False)
        Me.Login_TabPage.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Register_TabPage.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LoggingIn_TabPage.ResumeLayout(False)
        CType(Me.LoggingIn_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Registering_TabPage.ResumeLayout(False)
        CType(Me.Registering_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Friend WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MetroTabControl1 As MetroSuite.MetroTabControl
    Friend WithEvents Login_TabPage As System.Windows.Forms.TabPage
    Friend WithEvents Register_TabPage As System.Windows.Forms.TabPage
    Friend WithEvents LoggingIn_TabPage As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Registering_TabPage As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents Registering_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents LoggingIn_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents ServerStatus_lbl As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel1 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel2 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel3 As MetroTranslatorLabel
    Friend WithEvents LoggingInStatus_lbl As MetroTranslatorLabel
    Friend WithEvents RegisteringStatus_lbl As MetroTranslatorLabel
    Friend WithEvents username_txtbox As MetroTranslatorTextbox
    Friend WithEvents password_txtbox As MetroTranslatorTextbox
    Friend WithEvents Login_ShowPassword_chkbox As MetroTranslatorChecker
    Friend WithEvents Login_btn As MetroTranslatorButton
    Friend WithEvents CreateNewAccount_btn As MetroTranslatorButton
    Friend WithEvents Register_username_txtbox As MetroTranslatorTextbox
    Friend WithEvents Register_password_txtbox As MetroTranslatorTextbox
    Friend WithEvents Register_ShowPassword_chkbox As MetroTranslatorChecker
    Friend WithEvents AbortRegistration_btn As MetroTranslatorButton
    Friend WithEvents Register_btn As MetroTranslatorButton
    Friend WithEvents BackToLogin_btn As MetroTranslatorButton
    Friend WithEvents BackToLogin2_btn As MetroTranslatorButton
    Friend WithEvents WithoutLogin_btn As MetroTranslatorButton
End Class
