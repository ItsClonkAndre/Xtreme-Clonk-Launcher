﻿Option Strict On
Imports MetroSuite
Imports MetroSuite.Extension
Imports MadMilkman.Ini
Imports Microsoft.Win32

Public Class Uninstall_frm : Inherits MetroForm

#Region "ControlBox"

    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        If Not InProgress = True Then
            Main.CheckIfGamesExists() ' Refresh
            Me.Dispose()
        End If
    End Sub
    Private Sub controlbox_nmaximize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_nmaximize_lbl.Click
        If controlbox_nmaximize_lbl.Text = "□" Then
            controlbox_nmaximize_lbl.Text = "■"
            Me.WindowState = FormWindowState.Normal
        Else
            controlbox_nmaximize_lbl.Text = "□"
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub
    Private Sub controlbox_minimize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_minimize_lbl.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter, controlbox_nmaximize_lbl.MouseEnter, controlbox_minimize_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave, controlbox_nmaximize_lbl.MouseLeave, controlbox_minimize_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

#End Region

#Region "Functions"

    Public Sub ApplyTheme()
        Try
            Dim myTheme As New Styles.Themes.MetroSuiteTheme
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            If IO.File.Exists(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme")) Then ' If file exists
                myTheme = myTheme.FromFile(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme"))
            Else ' If not
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

#End Region

    Private RegistryKey As RegistryKey
    Private InProgress As Boolean
    Private GameName As String

    Public Sub New(ByVal _GameName As String)
        InitializeComponent()
        GameName = _GameName
    End Sub
    Private Sub Uninstall_frm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ApplyTheme() ' Set Theme

        ' Setup TabControl
        With MetroTabControl1
            .SuspendLayout()
            .SizeMode = TabSizeMode.Fixed
            .ItemSize = New Size(1, 1)
            .Appearance = CType(TabAppearance.Buttons, Appearance)
            .ResumeLayout()
        End With

        ' Set Text
        gamename_lbl.Text = GameName & " deinstallieren"
        UninstallGamename_lbl.Text = GameName & " wird deinstalliert..."
        UninstallationFinished_lbl.Text = GameName & " wurde deinstalliert!"

        ' Set Options
        Select Case GameName
            Case "OpenClonk"
                DeleteCEKey_chkbox.Enabled = False
                DeleteCEKey_chkbox.Checked = False
                DeleteKeysInRegEdit_chkbox.Enabled = True
                DeleteFolderninAppData_chkbox.Enabled = True
            Case "OpenClonk_x86"
                DeleteCEKey_chkbox.Enabled = False
                DeleteCEKey_chkbox.Checked = False
                DeleteKeysInRegEdit_chkbox.Enabled = True
                DeleteFolderninAppData_chkbox.Enabled = True
            Case "LegacyClonk"
                DeleteCEKey_chkbox.Enabled = False
                DeleteCEKey_chkbox.Checked = False
                DeleteKeysInRegEdit_chkbox.Enabled = True
                DeleteFolderninAppData_chkbox.Enabled = True
            Case "ClonkEndeavour"
                DeleteCEKey_chkbox.Enabled = True
                DeleteFolderninAppData_chkbox.Enabled = False
                DeleteFolderninAppData_chkbox.Checked = False
                DeleteKeysInRegEdit_chkbox.Enabled = True
            Case "ClonkPlanet"
                DeleteCEKey_chkbox.Enabled = False
                DeleteCEKey_chkbox.Checked = False
                DeleteKeysInRegEdit_chkbox.Enabled = False
                DeleteKeysInRegEdit_chkbox.Checked = False
                DeleteFolderninAppData_chkbox.Enabled = False
                DeleteFolderninAppData_chkbox.Checked = False
            Case "Clonk4"
                DeleteCEKey_chkbox.Enabled = False
                DeleteCEKey_chkbox.Checked = False
                DeleteKeysInRegEdit_chkbox.Enabled = True
                DeleteFolderninAppData_chkbox.Enabled = False
                DeleteFolderninAppData_chkbox.Checked = False
        End Select

    End Sub

    Private Sub Abort_btn_Click(sender As Object, e As EventArgs) Handles Abort_btn.Click
        Me.Dispose()
    End Sub
    Private Sub Exit_btn_Click(sender As Object, e As EventArgs) Handles Exit_btn.Click
        Main.CheckIfGamesExists() ' Refresh
        Me.Dispose()
    End Sub

    Private Sub Uninstall_btn_Click(sender As Object, e As EventArgs) Handles Uninstall_btn.Click
        ' Change TabPage
        MetroTabControl1.SelectedTab = progress_tp

        ' Info
        InProgress = True
        status_lb.Items.Add("Starting...")

        ' Uninstall Game
        Try
            If DeleteFiles_chkbox.Checked = True Then
                status_lb.Items.Add("Deleting files...")

                Select Case GameName
                    Case "OpenClonk"
                        If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk")) Then
                            System.IO.Directory.Delete(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk"), True)
                        Else
                            status_lb.Items.Add("Cannot delete files because the folder does not exists")
                        End If
                    Case "OpenClonk_x86"
                        If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86")) Then
                            System.IO.Directory.Delete(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86"), True)
                        Else
                            status_lb.Items.Add("Cannot delete files because the folder does not exists")
                        End If
                    Case "LegacyClonk"
                        If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk")) Then
                            System.IO.Directory.Delete(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk"), True)
                        Else
                            status_lb.Items.Add("Cannot delete files because the folder does not exists")
                        End If
                    Case "ClonkEndeavour"
                        If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour")) Then
                            System.IO.Directory.Delete(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour"), True)
                        Else
                            status_lb.Items.Add("Cannot delete files because the folder does not exists")
                        End If
                    Case "ClonkPlanet"
                        If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet")) Then
                            System.IO.Directory.Delete(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet"), True)
                        Else
                            status_lb.Items.Add("Cannot delete files because the folder does not exists")
                        End If
                    Case "Clonk4"
                        If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4")) Then
                            System.IO.Directory.Delete(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4"), True)
                        Else
                            status_lb.Items.Add("Cannot delete files because the folder does not exists")
                        End If
                End Select

                status_lb.Items.Add("Deleting files complete!")
            End If
        Catch ex As Exception
            status_lb.Items.Add("Error while deleting files... Details: " & ex.Message)
        End Try

        ' Delete AppData Folder
        Try
            If DeleteFolderninAppData_chkbox.Checked = True Then
                status_lb.Items.Add("Deleting folders in AppData...")
                Select Case GameName
                    Case "OpenClonk"
                        If System.IO.Directory.Exists((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\OpenClonk")) Then
                            System.IO.Directory.Delete((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\OpenClonk"), True)
                        Else
                            status_lb.Items.Add("Cannot delete folder because the folder does not exists")
                        End If
                    Case "OpenClonk_x86"
                        If System.IO.Directory.Exists((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\OpenClonk")) Then
                            System.IO.Directory.Delete((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\OpenClonk"), True)
                        Else
                            status_lb.Items.Add("Cannot delete folder because the folder does not exists")
                        End If
                    Case "ClonkRage"
                        If System.IO.Directory.Exists((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\LegacyClonk")) Then
                            System.IO.Directory.Delete((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\LegacyClonk"), True)
                        Else
                            status_lb.Items.Add("Cannot delete folder because the folder does not exists")
                        End If
                        If System.IO.Directory.Exists((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\Clonk Rage")) Then
                            System.IO.Directory.Delete((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\Clonk Rage"), True)
                        Else
                            status_lb.Items.Add("Cannot delete folder because the folder does not exists")
                        End If
                    Case "ClonkEndeavour"
                        ' Nothing
                    Case "ClonkPlanet"
                        ' Nothing
                    Case "Clonk4"
                        ' Nothing
                End Select
                status_lb.Items.Add("Deleting folders in AppData complete!")
            End If

            If DeleteCEKey_chkbox.Checked = True Then
                status_lb.Items.Add("Deleting Clonk Endeavour Key in AppData...")
                If System.IO.Directory.Exists((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\Clonk")) Then
                    System.IO.Directory.Delete((Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\Clonk"), True)
                Else
                    status_lb.Items.Add("Cannot delete key because the folder does not exists")
                End If
                status_lb.Items.Add("Deleting Clonk Endeavour Key in AppData complete!")
            End If

        Catch ex As Exception
            status_lb.Items.Add("Error while deleting folder in AppData... Details: " & ex.Message)
        End Try

        ' Delete AppData Keys
        Try
            If DeleteKeysInRegEdit_chkbox.Checked = True Then
                status_lb.Items.Add("Deleting Keys in Registry...")
                Select Case GameName
                    Case "OpenClonk"
                        Try
                            status_lb.Items.Add("Deleting Key : HKEY_LOCAL_MACHINE\SOFTWARE\OpenClonk Project")
                            RegistryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\", True)
                            RegistryKey.DeleteSubKeyTree("OpenClonk Project")
                            RegistryKey.Close()
                        Catch ex As Exception
                            status_lb.Items.Add("Deleting Key in Registry failed... Details: " & ex.Message)
                        End Try
                        Try
                            status_lb.Items.Add("Deleting Key : HKEY_CURRENT_USER\Software\OpenClonk Project")
                            RegistryKey = Registry.CurrentUser.OpenSubKey("Software\", True)
                            RegistryKey.DeleteSubKeyTree("OpenClonk Project")
                            RegistryKey.Close()
                        Catch ex As Exception
                            status_lb.Items.Add("Deleting Key in Registry failed... Details: " & ex.Message)
                        End Try
                    Case "OpenClonk_x86"
                        Try
                            status_lb.Items.Add("Deleting Key : HKEY_LOCAL_MACHINE\SOFTWARE\OpenClonk Project")
                            RegistryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\", True)
                            RegistryKey.DeleteSubKeyTree("OpenClonk Project")
                            RegistryKey.Close()
                        Catch ex As Exception
                            status_lb.Items.Add("Deleting Key in Registry failed... Details: " & ex.Message)
                        End Try
                        Try
                            status_lb.Items.Add("Deleting Key : HKEY_CURRENT_USER\Software\OpenClonk Project")
                            RegistryKey = Registry.CurrentUser.OpenSubKey("Software\", True)
                            RegistryKey.DeleteSubKeyTree("OpenClonk Project")
                            RegistryKey.Close()
                        Catch ex As Exception
                            status_lb.Items.Add("Deleting Key in Registry failed... Details: " & ex.Message)
                        End Try
                    Case "ClonkRage"
                        Try
                            status_lb.Items.Add("Deleting Key : HKEY_CURRENT_USER\Software\RedWolf Design\Clonk Rage")
                            RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\", True)
                            RegistryKey.DeleteSubKeyTree("Clonk Rage")
                            RegistryKey.Close()
                        Catch ex As Exception
                            status_lb.Items.Add("Deleting Key in Registry failed... Details: " & ex.Message)
                        End Try
                        Try
                            status_lb.Items.Add("Deleting Key : HKEY_CURRENT_USER\Software\LegacyClonk Team")
                            RegistryKey = Registry.CurrentUser.OpenSubKey("Software\", True)
                            RegistryKey.DeleteSubKeyTree("LegacyClonk Team")
                            RegistryKey.Close()
                        Catch ex As Exception
                            status_lb.Items.Add("Deleting Key in Registry failed... Details: " & ex.Message)
                        End Try
                    Case "ClonkEndeavour"
                        Try
                            status_lb.Items.Add("Deleting Key : HKEY_CURRENT_USER\Software\RedWolf Design\Clonk Endeavour")
                            RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\", True)
                            RegistryKey.DeleteSubKeyTree("Clonk Endeavour")
                            RegistryKey.Close()
                        Catch ex As Exception
                            status_lb.Items.Add("Deleting Key in Registry failed... Details: " & ex.Message)
                        End Try
                    Case "ClonkPlanet"
                        ' Nothing
                    Case "Clonk4"
                        Try
                            status_lb.Items.Add("Deleting Key : HKEY_CURRENT_USER\Software\RedWolf Design\Clonk 4")
                            RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\", True)
                            RegistryKey.DeleteSubKeyTree("Clonk 4")
                            RegistryKey.Close()
                        Catch ex As Exception
                            status_lb.Items.Add("Deleting Key in Registry failed... Details: " & ex.Message)
                        End Try
                End Select
                status_lb.Items.Add("Deleting Keys in Registry complete!")
            End If
        Catch ex As Exception
            status_lb.Items.Add("Error while deleting Keys in Registry... Details: " & ex.Message)
        End Try

        ' Complete
        status_lb.Items.Add("Process completed!")
        MetroTabControl1.SelectedTab = finished_tp
        InProgress = False
    End Sub

End Class