﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Settings
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Settings))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.settings_tbc = New MetroSuite.MetroTabControl()
        Me.Account_tb = New System.Windows.Forms.TabPage()
        Me.NotLoggedInInfo_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ShowPassword_chkbox = New Xtreme_Clonk_Launcher.MetroTranslatorChecker()
        Me.Password_txtbox = New Xtreme_Clonk_Launcher.MetroTranslatorTextbox()
        Me.username_txtbox = New Xtreme_Clonk_Launcher.MetroTranslatorTextbox()
        Me.MetroTranslatorLabel3 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel2 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel1 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.AcceptChanges_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel17 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel16 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel15 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.AllowPlayTimeData_mchbox = New Xtreme_Clonk_Launcher.MetroTranslatorChecker()
        Me.MetroTranslatorLabel14 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.AllowRushHourData_mchbox = New Xtreme_Clonk_Launcher.MetroTranslatorChecker()
        Me.MetroTranslatorLabel13 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel12 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel11 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel10 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel9 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel8 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel7 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel6 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel5 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel4 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ExitMode_mcmdbox = New MetroSuite.MetroComboBox()
        Me.StartTabPage_mcmdbox = New MetroSuite.MetroComboBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Theme_mcmdbox = New MetroSuite.MetroComboBox()
        Me.Language_mcmdbox = New MetroSuite.MetroComboBox()
        Me.CID_lbl = New MetroSuite.MetroLabel()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel21 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ShowChatClonkMessage_mchkbox = New Xtreme_Clonk_Launcher.MetroTranslatorChecker()
        Me.ShowChatMsg_mchkbox = New Xtreme_Clonk_Launcher.MetroTranslatorChecker()
        Me.ShowNewUpdateMsg_mchkbox = New Xtreme_Clonk_Launcher.MetroTranslatorChecker()
        Me.MetroTranslatorLabel20 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel19 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel18 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel22 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.CCANcopyInAnyDir_rbtn = New Xtreme_Clonk_Launcher.ClassicTranslatorRadioButton()
        Me.CCANcopyInGameDir_rbtn = New Xtreme_Clonk_Launcher.ClassicTranslatorRadioButton()
        Me.MetroLabel9 = New MetroSuite.MetroLabel()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.MetroTabControl1 = New MetroSuite.MetroTabControl()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel24 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.CheckForUpdates_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.MetroTranslatorLabel23 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.MetroLabel17 = New MetroSuite.MetroLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.MetroLabel1 = New MetroSuite.MetroLabel()
        Me.controlbox_pnl.SuspendLayout()
        Me.settings_tbc.SuspendLayout()
        Me.Account_tb.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.MetroTabControl1.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(726, 3)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 1
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Enabled = False
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'settings_tbc
        '
        Me.settings_tbc.Alignment = System.Windows.Forms.TabAlignment.Top
        Me.settings_tbc.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.settings_tbc.Appearance = System.Windows.Forms.Appearance.Normal
        Me.settings_tbc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.settings_tbc.BorderColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.settings_tbc.Controls.Add(Me.Account_tb)
        Me.settings_tbc.Controls.Add(Me.TabPage1)
        Me.settings_tbc.Controls.Add(Me.TabPage2)
        Me.settings_tbc.Controls.Add(Me.TabPage3)
        Me.settings_tbc.Controls.Add(Me.TabPage4)
        Me.settings_tbc.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.settings_tbc.ForeColor = System.Drawing.Color.Black
        Me.settings_tbc.HasAnimation = False
        Me.settings_tbc.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(106, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.settings_tbc.HeaderItemColor = System.Drawing.Color.White
        Me.settings_tbc.HotTrack = True
        Me.settings_tbc.HoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.settings_tbc.HoverColor = System.Drawing.Color.White
        Me.settings_tbc.ItemColor = System.Drawing.Color.White
        Me.settings_tbc.ItemForeColor = System.Drawing.Color.Black
        Me.settings_tbc.ItemSize = New System.Drawing.Size(123, 45)
        Me.settings_tbc.Location = New System.Drawing.Point(12, 35)
        Me.settings_tbc.Multiline = True
        Me.settings_tbc.Name = "settings_tbc"
        Me.settings_tbc.SelectedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.settings_tbc.SelectedForeColor = System.Drawing.Color.White
        Me.settings_tbc.SelectedIndex = 0
        Me.settings_tbc.SelectedItemColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.settings_tbc.SelectedItemLineColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.settings_tbc.Size = New System.Drawing.Size(762, 447)
        Me.settings_tbc.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.settings_tbc.TabContainerColor = System.Drawing.Color.White
        Me.settings_tbc.TabIndex = 2
        '
        'Account_tb
        '
        Me.Account_tb.BackColor = System.Drawing.Color.White
        Me.Account_tb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Account_tb.Controls.Add(Me.NotLoggedInInfo_lbl)
        Me.Account_tb.Controls.Add(Me.ShowPassword_chkbox)
        Me.Account_tb.Controls.Add(Me.Password_txtbox)
        Me.Account_tb.Controls.Add(Me.username_txtbox)
        Me.Account_tb.Controls.Add(Me.MetroTranslatorLabel3)
        Me.Account_tb.Controls.Add(Me.MetroTranslatorLabel2)
        Me.Account_tb.Controls.Add(Me.MetroTranslatorLabel1)
        Me.Account_tb.Controls.Add(Me.AcceptChanges_btn)
        Me.Account_tb.ForeColor = System.Drawing.Color.White
        Me.Account_tb.Location = New System.Drawing.Point(4, 49)
        Me.Account_tb.Name = "Account_tb"
        Me.Account_tb.Padding = New System.Windows.Forms.Padding(3)
        Me.Account_tb.Size = New System.Drawing.Size(754, 394)
        Me.Account_tb.TabIndex = 0
        Me.Account_tb.Text = "Account"
        '
        'NotLoggedInInfo_lbl
        '
        Me.NotLoggedInInfo_lbl.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.NotLoggedInInfo_lbl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.NotLoggedInInfo_lbl.Font = New System.Drawing.Font("Segoe UI", 11.75!)
        Me.NotLoggedInInfo_lbl.ForeColor = System.Drawing.Color.Red
        Me.NotLoggedInInfo_lbl.LanguageKey = "SETTINGS:ACCOUNT_NOTLOGGEDININFOTEXT"
        Me.NotLoggedInInfo_lbl.Location = New System.Drawing.Point(3, 3)
        Me.NotLoggedInInfo_lbl.Name = "NotLoggedInInfo_lbl"
        Me.NotLoggedInInfo_lbl.ShowToolTip = False
        Me.NotLoggedInInfo_lbl.Size = New System.Drawing.Size(746, 386)
        Me.NotLoggedInInfo_lbl.TabIndex = 21
        Me.NotLoggedInInfo_lbl.Text = "Bitte melde dich an oder erstelle einen Account um Einstellungen an deinem Accoun" &
    "t vorzunehmen."
        Me.NotLoggedInInfo_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.NotLoggedInInfo_lbl.Visible = False
        '
        'ShowPassword_chkbox
        '
        Me.ShowPassword_chkbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ShowPassword_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ShowPassword_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ShowPassword_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ShowPassword_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ShowPassword_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ShowPassword_chkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ShowPassword_chkbox.ForeColor = System.Drawing.Color.Gainsboro
        Me.ShowPassword_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ShowPassword_chkbox.LanguageKey = "LOGIN:LOGIN_PWCHECKBOX"
        Me.ShowPassword_chkbox.Location = New System.Drawing.Point(230, 269)
        Me.ShowPassword_chkbox.Name = "ShowPassword_chkbox"
        Me.ShowPassword_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ShowPassword_chkbox.Size = New System.Drawing.Size(121, 14)
        Me.ShowPassword_chkbox.TabIndex = 26
        Me.ShowPassword_chkbox.Text = "Passwort anzeigen"
        '
        'Password_txtbox
        '
        Me.Password_txtbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Password_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Password_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Password_txtbox.DefaultColor = System.Drawing.Color.White
        Me.Password_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Password_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Password_txtbox.ForeColor = System.Drawing.Color.Black
        Me.Password_txtbox.HideSelection = False
        Me.Password_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Password_txtbox.LanguageKey = "SETTINGS:ACCOUNT_PWTXTBOX"
        Me.Password_txtbox.Location = New System.Drawing.Point(230, 240)
        Me.Password_txtbox.Name = "Password_txtbox"
        Me.Password_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Password_txtbox.Size = New System.Drawing.Size(296, 23)
        Me.Password_txtbox.TabIndex = 25
        Me.Password_txtbox.Watermark = "Passwort"
        '
        'username_txtbox
        '
        Me.username_txtbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.username_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.username_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.username_txtbox.DefaultColor = System.Drawing.Color.White
        Me.username_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.username_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.username_txtbox.ForeColor = System.Drawing.Color.Black
        Me.username_txtbox.HideSelection = False
        Me.username_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.username_txtbox.LanguageKey = "SETTINGS:ACCOUNT_UNAMETXTBOX"
        Me.username_txtbox.Location = New System.Drawing.Point(230, 185)
        Me.username_txtbox.Name = "username_txtbox"
        Me.username_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.username_txtbox.Size = New System.Drawing.Size(296, 23)
        Me.username_txtbox.TabIndex = 24
        Me.username_txtbox.Watermark = "Benutzername"
        '
        'MetroTranslatorLabel3
        '
        Me.MetroTranslatorLabel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroTranslatorLabel3.AutoSize = True
        Me.MetroTranslatorLabel3.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel3.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.MetroTranslatorLabel3.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel3.LanguageKey = "SETTINGS:ACCOUNT_PWTXTBOX"
        Me.MetroTranslatorLabel3.Location = New System.Drawing.Point(226, 216)
        Me.MetroTranslatorLabel3.Name = "MetroTranslatorLabel3"
        Me.MetroTranslatorLabel3.ShowToolTip = True
        Me.MetroTranslatorLabel3.Size = New System.Drawing.Size(72, 21)
        Me.MetroTranslatorLabel3.TabIndex = 23
        Me.MetroTranslatorLabel3.Text = "Passwort"
        '
        'MetroTranslatorLabel2
        '
        Me.MetroTranslatorLabel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroTranslatorLabel2.AutoSize = True
        Me.MetroTranslatorLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel2.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.MetroTranslatorLabel2.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel2.LanguageKey = "SETTINGS:ACCOUNT_UNAMETXTBOX"
        Me.MetroTranslatorLabel2.Location = New System.Drawing.Point(226, 161)
        Me.MetroTranslatorLabel2.Name = "MetroTranslatorLabel2"
        Me.MetroTranslatorLabel2.ShowToolTip = True
        Me.MetroTranslatorLabel2.Size = New System.Drawing.Size(110, 21)
        Me.MetroTranslatorLabel2.TabIndex = 22
        Me.MetroTranslatorLabel2.Text = "Benutzername"
        '
        'MetroTranslatorLabel1
        '
        Me.MetroTranslatorLabel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroTranslatorLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel1.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel1.LanguageKey = "SETTINGS:ACCOUNT_MAINTEXT"
        Me.MetroTranslatorLabel1.Location = New System.Drawing.Point(121, 74)
        Me.MetroTranslatorLabel1.Name = "MetroTranslatorLabel1"
        Me.MetroTranslatorLabel1.ShowToolTip = True
        Me.MetroTranslatorLabel1.Size = New System.Drawing.Size(510, 68)
        Me.MetroTranslatorLabel1.TabIndex = 20
        Me.MetroTranslatorLabel1.Text = resources.GetString("MetroTranslatorLabel1.Text")
        Me.MetroTranslatorLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'AcceptChanges_btn
        '
        Me.AcceptChanges_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AcceptChanges_btn.BackColor = System.Drawing.Color.Transparent
        Me.AcceptChanges_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.AcceptChanges_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.AcceptChanges_btn.DefaultColor = System.Drawing.Color.White
        Me.AcceptChanges_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.AcceptChanges_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.AcceptChanges_btn.ForeColor = System.Drawing.Color.Black
        Me.AcceptChanges_btn.HoverColor = System.Drawing.Color.White
        Me.AcceptChanges_btn.LanguageKey = "SETTINGS:ACCOUNT_ACCEPTCHANGESBTN"
        Me.AcceptChanges_btn.Location = New System.Drawing.Point(578, 363)
        Me.AcceptChanges_btn.Name = "AcceptChanges_btn"
        Me.AcceptChanges_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.AcceptChanges_btn.RoundingArc = 23
        Me.AcceptChanges_btn.Size = New System.Drawing.Size(168, 23)
        Me.AcceptChanges_btn.TabIndex = 27
        Me.AcceptChanges_btn.Text = "Einstellungen übernehmen"
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel17)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel16)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel15)
        Me.TabPage1.Controls.Add(Me.AllowPlayTimeData_mchbox)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel14)
        Me.TabPage1.Controls.Add(Me.AllowRushHourData_mchbox)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel13)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel12)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel11)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel10)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel9)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel8)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel7)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel6)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel5)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel4)
        Me.TabPage1.Controls.Add(Me.ExitMode_mcmdbox)
        Me.TabPage1.Controls.Add(Me.StartTabPage_mcmdbox)
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Controls.Add(Me.Theme_mcmdbox)
        Me.TabPage1.Controls.Add(Me.Language_mcmdbox)
        Me.TabPage1.Controls.Add(Me.CID_lbl)
        Me.TabPage1.Location = New System.Drawing.Point(4, 49)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(754, 394)
        Me.TabPage1.TabIndex = 2
        Me.TabPage1.Text = "Optionen"
        '
        'MetroTranslatorLabel17
        '
        Me.MetroTranslatorLabel17.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel17.AutoSize = True
        Me.MetroTranslatorLabel17.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel17.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel17.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel17.LanguageKey = "SETTINGS:OTHER_AUTOSAVESETTINGSTEXT"
        Me.MetroTranslatorLabel17.Location = New System.Drawing.Point(172, 476)
        Me.MetroTranslatorLabel17.Name = "MetroTranslatorLabel17"
        Me.MetroTranslatorLabel17.ShowToolTip = True
        Me.MetroTranslatorLabel17.Size = New System.Drawing.Size(282, 15)
        Me.MetroTranslatorLabel17.TabIndex = 58
        Me.MetroTranslatorLabel17.Text = "Einstellungen speichern beim verlassen automatisch"
        '
        'MetroTranslatorLabel16
        '
        Me.MetroTranslatorLabel16.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel16.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel16.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel16.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel16.LanguageKey = "SETTINGS:OPTIONS_USERIDINFOTEXT"
        Me.MetroTranslatorLabel16.Location = New System.Drawing.Point(78, 367)
        Me.MetroTranslatorLabel16.Name = "MetroTranslatorLabel16"
        Me.MetroTranslatorLabel16.ShowToolTip = True
        Me.MetroTranslatorLabel16.Size = New System.Drawing.Size(470, 90)
        Me.MetroTranslatorLabel16.TabIndex = 57
        Me.MetroTranslatorLabel16.Text = resources.GetString("MetroTranslatorLabel16.Text")
        Me.MetroTranslatorLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTranslatorLabel15
        '
        Me.MetroTranslatorLabel15.AutoSize = True
        Me.MetroTranslatorLabel15.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel15.Font = New System.Drawing.Font("Segoe UI", 7.0!)
        Me.MetroTranslatorLabel15.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel15.LanguageKey = "SETTINGS:OPTIONS_SENDGAMETIMEDATAINFOTEXT"
        Me.MetroTranslatorLabel15.Location = New System.Drawing.Point(41, 278)
        Me.MetroTranslatorLabel15.Name = "MetroTranslatorLabel15"
        Me.MetroTranslatorLabel15.ShowToolTip = True
        Me.MetroTranslatorLabel15.Size = New System.Drawing.Size(410, 12)
        Me.MetroTranslatorLabel15.TabIndex = 56
        Me.MetroTranslatorLabel15.Text = "(Für dein Profil, damit andere Spieler sehen können wie lange du welches Spiel ge" &
    "spielt hast.)"
        '
        'AllowPlayTimeData_mchbox
        '
        Me.AllowPlayTimeData_mchbox.BackColor = System.Drawing.Color.Transparent
        Me.AllowPlayTimeData_mchbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.AllowPlayTimeData_mchbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.AllowPlayTimeData_mchbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.AllowPlayTimeData_mchbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.AllowPlayTimeData_mchbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.AllowPlayTimeData_mchbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.AllowPlayTimeData_mchbox.LanguageKey = "SETTINGS:OPTIONS_SENDGAMETIMEDATATEXT"
        Me.AllowPlayTimeData_mchbox.Location = New System.Drawing.Point(30, 261)
        Me.AllowPlayTimeData_mchbox.Name = "AllowPlayTimeData_mchbox"
        Me.AllowPlayTimeData_mchbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.AllowPlayTimeData_mchbox.Size = New System.Drawing.Size(340, 14)
        Me.AllowPlayTimeData_mchbox.TabIndex = 55
        Me.AllowPlayTimeData_mchbox.Text = "Dem Launcher es erlauben, Spielzeit-Daten zu übermitteln."
        '
        'MetroTranslatorLabel14
        '
        Me.MetroTranslatorLabel14.AutoSize = True
        Me.MetroTranslatorLabel14.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel14.Font = New System.Drawing.Font("Segoe UI", 7.0!)
        Me.MetroTranslatorLabel14.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel14.LanguageKey = "SETTINGS:OPTIONS_SENDRUSHHOURDATAINFOTEXT"
        Me.MetroTranslatorLabel14.Location = New System.Drawing.Point(41, 242)
        Me.MetroTranslatorLabel14.Name = "MetroTranslatorLabel14"
        Me.MetroTranslatorLabel14.ShowToolTip = True
        Me.MetroTranslatorLabel14.Size = New System.Drawing.Size(367, 12)
        Me.MetroTranslatorLabel14.TabIndex = 54
        Me.MetroTranslatorLabel14.Text = "(Für andere Spieler, um zusehen um welcher Uhrzeit die meisten Spieler aktiv sind" &
    ".)"
        '
        'AllowRushHourData_mchbox
        '
        Me.AllowRushHourData_mchbox.BackColor = System.Drawing.Color.Transparent
        Me.AllowRushHourData_mchbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.AllowRushHourData_mchbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.AllowRushHourData_mchbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.AllowRushHourData_mchbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.AllowRushHourData_mchbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.AllowRushHourData_mchbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.AllowRushHourData_mchbox.LanguageKey = "SETTINGS:OPTIONS_SENDRUSHHOURDATATEXT"
        Me.AllowRushHourData_mchbox.Location = New System.Drawing.Point(30, 227)
        Me.AllowRushHourData_mchbox.Name = "AllowRushHourData_mchbox"
        Me.AllowRushHourData_mchbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.AllowRushHourData_mchbox.Size = New System.Drawing.Size(338, 14)
        Me.AllowRushHourData_mchbox.TabIndex = 53
        Me.AllowRushHourData_mchbox.Text = "Dem Launcher es erlauben, Stoßzeit-Daten zu übermitteln."
        '
        'MetroTranslatorLabel13
        '
        Me.MetroTranslatorLabel13.AutoSize = True
        Me.MetroTranslatorLabel13.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel13.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel13.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroTranslatorLabel13.LanguageKey = "SETTINGS:OPTIONS_PRIVACYTEXT"
        Me.MetroTranslatorLabel13.Location = New System.Drawing.Point(39, 198)
        Me.MetroTranslatorLabel13.Name = "MetroTranslatorLabel13"
        Me.MetroTranslatorLabel13.ShowToolTip = True
        Me.MetroTranslatorLabel13.Size = New System.Drawing.Size(99, 21)
        Me.MetroTranslatorLabel13.TabIndex = 52
        Me.MetroTranslatorLabel13.Text = "Datenschutz"
        '
        'MetroTranslatorLabel12
        '
        Me.MetroTranslatorLabel12.AutoSize = True
        Me.MetroTranslatorLabel12.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel12.Font = New System.Drawing.Font("Segoe UI", 7.0!)
        Me.MetroTranslatorLabel12.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel12.LanguageKey = "SETTINGS:OPTIONS_EXITMODEINFOTEXT"
        Me.MetroTranslatorLabel12.Location = New System.Drawing.Point(39, 126)
        Me.MetroTranslatorLabel12.Name = "MetroTranslatorLabel12"
        Me.MetroTranslatorLabel12.ShowToolTip = True
        Me.MetroTranslatorLabel12.Size = New System.Drawing.Size(325, 12)
        Me.MetroTranslatorLabel12.TabIndex = 51
        Me.MetroTranslatorLabel12.Text = "(Entscheidet was passiert wenn auf der Hauptform das ""X"" gedrückt wird)"
        '
        'MetroTranslatorLabel11
        '
        Me.MetroTranslatorLabel11.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel11.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroTranslatorLabel11.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel11.LanguageKey = "SETTINGS:OPTIONS_EXITMODETEXT"
        Me.MetroTranslatorLabel11.Location = New System.Drawing.Point(6, 101)
        Me.MetroTranslatorLabel11.Name = "MetroTranslatorLabel11"
        Me.MetroTranslatorLabel11.ShowToolTip = True
        Me.MetroTranslatorLabel11.Size = New System.Drawing.Size(84, 19)
        Me.MetroTranslatorLabel11.TabIndex = 50
        Me.MetroTranslatorLabel11.Text = "ExitMode:"
        Me.MetroTranslatorLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'MetroTranslatorLabel10
        '
        Me.MetroTranslatorLabel10.AutoSize = True
        Me.MetroTranslatorLabel10.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel10.Font = New System.Drawing.Font("Segoe UI", 7.0!)
        Me.MetroTranslatorLabel10.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel10.LanguageKey = "SETTINGS:OPTIONS_STARTTABPAGEINFOTEXT"
        Me.MetroTranslatorLabel10.Location = New System.Drawing.Point(39, 169)
        Me.MetroTranslatorLabel10.Name = "MetroTranslatorLabel10"
        Me.MetroTranslatorLabel10.ShowToolTip = True
        Me.MetroTranslatorLabel10.Size = New System.Drawing.Size(260, 12)
        Me.MetroTranslatorLabel10.TabIndex = 49
        Me.MetroTranslatorLabel10.Text = "(Die TabPage die beim Start des Launcher's ausgewählt ist)"
        '
        'MetroTranslatorLabel9
        '
        Me.MetroTranslatorLabel9.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel9.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroTranslatorLabel9.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel9.LanguageKey = "SETTINGS:OPTIONS_STARTTABPAGETEXT"
        Me.MetroTranslatorLabel9.Location = New System.Drawing.Point(6, 144)
        Me.MetroTranslatorLabel9.Name = "MetroTranslatorLabel9"
        Me.MetroTranslatorLabel9.ShowToolTip = True
        Me.MetroTranslatorLabel9.Size = New System.Drawing.Size(119, 19)
        Me.MetroTranslatorLabel9.TabIndex = 48
        Me.MetroTranslatorLabel9.Text = "Start TabPage:"
        Me.MetroTranslatorLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'MetroTranslatorLabel8
        '
        Me.MetroTranslatorLabel8.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel8.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroTranslatorLabel8.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel8.LanguageKey = "SETTINGS:OPTIONS_THEMETEXT"
        Me.MetroTranslatorLabel8.Location = New System.Drawing.Point(6, 71)
        Me.MetroTranslatorLabel8.Name = "MetroTranslatorLabel8"
        Me.MetroTranslatorLabel8.ShowToolTip = True
        Me.MetroTranslatorLabel8.Size = New System.Drawing.Size(84, 19)
        Me.MetroTranslatorLabel8.TabIndex = 47
        Me.MetroTranslatorLabel8.Text = "Theme:"
        Me.MetroTranslatorLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'MetroTranslatorLabel7
        '
        Me.MetroTranslatorLabel7.AutoSize = True
        Me.MetroTranslatorLabel7.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel7.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.MetroTranslatorLabel7.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel7.LanguageKey = "SETTINGS:OTHER_NEEDSRESTARTTXT"
        Me.MetroTranslatorLabel7.Location = New System.Drawing.Point(320, 75)
        Me.MetroTranslatorLabel7.Name = "MetroTranslatorLabel7"
        Me.MetroTranslatorLabel7.ShowToolTip = True
        Me.MetroTranslatorLabel7.Size = New System.Drawing.Size(104, 13)
        Me.MetroTranslatorLabel7.TabIndex = 46
        Me.MetroTranslatorLabel7.Text = "(Benötigt Neustart)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'MetroTranslatorLabel6
        '
        Me.MetroTranslatorLabel6.AutoSize = True
        Me.MetroTranslatorLabel6.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel6.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.MetroTranslatorLabel6.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel6.LanguageKey = "SETTINGS:OTHER_RECOMMENDRESTARTTXT"
        Me.MetroTranslatorLabel6.Location = New System.Drawing.Point(320, 45)
        Me.MetroTranslatorLabel6.Name = "MetroTranslatorLabel6"
        Me.MetroTranslatorLabel6.ShowToolTip = True
        Me.MetroTranslatorLabel6.Size = New System.Drawing.Size(161, 13)
        Me.MetroTranslatorLabel6.TabIndex = 45
        Me.MetroTranslatorLabel6.Text = "(Ein Neustart wird empfohlen)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'MetroTranslatorLabel5
        '
        Me.MetroTranslatorLabel5.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel5.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroTranslatorLabel5.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel5.LanguageKey = "SETTINGS:OPTIONS_LANGUAGETEXT"
        Me.MetroTranslatorLabel5.Location = New System.Drawing.Point(6, 43)
        Me.MetroTranslatorLabel5.Name = "MetroTranslatorLabel5"
        Me.MetroTranslatorLabel5.ShowToolTip = True
        Me.MetroTranslatorLabel5.Size = New System.Drawing.Size(84, 19)
        Me.MetroTranslatorLabel5.TabIndex = 44
        Me.MetroTranslatorLabel5.Text = "Sprache:"
        Me.MetroTranslatorLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'MetroTranslatorLabel4
        '
        Me.MetroTranslatorLabel4.AutoSize = True
        Me.MetroTranslatorLabel4.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel4.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel4.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroTranslatorLabel4.LanguageKey = "SETTINGS:OPTIONS_GENERALLYTEXT"
        Me.MetroTranslatorLabel4.Location = New System.Drawing.Point(39, 14)
        Me.MetroTranslatorLabel4.Name = "MetroTranslatorLabel4"
        Me.MetroTranslatorLabel4.ShowToolTip = True
        Me.MetroTranslatorLabel4.Size = New System.Drawing.Size(84, 21)
        Me.MetroTranslatorLabel4.TabIndex = 43
        Me.MetroTranslatorLabel4.Text = "Allgemein"
        '
        'ExitMode_mcmdbox
        '
        Me.ExitMode_mcmdbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ExitMode_mcmdbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ExitMode_mcmdbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ExitMode_mcmdbox.DefaultColor = System.Drawing.Color.White
        Me.ExitMode_mcmdbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ExitMode_mcmdbox.DisplayMember = "Deutsch (German)"
        Me.ExitMode_mcmdbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ExitMode_mcmdbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExitMode_mcmdbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ExitMode_mcmdbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ExitMode_mcmdbox.ForeColor = System.Drawing.Color.Black
        Me.ExitMode_mcmdbox.FormattingEnabled = True
        Me.ExitMode_mcmdbox.Items.AddRange(New Object() {"Exit", "Minimize"})
        Me.ExitMode_mcmdbox.Location = New System.Drawing.Point(96, 101)
        Me.ExitMode_mcmdbox.Name = "ExitMode_mcmdbox"
        Me.ExitMode_mcmdbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ExitMode_mcmdbox.Size = New System.Drawing.Size(221, 24)
        Me.ExitMode_mcmdbox.TabIndex = 41
        '
        'StartTabPage_mcmdbox
        '
        Me.StartTabPage_mcmdbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.StartTabPage_mcmdbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.StartTabPage_mcmdbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.StartTabPage_mcmdbox.DefaultColor = System.Drawing.Color.White
        Me.StartTabPage_mcmdbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.StartTabPage_mcmdbox.DisplayMember = "Deutsch (German)"
        Me.StartTabPage_mcmdbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.StartTabPage_mcmdbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.StartTabPage_mcmdbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.StartTabPage_mcmdbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.StartTabPage_mcmdbox.ForeColor = System.Drawing.Color.Black
        Me.StartTabPage_mcmdbox.FormattingEnabled = True
        Me.StartTabPage_mcmdbox.Items.AddRange(New Object() {"Start", "Library", "CCAN 2.0", "News", "Events"})
        Me.StartTabPage_mcmdbox.Location = New System.Drawing.Point(131, 144)
        Me.StartTabPage_mcmdbox.Name = "StartTabPage_mcmdbox"
        Me.StartTabPage_mcmdbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.StartTabPage_mcmdbox.Size = New System.Drawing.Size(186, 24)
        Me.StartTabPage_mcmdbox.TabIndex = 38
        '
        'Panel3
        '
        Me.Panel3.Location = New System.Drawing.Point(4, 491)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(160, 10)
        Me.Panel3.TabIndex = 36
        '
        'Theme_mcmdbox
        '
        Me.Theme_mcmdbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Theme_mcmdbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Theme_mcmdbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Theme_mcmdbox.DefaultColor = System.Drawing.Color.White
        Me.Theme_mcmdbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Theme_mcmdbox.DisplayMember = "Deutsch (German)"
        Me.Theme_mcmdbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.Theme_mcmdbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Theme_mcmdbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Theme_mcmdbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Theme_mcmdbox.ForeColor = System.Drawing.Color.Black
        Me.Theme_mcmdbox.FormattingEnabled = True
        Me.Theme_mcmdbox.Location = New System.Drawing.Point(96, 71)
        Me.Theme_mcmdbox.Name = "Theme_mcmdbox"
        Me.Theme_mcmdbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Theme_mcmdbox.Size = New System.Drawing.Size(221, 24)
        Me.Theme_mcmdbox.TabIndex = 5
        '
        'Language_mcmdbox
        '
        Me.Language_mcmdbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Language_mcmdbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Language_mcmdbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Language_mcmdbox.DefaultColor = System.Drawing.Color.White
        Me.Language_mcmdbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Language_mcmdbox.DisplayMember = "Deutsch (German)"
        Me.Language_mcmdbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.Language_mcmdbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Language_mcmdbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Language_mcmdbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Language_mcmdbox.ForeColor = System.Drawing.Color.Black
        Me.Language_mcmdbox.FormattingEnabled = True
        Me.Language_mcmdbox.Location = New System.Drawing.Point(96, 41)
        Me.Language_mcmdbox.Name = "Language_mcmdbox"
        Me.Language_mcmdbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Language_mcmdbox.Size = New System.Drawing.Size(221, 24)
        Me.Language_mcmdbox.TabIndex = 3
        '
        'CID_lbl
        '
        Me.CID_lbl.AutoSize = True
        Me.CID_lbl.BackColor = System.Drawing.Color.Transparent
        Me.CID_lbl.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CID_lbl.ForeColor = System.Drawing.Color.Gainsboro
        Me.CID_lbl.Location = New System.Drawing.Point(26, 315)
        Me.CID_lbl.Name = "CID_lbl"
        Me.CID_lbl.Size = New System.Drawing.Size(64, 19)
        Me.CID_lbl.TabIndex = 0
        Me.CID_lbl.Text = "USER-ID:"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.MetroTranslatorLabel21)
        Me.TabPage2.Controls.Add(Me.ShowChatClonkMessage_mchkbox)
        Me.TabPage2.Controls.Add(Me.ShowChatMsg_mchkbox)
        Me.TabPage2.Controls.Add(Me.ShowNewUpdateMsg_mchkbox)
        Me.TabPage2.Controls.Add(Me.MetroTranslatorLabel20)
        Me.TabPage2.Controls.Add(Me.MetroTranslatorLabel19)
        Me.TabPage2.Controls.Add(Me.MetroTranslatorLabel18)
        Me.TabPage2.ForeColor = System.Drawing.Color.Black
        Me.TabPage2.Location = New System.Drawing.Point(4, 49)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(754, 394)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Benachrichtigungen"
        '
        'MetroTranslatorLabel21
        '
        Me.MetroTranslatorLabel21.AutoSize = True
        Me.MetroTranslatorLabel21.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel21.Font = New System.Drawing.Font("Segoe UI", 7.0!)
        Me.MetroTranslatorLabel21.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel21.LanguageKey = "SETTINGS:NOTIFICATIONS_NOTIFYCHATWHENPLAYINGINFOTEXT"
        Me.MetroTranslatorLabel21.Location = New System.Drawing.Point(41, 143)
        Me.MetroTranslatorLabel21.Name = "MetroTranslatorLabel21"
        Me.MetroTranslatorLabel21.ShowToolTip = True
        Me.MetroTranslatorLabel21.Size = New System.Drawing.Size(287, 12)
        Me.MetroTranslatorLabel21.TabIndex = 65
        Me.MetroTranslatorLabel21.Text = "(""'NAME' spielt nun OpenClonk! Möchtest du nicht mitspielen?"")"
        '
        'ShowChatClonkMessage_mchkbox
        '
        Me.ShowChatClonkMessage_mchkbox.BackColor = System.Drawing.Color.Transparent
        Me.ShowChatClonkMessage_mchkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ShowChatClonkMessage_mchkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ShowChatClonkMessage_mchkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ShowChatClonkMessage_mchkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ShowChatClonkMessage_mchkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ShowChatClonkMessage_mchkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ShowChatClonkMessage_mchkbox.LanguageKey = "SETTINGS:NOTIFICATIONS_NOTIFYCHATWHENPLAYINGTEXT"
        Me.ShowChatClonkMessage_mchkbox.Location = New System.Drawing.Point(30, 127)
        Me.ShowChatClonkMessage_mchkbox.Name = "ShowChatClonkMessage_mchkbox"
        Me.ShowChatClonkMessage_mchkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ShowChatClonkMessage_mchkbox.Size = New System.Drawing.Size(334, 14)
        Me.ShowChatClonkMessage_mchkbox.TabIndex = 64
        Me.ShowChatClonkMessage_mchkbox.Text = "Chat benachrichtigen wenn man anfängt Clonk zu spielen"
        '
        'ShowChatMsg_mchkbox
        '
        Me.ShowChatMsg_mchkbox.BackColor = System.Drawing.Color.Transparent
        Me.ShowChatMsg_mchkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ShowChatMsg_mchkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ShowChatMsg_mchkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ShowChatMsg_mchkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ShowChatMsg_mchkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ShowChatMsg_mchkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ShowChatMsg_mchkbox.LanguageKey = "SETTINGS:NOTIFICATIONS_CHATMESSAGETEXT"
        Me.ShowChatMsg_mchkbox.Location = New System.Drawing.Point(30, 102)
        Me.ShowChatMsg_mchkbox.Name = "ShowChatMsg_mchkbox"
        Me.ShowChatMsg_mchkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ShowChatMsg_mchkbox.Size = New System.Drawing.Size(301, 14)
        Me.ShowChatMsg_mchkbox.TabIndex = 63
        Me.ShowChatMsg_mchkbox.Text = "Benachrichtigung bei neuer Chatnachricht anzeigen"
        '
        'ShowNewUpdateMsg_mchkbox
        '
        Me.ShowNewUpdateMsg_mchkbox.BackColor = System.Drawing.Color.Transparent
        Me.ShowNewUpdateMsg_mchkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ShowNewUpdateMsg_mchkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ShowNewUpdateMsg_mchkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ShowNewUpdateMsg_mchkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ShowNewUpdateMsg_mchkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ShowNewUpdateMsg_mchkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ShowNewUpdateMsg_mchkbox.LanguageKey = "SETTINGS:NOTIFICATIONS_NEWUPDATETEXT"
        Me.ShowNewUpdateMsg_mchkbox.Location = New System.Drawing.Point(30, 43)
        Me.ShowNewUpdateMsg_mchkbox.Name = "ShowNewUpdateMsg_mchkbox"
        Me.ShowNewUpdateMsg_mchkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ShowNewUpdateMsg_mchkbox.Size = New System.Drawing.Size(325, 14)
        Me.ShowNewUpdateMsg_mchkbox.TabIndex = 62
        Me.ShowNewUpdateMsg_mchkbox.Text = "Benachrichtigung anzeigen bei neuem Launcher Update"
        '
        'MetroTranslatorLabel20
        '
        Me.MetroTranslatorLabel20.AutoSize = True
        Me.MetroTranslatorLabel20.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel20.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel20.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroTranslatorLabel20.LanguageKey = "SETTINGS:NOTIFICATIONS_CHATTEXT"
        Me.MetroTranslatorLabel20.Location = New System.Drawing.Point(39, 73)
        Me.MetroTranslatorLabel20.Name = "MetroTranslatorLabel20"
        Me.MetroTranslatorLabel20.ShowToolTip = True
        Me.MetroTranslatorLabel20.Size = New System.Drawing.Size(43, 21)
        Me.MetroTranslatorLabel20.TabIndex = 61
        Me.MetroTranslatorLabel20.Text = "Chat"
        '
        'MetroTranslatorLabel19
        '
        Me.MetroTranslatorLabel19.AutoSize = True
        Me.MetroTranslatorLabel19.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel19.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel19.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroTranslatorLabel19.LanguageKey = "SETTINGS:NOTIFICATIONS_GENERALLYTEXT"
        Me.MetroTranslatorLabel19.Location = New System.Drawing.Point(39, 14)
        Me.MetroTranslatorLabel19.Name = "MetroTranslatorLabel19"
        Me.MetroTranslatorLabel19.ShowToolTip = True
        Me.MetroTranslatorLabel19.Size = New System.Drawing.Size(84, 21)
        Me.MetroTranslatorLabel19.TabIndex = 60
        Me.MetroTranslatorLabel19.Text = "Allgemein"
        '
        'MetroTranslatorLabel18
        '
        Me.MetroTranslatorLabel18.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel18.AutoSize = True
        Me.MetroTranslatorLabel18.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel18.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel18.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel18.LanguageKey = "SETTINGS:OTHER_AUTOSAVESETTINGSTEXT"
        Me.MetroTranslatorLabel18.Location = New System.Drawing.Point(235, 369)
        Me.MetroTranslatorLabel18.Name = "MetroTranslatorLabel18"
        Me.MetroTranslatorLabel18.ShowToolTip = True
        Me.MetroTranslatorLabel18.Size = New System.Drawing.Size(282, 15)
        Me.MetroTranslatorLabel18.TabIndex = 59
        Me.MetroTranslatorLabel18.Text = "Einstellungen speichern beim verlassen automatisch"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.White
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage3.Controls.Add(Me.MetroTranslatorLabel22)
        Me.TabPage3.Controls.Add(Me.CCANcopyInAnyDir_rbtn)
        Me.TabPage3.Controls.Add(Me.CCANcopyInGameDir_rbtn)
        Me.TabPage3.Controls.Add(Me.MetroLabel9)
        Me.TabPage3.Location = New System.Drawing.Point(4, 49)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(754, 394)
        Me.TabPage3.TabIndex = 3
        Me.TabPage3.Text = "Downloads"
        '
        'MetroTranslatorLabel22
        '
        Me.MetroTranslatorLabel22.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel22.AutoSize = True
        Me.MetroTranslatorLabel22.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel22.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel22.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel22.LanguageKey = "SETTINGS:OTHER_AUTOSAVESETTINGSTEXT"
        Me.MetroTranslatorLabel22.Location = New System.Drawing.Point(235, 369)
        Me.MetroTranslatorLabel22.Name = "MetroTranslatorLabel22"
        Me.MetroTranslatorLabel22.ShowToolTip = True
        Me.MetroTranslatorLabel22.Size = New System.Drawing.Size(282, 15)
        Me.MetroTranslatorLabel22.TabIndex = 60
        Me.MetroTranslatorLabel22.Text = "Einstellungen speichern beim verlassen automatisch"
        '
        'CCANcopyInAnyDir_rbtn
        '
        Me.CCANcopyInAnyDir_rbtn.AutoSize = True
        Me.CCANcopyInAnyDir_rbtn.BackColor = System.Drawing.Color.Transparent
        Me.CCANcopyInAnyDir_rbtn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANcopyInAnyDir_rbtn.ForeColor = System.Drawing.Color.Gainsboro
        Me.CCANcopyInAnyDir_rbtn.LanguageKey = "SETTINGS:DOWNLOADS_SAVEINCUSTOMFOLDERTEXT"
        Me.CCANcopyInAnyDir_rbtn.Location = New System.Drawing.Point(30, 68)
        Me.CCANcopyInAnyDir_rbtn.Name = "CCANcopyInAnyDir_rbtn"
        Me.CCANcopyInAnyDir_rbtn.Size = New System.Drawing.Size(267, 19)
        Me.CCANcopyInAnyDir_rbtn.TabIndex = 28
        Me.CCANcopyInAnyDir_rbtn.TabStop = True
        Me.CCANcopyInAnyDir_rbtn.Text = "Objekte in einem beliebigen Ordner speichern"
        Me.CCANcopyInAnyDir_rbtn.UseVisualStyleBackColor = False
        '
        'CCANcopyInGameDir_rbtn
        '
        Me.CCANcopyInGameDir_rbtn.AutoSize = True
        Me.CCANcopyInGameDir_rbtn.BackColor = System.Drawing.Color.Transparent
        Me.CCANcopyInGameDir_rbtn.Checked = True
        Me.CCANcopyInGameDir_rbtn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANcopyInGameDir_rbtn.ForeColor = System.Drawing.Color.Gainsboro
        Me.CCANcopyInGameDir_rbtn.LanguageKey = "SETTINGS:DOWNLOADS_AUTOCOPYTEXT"
        Me.CCANcopyInGameDir_rbtn.Location = New System.Drawing.Point(30, 43)
        Me.CCANcopyInGameDir_rbtn.Name = "CCANcopyInGameDir_rbtn"
        Me.CCANcopyInGameDir_rbtn.Size = New System.Drawing.Size(366, 19)
        Me.CCANcopyInGameDir_rbtn.TabIndex = 27
        Me.CCANcopyInGameDir_rbtn.TabStop = True
        Me.CCANcopyInGameDir_rbtn.Text = "Objekte automatisch ins vorgegebene Spieleverzeichnis kopieren"
        Me.CCANcopyInGameDir_rbtn.UseVisualStyleBackColor = False
        '
        'MetroLabel9
        '
        Me.MetroLabel9.AutoSize = True
        Me.MetroLabel9.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel9.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel9.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel9.Location = New System.Drawing.Point(39, 14)
        Me.MetroLabel9.Name = "MetroLabel9"
        Me.MetroLabel9.Size = New System.Drawing.Size(53, 21)
        Me.MetroLabel9.TabIndex = 20
        Me.MetroLabel9.Text = "CCAN"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.White
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage4.Controls.Add(Me.MetroTabControl1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 49)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(754, 394)
        Me.TabPage4.TabIndex = 4
        Me.TabPage4.Text = "Info zum Launcher"
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Appearance = System.Windows.Forms.Appearance.Normal
        Me.MetroTabControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MetroTabControl1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.MetroTabControl1.Controls.Add(Me.TabPage5)
        Me.MetroTabControl1.Controls.Add(Me.TabPage6)
        Me.MetroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroTabControl1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTabControl1.ForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.HasAnimation = False
        Me.MetroTabControl1.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(106, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.MetroTabControl1.HeaderItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.HotTrack = True
        Me.MetroTabControl1.HoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.HoverColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.ItemSize = New System.Drawing.Size(45, 120)
        Me.MetroTabControl1.Location = New System.Drawing.Point(3, 3)
        Me.MetroTabControl1.Multiline = True
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedForeColor = System.Drawing.Color.White
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.SelectedItemColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedItemLineColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.Size = New System.Drawing.Size(746, 386)
        Me.MetroTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MetroTabControl1.TabContainerColor = System.Drawing.Color.White
        Me.MetroTabControl1.TabIndex = 39
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.White
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage5.Controls.Add(Me.MetroTranslatorLabel24)
        Me.TabPage5.Controls.Add(Me.CheckForUpdates_btn)
        Me.TabPage5.Controls.Add(Me.MetroTranslatorLabel23)
        Me.TabPage5.Controls.Add(Me.PictureBox2)
        Me.TabPage5.Controls.Add(Me.LinkLabel1)
        Me.TabPage5.Controls.Add(Me.PictureBox3)
        Me.TabPage5.Controls.Add(Me.LinkLabel3)
        Me.TabPage5.Controls.Add(Me.MetroLabel17)
        Me.TabPage5.Controls.Add(Me.PictureBox1)
        Me.TabPage5.Controls.Add(Me.LinkLabel2)
        Me.TabPage5.Controls.Add(Me.RichTextBox1)
        Me.TabPage5.Location = New System.Drawing.Point(124, 4)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(618, 378)
        Me.TabPage5.TabIndex = 0
        Me.TabPage5.Text = "Info"
        '
        'MetroTranslatorLabel24
        '
        Me.MetroTranslatorLabel24.AutoSize = True
        Me.MetroTranslatorLabel24.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel24.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.MetroTranslatorLabel24.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel24.LanguageKey = "SETTINGS:ABOUT_USEDLIBRARIESTEXT"
        Me.MetroTranslatorLabel24.Location = New System.Drawing.Point(6, 119)
        Me.MetroTranslatorLabel24.Name = "MetroTranslatorLabel24"
        Me.MetroTranslatorLabel24.ShowToolTip = True
        Me.MetroTranslatorLabel24.Size = New System.Drawing.Size(154, 20)
        Me.MetroTranslatorLabel24.TabIndex = 41
        Me.MetroTranslatorLabel24.Text = "Benutzte Bibliotheken"
        '
        'CheckForUpdates_btn
        '
        Me.CheckForUpdates_btn.BackColor = System.Drawing.Color.Transparent
        Me.CheckForUpdates_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CheckForUpdates_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CheckForUpdates_btn.DefaultColor = System.Drawing.Color.White
        Me.CheckForUpdates_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CheckForUpdates_btn.Font = New System.Drawing.Font("Segoe UI", 7.8!)
        Me.CheckForUpdates_btn.HoverColor = System.Drawing.Color.White
        Me.CheckForUpdates_btn.IsRound = True
        Me.CheckForUpdates_btn.LanguageKey = "SETTINGS:ABOUT_CHECKFORUPDATESBTN"
        Me.CheckForUpdates_btn.Location = New System.Drawing.Point(244, 96)
        Me.CheckForUpdates_btn.Name = "CheckForUpdates_btn"
        Me.CheckForUpdates_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CheckForUpdates_btn.RoundingArc = 19
        Me.CheckForUpdates_btn.Size = New System.Drawing.Size(128, 19)
        Me.CheckForUpdates_btn.TabIndex = 40
        Me.CheckForUpdates_btn.Text = "Auf Updates prüfen"
        '
        'MetroTranslatorLabel23
        '
        Me.MetroTranslatorLabel23.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel23.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.MetroTranslatorLabel23.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel23.LanguageKey = "SETTINGS:ABOUT_TRADEMARKINFOTEXT"
        Me.MetroTranslatorLabel23.Location = New System.Drawing.Point(6, 3)
        Me.MetroTranslatorLabel23.Name = "MetroTranslatorLabel23"
        Me.MetroTranslatorLabel23.ShowToolTip = True
        Me.MetroTranslatorLabel23.Size = New System.Drawing.Size(604, 63)
        Me.MetroTranslatorLabel23.TabIndex = 39
        Me.MetroTranslatorLabel23.Text = "'Clonk' ist ein eingetragenes Warenzeichen von Matthes Bender." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Alle weiteren erw" &
    "ähnten Produkt- und Firmennamen sind Marken der jeweiligen Eigentümer."
        Me.MetroTranslatorLabel23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.quixo_systems_white
        Me.PictureBox2.Location = New System.Drawing.Point(410, 322)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(193, 48)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.LinkLabel1.Location = New System.Drawing.Point(406, 299)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(203, 20)
        Me.LinkLabel1.TabIndex = 32
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "quixo-systems.jimdofree.com"
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.gecko_logo
        Me.PictureBox3.Location = New System.Drawing.Point(211, 322)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(193, 48)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 37
        Me.PictureBox3.TabStop = False
        '
        'LinkLabel3
        '
        Me.LinkLabel3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LinkLabel3.AutoSize = True
        Me.LinkLabel3.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.LinkLabel3.Location = New System.Drawing.Point(207, 299)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(120, 20)
        Me.LinkLabel3.TabIndex = 38
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "www.mozilla.org"
        '
        'MetroLabel17
        '
        Me.MetroLabel17.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel17.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel17.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroLabel17.Location = New System.Drawing.Point(6, 73)
        Me.MetroLabel17.Name = "MetroLabel17"
        Me.MetroLabel17.Size = New System.Drawing.Size(604, 19)
        Me.MetroLabel17.TabIndex = 29
        Me.MetroLabel17.Text = "Xtreme-Clonk-Launcher Version: 1.2.2 Open-Source version"
        Me.MetroLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.original_clonk_logo
        Me.PictureBox1.Location = New System.Drawing.Point(12, 322)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(193, 48)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 34
        Me.PictureBox1.TabStop = False
        '
        'LinkLabel2
        '
        Me.LinkLabel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.LinkLabel2.Location = New System.Drawing.Point(8, 299)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(64, 20)
        Me.LinkLabel2.TabIndex = 33
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "clonk.de"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.White
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(6, 142)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.Size = New System.Drawing.Size(604, 154)
        Me.RichTextBox1.TabIndex = 36
        Me.RichTextBox1.Text = resources.GetString("RichTextBox1.Text")
        Me.RichTextBox1.WordWrap = False
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.White
        Me.TabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage6.Controls.Add(Me.MetroLabel1)
        Me.TabPage6.Location = New System.Drawing.Point(124, 4)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(618, 378)
        Me.TabPage6.TabIndex = 1
        Me.TabPage6.Text = "Thanks to"
        '
        'MetroLabel1
        '
        Me.MetroLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel1.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel1.Location = New System.Drawing.Point(6, 3)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(604, 370)
        Me.MetroLabel1.TabIndex = 3
        Me.MetroLabel1.Text = "Thanks to @Cenodis for helping me with the translations! :-)"
        Me.MetroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Settings
        '
        Me.AllowResize = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(786, 494)
        Me.Controls.Add(Me.settings_tbc)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Settings"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "Xtreme-Clonk-Launcher"
        Me.controlbox_pnl.ResumeLayout(False)
        Me.settings_tbc.ResumeLayout(False)
        Me.Account_tb.ResumeLayout(False)
        Me.Account_tb.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.MetroTabControl1.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Friend WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents settings_tbc As MetroSuite.MetroTabControl
    Friend WithEvents Account_tb As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents CID_lbl As MetroSuite.MetroLabel
    Friend WithEvents Language_mcmdbox As MetroSuite.MetroComboBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents MetroLabel9 As MetroSuite.MetroLabel
    Friend WithEvents Theme_mcmdbox As MetroSuite.MetroComboBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents MetroLabel17 As MetroSuite.MetroLabel
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabel3 As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents StartTabPage_mcmdbox As MetroSuite.MetroComboBox
    Friend WithEvents ExitMode_mcmdbox As MetroSuite.MetroComboBox
    Friend WithEvents MetroTranslatorLabel1 As MetroTranslatorLabel
    Friend WithEvents NotLoggedInInfo_lbl As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel2 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel3 As MetroTranslatorLabel
    Friend WithEvents Password_txtbox As MetroTranslatorTextbox
    Friend WithEvents username_txtbox As MetroTranslatorTextbox
    Friend WithEvents ShowPassword_chkbox As MetroTranslatorChecker
    Friend WithEvents AcceptChanges_btn As MetroTranslatorButton
    Friend WithEvents MetroTabControl1 As MetroSuite.MetroTabControl
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents MetroLabel1 As MetroSuite.MetroLabel
    Friend WithEvents MetroTranslatorLabel4 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel5 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel6 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel7 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel8 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel9 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel10 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel11 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel12 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel15 As MetroTranslatorLabel
    Friend WithEvents AllowPlayTimeData_mchbox As MetroTranslatorChecker
    Friend WithEvents MetroTranslatorLabel14 As MetroTranslatorLabel
    Friend WithEvents AllowRushHourData_mchbox As MetroTranslatorChecker
    Friend WithEvents MetroTranslatorLabel13 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel16 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel17 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel18 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel20 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel19 As MetroTranslatorLabel
    Friend WithEvents ShowChatClonkMessage_mchkbox As MetroTranslatorChecker
    Friend WithEvents ShowChatMsg_mchkbox As MetroTranslatorChecker
    Friend WithEvents ShowNewUpdateMsg_mchkbox As MetroTranslatorChecker
    Friend WithEvents MetroTranslatorLabel21 As MetroTranslatorLabel
    Friend WithEvents CCANcopyInAnyDir_rbtn As ClassicTranslatorRadioButton
    Friend WithEvents CCANcopyInGameDir_rbtn As ClassicTranslatorRadioButton
    Friend WithEvents MetroTranslatorLabel22 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel23 As MetroTranslatorLabel
    Friend WithEvents CheckForUpdates_btn As MetroTranslatorButton
    Friend WithEvents MetroTranslatorLabel24 As MetroTranslatorLabel
End Class
