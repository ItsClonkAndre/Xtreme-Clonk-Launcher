﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Debug_frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Debug_frm))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ResetLastDayDate_btn = New System.Windows.Forms.Button()
        Me.ResetSurveyCompleted_btn = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LastDayDateValue_lbl = New System.Windows.Forms.Label()
        Me.SurveyCompletedValue_lbl = New System.Windows.Forms.Label()
        Me.GetOpenedIP_btn = New System.Windows.Forms.Button()
        Me.lock_pnl = New System.Windows.Forms.Panel()
        Me.enter_btn = New System.Windows.Forms.Button()
        Me.close_btn = New System.Windows.Forms.Button()
        Me.pw_txtbox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lock_pnl.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.25!)
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(312, 52)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "You shouldn't be here, this window is for testing purposes only. Please close thi" &
    "s window again if you accidentally opened it."
        '
        'ResetLastDayDate_btn
        '
        Me.ResetLastDayDate_btn.Location = New System.Drawing.Point(25, 98)
        Me.ResetLastDayDate_btn.Name = "ResetLastDayDate_btn"
        Me.ResetLastDayDate_btn.Size = New System.Drawing.Size(176, 23)
        Me.ResetLastDayDate_btn.TabIndex = 1
        Me.ResetLastDayDate_btn.Text = "Reset LastDayDate Setting"
        Me.ResetLastDayDate_btn.UseVisualStyleBackColor = True
        '
        'ResetSurveyCompleted_btn
        '
        Me.ResetSurveyCompleted_btn.Location = New System.Drawing.Point(25, 127)
        Me.ResetSurveyCompleted_btn.Name = "ResetSurveyCompleted_btn"
        Me.ResetSurveyCompleted_btn.Size = New System.Drawing.Size(176, 23)
        Me.ResetSurveyCompleted_btn.TabIndex = 2
        Me.ResetSurveyCompleted_btn.Text = "Reset SurveyCompleted Setting"
        Me.ResetSurveyCompleted_btn.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(0, 216)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(336, 23)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "- DEBUG -"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LastDayDateValue_lbl
        '
        Me.LastDayDateValue_lbl.Location = New System.Drawing.Point(207, 98)
        Me.LastDayDateValue_lbl.Name = "LastDayDateValue_lbl"
        Me.LastDayDateValue_lbl.Size = New System.Drawing.Size(117, 23)
        Me.LastDayDateValue_lbl.TabIndex = 5
        Me.LastDayDateValue_lbl.Text = "Value"
        Me.LastDayDateValue_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'SurveyCompletedValue_lbl
        '
        Me.SurveyCompletedValue_lbl.Location = New System.Drawing.Point(207, 127)
        Me.SurveyCompletedValue_lbl.Name = "SurveyCompletedValue_lbl"
        Me.SurveyCompletedValue_lbl.Size = New System.Drawing.Size(117, 23)
        Me.SurveyCompletedValue_lbl.TabIndex = 6
        Me.SurveyCompletedValue_lbl.Text = "Value"
        Me.SurveyCompletedValue_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GetOpenedIP_btn
        '
        Me.GetOpenedIP_btn.Location = New System.Drawing.Point(25, 156)
        Me.GetOpenedIP_btn.Name = "GetOpenedIP_btn"
        Me.GetOpenedIP_btn.Size = New System.Drawing.Size(176, 23)
        Me.GetOpenedIP_btn.TabIndex = 7
        Me.GetOpenedIP_btn.Text = "Get Opened IP"
        Me.GetOpenedIP_btn.UseVisualStyleBackColor = True
        '
        'lock_pnl
        '
        Me.lock_pnl.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lock_pnl.Controls.Add(Me.enter_btn)
        Me.lock_pnl.Controls.Add(Me.close_btn)
        Me.lock_pnl.Controls.Add(Me.pw_txtbox)
        Me.lock_pnl.Controls.Add(Me.Label4)
        Me.lock_pnl.Controls.Add(Me.Label3)
        Me.lock_pnl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lock_pnl.ForeColor = System.Drawing.Color.White
        Me.lock_pnl.Location = New System.Drawing.Point(0, 0)
        Me.lock_pnl.Name = "lock_pnl"
        Me.lock_pnl.Size = New System.Drawing.Size(336, 216)
        Me.lock_pnl.TabIndex = 8
        '
        'enter_btn
        '
        Me.enter_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enter_btn.ForeColor = System.Drawing.Color.Black
        Me.enter_btn.Location = New System.Drawing.Point(95, 153)
        Me.enter_btn.Name = "enter_btn"
        Me.enter_btn.Size = New System.Drawing.Size(75, 23)
        Me.enter_btn.TabIndex = 5
        Me.enter_btn.Text = "Enter"
        Me.enter_btn.UseVisualStyleBackColor = True
        '
        'close_btn
        '
        Me.close_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.close_btn.ForeColor = System.Drawing.Color.Black
        Me.close_btn.Location = New System.Drawing.Point(176, 153)
        Me.close_btn.Name = "close_btn"
        Me.close_btn.Size = New System.Drawing.Size(75, 23)
        Me.close_btn.TabIndex = 4
        Me.close_btn.Text = "Close"
        Me.close_btn.UseVisualStyleBackColor = True
        '
        'pw_txtbox
        '
        Me.pw_txtbox.Location = New System.Drawing.Point(30, 101)
        Me.pw_txtbox.Name = "pw_txtbox"
        Me.pw_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.pw_txtbox.Size = New System.Drawing.Size(279, 20)
        Me.pw_txtbox.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.25!)
        Me.Label4.Location = New System.Drawing.Point(27, 82)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(282, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Please enter password to access all functions."
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.25!)
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(312, 52)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "You shouldn't be here, this window is for testing purposes only. Please close thi" &
    "s window again if you accidentally opened it."
        '
        'Debug_frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(336, 239)
        Me.Controls.Add(Me.lock_pnl)
        Me.Controls.Add(Me.GetOpenedIP_btn)
        Me.Controls.Add(Me.SurveyCompletedValue_lbl)
        Me.Controls.Add(Me.LastDayDateValue_lbl)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ResetSurveyCompleted_btn)
        Me.Controls.Add(Me.ResetLastDayDate_btn)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Debug_frm"
        Me.Text = "Xtreme-Clonk-Launcher"
        Me.lock_pnl.ResumeLayout(False)
        Me.lock_pnl.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ResetLastDayDate_btn As System.Windows.Forms.Button
    Friend WithEvents ResetSurveyCompleted_btn As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LastDayDateValue_lbl As System.Windows.Forms.Label
    Friend WithEvents SurveyCompletedValue_lbl As System.Windows.Forms.Label
    Friend WithEvents GetOpenedIP_btn As System.Windows.Forms.Button
    Friend WithEvents lock_pnl As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents enter_btn As System.Windows.Forms.Button
    Friend WithEvents close_btn As System.Windows.Forms.Button
    Friend WithEvents pw_txtbox As System.Windows.Forms.TextBox
End Class
