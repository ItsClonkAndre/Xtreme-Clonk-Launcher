﻿Option Strict On
Imports MetroSuite.Extension
Imports MetroSuite
Public Class CCANObjectPreviewFrm : Inherits MetroSuite.MetroForm

    Private Deleted As Boolean
    Private _CommentNum As Integer
    Private CCANObject As CCANobject
    Private Comments As List(Of Object)

#Region "ControlBox"

    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        Me.Close()
    End Sub
    Private Sub controlbox_nmaximize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_nmaximize_lbl.Click
        If controlbox_nmaximize_lbl.Text = "□" Then
            controlbox_nmaximize_lbl.Text = "■"
            Me.WindowState = FormWindowState.Normal
        Else
            controlbox_nmaximize_lbl.Text = "□"
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub
    Private Sub controlbox_minimize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_minimize_lbl.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter, controlbox_nmaximize_lbl.MouseEnter, controlbox_minimize_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave, controlbox_nmaximize_lbl.MouseLeave, controlbox_minimize_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

#End Region

#Region "Functions"

    Public Function ContainsOnlyRightChars(input As String) As Boolean
        Dim AlphabetChars As Char() = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZß!?'%&/([(])}\=+-.,#*'_:;<> ".ToCharArray
        For Each c As Char In input.ToCharArray
            If Not AlphabetChars.Contains(c) Then
                Return False
            End If
        Next
        Return True
    End Function

    Private Sub SortObjectComments(ctrl As Control, Optional SortMode As Integer = 0)
        Try
            Select Case SortMode
                Case 0 ' Newest
                    If Not ctrl.Controls.Count = 0 Then
                        Dim ctrCol = (From c In ctrl.Controls.OfType(Of CCANCommentUC)() Order By c.uDate).ToArray
                        ctrl.Controls.Clear()
                        ctrl.Controls.AddRange(ctrCol)

                        For i = 0 To ctrCol.Length
                            ctrl.Controls.SetChildIndex(ctrCol(i), 0)
                        Next
                    End If
                Case 1 ' Oldest
                    If Not ctrl.Controls.Count = 0 Then
                        Dim ctrCol = (From c In ctrl.Controls.OfType(Of CCANCommentUC)() Order By c.uDate).ToArray
                        ctrl.Controls.Clear()
                        ctrl.Controls.AddRange(ctrCol)
                    End If
            End Select
        Catch ex As Exception
            AllComments_flp.Enabled = True
        End Try
    End Sub

#End Region

#Region " Network "

    Private Sub UTC_UTicketArrived(sSenderID As String, bSentToAll As Boolean, sCommand As String, oUserData As List(Of Object))
        Select Case sCommand
            Case "ToClient:CCANOBJECT:ReceiveCommentsStatus"
                Select Case oUserData(0).ToString
                    Case "ERROR"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() CommentsCount_lbl.Text = "Alle Bewertungen (" & AllComments_flp.Controls.Count & ")"))
                            Me.Invoke(New MethodInvoker(Sub() AllComments_flp.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() LoadingComments_picbox.Visible = False))
                        Else
                            CommentsCount_lbl.Text = "Alle Bewertungen (0)"
                            AllComments_flp.Enabled = True
                            LoadingComments_picbox.Visible = False
                        End If

                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Fehler beim Laden der Kommentare für dieses Objekt. " & Environment.NewLine & "Details: " & oUserData(1).ToString)
                        _newMsg.ShowDialog()
                    Case "SUCCESS"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() SortObjectComments(AllComments_flp)))
                            Me.Invoke(New MethodInvoker(Sub() CommentsCount_lbl.Text = "Alle Bewertungen (" & AllComments_flp.Controls.Count & ")"))
                            Me.Invoke(New MethodInvoker(Sub() AllComments_flp.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() LoadingComments_picbox.Visible = False))
                        Else
                            SortObjectComments(AllComments_flp)
                            CommentsCount_lbl.Text = "Alle Bewertungen (" & AllComments_flp.Controls.Count & ")"
                            AllComments_flp.Enabled = True
                            LoadingComments_picbox.Visible = False
                        End If
                End Select

            Case "ToClient:CCANOBJECT:ReceiveComments"
                For Each _RowComments As String In oUserData

                    Dim _newComment As CCANCommentUC
                    Dim CCANID As String = _RowComments.Split(CChar("|"))(0)
                    Dim COMMENTID As String = _RowComments.Split(CChar("|"))(1).Split(CChar("|"))(0)
                    Dim COMMENT As String = _RowComments.Split(CChar("|"))(2).Split(CChar("|"))(0)
                    Dim USERNAME As String = _RowComments.Split(CChar("|"))(3).Split(CChar("|"))(0)
                    Dim RATING As String = _RowComments.Split(CChar("|"))(4).Split(CChar("|"))(0)
                    Dim uDATE As String = _RowComments.Split(CChar("|"))(5).Split(CChar("|"))(0)
                    Dim uTIME As String = _RowComments.Split(CChar("|"))(6).Split(CChar("|"))(0)

                    If Me.InvokeRequired = True Then ' From another Thread
                        Me.Invoke(New MethodInvoker(Sub() _newComment = New CCANCommentUC(CInt(COMMENTID), CCANID, USERNAME, uDATE, uTIME, COMMENT)))
                        Me.Invoke(New MethodInvoker(Sub() AllComments_flp.Controls.Add(_newComment)))
                    Else
                        _newComment = New CCANCommentUC(CInt(COMMENTID), CCANID, USERNAME, uDATE, uTIME, COMMENT)
                        AllComments_flp.Controls.Add(_newComment)
                    End If

                Next

            Case "ToClient:CCAN:DeleteObjectStatus"
                Select Case oUserData(0).ToString
                    Case "ERROR"
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Fehler beim löschen deines Objektes. " & Environment.NewLine & "Details: " & oUserData(1).ToString)
                        _newMsg.ShowDialog()
                    Case "SUCCESS"
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Dein Objekt wurde gelöscht! Benutzer die die Liste der Objekte noch nicht aktualisiert haben, werden dein Objekt jedoch noch sehen können.")
                        _newMsg.ShowDialog()
                End Select

        End Select
    End Sub

#End Region

    Public Sub New(ByVal _CCANObject As CCANobject, ByVal _Comments As List(Of Object))
        InitializeComponent()

        If Not Networking.IsObjectNothing Then
            AddHandler Networking.UTC.UTicketArrived, AddressOf UTC_UTicketArrived
        End If

        CCANObject = _CCANObject
        Comments = _Comments
    End Sub
    Private Sub CCANObjectPreviewFrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If (CCANObject Is Nothing) Then ' If Nothing
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Fehler beim Laden der Informationen. System.NullReferenceException")
            _newMsg.ShowDialog()
            Me.Close()
        Else ' Else
            ' Set Informations
            Me.Text = "CCAN | " & CCANObject.GetTitle
            CCANtitle_lbl.Text = CCANObject.GetTitle
            CCANdesc_rtb.Text = CCANObject.GetDescription
            CCANauthor_lbl.Text = "Autor: " & CCANObject.GetAuthor
            CCANversion_lbl.Text = "Version: " & CCANObject.GetVersion
            CCANplayercount_lbl.Text = "Spieleranzahl: " & CCANObject.GetPlayerAmount
            Unready_lbl.Visible = CCANObject.GetState
            UploadDate_lbl.Text = "Hochgeladen am: " & CCANObject.GetUploadDate

            CCANgameversion_lbl.Text = "Spielversion: " & CCANObject.GetEngineCategory
            CCANcategory_lbl.Text = "Kategorie: " & CCANObject.GetFirstCategory & ", " & CCANObject.GetSecondCategory

            AverageRating_sr.Value = CCANObject.GetAverageRating

            ' Request Comments for this object
            Dim _data As New List(Of Object)
            _data.Add(CCANObject.GetUniqueObjectID)
            _data.Add(QClipboard.AccountName)

            AllComments_flp.Enabled = False
            LoadingComments_picbox.Visible = True

            Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:RequstComments", _data)

            If (CCANObject.GetAuthor = QClipboard.AccountName) Then
                DeleteObject_btn.Visible = True
            End If
        End If
    End Sub

    Private Sub comment_txtbox_TextChanged(sender As Object, e As EventArgs) Handles comment_txtbox.TextChanged
        Characters_mbar.Value = comment_txtbox.Text.Length
        If (comment_txtbox.Text.Length = comment_txtbox.MaxLength) Then
            Characters_mbar.ProgressColor = Color.Red
        Else
            If (Characters_mbar.Value >= comment_txtbox.MaxLength - 20) Then
                Characters_mbar.ProgressColor = Color.Goldenrod
            Else
                Characters_mbar.ProgressColor = Color.FromArgb(0, 122, 204)
            End If
        End If
    End Sub

    Private Sub ShowNewestFirst_chkbox_CheckedChanged(sender As Object, isChecked As Boolean) Handles ShowNewestFirst_chkbox.CheckedChanged
        If isChecked = True Then
            AllComments_flp.Enabled = False
            LoadingComments_picbox.Visible = True

            SortObjectComments(AllComments_flp)

            AllComments_flp.Enabled = True
            LoadingComments_picbox.Visible = False
        Else
            AllComments_flp.Enabled = False
            LoadingComments_picbox.Visible = True

            SortObjectComments(AllComments_flp, 1)

            AllComments_flp.Enabled = True
            LoadingComments_picbox.Visible = False
        End If
    End Sub

    Private Sub CCANauthor_lbl_Click(sender As Object, e As EventArgs) Handles CCANauthor_lbl.Click
        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Ein Profil für jeden Benutzer ist in den nächsten Updates geplant. Behalte immer den Clonk Discord im Auge, oder besuche die offizielle Entwicklerseite für den Clonk-Launcher Xtreme https://quixo-systems.jimdo.com/kategorien/programme/clonk-launcher-xtreme/.")
        _newMsg.ShowDialog()
    End Sub

    Private Sub DeleteObject_btn_Click(sender As Object, e As EventArgs) Handles DeleteObject_btn.Click
        If Not Deleted Then
            Using _SelectOpenClonkVersion As New CMessage(CMessage.Mode.YesNo, CMessage.MessageStyle.Nachricht, "Soll '" & CCANObject.GetTitle & "' wirklich vom Server gelöscht werden?")
                Dim dr As DialogResult
                dr = _SelectOpenClonkVersion.ShowDialog

                If dr = System.Windows.Forms.DialogResult.Yes Then
                    Dim _dData As New List(Of Object)
                    _dData.Add(CCANObject.GetUniqueObjectID)

                    Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:DeleteObject", _dData)

                    Deleted = True

                End If
            End Using
        End If
    End Sub

    Private Sub RateObject_btn_Click(sender As Object, e As EventArgs) Handles RateObject_btn.Click
        If QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym Then
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Um eine Bewertung senden zu können musst du angemeldet sein.")
            _newMsg.ShowDialog()
        Else
            If Not Deleted Then
                If String.IsNullOrWhiteSpace(comment_txtbox.Text) Then
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Nachricht, "Bitte Text eingeben.")
                    _newMsg.ShowDialog()
                Else
                    If comment_txtbox.Text.Contains("|") Then
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Falls folgendes Sonderzeichen enthalten ist; | muss dieses entfernt werden. Erlaubte Sonderzeichen: !?'%&/([(])}\=+-.,#*_:;<>")
                        _newMsg.ShowDialog()
                    Else
                        If Not ContainsOnlyRightChars(comment_txtbox.Text) Then
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, "Es wurde ein anderes, nicht erlaubtes Sonderzeichen gefunden. Erlaubte Sonderzeichen: !?'%&/([(])}\=+-.,#*_:;<>")
                            _newMsg.ShowDialog()
                        Else
                            If CommentRating_sr.Value = 0 Then
                                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte gebe eine Bewertung von 1 bis 5 ab.")
                                _newMsg.ShowDialog()
                            Else

                                _CommentNum = _CommentNum + 1 ' Comment Num

                                Dim _NewComment As New CCANCommentUC(_CommentNum, CCANObject.GetUniqueObjectID, QClipboard.AccountName, CStr(Date.Today), Date.Now.Hour & ":" & Date.Now.Minute, comment_txtbox.Text) ' Create CommentUC
                                AllComments_flp.Controls.Add(_NewComment) ' Add CommentUC

                                CommentsCount_lbl.Text = "Alle Bewertungen (" & AllComments_flp.Controls.Count & ")" ' Refresh Counter

                                Dim _Comment As New List(Of Object) ' Comment List
                                _Comment.Add(CCANObject.GetUniqueObjectID)
                                _Comment.Add(_CommentNum)
                                _Comment.Add(comment_txtbox.Text)
                                _Comment.Add(QClipboard.AccountName)
                                _Comment.Add(CommentRating_sr.Value.ToString)
                                _Comment.Add(CStr(Date.Today))
                                _Comment.Add(Date.Now.Hour & ":" & Date.Now.Minute)

                                ' Reset Text and other...
                                comment_txtbox.Text = ""
                                CommentRating_sr.Value = 0
                                Characters_mbar.Value = 0

                                ' Upload Comment
                                Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:WriteComment", _Comment)

                            End If
                        End If
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub download_btn_Click(sender As Object, e As EventArgs) Handles download_btn.Click
        Try
            If Main.CCANcopyInGameDir = True Then ' Copy in target Directory
                Select Case CCANObject.GetEngineCategory

                    Case "OpenClonk"
                        Using _SelectOpenClonkVersion As New CMessage(CMessage.Mode.OpenClonkVersionSelection, CMessage.MessageStyle.Nachricht, "Soll '" & CCANObject.GetTitle & "' in der 32-Bit OpenClonk Installation oder in der 64-Bit Installation gespeichert werden?")
                            Dim dr As DialogResult
                            dr = _SelectOpenClonkVersion.ShowDialog

                            If dr = System.Windows.Forms.DialogResult.Yes Then ' 64-Bit
                                If System.IO.Directory.Exists(".\Data\InstalledGames\OpenClonk") Then ' If game exists
                                    If Not System.IO.File.Exists(".\Data\InstalledGames\OpenClonk\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' If File doesnt exists

                                        System.IO.File.WriteAllBytes(".\Data\InstalledGames\OpenClonk\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension, CCANObject.GetFileBytes) ' Create File

                                        If System.IO.File.Exists(".\Data\InstalledGames\OpenClonk\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' Check if file was created
                                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "'" & CCANObject.GetTitle & "' wurde erfolgreich in 'OpenClonk' gespeichert!")
                                            _newMsg.ShowDialog()
                                        Else
                                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Unbekannter Fehler bem speichern von '" & CCANObject.GetTitle & "'")
                                            _newMsg.ShowDialog()
                                        End If

                                    Else
                                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da dieses schon existiert.")
                                        _newMsg.ShowDialog()
                                    End If
                                Else
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da OpenClonk Installation nicht existiert.")
                                    _newMsg.ShowDialog()
                                End If

                            ElseIf dr = System.Windows.Forms.DialogResult.No Then ' 32-Bit
                                If System.IO.Directory.Exists(".\Data\InstalledGames\OpenClonk_x86") Then ' If game exists
                                    If Not System.IO.File.Exists(".\Data\InstalledGames\OpenClonk_x86\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' If File doesnt exists

                                        System.IO.File.WriteAllBytes(".\Data\InstalledGames\OpenClonk_x86\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension, CCANObject.GetFileBytes) ' Create File

                                        If System.IO.File.Exists(".\Data\InstalledGames\OpenClonk_x86\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' Check if file was created
                                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "'" & CCANObject.GetTitle & "' wurde erfolgreich in 'OpenClonk_x86' gespeichert!")
                                            _newMsg.ShowDialog()
                                        Else
                                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Unbekannter Fehler bem speichern von '" & CCANObject.GetTitle & "'")
                                            _newMsg.ShowDialog()
                                        End If

                                    Else
                                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da dieses schon existiert.")
                                        _newMsg.ShowDialog()
                                    End If
                                Else
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da OpenClonk_x86 Installation nicht existiert.")
                                    _newMsg.ShowDialog()
                                End If

                            ElseIf dr = System.Windows.Forms.DialogResult.Cancel Then
                                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt wird nicht gespeichert da keine Auswahl getroffen wurde.")
                                _newMsg.ShowDialog()
                            End If

                        End Using

                    Case "Clonk Rage"
                        If System.IO.Directory.Exists(".\Data\InstalledGames\LegacyClonk") Then ' If game exists
                            If Not System.IO.File.Exists(".\Data\InstalledGames\LegacyClonk\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' If File doesnt exists

                                System.IO.File.WriteAllBytes(".\Data\InstalledGames\LegacyClonk\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension, CCANObject.GetFileBytes) ' Create File

                                If System.IO.File.Exists(".\Data\InstalledGames\LegacyClonk\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' Check if file was created
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "'" & CCANObject.GetTitle & "' wurde erfolgreich in 'Clonk Rage' gespeichert!")
                                    _newMsg.ShowDialog()
                                Else
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Unbekannter Fehler bem speichern von '" & CCANObject.GetTitle & "'")
                                    _newMsg.ShowDialog()
                                End If

                            Else
                                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da dieses schon existiert.")
                                _newMsg.ShowDialog()
                            End If
                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da Clonk Rage Installation nicht existiert.")
                            _newMsg.ShowDialog()
                        End If

                    Case "Clonk Endeavour"
                        If System.IO.Directory.Exists(".\Data\InstalledGames\Clonk Endeavour") Then ' If game exists
                            If Not System.IO.File.Exists(".\Data\InstalledGames\Clonk Endeavour\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' If File doesnt exists

                                System.IO.File.WriteAllBytes(".\Data\InstalledGames\Clonk Endeavour\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension, CCANObject.GetFileBytes) ' Create File

                                If System.IO.File.Exists(".\Data\InstalledGames\Clonk Endeavour\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' Check if file was created
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "'" & CCANObject.GetTitle & "' wurde erfolgreich in 'Clonk Endeavour' gespeichert!")
                                    _newMsg.ShowDialog()
                                Else
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Unbekannter Fehler bem speichern von '" & CCANObject.GetTitle & "'")
                                    _newMsg.ShowDialog()
                                End If

                            Else
                                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da dieses schon existiert.")
                                _newMsg.ShowDialog()
                            End If
                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da Clonk Endeavour Installation nicht existiert.")
                            _newMsg.ShowDialog()
                        End If

                    Case "Clonk Planet"
                        If System.IO.Directory.Exists(".\Data\InstalledGames\Clonk Planet") Then ' If game exists
                            If Not System.IO.File.Exists(".\Data\InstalledGames\Clonk Planet\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' If File doesnt exists

                                System.IO.File.WriteAllBytes(".\Data\InstalledGames\Clonk Planet\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension, CCANObject.GetFileBytes) ' Create File

                                If System.IO.File.Exists(".\Data\InstalledGames\Clonk Planet\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' Check if file was created
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "'" & CCANObject.GetTitle & "' wurde erfolgreich in 'Clonk Planet' gespeichert!")
                                    _newMsg.ShowDialog()
                                Else
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Unbekannter Fehler bem speichern von '" & CCANObject.GetTitle & "'")
                                    _newMsg.ShowDialog()
                                End If

                            Else
                                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da dieses schon existiert.")
                                _newMsg.ShowDialog()
                            End If
                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da Clonk Planet Installation nicht existiert.")
                            _newMsg.ShowDialog()
                        End If

                    Case "Clonk 4"
                        If System.IO.Directory.Exists(".\Data\InstalledGames\Clonk 4") Then ' If game exists
                            If Not System.IO.File.Exists(".\Data\InstalledGames\Clonk 4\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' If File doesnt exists

                                System.IO.File.WriteAllBytes(".\Data\InstalledGames\Clonk 4\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension, CCANObject.GetFileBytes) ' Create File

                                If System.IO.File.Exists(".\Data\InstalledGames\Clonk 4\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' Check if file was created
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "'" & CCANObject.GetTitle & "' wurde erfolgreich in 'Clonk 4' gespeichert!")
                                    _newMsg.ShowDialog()
                                Else
                                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Unbekannter Fehler bem speichern von '" & CCANObject.GetTitle & "'")
                                    _newMsg.ShowDialog()
                                End If

                            Else
                                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da dieses schon existiert.")
                                _newMsg.ShowDialog()
                            End If
                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da Clonk 4 Installation nicht existiert.")
                            _newMsg.ShowDialog()
                        End If

                    Case Else ' Support for other games
                        ' Not implemented

                End Select
            Else ' Copy in user choise directory

                Dim _fbd As New FolderBrowserDialog With {.Description = "Ordner auswählen wo '" & CCANObject.GetTitle & "' gespeichert werden soll.", .ShowNewFolderButton = True}
                If (_fbd.ShowDialog() = System.Windows.Forms.DialogResult.OK) Then

                    If Not System.IO.File.Exists(_fbd.SelectedPath & "\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' If File doesnt exists

                        System.IO.File.WriteAllBytes(_fbd.SelectedPath & "\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension, CCANObject.GetFileBytes) ' Create File

                        If System.IO.File.Exists(_fbd.SelectedPath & "\" & CCANObject.GetOriginalFilename & CCANObject.GetOriginalFileExtension) Then ' Check if file was created
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "'" & CCANObject.GetTitle & "' wurde erfolgreich in '" & _fbd.SelectedPath & "' gespeichert!")
                            _newMsg.ShowDialog()
                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Unbekannter Fehler bem speichern von '" & CCANObject.GetTitle & "'")
                            _newMsg.ShowDialog()
                        End If

                    Else
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Das Objekt kann nicht gespeichert werden da dieses schon existiert.")
                        _newMsg.ShowDialog()
                    End If

                End If

            End If
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Fehler beim speichern von '" & CCANObject.GetTitle & "'" & Environment.NewLine & ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

End Class