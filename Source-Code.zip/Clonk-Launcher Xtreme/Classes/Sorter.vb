﻿Option Strict On
Imports System.IO

Public Class Sorter
    Implements IComparer
    Public Function CompareDesc(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
        Dim F1 As String = DirectCast(x, CCANObjectPreviewUC).CCANObject.GetUploadDateWithoutTime
        Dim F2 As String = DirectCast(y, CCANObjectPreviewUC).CCANObject.GetUploadDateWithoutTime
        CompareDesc = DateTime.Compare(CType(F1, Date), Date.Today)
    End Function
End Class
