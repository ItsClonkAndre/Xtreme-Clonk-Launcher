﻿Option Strict On
Imports UniversalTicket

Public Class Networking

    Public Shared UTC As UTicketClient
    Public Shared OpenedIP As String

    Public Shared Function Initialize(Optional ByVal DEBUGMODE As Boolean = False, Optional ByVal OpenIP As String = "- OPEN SERVER IP HERE -") As Boolean ' Must be called first
        Try
            If Debugger.IsAttached Or DEBUGMODE = True Then

                Using _SelectionMsg As New CMessage(CMessage.Mode.DebugNetworkSelection, CMessage.MessageStyle.Nachricht, "DEBUG: Should the loopback IP (127.0.0.1) be used or the server IP (- Enter local test server ip here -) ?") ' Select between Loobpack and Server-IP
                    Dim _dresult As DialogResult
                    _dresult = _SelectionMsg.ShowDialog

                    If _dresult = DialogResult.Yes Then ' Server-IP
                        UTC = New UTicketClient("- Enter local test server ip here -", 7346, "- Enter Server password here -") ' Debug
                        OpenedIP = "- Enter local test server ip here -"
                        Return True
                    ElseIf _dresult = DialogResult.No Then ' Loopback
                        UTC = New UTicketClient("127.0.0.1", 7346, "- Enter Server password here -") ' Debug
                        OpenedIP = "127.0.0.1"
                        Return True
                    End If

                End Using

            Else
                UTC = New UTicketClient(OpenIP, 7346, "- Enter Server password here -") ' Server
                OpenedIP = OpenIP
                Return True
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function IsObjectNothing() As Boolean
        If (UTC Is Nothing) Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Shared Function IsServerAvailable() As Boolean
        Try
            If (UTC Is Nothing) Then
                Return False
            Else
                Return UTC.isServerAvailable
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function IsConnectionAlive() As Boolean
        Try
            If (UTC Is Nothing) Then
                Return False
            Else
                Return UTC.isConnectionAlive
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Sub GetOpenedIP()
        MessageBox.Show(OpenedIP)
    End Sub

    Public Shared Sub Shutdown()
        Try
            If Not (UTC Is Nothing) Then
                UTC.shutdown()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Network shutdown", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class
