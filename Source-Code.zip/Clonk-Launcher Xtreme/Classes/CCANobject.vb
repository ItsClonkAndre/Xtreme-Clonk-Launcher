﻿Option Strict On
<Serializable()>
Public Class CCANobject

    ' File
    Private FileBytes() As Byte
    Private OriginalFilename As String
    Private OriginalFileExtension As String

    ' Object
    Private oTitle As String
    Private oDescription As String
    Private oAuthor As String
    Private oVersion As String
    Private oPlayerAmount As String
    Private Unfinished As Boolean
    Private UniqueObjectID As String
    Private UploadDate As String

    ' Rating
    Private AverageRating As Integer
    Private PeopleRated As Integer

    ' Category
    Private oEngineVersion As String
    Private oFirstCategory As String
    Private oSecondCategory As String

    Public Sub New(ByVal _Title As String, ByVal _Description As String, ByVal _author As String, ByVal _ObjectVersion As String, ByVal _oCCANfirstCategory As String, ByVal _oCCANsecondCategory As String, ByVal _GameVersion As String, ByVal _Unfinished As Boolean, ByVal _PlayerAmount As String, ByVal _PeopleRated As Integer, ByVal _AverageRating As Integer, ByVal _UploadDate As String, ByVal _UniqueObjectID As String, ByVal _OriginalFilename As String, ByVal _OriginalFileExtension As String, ByVal _FileBytes() As Byte)
        ' File
        FileBytes = _FileBytes
        OriginalFileExtension = _OriginalFileExtension
        OriginalFilename = _OriginalFilename

        ' Object
        oTitle = _Title
        oDescription = _Description
        oAuthor = _author
        oVersion = _ObjectVersion
        oPlayerAmount = _PlayerAmount
        Unfinished = _Unfinished
        UniqueObjectID = _UniqueObjectID
        UploadDate = _UploadDate

        ' Rating
        AverageRating = _AverageRating
        PeopleRated = _PeopleRated

        ' Category
        oEngineVersion = _GameVersion
        oFirstCategory = _oCCANfirstCategory
        oSecondCategory = _oCCANsecondCategory
    End Sub

    ' File
    Public Function GetFileBytes() As Byte()
        Try
            Return FileBytes
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Function GetOriginalFilename() As String
        Return OriginalFilename
    End Function
    Public Function GetOriginalFileExtension() As String
        Return OriginalFileExtension
    End Function

    ' Object
    Public Function GetTitle() As String
        Return OTitle
    End Function
    Public Function GetDescription() As String
        Return ODescription
    End Function
    Public Function GetAuthor() As String
        Return OAuthor
    End Function
    Public Function GetVersion() As String
        Return OVersion
    End Function
    Public Function GetState() As Boolean
        Return unfinished
    End Function
    Public Function GetPlayerAmount() As String
        Return OPlayerAmount
    End Function
    Public Function GetUniqueObjectID() As String
        Return UniqueObjectID
    End Function

    Public Function GetUploadDate() As String
        Return UploadDate
    End Function
    Public Function GetUploadDateWithoutTime() As String
        Return UploadDate.Split(CChar("-"))(0)
    End Function

    ' Rating
    Public Function GetAverageRating() As Integer
        Try
            Return AverageRating
        Catch ex As Exception
            Return 0
        End Try
    End Function
    Public Function GetPeopleRated() As Integer
        Return PeopleRated
    End Function

    ' Category
    Public Function GetFirstCategory() As String
        Return oFirstCategory
    End Function
    Public Function GetSecondCategory() As String
        Return oSecondCategory
    End Function
    Public Function GetEngineCategory() As String
        Return oEngineVersion
    End Function

End Class
