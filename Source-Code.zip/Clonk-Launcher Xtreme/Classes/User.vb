﻿Option Strict On
Public Class User

    Private Enum UserStatus
        Online
        Offline
        Banned
    End Enum

    Private uUsername As String
    Private uPassword As String
    Private uID As String
    Private uStatus As UserStatus = UserStatus.Offline

    Public Sub New(ByVal _uUsername As String, ByVal _uPassword As String)
        Me.uUsername = _uUsername
        Me.uPassword = _uPassword
    End Sub

    Public Function GetUsername() As String
        Return uUsername
    End Function
    Public Function GetUID() As String
        Return uID
    End Function

    Public Function IsBanned() As Boolean
        Return uStatus = UserStatus.Banned
    End Function
    Public Function isOnline() As Boolean
        Return uStatus = UserStatus.Online
    End Function

    Public Function ComparePassword(ByVal InputPassword As String) As Boolean ' IMPORT ENCRYPTER.DLL
        Return uPassword = InputPassword
    End Function

    Public Sub SetOnline(ByVal UID As String)
        Me.uID = UID
        Me.uStatus = UserStatus.Online
    End Sub
    Public Sub SetOffline()
        Me.uID = Nothing
        Me.uStatus = UserStatus.Offline
    End Sub

    Public Sub BanUser()
        Me.uID = Nothing
        Me.uStatus = UserStatus.Banned
    End Sub

End Class
