﻿Option Strict On
Imports System
Imports System.Drawing
Imports System.Runtime.InteropServices

Public Class API_GetPixelColor

    <DllImport("user32.dll")>
    Private Shared Function GetDC(ByVal hwnd As IntPtr) As IntPtr
    End Function
    <DllImport("user32.dll")>
    Private Shared Function ReleaseDC(ByVal hwnd As IntPtr, ByVal hdc As IntPtr) As Int32
    End Function
    <DllImport("gdi32.dll")>
    Private Shared Function GetPixel(ByVal hdc As IntPtr, ByVal nXPos As Integer, ByVal nYPos As Integer) As UInteger
    End Function

    Public Shared Function GetPixelColor(ByVal x As Integer, ByVal y As Integer) As Color
        Dim hdc As IntPtr = GetDC(IntPtr.Zero)
        Dim pixel As UInteger = GetPixel(hdc, x, y)
        ReleaseDC(IntPtr.Zero, hdc)

        Dim color As Color = color.FromArgb(CInt((pixel) And &HFF), CInt((pixel >> 8) And &HFF), CInt((pixel >> 16) And &HFF))

        Return color
    End Function

End Class
