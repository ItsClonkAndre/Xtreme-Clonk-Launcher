﻿Option Strict On
Public Class QClipboard

    Public Enum LoginMode
        Anonym
        User
    End Enum

    ' Account
    Public Shared LoggedOnMode As LoginMode
    Public Shared AccountName As String
    Public Shared AccountEmail As String
    Public Shared AccountPassword As String

    ' Program
    Public Shared LinuxMode As Boolean

    ' Language
    Public Shared LanguageTable As New Hashtable
    Public Shared SelectedLanguage As String

End Class
