﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CInputBox
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CInputBox))
        Me.message_lbl = New Xtreme_Clonk_Launcher.TransparentRichTextBox()
        Me.input_txtbox = New MetroSuite.MetroTextbox()
        Me.abort_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.accept_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.SuspendLayout()
        '
        'message_lbl
        '
        Me.message_lbl.BackColor = System.Drawing.Color.Transparent
        Me.message_lbl.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.message_lbl.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.message_lbl.ForeColor = System.Drawing.Color.White
        Me.message_lbl.Image = Nothing
        Me.message_lbl.Location = New System.Drawing.Point(12, 31)
        Me.message_lbl.Name = "message_lbl"
        Me.message_lbl.ReadOnly = True
        Me.message_lbl.Size = New System.Drawing.Size(328, 65)
        Me.message_lbl.TabIndex = 6
        Me.message_lbl.Text = "MESSAGE"
        '
        'input_txtbox
        '
        Me.input_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.input_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.input_txtbox.DefaultColor = System.Drawing.Color.White
        Me.input_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.input_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.input_txtbox.ForeColor = System.Drawing.Color.Black
        Me.input_txtbox.HideSelection = False
        Me.input_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.input_txtbox.Location = New System.Drawing.Point(12, 102)
        Me.input_txtbox.Name = "input_txtbox"
        Me.input_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.input_txtbox.Size = New System.Drawing.Size(328, 23)
        Me.input_txtbox.TabIndex = 9
        '
        'abort_btn
        '
        Me.abort_btn.BackColor = System.Drawing.Color.Transparent
        Me.abort_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.abort_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.abort_btn.DefaultColor = System.Drawing.Color.White
        Me.abort_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.abort_btn.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.abort_btn.HoverColor = System.Drawing.Color.White
        Me.abort_btn.LanguageKey = "CINPUTBOX:ABORT"
        Me.abort_btn.Location = New System.Drawing.Point(346, 64)
        Me.abort_btn.Name = "abort_btn"
        Me.abort_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.abort_btn.RoundingArc = 28
        Me.abort_btn.Size = New System.Drawing.Size(112, 28)
        Me.abort_btn.TabIndex = 10
        Me.abort_btn.Text = "Abbrechen"
        '
        'accept_btn
        '
        Me.accept_btn.BackColor = System.Drawing.Color.Transparent
        Me.accept_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.accept_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.accept_btn.DefaultColor = System.Drawing.Color.White
        Me.accept_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.accept_btn.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.accept_btn.HoverColor = System.Drawing.Color.White
        Me.accept_btn.LanguageKey = "CINPUTBOX:OK"
        Me.accept_btn.Location = New System.Drawing.Point(346, 98)
        Me.accept_btn.Name = "accept_btn"
        Me.accept_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.accept_btn.RoundingArc = 28
        Me.accept_btn.Size = New System.Drawing.Size(112, 28)
        Me.accept_btn.TabIndex = 11
        Me.accept_btn.Text = "Ok"
        '
        'CInputBox
        '
        Me.AllowResize = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(470, 137)
        Me.Controls.Add(Me.accept_btn)
        Me.Controls.Add(Me.abort_btn)
        Me.Controls.Add(Me.input_txtbox)
        Me.Controls.Add(Me.message_lbl)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CInputBox"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "CInputBox"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents message_lbl As Xtreme_Clonk_Launcher.TransparentRichTextBox
    Friend WithEvents input_txtbox As MetroSuite.MetroTextbox
    Friend WithEvents abort_btn As MetroTranslatorButton
    Friend WithEvents accept_btn As MetroTranslatorButton
End Class
