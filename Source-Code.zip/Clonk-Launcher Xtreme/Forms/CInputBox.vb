﻿Option Strict On
Imports MetroSuite.Extension
Imports MetroSuite
Imports MadMilkman.Ini

Public Class CInputBox : Inherits MetroSuite.MetroForm

#Region "Theme"

    Public Sub ApplyTheme()
        Try
            Dim myTheme As New Styles.Themes.MetroSuiteTheme
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            If IO.File.Exists(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme")) Then ' If file exists
                myTheme = myTheme.FromFile(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme"))
            Else ' If not
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

#End Region

#Region " Functions "

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

    Private Sub ApplyLanguage()
        Try
            For Each _cntrl As Control In ListControls(Me)
                If _cntrl.GetType().Name = "MetroTranslatorLabel" Then
                    DirectCast(_cntrl, MetroTranslatorLabel).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorButton" Then
                    DirectCast(_cntrl, MetroTranslatorButton).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorChecker" Then
                    DirectCast(_cntrl, MetroTranslatorChecker).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorTextbox" Then
                    DirectCast(_cntrl, MetroTranslatorTextbox).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "ClassicTranslatorRadioButton" Then
                    DirectCast(_cntrl, ClassicTranslatorRadioButton).ApplyLanguage()
                End If
            Next
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub
    Private Function ListControls(ByVal control As Control) As IEnumerable(Of Control)
        Dim ctrl As IEnumerable(Of Control) = control.Controls.Cast(Of Control)()
        Return ctrl.Concat(ctrl.SelectMany(AddressOf ListControls))
    End Function

#End Region

    Private Sub CInputBox_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ApplyTheme() ' Set Theme
        ApplyLanguage() ' Applys Language
    End Sub

    Protected ReturnedText As String = ""

    Public Function ShowInputBox(ByVal TitleText As String, ByVal PromptText As String, Optional ByVal DefaultText As String = Nothing, Optional ByVal InputWatermark As String = ". . .", Optional ByVal PasswordChar As String = Nothing) As String
        Me.Text = TitleText
        message_lbl.Text = PromptText
        input_txtbox.Watermark = InputWatermark
        input_txtbox.Text = DefaultText
        input_txtbox.PasswordChar = CChar(PasswordChar)

        Me.ShowDialog()
        Return ReturnedText
    End Function

    Private Sub accept_btn_Click(sender As Object, e As EventArgs) Handles accept_btn.Click
        If Not String.IsNullOrWhiteSpace(input_txtbox.Text) Then
            ReturnedText = input_txtbox.Text
            Me.Dispose()
        End If
    End Sub

    Private Sub abort_btn_Click(sender As Object, e As EventArgs) Handles abort_btn.Click
        ReturnedText = Nothing
        Me.Dispose()
    End Sub

End Class