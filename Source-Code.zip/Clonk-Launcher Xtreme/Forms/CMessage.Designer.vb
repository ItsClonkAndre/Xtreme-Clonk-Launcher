﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CMessage
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CMessage))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.command1_btn = New MetroSuite.MetroButton()
        Me.command2_btn = New MetroSuite.MetroButton()
        Me.message_lbl = New Xtreme_Clonk_Launcher.TransparentRichTextBox()
        Me.MetroProgressbar1 = New MetroSuite.MetroProgressbar()
        Me.controlbox_pnl.SuspendLayout()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(440, 2)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(28, 27)
        Me.controlbox_pnl.TabIndex = 1
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(10, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'command1_btn
        '
        Me.command1_btn.BackColor = System.Drawing.Color.Transparent
        Me.command1_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.command1_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.command1_btn.DefaultColor = System.Drawing.Color.White
        Me.command1_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.command1_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.command1_btn.ForeColor = System.Drawing.Color.Black
        Me.command1_btn.HoverColor = System.Drawing.Color.White
        Me.command1_btn.Location = New System.Drawing.Point(366, 145)
        Me.command1_btn.Name = "command1_btn"
        Me.command1_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.command1_btn.RoundingArc = 23
        Me.command1_btn.Size = New System.Drawing.Size(92, 23)
        Me.command1_btn.TabIndex = 3
        Me.command1_btn.Text = "MetroButton1"
        Me.command1_btn.Visible = False
        '
        'command2_btn
        '
        Me.command2_btn.BackColor = System.Drawing.Color.Transparent
        Me.command2_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.command2_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.command2_btn.DefaultColor = System.Drawing.Color.White
        Me.command2_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.command2_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.command2_btn.ForeColor = System.Drawing.Color.Black
        Me.command2_btn.HoverColor = System.Drawing.Color.White
        Me.command2_btn.Location = New System.Drawing.Point(268, 145)
        Me.command2_btn.Name = "command2_btn"
        Me.command2_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.command2_btn.RoundingArc = 23
        Me.command2_btn.Size = New System.Drawing.Size(92, 23)
        Me.command2_btn.TabIndex = 4
        Me.command2_btn.Text = "MetroButton2"
        Me.command2_btn.Visible = False
        '
        'message_lbl
        '
        Me.message_lbl.BackColor = System.Drawing.Color.Transparent
        Me.message_lbl.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.message_lbl.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.message_lbl.ForeColor = System.Drawing.Color.White
        Me.message_lbl.Image = Nothing
        Me.message_lbl.Location = New System.Drawing.Point(12, 31)
        Me.message_lbl.Name = "message_lbl"
        Me.message_lbl.ReadOnly = True
        Me.message_lbl.Size = New System.Drawing.Size(446, 108)
        Me.message_lbl.TabIndex = 5
        Me.message_lbl.Text = "MESSAGE"
        '
        'MetroProgressbar1
        '
        Me.MetroProgressbar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MetroProgressbar1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.MetroProgressbar1.DefaultColor = System.Drawing.Color.White
        Me.MetroProgressbar1.GradientColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(163, Byte), Integer))
        Me.MetroProgressbar1.Location = New System.Drawing.Point(12, 145)
        Me.MetroProgressbar1.Name = "MetroProgressbar1"
        Me.MetroProgressbar1.ProgressColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroProgressbar1.RoundingArc = 23
        Me.MetroProgressbar1.Size = New System.Drawing.Size(446, 23)
        Me.MetroProgressbar1.TabIndex = 6
        Me.MetroProgressbar1.Value = 0
        Me.MetroProgressbar1.Visible = False
        '
        'CMessage
        '
        Me.AllowResize = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(470, 180)
        Me.Controls.Add(Me.message_lbl)
        Me.Controls.Add(Me.command2_btn)
        Me.Controls.Add(Me.command1_btn)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Controls.Add(Me.MetroProgressbar1)
        Me.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "CMessage"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "Nachricht"
        Me.TopMost = True
        Me.controlbox_pnl.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Friend WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents command1_btn As MetroSuite.MetroButton
    Friend WithEvents command2_btn As MetroSuite.MetroButton
    Friend WithEvents message_lbl As Xtreme_Clonk_Launcher.TransparentRichTextBox
    Friend WithEvents MetroProgressbar1 As MetroSuite.MetroProgressbar
End Class
