﻿Option Strict On
Imports MetroSuite.Extension
Imports MetroSuite
Imports MadMilkman.Ini
Imports System.ComponentModel
Imports System.Text.RegularExpressions
Imports System.Text

Public Class CMessage : Inherits MetroSuite.MetroForm

    Public Enum Mode
        OpenClonkVersionSelection
        DebugNetworkSelection
        Loading
        OkOnly
        YesNo
    End Enum
    Public Enum MessageStyle
        Nachricht
        Information
        _Error
        Attention
        Wait
    End Enum

    Private _SelectedMode As Mode
    Private _SelectedMessageStyle As MessageStyle
    Private _Message As String
    Public Sub New(ByVal SelectedMode As Mode, ByVal SelectedMessageStyle As MessageStyle, ByVal Message As String)
        InitializeComponent()
        _SelectedMode = SelectedMode
        _SelectedMessageStyle = SelectedMessageStyle
        _Message = Message
    End Sub

#Region " Functions "

    Public Sub ApplyTheme()
        Try
            Dim myTheme As New Styles.Themes.MetroSuiteTheme
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            If IO.File.Exists(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme")) Then ' If file exists
                myTheme = myTheme.FromFile(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme"))
            Else ' If not
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

    Public Function GetSpecificLanguageString(ByVal Key As String) As String
        Try
            For Each Entry As DictionaryEntry In QClipboard.LanguageTable
                If String.Equals(CStr(Entry.Key), Key) = True Then
                    Return Entry.Value.ToString
                    Exit Function
                End If
            Next
            Return "Not found"
        Catch ex As Exception
            Return "ERROR"
        End Try
    End Function

    Public Function Coding(ByVal InputText As String, Optional ByVal ReplaceWith As String = "NEWSTRING") As String
        Select Case True
            Case InputText.Contains("%s")
                Return InputText.Replace("%s", ReplaceWith) ' Replace with new string
            Case InputText.Contains("<br>")
                Return InputText.Replace("<br>", Environment.NewLine) ' Replace with new line
            Case InputText.Contains("<ReturnFromFile:>") And InputText.Contains("<End>")
                Try
                    Dim m As MatchCollection = Regex.Matches(InputText, "<ReturnFromFile:>(.+?)<End>") ' GetFileName
                    Return System.IO.File.ReadAllText(MakeLinuxCompatible(".\Data\Language\" & m(0).Groups(1).Value), Encoding.UTF8) ' ReadFileFromFilename
                Catch ex As Exception
                    Return "Error while reading text from file at: " & InputText & Environment.NewLine & "Details: " & ex.Message
                End Try
            Case Else
                Return InputText
        End Select
    End Function

#End Region

#Region "ControlBox"

    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Dispose()
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

#End Region

    Private Sub message_lbl_LinkClicked(sender As Object, e As LinkClickedEventArgs) Handles message_lbl.LinkClicked
        Select Case MessageBox.Show(Coding(GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_OPENLINKTEXT"), e.LinkText.ToString), GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_OPENLINKTITLE"), MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            Case System.Windows.Forms.DialogResult.Yes
                Process.Start(e.LinkText.ToString)
        End Select
    End Sub
    Private Sub CMessage_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If (e.CloseReason = CloseReason.UserClosing) Then
            If _SelectedMode = Mode.Loading Then
                e.Cancel = True
            Else
                e.Cancel = False
            End If
        ElseIf (e.CloseReason = CloseReason.TaskManagerClosing) Then
            If _SelectedMode = Mode.Loading Then
                e.Cancel = True
            Else
                e.Cancel = False
            End If
        End If
    End Sub
    Private Sub CMessage_Load(sender As Object, e As EventArgs) Handles Me.Load
        ApplyTheme() ' Set Theme

        ' SetText
        message_lbl.Text = _Message

        Select Case _SelectedMessageStyle
            Case MessageStyle.Nachricht
                Me.Text = GetSpecificLanguageString("CMESSAGEBOX:TITLE_MESSAGE")
            Case MessageStyle.Information
                Me.Text = GetSpecificLanguageString("CMESSAGEBOX:TITLE_INFORMATION")
            Case MessageStyle.Attention
                Me.Text = GetSpecificLanguageString("CMESSAGEBOX:TITLE_CAUTION")
            Case MessageStyle._Error
                Me.Text = GetSpecificLanguageString("CMESSAGEBOX:TITLE_ERROR")
            Case MessageStyle.Wait
                Me.Text = GetSpecificLanguageString("CMESSAGEBOX:TITLE_PLEASEWAIT")
        End Select

        Select Case _SelectedMode
            Case Mode.OkOnly
                command1_btn.Text = GetSpecificLanguageString("CMESSAGEBOX:OK")
                command1_btn.Visible = True
            Case Mode.YesNo
                command1_btn.Text = GetSpecificLanguageString("CMESSAGEBOX:YES")
                command2_btn.Text = GetSpecificLanguageString("CMESSAGEBOX:NO")
                command1_btn.Visible = True
                command2_btn.Visible = True
            Case Mode.OpenClonkVersionSelection
                command1_btn.Text = "64-Bit"
                command2_btn.Text = "32-Bit"
                command1_btn.Visible = True
                command2_btn.Visible = True
            Case Mode.DebugNetworkSelection
                command1_btn.Text = "Server-IP"
                command2_btn.Text = "Loopback"
                command1_btn.Visible = True
                command2_btn.Visible = True
            Case Mode.Loading
                controlbox_pnl.Visible = False
                MetroProgressbar1.Visible = True
        End Select
    End Sub

    Private Sub MetroProgressbar1_ProgressChanged(sender As Object, Value As Integer) Handles MetroProgressbar1.ProgressChanged
        If (Value = MetroProgressbar1.Maximum) Then
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Dispose()
        End If
    End Sub

    Private Sub command1_btn_Click(sender As Object, e As EventArgs) Handles command1_btn.Click
        Select Case _SelectedMode
            Case Mode.OkOnly
                Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
                Me.Dispose()
            Case Mode.YesNo
                Me.DialogResult = System.Windows.Forms.DialogResult.Yes
                Me.Dispose()
            Case Mode.OpenClonkVersionSelection
                Me.DialogResult = System.Windows.Forms.DialogResult.Yes
                Me.Dispose()
            Case Mode.DebugNetworkSelection
                Me.DialogResult = System.Windows.Forms.DialogResult.Yes
                Me.Dispose()
        End Select
    End Sub

    Private Sub command2_btn_Click(sender As Object, e As EventArgs) Handles command2_btn.Click
        Select Case _SelectedMode
            Case Mode.YesNo
                Me.DialogResult = System.Windows.Forms.DialogResult.No
                Me.Dispose()
            Case Mode.OpenClonkVersionSelection
                Me.DialogResult = System.Windows.Forms.DialogResult.No
                Me.Dispose()
            Case Mode.DebugNetworkSelection
                Me.DialogResult = System.Windows.Forms.DialogResult.No
                Me.Dispose()
        End Select
    End Sub

End Class