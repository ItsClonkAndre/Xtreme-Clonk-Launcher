﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CCANObjectPreviewUC
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.title_lbl = New MetroSuite.MetroLabel()
        Me.ViewObject_btn = New MetroSuite.MetroButton()
        Me.MetroLabel25 = New MetroSuite.MetroLabel()
        Me.ClonkEngine_lbl = New MetroSuite.MetroLabel()
        Me.PlayerCount_lbl = New MetroSuite.MetroLabel()
        Me.Category_lbl = New MetroSuite.MetroLabel()
        Me.Unready_lbl = New MetroSuite.MetroLabel()
        Me.DateAndTime_lbl = New MetroSuite.MetroLabel()
        Me.Rating_sr = New Xtreme_Clonk_Launcher.StarRating()
        Me.Type_picbox = New System.Windows.Forms.PictureBox()
        CType(Me.Type_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'title_lbl
        '
        Me.title_lbl.BackColor = System.Drawing.Color.Gainsboro
        Me.title_lbl.Dock = System.Windows.Forms.DockStyle.Top
        Me.title_lbl.Font = New System.Drawing.Font("Segoe UI Semibold", 12.25!, System.Drawing.FontStyle.Bold)
        Me.title_lbl.Location = New System.Drawing.Point(0, 0)
        Me.title_lbl.Name = "title_lbl"
        Me.title_lbl.Size = New System.Drawing.Size(918, 23)
        Me.title_lbl.TabIndex = 2
        Me.title_lbl.Text = "TITEL"
        '
        'ViewObject_btn
        '
        Me.ViewObject_btn.BackColor = System.Drawing.Color.Transparent
        Me.ViewObject_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ViewObject_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ViewObject_btn.DefaultColor = System.Drawing.Color.White
        Me.ViewObject_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ViewObject_btn.Dock = System.Windows.Forms.DockStyle.Right
        Me.ViewObject_btn.Font = New System.Drawing.Font("Arial", 10.75!, System.Drawing.FontStyle.Bold)
        Me.ViewObject_btn.HoverColor = System.Drawing.Color.White
        Me.ViewObject_btn.Location = New System.Drawing.Point(918, 0)
        Me.ViewObject_btn.Name = "ViewObject_btn"
        Me.ViewObject_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ViewObject_btn.RoundingArc = 65
        Me.ViewObject_btn.Size = New System.Drawing.Size(79, 65)
        Me.ViewObject_btn.TabIndex = 3
        Me.ViewObject_btn.Text = "Ansehen"
        '
        'MetroLabel25
        '
        Me.MetroLabel25.AutoSize = True
        Me.MetroLabel25.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel25.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel25.ForeColor = System.Drawing.Color.Black
        Me.MetroLabel25.Location = New System.Drawing.Point(16, 32)
        Me.MetroLabel25.Name = "MetroLabel25"
        Me.MetroLabel25.Size = New System.Drawing.Size(140, 15)
        Me.MetroLabel25.TabIndex = 4
        Me.MetroLabel25.Text = "Durchschnittsbewertung:"
        '
        'ClonkEngine_lbl
        '
        Me.ClonkEngine_lbl.AutoSize = True
        Me.ClonkEngine_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEngine_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClonkEngine_lbl.ForeColor = System.Drawing.Color.Black
        Me.ClonkEngine_lbl.Location = New System.Drawing.Point(255, 32)
        Me.ClonkEngine_lbl.Name = "ClonkEngine_lbl"
        Me.ClonkEngine_lbl.Size = New System.Drawing.Size(39, 15)
        Me.ClonkEngine_lbl.TabIndex = 6
        Me.ClonkEngine_lbl.Text = "Für: ..."
        '
        'PlayerCount_lbl
        '
        Me.PlayerCount_lbl.AutoSize = True
        Me.PlayerCount_lbl.BackColor = System.Drawing.Color.Transparent
        Me.PlayerCount_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.PlayerCount_lbl.ForeColor = System.Drawing.Color.Black
        Me.PlayerCount_lbl.Location = New System.Drawing.Point(379, 32)
        Me.PlayerCount_lbl.Name = "PlayerCount_lbl"
        Me.PlayerCount_lbl.Size = New System.Drawing.Size(78, 15)
        Me.PlayerCount_lbl.TabIndex = 7
        Me.PlayerCount_lbl.Text = "Spielerzahl: ..."
        '
        'Category_lbl
        '
        Me.Category_lbl.AutoSize = True
        Me.Category_lbl.BackColor = System.Drawing.Color.Transparent
        Me.Category_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Category_lbl.ForeColor = System.Drawing.Color.Black
        Me.Category_lbl.Location = New System.Drawing.Point(516, 32)
        Me.Category_lbl.Name = "Category_lbl"
        Me.Category_lbl.Size = New System.Drawing.Size(187, 15)
        Me.Category_lbl.TabIndex = 8
        Me.Category_lbl.Text = "Kategorie: KATEGORIE, KATEGORIE"
        '
        'Unready_lbl
        '
        Me.Unready_lbl.AutoSize = True
        Me.Unready_lbl.BackColor = System.Drawing.Color.Transparent
        Me.Unready_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Unready_lbl.ForeColor = System.Drawing.Color.Red
        Me.Unready_lbl.Location = New System.Drawing.Point(832, 36)
        Me.Unready_lbl.Name = "Unready_lbl"
        Me.Unready_lbl.Size = New System.Drawing.Size(50, 15)
        Me.Unready_lbl.TabIndex = 9
        Me.Unready_lbl.Text = "Unfertig"
        Me.Unready_lbl.Visible = False
        '
        'DateAndTime_lbl
        '
        Me.DateAndTime_lbl.AutoSize = True
        Me.DateAndTime_lbl.BackColor = System.Drawing.Color.Transparent
        Me.DateAndTime_lbl.Font = New System.Drawing.Font("Segoe UI", 7.0!)
        Me.DateAndTime_lbl.ForeColor = System.Drawing.Color.Black
        Me.DateAndTime_lbl.Location = New System.Drawing.Point(1, 52)
        Me.DateAndTime_lbl.Name = "DateAndTime_lbl"
        Me.DateAndTime_lbl.Size = New System.Drawing.Size(81, 12)
        Me.DateAndTime_lbl.TabIndex = 15
        Me.DateAndTime_lbl.Text = "00.00.0000 - 00:00"
        '
        'Rating_sr
        '
        Me.Rating_sr.Location = New System.Drawing.Point(162, 32)
        Me.Rating_sr.Name = "Rating_sr"
        Me.Rating_sr.NotClickable = True
        Me.Rating_sr.Size = New System.Drawing.Size(75, 15)
        Me.Rating_sr.StarCount = 5
        Me.Rating_sr.StarGold = Nothing
        Me.Rating_sr.StarGray = Nothing
        Me.Rating_sr.StarHeight = 15
        Me.Rating_sr.StarWidth = 15
        Me.Rating_sr.TabIndex = 5
        Me.Rating_sr.Value = 0
        '
        'Type_picbox
        '
        Me.Type_picbox.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.clonk_help
        Me.Type_picbox.Location = New System.Drawing.Point(888, 32)
        Me.Type_picbox.Name = "Type_picbox"
        Me.Type_picbox.Size = New System.Drawing.Size(24, 24)
        Me.Type_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Type_picbox.TabIndex = 16
        Me.Type_picbox.TabStop = False
        '
        'CCANObjectPreviewUC
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Controls.Add(Me.Type_picbox)
        Me.Controls.Add(Me.DateAndTime_lbl)
        Me.Controls.Add(Me.Unready_lbl)
        Me.Controls.Add(Me.Category_lbl)
        Me.Controls.Add(Me.PlayerCount_lbl)
        Me.Controls.Add(Me.ClonkEngine_lbl)
        Me.Controls.Add(Me.Rating_sr)
        Me.Controls.Add(Me.MetroLabel25)
        Me.Controls.Add(Me.title_lbl)
        Me.Controls.Add(Me.ViewObject_btn)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Name = "CCANObjectPreviewUC"
        Me.Size = New System.Drawing.Size(997, 65)
        CType(Me.Type_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents title_lbl As MetroSuite.MetroLabel
    Friend WithEvents ViewObject_btn As MetroSuite.MetroButton
    Friend WithEvents MetroLabel25 As MetroSuite.MetroLabel
    Friend WithEvents Rating_sr As Xtreme_Clonk_Launcher.StarRating
    Friend WithEvents ClonkEngine_lbl As MetroSuite.MetroLabel
    Friend WithEvents PlayerCount_lbl As MetroSuite.MetroLabel
    Friend WithEvents Category_lbl As MetroSuite.MetroLabel
    Friend WithEvents Unready_lbl As MetroSuite.MetroLabel
    Friend WithEvents DateAndTime_lbl As MetroSuite.MetroLabel
    Friend WithEvents Type_picbox As System.Windows.Forms.PictureBox

End Class
