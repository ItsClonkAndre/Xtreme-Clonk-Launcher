﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewsUC
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ReadMore_btn = New MetroSuite.MetroButton()
        Me.From_lbl = New MetroSuite.MetroLabel()
        Me.Title_lbl = New MetroSuite.MetroLabel()
        Me.SuspendLayout()
        '
        'ReadMore_btn
        '
        Me.ReadMore_btn.BackColor = System.Drawing.Color.Transparent
        Me.ReadMore_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ReadMore_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ReadMore_btn.DefaultColor = System.Drawing.Color.White
        Me.ReadMore_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ReadMore_btn.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ReadMore_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ReadMore_btn.HoverColor = System.Drawing.Color.White
        Me.ReadMore_btn.Location = New System.Drawing.Point(0, 77)
        Me.ReadMore_btn.Name = "ReadMore_btn"
        Me.ReadMore_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ReadMore_btn.RoundingArc = 23
        Me.ReadMore_btn.Size = New System.Drawing.Size(202, 23)
        Me.ReadMore_btn.TabIndex = 0
        Me.ReadMore_btn.Text = "Mehr darüber..."
        '
        'From_lbl
        '
        Me.From_lbl.BackColor = System.Drawing.Color.Transparent
        Me.From_lbl.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.From_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.From_lbl.Location = New System.Drawing.Point(0, 61)
        Me.From_lbl.Name = "From_lbl"
        Me.From_lbl.Size = New System.Drawing.Size(202, 16)
        Me.From_lbl.TabIndex = 1
        Me.From_lbl.Text = "Vom: 08.02.2020 - 19:45"
        Me.From_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Title_lbl
        '
        Me.Title_lbl.BackColor = System.Drawing.Color.Transparent
        Me.Title_lbl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Title_lbl.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Title_lbl.Location = New System.Drawing.Point(0, 0)
        Me.Title_lbl.Name = "Title_lbl"
        Me.Title_lbl.Size = New System.Drawing.Size(202, 61)
        Me.Title_lbl.TabIndex = 2
        Me.Title_lbl.Text = "TITEL"
        Me.Title_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NewsUC
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.Title_lbl)
        Me.Controls.Add(Me.From_lbl)
        Me.Controls.Add(Me.ReadMore_btn)
        Me.Name = "NewsUC"
        Me.Size = New System.Drawing.Size(202, 100)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReadMore_btn As MetroSuite.MetroButton
    Friend WithEvents From_lbl As MetroSuite.MetroLabel
    Friend WithEvents Title_lbl As MetroSuite.MetroLabel

End Class
