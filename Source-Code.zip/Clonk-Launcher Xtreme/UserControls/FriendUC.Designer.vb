﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FriendUC
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.user_picbox = New System.Windows.Forms.PictureBox()
        Me.username_lbl = New MetroSuite.MetroLabel()
        Me.OpenPrivateChat_btn = New System.Windows.Forms.Button()
        CType(Me.user_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'user_picbox
        '
        Me.user_picbox.Dock = System.Windows.Forms.DockStyle.Left
        Me.user_picbox.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.clonk_user_unknown
        Me.user_picbox.Location = New System.Drawing.Point(0, 0)
        Me.user_picbox.Name = "user_picbox"
        Me.user_picbox.Size = New System.Drawing.Size(40, 50)
        Me.user_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.user_picbox.TabIndex = 11
        Me.user_picbox.TabStop = False
        '
        'username_lbl
        '
        Me.username_lbl.BackColor = System.Drawing.Color.Transparent
        Me.username_lbl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.username_lbl.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.username_lbl.ForeColor = System.Drawing.Color.White
        Me.username_lbl.Location = New System.Drawing.Point(40, 0)
        Me.username_lbl.Name = "username_lbl"
        Me.username_lbl.Size = New System.Drawing.Size(148, 32)
        Me.username_lbl.TabIndex = 12
        Me.username_lbl.Text = "Anonym"
        Me.username_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'OpenPrivateChat_btn
        '
        Me.OpenPrivateChat_btn.BackColor = System.Drawing.Color.DarkGray
        Me.OpenPrivateChat_btn.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.OpenPrivateChat_btn.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.OpenPrivateChat_btn.ForeColor = System.Drawing.Color.Black
        Me.OpenPrivateChat_btn.Location = New System.Drawing.Point(40, 32)
        Me.OpenPrivateChat_btn.Name = "OpenPrivateChat_btn"
        Me.OpenPrivateChat_btn.Size = New System.Drawing.Size(148, 18)
        Me.OpenPrivateChat_btn.TabIndex = 13
        Me.OpenPrivateChat_btn.Text = "Chat öffnen"
        Me.OpenPrivateChat_btn.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.OpenPrivateChat_btn.UseVisualStyleBackColor = False
        '
        'FriendUC
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Controls.Add(Me.username_lbl)
        Me.Controls.Add(Me.OpenPrivateChat_btn)
        Me.Controls.Add(Me.user_picbox)
        Me.Margin = New System.Windows.Forms.Padding(1, 3, 3, 3)
        Me.Name = "FriendUC"
        Me.Size = New System.Drawing.Size(188, 50)
        CType(Me.user_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents user_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents username_lbl As MetroSuite.MetroLabel
    Friend WithEvents OpenPrivateChat_btn As System.Windows.Forms.Button

End Class
