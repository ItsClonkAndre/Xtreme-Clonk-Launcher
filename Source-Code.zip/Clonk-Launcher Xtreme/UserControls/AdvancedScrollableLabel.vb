﻿Imports MetroSuite
Imports System.ComponentModel
Imports System.Drawing.Design
Public Class AdvancedScrollableLabel : Inherits MetroSuite.MetroTextbox

    Private Const INPUTTEXT_DEFAULT_VALUE As String = Nothing
    Private _inputtext As String = INPUTTEXT_DEFAULT_VALUE
    <Editor("System.ComponentModel.Design.MultilineStringEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", GetType(UITypeEditor))>
    <Browsable(True), DefaultValue(INPUTTEXT_DEFAULT_VALUE), Description("Hier Text eingeben der dem Benutzer angezeigt werden soll. (MultiLine)")>
    Public Property InputText As String
        Get
            Return _inputtext
        End Get
        Set(value As String)
            _inputtext = value
            Me.Text = value
        End Set
    End Property

    Public Sub New()
        Me.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.ReadOnly = True
        Me.Multiline = True
    End Sub

End Class
