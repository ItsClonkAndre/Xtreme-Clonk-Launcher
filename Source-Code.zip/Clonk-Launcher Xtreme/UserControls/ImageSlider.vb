﻿Imports System
Imports System.Collections.Generic
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Text
Imports System.Windows.Forms

Class ImageSlider
    Inherits Panel

    Private _timer As Timer
    Private _captionTextLeft As Integer = 20
    Private _captionPosX As Integer = 20
    Private _pageIndex As Integer = 0
    Protected _imageList As List(Of Image) = New List(Of Image)()
    Protected _captionList As List(Of String) = New List(Of String)()
    Protected _captionBgColor As List(Of Color) = New List(Of Color)()
    Private leftButton As xButton
    Private rightButton As xButton

    Public Sub New()
        Me.Animation = True
        Me.CaptionAnimationSpeed = 50
        Me.CaptionTextLeft = 20
        Me.CaptionHeight = 50
        Me.CaptionBackgrounColor = Color.Black
        Me.CaptionOpacity = 100
        leftButton = New xButton()
        leftButton.Text = "<"
        leftButton.ForeColor = Color.White
        AddHandler leftButton.Click, New EventHandler(AddressOf leftButton_Click)
        rightButton = New xButton()
        rightButton.Text = ">"
        rightButton.ForeColor = Color.White
        AddHandler rightButton.Click, New EventHandler(AddressOf rightButton_Click)
        AddHandler Me.Resize, AddressOf ImageSlider_Resize
        Me.Controls.Add(leftButton)
        Me.Controls.Add(rightButton)
    End Sub

    Private Sub ImageSlider_Resize(ByVal sender As Object, ByVal e As EventArgs)
        leftButton.Location = New Point(0, (Me.Height / 2) - (leftButton.Height / 2))
        rightButton.Location = New Point(Me.Width - rightButton.Width, (Me.Height / 2) - (rightButton.Height / 2))
    End Sub

    Private Sub leftButton_Click(ByVal sender As Object, ByVal e As EventArgs)
        If _pageIndex > 0 Then
            _pageIndex -= 1
        Else
            _pageIndex = _imageList.Count - 1
        End If

        If Animation Then
            _captionPosX = Me.Width
            Me.DoubleBuffered = True
            _timer = New Timer()
            _timer.Interval = 1
            AddHandler _timer.Tick, New EventHandler(AddressOf _timer_Tick)
            _timer.Start()
        Else
            _captionPosX = _captionTextLeft
            Me.Invalidate()
        End If
    End Sub

    Private Sub rightButton_Click(ByVal sender As Object, ByVal e As EventArgs)
        If _pageIndex < _imageList.Count - 1 Then
            _pageIndex += 1
        Else
            _pageIndex = 0
        End If

        If Animation Then
            _captionPosX = Me.Width
            DoubleBuffered = True
            _timer = New Timer()
            _timer.Interval = 1
            AddHandler _timer.Tick, New EventHandler(AddressOf _timer_Tick)
            _timer.Start()
        Else
            _captionPosX = _captionTextLeft
            Me.Invalidate()
        End If
    End Sub

    Private Sub _timer_Tick(ByVal sender As Object, ByVal e As EventArgs)
        If _captionPosX >= _captionTextLeft Then
            Dim subtract As Integer = CaptionAnimationSpeed
            Dim diff As Integer = _captionPosX - subtract

            If diff < subtract Then
                _captionPosX -= _captionPosX - _captionTextLeft
            Else
                _captionPosX -= subtract
            End If

            Me.Invalidate()
        Else
            Me.DoubleBuffered = False
            _timer.Dispose()
        End If
    End Sub

    Public Sub AddImageViaFile(ByVal path As String)
        Dim img As Image = Image.FromFile(path)
        _AddImage(img, "", Me.CaptionBackgrounColor)
    End Sub

    Public Sub AddImageViaFile(ByVal path As String, ByVal caption As String)
        Dim img As Image = Image.FromFile(path)
        _AddImage(img, caption, Me.CaptionBackgrounColor)
    End Sub

    Public Sub AddImageViaFile(ByVal path As String, ByVal caption As String, ByVal captionBackgroundColor As Color)
        Dim img As Image = Image.FromFile(path)
        _AddImage(img, caption, captionBackgroundColor)
    End Sub

    Public Sub AddImage(ByVal img As Image)
        _AddImage(img, "", Me.CaptionBackgrounColor)
    End Sub

    Public Sub AddImage(ByVal img As Image, ByVal caption As String)
        _AddImage(img, caption, Me.CaptionBackgrounColor)
    End Sub

    Public Sub AddImage(ByVal img As Image, ByVal caption As String, ByVal captionBackgroundColor As Color)
        _AddImage(img, caption, captionBackgroundColor)
    End Sub

    Public Sub NextImage()
        If _pageIndex < _imageList.Count - 1 Then
            _pageIndex += 1
        Else
            _pageIndex = 0
        End If

        If Animation Then
            _captionPosX = Me.Width
            DoubleBuffered = True
            _timer = New Timer()
            _timer.Interval = 1
            AddHandler _timer.Tick, New EventHandler(AddressOf _timer_Tick)
            _timer.Start()
        Else
            _captionPosX = _captionTextLeft
            Me.Invalidate()
        End If
    End Sub

    Protected Sub _AddImage(ByVal img As Image, ByVal caption As String, ByVal captionBackgroundColor As Color)
        _imageList.Add(img)
        _captionList.Add(caption)
        _captionBgColor.Add(captionBackgroundColor)
    End Sub

    Public Property CaptionHeight As Integer

    Public Property CaptionTextLeft As Integer
        Set(ByVal value As Integer)
            _captionPosX = value
            _captionTextLeft = value
        End Set
        Get
            Return _captionTextLeft
        End Get
    End Property

    Public Property CaptionBackgrounColor As Color
    Public Property CaptionOpacity As Integer
    Public Property CaptionAnimationSpeed As Integer
    Public Property Animation As Boolean

    Public ReadOnly Property _LeftButton As xButton
        Get
            Return _LeftButton
        End Get
    End Property

    Public ReadOnly Property _RightButton As xButton
        Get
            Return _RightButton
        End Get
    End Property

    Public ReadOnly Property GetCurrentImageIndex As Integer
        Get
            Return _pageIndex
        End Get
    End Property

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        MyBase.OnPaint(e)
        Dim g As Graphics = e.Graphics

        Try
            Dim captionBgColor As Color = Color.FromArgb(CaptionOpacity, _captionBgColor(_pageIndex).R, _captionBgColor(_pageIndex).G, _captionBgColor(_pageIndex).B)
            g.DrawImage(_imageList(_pageIndex), New Rectangle(0, 0, Me.Width, Me.Height))
            g.FillRectangle(New SolidBrush(captionBgColor), New Rectangle(0, Me.Height - Me.CaptionHeight, Me.Width, Me.Height))
            Dim caption As String = _captionList(_pageIndex)
            Dim fontSize As SizeF = g.MeasureString(_captionList(_pageIndex), Me.Font)
            g.DrawString(_captionList(_pageIndex), Me.Font, New SolidBrush(Me.ForeColor), _captionPosX, Me.Height - CInt((Me.CaptionHeight - (fontSize.Height / 2))))
        Catch
        End Try
    End Sub

    Public Class xButton
        Inherits Button

        Public Sub New()
            Me.BackColor = Color.Black
            Me.Height = 50
            Me.Width = 50
        End Sub

        Protected Overrides Sub OnPaint(ByVal pevent As PaintEventArgs)
            Dim g As Graphics = pevent.Graphics
            Dim area As Rectangle = New Rectangle(0, 0, Me.Width, Me.Height)
            g.FillRectangle(New SolidBrush(Me.BackColor), area)
            Dim fontSize As SizeF = g.MeasureString(Me.Text, Me.Font)
            g.DrawString(Me.Text, Me.Font, New SolidBrush(Me.ForeColor), (Me.Width - fontSize.Width) / 2, (Me.Height - fontSize.Height) / 2)
        End Sub
    End Class
End Class

