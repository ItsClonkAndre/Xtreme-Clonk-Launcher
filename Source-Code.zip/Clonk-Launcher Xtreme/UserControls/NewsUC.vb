﻿Option Strict On
Imports MetroSuite
Imports Gecko
Public Class NewsUC

    Private NewsID As String
    Private Title As String
    Private DateTime As String
    Private YouTubeVideoLink As String
    Private Desc As String
    Public Sub New(ByVal _Title As String, ByVal _Desc As String, ByVal _YouTubeVideoLink As String, ByVal _DateTime As String, ByVal _NewsID As String)
        InitializeComponent()
        Title = _Title
        DateTime = _DateTime
        NewsID = _NewsID
        Desc = _Desc
        YouTubeVideoLink = _YouTubeVideoLink
    End Sub

    Private Sub NewsUC_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' Set Text
        Title_lbl.Text = Title
        From_lbl.Text = "Vom: " & DateTime
    End Sub

    Private Sub ReadMore_btn_Click(sender As Object, e As EventArgs) Handles ReadMore_btn.Click
        Main.NewsPanel_pnl.Visible = True
        Main.NewsTitle_lbl.Text = Title
        Main.NewsDesc_lbl.InputText = Desc
    End Sub
End Class
