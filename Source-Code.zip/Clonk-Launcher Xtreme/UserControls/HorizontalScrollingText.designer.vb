﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HorizontalScrollingText
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ScrollingTextLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ScrollingTextLabel
        '
        Me.ScrollingTextLabel.AutoSize = True
        Me.ScrollingTextLabel.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ScrollingTextLabel.ForeColor = System.Drawing.Color.Black
        Me.ScrollingTextLabel.Location = New System.Drawing.Point(44, 9)
        Me.ScrollingTextLabel.Name = "ScrollingTextLabel"
        Me.ScrollingTextLabel.Size = New System.Drawing.Size(32, 15)
        Me.ScrollingTextLabel.TabIndex = 0
        Me.ScrollingTextLabel.Text = "TEXT"
        '
        'HorizontalScrollingText
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.ScrollingTextLabel)
        Me.Name = "HorizontalScrollingText"
        Me.Size = New System.Drawing.Size(120, 32)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ScrollingTextLabel As Label
End Class
