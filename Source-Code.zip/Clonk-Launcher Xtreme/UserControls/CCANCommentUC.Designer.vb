﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CCANCommentUC
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.delete_btn = New MetroSuite.MetroButton()
        Me.Info_lbl = New System.Windows.Forms.Label()
        Me.Comment_lbl = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.delete_btn)
        Me.Panel1.Controls.Add(Me.Info_lbl)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(888, 20)
        Me.Panel1.TabIndex = 1
        '
        'delete_btn
        '
        Me.delete_btn.BackColor = System.Drawing.Color.Transparent
        Me.delete_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.delete_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.delete_btn.DefaultColor = System.Drawing.Color.White
        Me.delete_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.delete_btn.Dock = System.Windows.Forms.DockStyle.Right
        Me.delete_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.delete_btn.ForeColor = System.Drawing.Color.Red
        Me.delete_btn.HoverColor = System.Drawing.Color.White
        Me.delete_btn.Location = New System.Drawing.Point(831, 0)
        Me.delete_btn.Name = "delete_btn"
        Me.delete_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.delete_btn.RoundingArc = 18
        Me.delete_btn.Size = New System.Drawing.Size(55, 18)
        Me.delete_btn.TabIndex = 1
        Me.delete_btn.Text = "Löschen"
        Me.delete_btn.Visible = False
        '
        'Info_lbl
        '
        Me.Info_lbl.AutoSize = True
        Me.Info_lbl.Location = New System.Drawing.Point(1, 1)
        Me.Info_lbl.Name = "Info_lbl"
        Me.Info_lbl.Size = New System.Drawing.Size(220, 15)
        Me.Info_lbl.TabIndex = 0
        Me.Info_lbl.Text = "ClonkAndre am 01.01.2020 um 00:00 Uhr"
        '
        'Comment_lbl
        '
        Me.Comment_lbl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Comment_lbl.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Comment_lbl.DefaultColor = System.Drawing.Color.White
        Me.Comment_lbl.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Comment_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Comment_lbl.HideSelection = False
        Me.Comment_lbl.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Comment_lbl.InputText = ""
        Me.Comment_lbl.Location = New System.Drawing.Point(0, 20)
        Me.Comment_lbl.Multiline = True
        Me.Comment_lbl.Name = "Comment_lbl"
        Me.Comment_lbl.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Comment_lbl.ReadOnly = True
        Me.Comment_lbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Comment_lbl.Size = New System.Drawing.Size(888, 37)
        Me.Comment_lbl.TabIndex = 2
        Me.Comment_lbl.Text = "TEXT"
        '
        'CCANCommentUC
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.Controls.Add(Me.Comment_lbl)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Name = "CCANCommentUC"
        Me.Size = New System.Drawing.Size(888, 57)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Info_lbl As System.Windows.Forms.Label
    Friend WithEvents Comment_lbl As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
    Friend WithEvents delete_btn As MetroSuite.MetroButton

End Class
