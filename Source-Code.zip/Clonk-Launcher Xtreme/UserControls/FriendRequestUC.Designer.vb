﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FriendRequestUC
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Accept_btn = New MetroSuite.MetroButton()
        Me.discard_btn = New MetroSuite.MetroButton()
        Me.text_lbl = New MetroSuite.MetroLabel()
        Me.SuspendLayout()
        '
        'Accept_btn
        '
        Me.Accept_btn.BackColor = System.Drawing.Color.Transparent
        Me.Accept_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Accept_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Accept_btn.DefaultColor = System.Drawing.Color.White
        Me.Accept_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Accept_btn.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.Accept_btn.ForeColor = System.Drawing.Color.Green
        Me.Accept_btn.HoverColor = System.Drawing.Color.White
        Me.Accept_btn.Location = New System.Drawing.Point(0, 48)
        Me.Accept_btn.Name = "Accept_btn"
        Me.Accept_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Accept_btn.RoundingArc = 23
        Me.Accept_btn.Size = New System.Drawing.Size(87, 23)
        Me.Accept_btn.TabIndex = 0
        Me.Accept_btn.Text = "Annehmen"
        '
        'discard_btn
        '
        Me.discard_btn.BackColor = System.Drawing.Color.Transparent
        Me.discard_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.discard_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.discard_btn.DefaultColor = System.Drawing.Color.White
        Me.discard_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.discard_btn.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.discard_btn.ForeColor = System.Drawing.Color.Red
        Me.discard_btn.HoverColor = System.Drawing.Color.White
        Me.discard_btn.Location = New System.Drawing.Point(87, 48)
        Me.discard_btn.Name = "discard_btn"
        Me.discard_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.discard_btn.RoundingArc = 23
        Me.discard_btn.Size = New System.Drawing.Size(87, 23)
        Me.discard_btn.TabIndex = 1
        Me.discard_btn.Text = "Ablehnen"
        '
        'text_lbl
        '
        Me.text_lbl.BackColor = System.Drawing.Color.Transparent
        Me.text_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.text_lbl.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.text_lbl.ForeColor = System.Drawing.Color.Black
        Me.text_lbl.Location = New System.Drawing.Point(3, 1)
        Me.text_lbl.Name = "text_lbl"
        Me.text_lbl.Size = New System.Drawing.Size(168, 45)
        Me.text_lbl.TabIndex = 2
        Me.text_lbl.Text = "%USERNAME% möchte dein Freund sein"
        Me.text_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FriendRequestUC
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.text_lbl)
        Me.Controls.Add(Me.discard_btn)
        Me.Controls.Add(Me.Accept_btn)
        Me.Name = "FriendRequestUC"
        Me.Size = New System.Drawing.Size(174, 71)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Accept_btn As MetroSuite.MetroButton
    Friend WithEvents discard_btn As MetroSuite.MetroButton
    Friend WithEvents text_lbl As MetroSuite.MetroLabel

End Class
