﻿Option Strict On

' ContextMenuStrip
Public Class ModernContextMenuStrip : Inherits ContextMenuStrip

    Public Enum Styles
        Light
        Dark
    End Enum

#Region " Propertys "

    Private SelectedStyleValue As Styles = Styles.Light
    Public Property Style() As Styles
        Get
            Return SelectedStyleValue
        End Get
        Set(ByVal value As Styles)
            SelectedStyleValue = value ' SetValue

            ' SetStyle
            Select Case value
                Case Styles.Light
                    Me.BackColor = Color.FromArgb(255, 255, 255, 255)
                    Me.ForeColor = Color.FromArgb(0, 0, 0)
                Case Styles.Dark
                    Me.BackColor = Color.FromArgb(255, 30, 30, 30)
                    Me.ForeColor = Color.FromArgb(255, 255, 255)
            End Select

        End Set
    End Property

#End Region

    Public Sub New()
        ' Set Propertys for Control
        Me.Font = New Font("Segoe UI", 9.75)
        Me.RenderMode = ToolStripRenderMode.System
        Me.ShowItemToolTips = False

        ' Set Style
        Select Case SelectedStyleValue
            Case Styles.Light
                Me.BackColor = Color.FromArgb(255, 255, 255, 255)
                Me.ForeColor = Color.FromArgb(0, 0, 0)
            Case Styles.Dark
                Me.BackColor = Color.FromArgb(255, 30, 30, 30)
                Me.ForeColor = Color.FromArgb(255, 255, 255)
        End Select
    End Sub
End Class

' ToolStripMenuItem
Public Class ModernToolStripMenuItem : Inherits ToolStripMenuItem

    Public Enum Styles
        Light
        Dark
    End Enum

#Region " Propertys "

    Public Property OnMouseHoverForeColor As Color = Color.FromArgb(255, 255, 255)
    Public Property OnMouseHoverDrawBold As Boolean = True

    Private SelectedStyleValue As Styles = Styles.Light
    Public Property Style() As Styles
        Get
            Return SelectedStyleValue
        End Get
        Set(ByVal value As Styles)
            SelectedStyleValue = value ' SetValue

            ' SetStyle
            Select Case value
                Case Styles.Light
                    Me.BackColor = Color.FromArgb(255, 255, 255, 255)
                    Me.ForeColor = Color.FromArgb(0, 0, 0)
                Case Styles.Dark
                    Me.BackColor = Color.FromArgb(255, 30, 30, 30)
                    Me.ForeColor = Color.FromArgb(255, 255, 255)
            End Select

        End Set
    End Property

#End Region

    Public Sub New()
        ' Set Propertys for Control
        Me.Padding = New Padding(0, 3, 0, 3)
        Me.Font = New Font("Segoe UI", 9.75)

        ' Set Style
        Select Case SelectedStyleValue
            Case Styles.Light
                Me.BackColor = Color.FromArgb(255, 255, 255, 255)
                Me.ForeColor = Color.FromArgb(0, 0, 0)
            Case Styles.Dark
                Me.BackColor = Color.FromArgb(255, 30, 30, 30)
                Me.ForeColor = Color.FromArgb(255, 255, 255)
        End Select
    End Sub

    Private Sub ModernToolStripMenuItem_MouseEnter(sender As Object, e As EventArgs) Handles Me.MouseEnter
        Me.ForeColor = Me.OnMouseHoverForeColor

        If OnMouseHoverDrawBold = True Then
            Me.Font = New Font(Me.Font.FontFamily.Name, Me.Font.Size, FontStyle.Bold)
        Else
            Me.Font = New Font(Me.Font.FontFamily.Name, 9.75)
        End If
    End Sub

    Private Sub ModernToolStripMenuItem_MouseLeave(sender As Object, e As EventArgs) Handles Me.MouseLeave
        Me.Font = New Font(Me.Font.FontFamily.Name, Me.Font.Size)
        Select Case SelectedStyleValue
            Case Styles.Light
                Me.ForeColor = Color.FromArgb(0, 0, 0)
            Case Styles.Dark
                Me.ForeColor = Color.FromArgb(255, 255, 255)
        End Select
    End Sub

End Class
