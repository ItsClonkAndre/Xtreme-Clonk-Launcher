﻿Public Class FriendUC

End Class
