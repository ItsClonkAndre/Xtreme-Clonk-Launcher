﻿Option Strict On
Imports MetroSuite
Public Class PictureBoxClickAnimation : Inherits PictureBox

    Private clickanimation As New MetroSuite.Components.MetroAnimator
    Private mballon As New MetroSuite.MetroBalloon
    Public Property ShowBallon As Boolean = True
    Public Property AnimationSpeed As Integer = 40
    Public Property AnimationColor As Color = Color.FromArgb(100, 64, 64, 64)

    Public Sub New()
        ' Set Click Animation
        clickanimation.AnimationColor = AnimationColor
        clickanimation.ClickControl = Me
        clickanimation.Speed = AnimationSpeed
    End Sub

    Private Sub PictureBoxClickAnimation_MouseEnter(sender As Object, e As EventArgs) Handles Me.MouseEnter
        If ShowBallon = True Then
            mballon.ShowBalloon("Zum Anzeigen der Neuigkeit auf diesem Bild klicken.", MousePosition)
        End If
    End Sub

End Class
