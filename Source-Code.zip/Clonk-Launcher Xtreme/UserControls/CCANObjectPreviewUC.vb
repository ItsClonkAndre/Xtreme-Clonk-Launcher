﻿Option Strict On
Public Class CCANObjectPreviewUC

    Public Property CCANObject As CCANobject
    Public Property Comments As List(Of Object)

    'Public Sub New(ByVal Title As String, ByVal AverageRating As Integer, ByVal GameEngine As String, ByVal PlayerCount As String, ByVal Category As String, ByVal DateAndTime As String, ByVal ObjectID As String, ByVal Unfinished As Boolean, ByVal _CCANObject As CCANobject)
    '    InitializeComponent()

    '    Me.CCANObject = _CCANObject

    '    title_lbl.Text = Title
    '    Author_lbl.Text = "Autor: " & CCANObject.GetAuthor
    '    Rating_sr.Value = AverageRating
    '    ClonkEngine_lbl.Text = "Für: " & GameEngine
    '    PlayerCount_lbl.Text = "Spielerzahl: " & PlayerCount
    '    Category_lbl.Text = "Kategorie: " & Category
    '    DateAndTime_lbl.Text = DateAndTime & " - " & ObjectID
    '    Unready_lbl.Visible = Unfinished
    'End Sub

    Public Sub New(ByVal _CCANObject As CCANobject, ByVal _Comments As List(Of Object))
        InitializeComponent()

        Me.CCANObject = _CCANObject
        Me.Comments = _Comments

        title_lbl.Text = CCANObject.GetTitle
        Rating_sr.Value = CCANObject.GetAverageRating
        ClonkEngine_lbl.Text = "Für: " & CCANObject.GetEngineCategory
        PlayerCount_lbl.Text = "Spielerzahl: " & CCANObject.GetPlayerAmount
        Category_lbl.Text = "Kategorie: " & CCANObject.GetFirstCategory & ", " & CCANObject.GetSecondCategory
        DateAndTime_lbl.Text = "Hochgeladen am: " & CCANObject.GetUploadDate & " | ID: " & CCANObject.GetUniqueObjectID & " | Autor: " & CCANObject.GetAuthor
        Unready_lbl.Visible = CCANObject.GetState
        Rating_sr.Value = CCANObject.GetAverageRating

        ' Image
        Select Case CCANObject.GetFirstCategory
            Case "Szenario"
                Type_picbox.Image = My.Resources.ccan_szenarios
            Case "Objekt"
                Type_picbox.Image = My.Resources.ccan_object
            Case "Dokument"
                Type_picbox.Image = My.Resources.ccan_other
            Case "Komplettpaket (.zip)"
                Type_picbox.Image = My.Resources.clonk_zipfile
        End Select

    End Sub

    Private Sub ViewObject_btn_Click(sender As Object, e As EventArgs) Handles ViewObject_btn.Click
        Dim ShowObject As New CCANObjectPreviewFrm(Me.CCANObject, Me.Comments)
        ShowObject.ShowDialog()
    End Sub

End Class
