﻿Option Strict On
Public Class MetroTranslatorTextbox : Inherits MetroSuite.MetroTextbox

#Region " Functions "

    Private Function Coding(ByVal input As String) As String
        If input.Contains("<br>") Then
            Return input.Replace("<br>", Environment.NewLine) ' Linebreak
        Else
            Return input
        End If
    End Function

#End Region

    Public Property LanguageKey As String ' Usage: SECTION:KEY

    Public Sub New()
        Me.Font = New Font("Segoe UI", 9)
    End Sub

    Public Sub ApplyLanguage() ' Only for Watermark
        Try
            If String.IsNullOrWhiteSpace(LanguageKey) Then
                Me.Watermark = "Error: LanguageKey is empty!"
            Else

                For Each Entry As DictionaryEntry In QClipboard.LanguageTable
                    If String.Equals(CStr(Entry.Key), LanguageKey) = True Then
                        Me.Watermark = Coding(CStr(Entry.Value))
                        Exit For
                    Else
                        Me.Watermark = Coding("Loading...")
                    End If
                Next

            End If
        Catch ex As Exception
            Me.Watermark = ex.Message ' Shows error message
        End Try
    End Sub


End Class
