﻿Option Strict On
Public Class HorizontalScrollingText

    Private tmr As New Timer

    Public Enum sStyle
        Light
        Dark
        Custom
    End Enum

#Region " Propertys "

    Private _Speed As Integer = 15
    Public Property ScrollSpeed() As Integer
        Get
            Return _Speed
        End Get
        Set(ByVal value As Integer)
            _Speed = value ' SetValue
        End Set
    End Property

    Private _Step As Integer = 1
    Public Property Stepping() As Integer
        Get
            Return _Step
        End Get
        Set(ByVal value As Integer)
            _Step = value ' SetValue
        End Set
    End Property

    Private _InputText As String = "TEXT"
    Public Property InputText() As String
        Get
            Return _InputText
        End Get
        Set(ByVal value As String)
            _InputText = value ' SetValue
            ScrollingTextLabel.Text = value
        End Set
    End Property

    Private _Style As sStyle
    Public Property Style() As sStyle
        Get
            Return _Style
        End Get
        Set(ByVal value As sStyle)
            _Style = value ' SetValue

            Select Case value
                Case sStyle.Light
                    Me.BackColor = Color.White
                    Me.ScrollingTextLabel.ForeColor = Color.Black
                Case sStyle.Dark
                    Me.BackColor = Color.FromArgb(64, 64, 64)
                    Me.ScrollingTextLabel.ForeColor = Color.White
            End Select

        End Set
    End Property

    Private _TextColor As Color = Color.White
    Public Property TextColor() As Color
        Get
            Return _TextColor
        End Get
        Set(ByVal value As Color)
            _TextColor = value ' SetValue

            If (_Style = sStyle.Custom) Then
                ScrollingTextLabel.ForeColor = value
            End If

        End Set
    End Property

#End Region

    Public Sub New()
        InitializeComponent()

        ' Label
        Me.BackColor = Color.Transparent
        ScrollingTextLabel.ForeColor = Color.Black
        ScrollingTextLabel.Location = New Point(42, 8)

        ' Timer
        tmr.Interval = _Speed

        AddHandler tmr.Tick, AddressOf Timer_Tick
    End Sub

    Public Sub StartScrolling()
        tmr.Start()
    End Sub

    Public Sub StopScrolling()
        tmr.Stop()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        If ScrollingTextLabel.Right < 0 Then
            ScrollingTextLabel.Left = Me.ClientSize.Width
        Else
            ScrollingTextLabel.Left -= _Step
        End If
    End Sub
   
End Class
