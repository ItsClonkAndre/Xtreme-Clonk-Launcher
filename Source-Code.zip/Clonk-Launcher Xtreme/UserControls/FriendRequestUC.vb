﻿Option Strict On
Public Class FriendRequestUC

    Private _Username As String = "%USERNAME%"
    Public Property Username() As String
        Get
            Return _Username
        End Get
        Set(ByVal value As String)
            _Username = value ' SetValue
            text_lbl.Text = value & " möchte dein Freund sein"
        End Set
    End Property

    Private Sub Accept_btn_Click(sender As Object, e As EventArgs) Handles Accept_btn.Click
        If Networking.IsConnectionAlive Then
            Networking.UTC.sendUTicket("ADMIN", "ToServer:AcceptFriendRequest", _Username)
        End If
    End Sub

    Private Sub discard_btn_Click(sender As Object, e As EventArgs) Handles discard_btn.Click
        If Networking.IsConnectionAlive Then
            Networking.UTC.sendUTicket("ADMIN", "ToServer:DeclineFriendRequest", _Username)
        End If
    End Sub
End Class
