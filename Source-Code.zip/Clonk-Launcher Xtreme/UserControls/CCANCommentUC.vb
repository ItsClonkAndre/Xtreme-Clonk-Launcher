﻿Option Strict On
Public Class CCANCommentUC

    Public Property uDate As String
    Private Deleted As Boolean
    Private sSender As String
    Private ObjectID As String
    Private CommentID As Integer

    Public Sub New(ByVal _CommentID As Integer, ByVal _ObjectID As String, ByVal _Sender As String, ByVal _Date As String, ByVal _Time As String, ByVal _Comment As String)
        InitializeComponent()

        If (_Sender = QClipboard.AccountName) Then ' Delete Button
            delete_btn.Visible = True
        End If

        Comment_lbl.Dock = DockStyle.Fill
        'Comment_lbl.Size = New Size(888, 37)

        uDate = _Date
        sSender = _Sender
        ObjectID = _ObjectID
        CommentID = _CommentID

        Info_lbl.Text = _Sender & " am " & _Date & " um " & _Time
        Comment_lbl.Text = _Comment
    End Sub

    Private Sub delete_btn_Click(sender As Object, e As EventArgs) Handles delete_btn.Click
        If Not Deleted Then
            Dim _data As New List(Of Object)
            _data.Add(ObjectID)
            _data.Add(CommentID.ToString)
            _data.Add(sSender)

            Deleted = True

            Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:DeleteComment", _data)

            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Dein Kommentar sollte nun gelöscht sein. Benutzer die die Kommentare noch nicht aktualisiert haben, werden dein Kommentar jedoch noch sehen können.")
            _newMsg.ShowDialog()
        End If
    End Sub
End Class
