﻿Option Strict On
Public Class MetroTranslatorLabel : Inherits MetroSuite.MetroLabel

#Region " Functions "

    Private Function Coding(ByVal input As String) As String
        If input.Contains("<br>") Then
            Return input.Replace("<br>", Environment.NewLine) ' Linebreak
        Else
            Return input
        End If
    End Function

#End Region

    Private TextToolTip As ToolTip
    Public Property LanguageKey As String ' Usage: SECTION:KEY
    Public Property ShowToolTip As Boolean = True

    Public Sub New()
        Me.BackColor = Color.Transparent
        Me.Font = New Font("Segoe UI", 9)
    End Sub

    Public Sub ApplyLanguage()
        Try
            If String.IsNullOrWhiteSpace(LanguageKey) Then
                Me.Text = "Error: LanguageKey is empty!"
            Else

                For Each Entry As DictionaryEntry In QClipboard.LanguageTable
                    If String.Equals(CStr(Entry.Key), LanguageKey) = True Then
                        Me.Text = Coding(CStr(Entry.Value))
                        Exit For
                    Else
                        Me.Text = Coding("Loading...")
                    End If
                Next

            End If
        Catch ex As Exception
            Me.Text = ex.Message ' Shows error message
        End Try
    End Sub

    Private Sub MetroTranslatorLabel_MouseEnter(sender As Object, e As EventArgs) Handles Me.MouseEnter
        If ShowToolTip = True Then
            TextToolTip = New ToolTip()
            TextToolTip.SetToolTip(Me, Me.Text)
        End If
    End Sub

End Class
