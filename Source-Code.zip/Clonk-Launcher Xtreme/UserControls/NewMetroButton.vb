﻿Option Strict On
Public Class NewMetroButton : Inherits MetroSuite.MetroButton

    Public Property ScalingSize As Size = New Size(32, 32)

    Private OriginalImage As Bitmap
    Private _ScaleImageToPerfectSize As Boolean = False
    Public Property ScaleImage() As Boolean
        Get
            Return _ScaleImageToPerfectSize
        End Get
        Set(ByVal value As Boolean)
            _ScaleImageToPerfectSize = value ' SetValue

            Try ' Try to Scale down Image

                If value = True Then
                    If Not (Me.Icon Is Nothing) Then
                        OriginalImage = CType(Me.Icon, Bitmap)
                        Dim NewImage As New Bitmap(Me.Icon, ScalingSize)
                        Me.Icon = NewImage
                    End If
                Else
                    If Not (Me.Icon Is Nothing) Then
                        If Not (OriginalImage Is Nothing) Then
                            Me.Icon = OriginalImage
                        End If
                    End If
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error while adjusting image")
            End Try

        End Set
    End Property

End Class
