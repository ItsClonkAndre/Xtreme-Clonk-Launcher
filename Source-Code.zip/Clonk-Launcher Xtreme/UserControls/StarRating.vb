﻿Option Strict On
Imports System.Drawing
Imports System.Windows.Forms

Public Class StarRating
    Inherits Panel

    Public Property NotClickable As Boolean = False

    Private stars As Integer = 5
    Private StarValue As Integer = 0

    Private starswidth As Integer
    Private starsheight As Integer

    Dim classwidth As Integer
    Dim classheight As Integer

    Dim empty As Image = My.Resources.star_off
    Dim filled As Image = My.Resources.star_on

    Dim userempty As Image
    Dim userfilled As Image

    Dim mouseindex As Integer
    Dim mouseisover As Boolean

    Public Sub New()

        ' This call is required by the designer.
        'InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        starswidth = 15
        starsheight = 15

        stars = 5
        StarValue = 0

        classwidth = stars * starswidth
        classheight = starsheight

        mouseisover = False

        Me.DoubleBuffered = True

    End Sub

    Private Sub UserControl1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        If Not NotClickable Then
            If mouseindex = StarValue - 1 Then
                StarValue = 0
            Else
                StarValue = mouseindex + 1
            End If

            RaiseEvent ValueChanged(Value)

            Me.Refresh()
        End If
    End Sub

    Private Sub UserControl1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MouseEnter
        If Not NotClickable Then
            mouseisover = True
            Me.Refresh()
        End If
    End Sub

    Private Sub UserControl1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MouseLeave
        If Not NotClickable Then
            mouseisover = False
            Me.Refresh()
        End If
    End Sub

    Public Event ValueChanged(ByVal Value As Integer)

    Private Sub UserControl1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
        If Not NotClickable Then
            Dim tempindex = e.X \ starswidth
            If tempindex <> mouseindex Then
                mouseindex = tempindex
                Me.Refresh()
            End If
        End If
    End Sub


    Private Sub UserControl1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        Dim emptytouse As Image
        Dim filledtouse As Image

        If userempty Is Nothing Or userfilled Is Nothing Then
            emptytouse = empty
            filledtouse = filled
        Else
            emptytouse = userempty
            filledtouse = userfilled
        End If

        Dim i As Integer
        e.Graphics.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic

        For i = StarValue + 1 To stars
            e.Graphics.DrawImage(emptytouse, New Rectangle((i * starswidth) - starswidth, 0, starswidth, starsheight))
        Next

        For i = 0 To StarValue
            e.Graphics.DrawImage(filledtouse, New Rectangle((i * starswidth) - starswidth, 0, starswidth, starsheight))
        Next

        If mouseisover = True Then
            e.Graphics.DrawImage(filledtouse, New Rectangle(((mouseindex + 1) * starswidth) - starswidth, 0, starswidth, starsheight))
        End If
    End Sub

    Public Property StarCount() As Integer
        Get
            Return stars
        End Get
        Set(ByVal value As Integer)
            stars = value
            Updatesize()
        End Set
    End Property

    Public Property StarWidth() As Integer
        Get
            Return starswidth
        End Get
        Set(ByVal value As Integer)
            starswidth = value
            Updatesize()
        End Set
    End Property

    Public Property StarHeight() As Integer
        Get
            Return starsheight
        End Get
        Set(ByVal value As Integer)
            starsheight = value
            Updatesize()
        End Set
    End Property

    Public Property Value() As Integer
        Get
            Return StarValue
        End Get
        Set(ByVal value As Integer)
            If value > StarCount Then
                StarValue = StarCount
            Else
                StarValue = value
            End If
            RaiseEvent ValueChanged(StarValue)
        End Set
    End Property

    Public Property StarGray() As Image
        Get
            Return userempty
        End Get
        Set(ByVal value As Image)
            userempty = value
            Me.Refresh()
        End Set
    End Property

    Public Property StarGold() As Image
        Get
            Return userfilled
        End Get
        Set(ByVal value As Image)
            userfilled = value
            Me.Refresh()
        End Set
    End Property

    Private Sub Updatesize()
        classwidth = stars * starswidth
        Me.Width = classwidth
        Me.Height = starsheight
    End Sub

    Private Sub UserControl1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Updatesize()
    End Sub

End Class
