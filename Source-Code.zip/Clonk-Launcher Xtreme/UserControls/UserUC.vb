﻿Public Class UserUC

    Private AllReadyRequested As Boolean
    Private Sub AddFriend_ll_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles AddFriend_ll.LinkClicked
        If AllReadyRequested = True Then
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Du hast diesem Benutzer bereits eine Anfrage gesendet.")
            _newMsg.ShowDialog()
        Else
            If Networking.IsConnectionAlive = True Then
                AllReadyRequested = True

                Dim ListOfData As New List(Of Object)
                ListOfData.Add(username_lbl.Text) ' To
                ListOfData.Add(QClipboard.AccountName) ' From

                Networking.UTC.sendUTicket("ADMIN", "ToServer:SendFriendRequest", ListOfData)
            Else
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Anfrage konnte nicht gesendet werden, da keine Verbindung zum Server besteht.")
                _newMsg.ShowDialog()
            End If
        End If
    End Sub

End Class
