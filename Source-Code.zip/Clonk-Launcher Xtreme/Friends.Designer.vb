﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Friends
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Friends))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.friends_flp1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.username_lbl = New MetroSuite.MetroLabel()
        Me.user_picbox = New System.Windows.Forms.PictureBox()
        Me.message_txtbox = New MetroSuite.MetroTextbox()
        Me.send_btn = New MetroSuite.MetroButton()
        Me.UserInOpenChat_flp2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.MetroTabControl1 = New MetroSuite.MetroTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Chat_tbcntrl = New MetroSuite.MetroTabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.chat_lb = New MetroSuite.MetroListbox()
        Me.controlbox_pnl.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.user_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Chat_tbcntrl.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(822, 2)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 2
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Enabled = False
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'friends_flp1
        '
        Me.friends_flp1.AutoScroll = True
        Me.friends_flp1.BackColor = System.Drawing.Color.Black
        Me.friends_flp1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.friends_flp1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.friends_flp1.Location = New System.Drawing.Point(3, 3)
        Me.friends_flp1.Name = "friends_flp1"
        Me.friends_flp1.Size = New System.Drawing.Size(212, 348)
        Me.friends_flp1.TabIndex = 3
        Me.friends_flp1.WrapContents = False
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.username_lbl)
        Me.Panel1.Controls.Add(Me.user_picbox)
        Me.Panel1.Location = New System.Drawing.Point(12, 31)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(228, 65)
        Me.Panel1.TabIndex = 4
        '
        'username_lbl
        '
        Me.username_lbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.username_lbl.BackColor = System.Drawing.Color.Transparent
        Me.username_lbl.Font = New System.Drawing.Font("Segoe UI Semilight", 9.0!)
        Me.username_lbl.ForeColor = System.Drawing.Color.Gainsboro
        Me.username_lbl.Location = New System.Drawing.Point(46, 0)
        Me.username_lbl.Name = "username_lbl"
        Me.username_lbl.Size = New System.Drawing.Size(175, 60)
        Me.username_lbl.TabIndex = 10
        Me.username_lbl.Text = "Anonym"
        Me.username_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'user_picbox
        '
        Me.user_picbox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.user_picbox.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.clonk_user_unknown
        Me.user_picbox.Location = New System.Drawing.Point(8, 15)
        Me.user_picbox.Name = "user_picbox"
        Me.user_picbox.Size = New System.Drawing.Size(32, 32)
        Me.user_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.user_picbox.TabIndex = 9
        Me.user_picbox.TabStop = False
        '
        'message_txtbox
        '
        Me.message_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.message_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.message_txtbox.DefaultColor = System.Drawing.Color.White
        Me.message_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.message_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.message_txtbox.ForeColor = System.Drawing.Color.Black
        Me.message_txtbox.HideSelection = False
        Me.message_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.message_txtbox.Location = New System.Drawing.Point(246, 467)
        Me.message_txtbox.Name = "message_txtbox"
        Me.message_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.message_txtbox.Size = New System.Drawing.Size(517, 24)
        Me.message_txtbox.TabIndex = 6
        Me.message_txtbox.Watermark = "Text zum senden eingeben"
        '
        'send_btn
        '
        Me.send_btn.BackColor = System.Drawing.Color.Transparent
        Me.send_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.send_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.send_btn.DefaultColor = System.Drawing.Color.White
        Me.send_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.send_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.send_btn.HoverColor = System.Drawing.Color.White
        Me.send_btn.Location = New System.Drawing.Point(769, 467)
        Me.send_btn.Name = "send_btn"
        Me.send_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.send_btn.RoundingArc = 24
        Me.send_btn.Size = New System.Drawing.Size(100, 24)
        Me.send_btn.TabIndex = 7
        Me.send_btn.Text = "Senden"
        '
        'UserInOpenChat_flp2
        '
        Me.UserInOpenChat_flp2.AutoScroll = True
        Me.UserInOpenChat_flp2.BackColor = System.Drawing.Color.Black
        Me.UserInOpenChat_flp2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.UserInOpenChat_flp2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.UserInOpenChat_flp2.Location = New System.Drawing.Point(3, 3)
        Me.UserInOpenChat_flp2.Name = "UserInOpenChat_flp2"
        Me.UserInOpenChat_flp2.Size = New System.Drawing.Size(212, 348)
        Me.UserInOpenChat_flp2.TabIndex = 4
        Me.UserInOpenChat_flp2.WrapContents = False
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Alignment = System.Windows.Forms.TabAlignment.Top
        Me.MetroTabControl1.Appearance = System.Windows.Forms.Appearance.Normal
        Me.MetroTabControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MetroTabControl1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.MetroTabControl1.Controls.Add(Me.TabPage1)
        Me.MetroTabControl1.Controls.Add(Me.TabPage2)
        Me.MetroTabControl1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTabControl1.ForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(106, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.MetroTabControl1.HeaderItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.HotTrack = True
        Me.MetroTabControl1.HoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.HoverColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.ItemSize = New System.Drawing.Size(110, 25)
        Me.MetroTabControl1.Location = New System.Drawing.Point(12, 102)
        Me.MetroTabControl1.Multiline = True
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedForeColor = System.Drawing.Color.White
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.SelectedItemColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedItemLineColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.Size = New System.Drawing.Size(228, 389)
        Me.MetroTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MetroTabControl1.TabContainerColor = System.Drawing.Color.White
        Me.MetroTabControl1.TabIndex = 8
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.friends_flp1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(220, 356)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Freunde"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.UserInOpenChat_flp2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(220, 356)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Öffentlicher Chat"
        '
        'Chat_tbcntrl
        '
        Me.Chat_tbcntrl.Alignment = System.Windows.Forms.TabAlignment.Top
        Me.Chat_tbcntrl.Appearance = System.Windows.Forms.Appearance.Normal
        Me.Chat_tbcntrl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Chat_tbcntrl.BorderColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Chat_tbcntrl.Controls.Add(Me.TabPage3)
        Me.Chat_tbcntrl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Chat_tbcntrl.ForeColor = System.Drawing.Color.Black
        Me.Chat_tbcntrl.HasAnimation = False
        Me.Chat_tbcntrl.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(106, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Chat_tbcntrl.HeaderItemColor = System.Drawing.Color.White
        Me.Chat_tbcntrl.HotTrack = True
        Me.Chat_tbcntrl.HoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Chat_tbcntrl.HoverColor = System.Drawing.Color.White
        Me.Chat_tbcntrl.ItemColor = System.Drawing.Color.White
        Me.Chat_tbcntrl.ItemForeColor = System.Drawing.Color.Black
        Me.Chat_tbcntrl.ItemSize = New System.Drawing.Size(108, 25)
        Me.Chat_tbcntrl.Location = New System.Drawing.Point(246, 31)
        Me.Chat_tbcntrl.Multiline = True
        Me.Chat_tbcntrl.Name = "Chat_tbcntrl"
        Me.Chat_tbcntrl.SelectedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Chat_tbcntrl.SelectedForeColor = System.Drawing.Color.White
        Me.Chat_tbcntrl.SelectedIndex = 0
        Me.Chat_tbcntrl.SelectedItemColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Chat_tbcntrl.SelectedItemLineColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Chat_tbcntrl.Size = New System.Drawing.Size(623, 430)
        Me.Chat_tbcntrl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.Chat_tbcntrl.TabContainerColor = System.Drawing.Color.White
        Me.Chat_tbcntrl.TabIndex = 9
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.White
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage3.Controls.Add(Me.chat_lb)
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(615, 397)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "Öffentlicher Chat"
        '
        'chat_lb
        '
        Me.chat_lb.BackColor = System.Drawing.Color.White
        Me.chat_lb.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.chat_lb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.chat_lb.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chat_lb.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.chat_lb.ForeColor = System.Drawing.Color.Black
        Me.chat_lb.FormattingEnabled = True
        Me.chat_lb.ItemHeight = 17
        Me.chat_lb.Location = New System.Drawing.Point(3, 3)
        Me.chat_lb.Name = "chat_lb"
        Me.chat_lb.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.chat_lb.Size = New System.Drawing.Size(607, 389)
        Me.chat_lb.TabIndex = 0
        '
        'Friends
        '
        Me.AllowResize = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(881, 503)
        Me.Controls.Add(Me.Chat_tbcntrl)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.send_btn)
        Me.Controls.Add(Me.message_txtbox)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Friends"
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "Xtreme-Clonk-Launcher | Freunde (Alpha)"
        Me.controlbox_pnl.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.user_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.Chat_tbcntrl.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Friend WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents friends_flp1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents user_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents username_lbl As MetroSuite.MetroLabel
    Friend WithEvents message_txtbox As MetroSuite.MetroTextbox
    Friend WithEvents send_btn As MetroSuite.MetroButton
    Friend WithEvents UserInOpenChat_flp2 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents MetroTabControl1 As MetroSuite.MetroTabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Chat_tbcntrl As MetroSuite.MetroTabControl
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents chat_lb As MetroSuite.MetroListbox
End Class
