﻿Option Strict On
Imports System.IO
Imports MetroSuite.Extension
Imports MetroSuite
Imports MadMilkman.Ini
Public Class Settings : Inherits MetroForm

    Private OldUsername, OldPassword As String

#Region "Functions"

    Public Sub ApplyTheme()
        Try
            Dim myTheme As New Styles.Themes.MetroSuiteTheme
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            If IO.File.Exists(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme")) Then ' If file exists
                myTheme = myTheme.FromFile(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme"))
            Else ' If not
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Public Sub ReloadSettings()
        Try
            ' Notifications
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))
            ShowChatMsg_mchkbox.Checked = CBool(_IniFile.Sections("Notifications").Keys("NewChatMessage").Value)
            ShowNewUpdateMsg_mchkbox.Checked = CBool(_IniFile.Sections("Notifications").Keys("NewUpdates").Value)
            ShowChatClonkMessage_mchkbox.Checked = CBool(_IniFile.Sections("Notifications").Keys("ShowClonkMessage").Value)

            ' Data Protection
            AllowRushHourData_mchbox.Checked = CBool(_IniFile.Sections("DataProtection").Keys("AllowSendingRushHourData").Value)
            AllowPlayTimeData_mchbox.Checked = CBool(_IniFile.Sections("DataProtection").Keys("AllowSendingPlayTimeData").Value)

            ' Downloads
            If _IniFile.Sections("Settings").Keys("DownloadMode").Value = "1" Then
                CCANcopyInGameDir_rbtn.Checked = True
            ElseIf _IniFile.Sections("Settings").Keys("DownloadMode").Value = "2" Then
                CCANcopyInAnyDir_rbtn.Checked = True
            Else
                CCANcopyInGameDir_rbtn.Checked = True
            End If

            ' Client / User
            Theme_mcmdbox.SelectedItem = _IniFile.Sections("Settings").Keys("Theme").Value
            StartTabPage_mcmdbox.SelectedItem = _IniFile.Sections("Settings").Keys("StartTabPage").Value
            ExitMode_mcmdbox.SelectedItem = _IniFile.Sections("Settings").Keys("ExitMode").Value

            If Language_mcmdbox.Items.Contains(_IniFile.Sections("Settings").Keys("Language").Value) Then
                Language_mcmdbox.SelectedItem = _IniFile.Sections("Settings").Keys("Language").Value
            Else
                Language_mcmdbox.SelectedItem = "English"
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, "Your selected language (" & _IniFile.Sections("Settings").Keys("Language").Value & ") was not found in the list. Please make sure that the language file exists. Now using: English language")
                _newMsg.ShowDialog()
            End If

            ' User-ID
            CID_lbl.Text = "User-ID: " & My.Settings.USERID
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Fehler beim Laden der Einstellungen: " & ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Private Sub ApplyLanguage()
        Try
            For Each _cntrl As Control In ListControls(Me)
                If _cntrl.GetType().Name = "MetroTranslatorLabel" Then
                    DirectCast(_cntrl, MetroTranslatorLabel).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorButton" Then
                    DirectCast(_cntrl, MetroTranslatorButton).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorChecker" Then
                    DirectCast(_cntrl, MetroTranslatorChecker).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorTextbox" Then
                    DirectCast(_cntrl, MetroTranslatorTextbox).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "ClassicTranslatorRadioButton" Then
                    DirectCast(_cntrl, ClassicTranslatorRadioButton).ApplyLanguage()
                End If
            Next

            ' Set TabPages Title
            Account_tb.Text = GetSpecificLanguageString("SETTINGS:ACCOUNT_TITLE")
            TabPage1.Text = GetSpecificLanguageString("SETTINGS:OPTIONS_TITLE")
            TabPage2.Text = GetSpecificLanguageString("SETTINGS:NOTIFICATIONS_TITLE")
            TabPage3.Text = GetSpecificLanguageString("SETTINGS:DOWNLOADS_TITLE")
            TabPage4.Text = GetSpecificLanguageString("SETTINGS:ABOUT_TITLE")

        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub
    Private Function ListControls(ByVal control As Control) As IEnumerable(Of Control)
        Dim ctrl As IEnumerable(Of Control) = control.Controls.Cast(Of Control)()
        Return ctrl.Concat(ctrl.SelectMany(AddressOf ListControls))
    End Function

    Public Sub GettingAccountInformations()
        Try
            Networking.UTC.sendUTicket("ADMIN", "ACCOUNT:GetInformations", My.Settings.USERID)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

#Region " Functions "

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

    Public Function GetSpecificLanguageString(ByVal Key As String) As String
        Try
            For Each Entry As DictionaryEntry In QClipboard.LanguageTable
                If String.Equals(CStr(Entry.Key), Key) = True Then
                    Return Entry.Value.ToString
                    Exit Function
                End If
            Next
            Return "Not found"
        Catch ex As Exception
            Return "ERROR"
        End Try
    End Function

#End Region

#End Region

#Region "ControlBox"

    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        Me.Close()
    End Sub
    Private Sub controlbox_nmaximize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_nmaximize_lbl.Click
        If controlbox_nmaximize_lbl.Text = "□" Then
            controlbox_nmaximize_lbl.Text = "■"
            Me.WindowState = FormWindowState.Normal
        Else
            controlbox_nmaximize_lbl.Text = "□"
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub
    Private Sub controlbox_minimize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_minimize_lbl.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter, controlbox_nmaximize_lbl.MouseEnter, controlbox_minimize_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave, controlbox_nmaximize_lbl.MouseLeave, controlbox_minimize_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

#End Region

#Region "TabControl"

    'Account
    Private Sub ShowPassword_chkbox_CheckedChanged(sender As Object, isChecked As Boolean)
        If isChecked = True Then
            Password_txtbox.PasswordChar = Nothing
        Else
            Password_txtbox.PasswordChar = CChar("*")
        End If
    End Sub

#End Region

#Region " Network "

    Private Sub UTC_UTicketArrived(sSenderID As String, bSentToAll As Boolean, sCommand As String, oUserData As List(Of Object))
        Select Case sCommand
            Case "ACCOUNT:ReceiveAccountInformations"
                Try
                    OldUsername = oUserData(0).ToString
                    OldPassword = oUserData(1).ToString
                    username_txtbox.Text = oUserData(0).ToString
                    Password_txtbox.Text = oUserData(1).ToString
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.OkOnly, "- DEBUG -")
                End Try
            Case "ACCOUNT:ReceiveAccountInformationsFails"
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, "Fehler beim abrufen deiner Accountinformationen." & vbNewLine & oUserData(0).ToString)
                _newMsg.ShowDialog()
            Case "ACCOUNT:ChangingInformationsSuccess"
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Deine Daten wurden erfolgreich geändert!")
                _newMsg.ShowDialog()

                Networking.UTC.sendUTicket("ADMIN", "ACCOUNT:GetInformations", My.Settings.USERID) ' Reload
            Case "ACCOUNT:ChangingInformationsFailed"
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Es gab ein Fehler beim speichern der neuen Daten :/" & vbNewLine & oUserData(0).ToString)
                _newMsg.ShowDialog()
        End Select
    End Sub

#End Region

#Region "LinkLabel"

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("https://quixo-systems.jimdofree.com/")
    End Sub
    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://www.clonk.de")
    End Sub
    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        Process.Start("https://www.mozilla.org/")
    End Sub

    Private Sub RichTextBox1_LinkClicked(sender As Object, e As LinkClickedEventArgs) Handles RichTextBox1.LinkClicked
        Select Case MessageBox.Show(e.LinkText.ToString & " öffnen?", "Link öffnen", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            Case System.Windows.Forms.DialogResult.Yes
                Process.Start(e.LinkText.ToString)
        End Select
    End Sub

#End Region

    Private Sub Settings_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Try
            Dim ShouldRebuildDB As Boolean
            Dim _IniFile As New IniFile(New IniOptions())

            ' compares old language value with new
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))
            If Not _IniFile.Sections("Settings").Keys("Language").Value = Language_mcmdbox.SelectedItem.ToString Then
                ShouldRebuildDB = True
            End If

            ' Clears and resets variable
            _IniFile = Nothing
            _IniFile = New IniFile(New IniOptions())

            ' Set new settings
            _IniFile.Sections.Add("Notifications").Keys.Add("NewChatMessage", CStr(ShowChatMsg_mchkbox.Checked))
            _IniFile.Sections("Notifications").Keys.Add("NewUpdates", CStr(ShowNewUpdateMsg_mchkbox.Checked))
            _IniFile.Sections("Notifications").Keys.Add("ShowClonkMessage", CStr(ShowChatClonkMessage_mchkbox.Checked))
            _IniFile.Sections.Add("DataProtection").Keys.Add("AllowSendingRushHourData", CStr(AllowRushHourData_mchbox.Checked))
            _IniFile.Sections("DataProtection").Keys.Add("AllowSendingPlayTimeData", CStr(AllowPlayTimeData_mchbox.Checked))
            _IniFile.Sections.Add("Settings").Keys.Add("ConnectionMode", "Server")
            _IniFile.Sections("Settings").Keys.Add("ExitMode", ExitMode_mcmdbox.SelectedItem.ToString)
            _IniFile.Sections("Settings").Keys.Add("Language", Language_mcmdbox.SelectedItem.ToString)
            _IniFile.Sections("Settings").Keys.Add("Theme", Theme_mcmdbox.SelectedItem.ToString)
            _IniFile.Sections("Settings").Keys.Add("StartTabPage", StartTabPage_mcmdbox.SelectedItem.ToString)

            If CCANcopyInGameDir_rbtn.Checked = True Then
                _IniFile.Sections("Settings").Keys.Add("DownloadMode", "1")
            ElseIf CCANcopyInAnyDir_rbtn.Checked = True Then
                _IniFile.Sections("Settings").Keys.Add("DownloadMode", "2")
            End If

            ' Save new settings
            _IniFile.Save(MakeLinuxCompatible(".\settings.ini"))

            ' Reloads/builds everything
            Main.ReloadSettings()
            If ShouldRebuildDB = True Then
                Main.RebuildLanguageDatabase()
            End If
        Catch ex As Exception : End Try
    End Sub
    Private Sub Settings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ApplyTheme() ' Set Theme
        ApplyLanguage() ' Applys Language

        Control.CheckForIllegalCrossThreadCalls = False

        'AddHandler
        If Not Networking.IsObjectNothing Then
            AddHandler Networking.UTC.UTicketArrived, AddressOf UTC_UTicketArrived
        End If

        ' CheckLoggedInMode
        If QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym Then
            NotLoggedInInfo_lbl.Visible = True

            For Each _cntrl As Control In Account_tb.Controls ' Deaktiviert alle Controls
                If Not _cntrl.Name = "NotLoggedInInfo_lbl" Then
                    _cntrl.Enabled = False
                End If
            Next
        Else
            GettingAccountInformations()
            NotLoggedInInfo_lbl.Visible = False
        End If

        ' LoadAllLanguages
        Try
            Dim TargetDirectory As New DirectoryInfo(MakeLinuxCompatible(".\Data\Language\"))
            Dim fiArr As FileInfo() = TargetDirectory.GetFiles()
            For Each _File As FileInfo In fiArr
                If _File.Extension = ".lang" Then
                    Language_mcmdbox.Items.Add(IO.Path.GetFileNameWithoutExtension(_File.Name))
                End If
            Next _File
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Error while reading all languages in folder..." & Environment.NewLine & "Details: " & ex.Message)
            _newMsg.ShowDialog()
        End Try

        ' LoadAllThemes
        Try
            Dim TargetDirectory As New DirectoryInfo(MakeLinuxCompatible(".\Data\Themes\"))
            Dim fiArr As FileInfo() = TargetDirectory.GetFiles()
            For Each _File As FileInfo In fiArr
                If _File.Extension = ".mstheme" Then
                    Theme_mcmdbox.Items.Add(IO.Path.GetFileNameWithoutExtension(_File.Name))
                End If
            Next _File
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Error while reading all themes in folder..." & Environment.NewLine & "Details: " & ex.Message)
            _newMsg.ShowDialog()
        End Try

        ' LoadSettings
        ReloadSettings()
    End Sub

    Private Sub AcceptChanges_btn_Click(sender As Object, e As EventArgs) Handles AcceptChanges_btn.Click
        Select Case MessageBox.Show("Änderungen an deinem Account vornehmen?", "Ändern bestätigen?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            Case System.Windows.Forms.DialogResult.Yes
                Dim SafetyBox As String = CInputBox.ShowInputBox("Identität bestätigen", "Bitte gebe dein altes Passwort zur Bestätigung ein.", Nothing, "Passwort eigeben", "*")
                If SafetyBox = OldPassword Then
                    Dim NewData As New List(Of Object)
                    NewData.Add(My.Settings.USERID)
                    NewData.Add(username_txtbox.Text)
                    NewData.Add(Password_txtbox.Text)

                    Networking.UTC.sendUTicket("ADMIN", "ACCOUNT:ChangeInformations", NewData)
                    GettingAccountInformations()
                Else
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Änderung an deinem Account wurde abgebrochen. Bitte Passwort erneut eingeben.")
                    _newMsg.ShowDialog()

                    Password_txtbox.Text = OldPassword
                    username_txtbox.Text = OldUsername
                End If
        End Select
    End Sub

    Private Sub CheckForUpdates_btn_Click(sender As Object, e As EventArgs) Handles CheckForUpdates_btn.Click
        Main.CheckForUpdates()
    End Sub

End Class