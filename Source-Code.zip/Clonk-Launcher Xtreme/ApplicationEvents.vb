﻿Namespace My

    ' The following events are available for MyApplication:
    ' 
    ' Startup: Raised when the application starts, before the startup form is created.
    ' Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
    ' UnhandledException: Raised if the application encounters an unhandled exception.
    ' StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
    ' NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
    Partial Friend Class MyApplication

        Private Sub MyApplication_NetworkAvailabilityChanged(sender As Object, e As Devices.NetworkAvailableEventArgs) Handles Me.NetworkAvailabilityChanged
            If e.IsNetworkAvailable = False Then
                If Xtreme_Clonk_Launcher.Main.IsCurrentlyDownloading = True Then
                    Xtreme_Clonk_Launcher.Main.Downloader.CancelAsync()
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, "Der Download wurde unerwartet abgebrochen da keine Verbindung zum Internet besteht.")
                    _newMsg.ShowDialog()
                End If
            End If
        End Sub

        Private Sub MyApplication_Startup(sender As Object, e As ApplicationServices.StartupEventArgs) Handles Me.Startup
            Try
                'Dim _ProfileDirectory As String = ".\Firefox\Profile"

                'If Not System.IO.Directory.Exists(_ProfileDirectory) Then ' Check and create Profile Folder
                '    System.IO.Directory.CreateDirectory(_ProfileDirectory)
                'End If

                'Xpcom.ProfileDirectory = _ProfileDirectory ' Profile Folder
            Catch ex As Exception
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Fataler Fehler in: MyApplication Events - MyApplication_Startup" & vbNewLine & ex.Message)
                _newMsg.ShowDialog()
            End Try
        End Sub

        Private Sub MyApplication_UnhandledException(sender As Object, e As ApplicationServices.UnhandledExceptionEventArgs) Handles Me.UnhandledException
            Try
                Dim NewErrorInfo As New UnhandledExceptionInfo(e.Exception)
                NewErrorInfo.ShowDialog()
            Catch ex As Exception
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Fataler Fehler in: MyApplication Events - MyApplication_UnhandledException" & Environment.NewLine & ex.Message)
                _newMsg.ShowDialog()
            End Try
        End Sub
    End Class

End Namespace

