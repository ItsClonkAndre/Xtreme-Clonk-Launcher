﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UploadObjectFrm
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UploadObjectFrm))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.MetroLabel15 = New MetroSuite.MetroLabel()
        Me.SelectFile_btn = New MetroSuite.MetroButton()
        Me.MetroLabel1 = New MetroSuite.MetroLabel()
        Me.ObjectTitel_txtbox = New MetroSuite.MetroTextbox()
        Me.ObjectVersion_txtbox = New MetroSuite.MetroTextbox()
        Me.MetroLabel2 = New MetroSuite.MetroLabel()
        Me.Unfinished_chkbox = New MetroSuite.MetroChecker()
        Me.MetroLabel3 = New MetroSuite.MetroLabel()
        Me.EngineVersion_cmbbox = New MetroSuite.MetroComboBox()
        Me.CategoryOne_cmbbox = New MetroSuite.MetroComboBox()
        Me.MetroLabel4 = New MetroSuite.MetroLabel()
        Me.Players_txtbox = New MetroSuite.MetroTextbox()
        Me.MetroLabel5 = New MetroSuite.MetroLabel()
        Me.MetroLabel6 = New MetroSuite.MetroLabel()
        Me.desc_txtbox = New MetroSuite.MetroTextbox()
        Me.upload_btn = New MetroSuite.MetroButton()
        Me.CategorySzenario_cmbbox = New MetroSuite.MetroComboBox()
        Me.CategoryObject_cmbbox = New MetroSuite.MetroComboBox()
        Me.categoryDocument_cmbbox = New MetroSuite.MetroComboBox()
        Me.CompletePackageInformation_lbl = New MetroSuite.MetroLabel()
        Me.FileStatus_picbox = New System.Windows.Forms.PictureBox()
        Me.loading_pnl = New System.Windows.Forms.Panel()
        Me.UploadingStatus_lbl = New MetroSuite.MetroLabel()
        Me.Uploading_picbox = New System.Windows.Forms.PictureBox()
        Me.controlbox_pnl.SuspendLayout()
        CType(Me.FileStatus_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.loading_pnl.SuspendLayout()
        CType(Me.Uploading_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(345, 3)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 2
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Enabled = False
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'MetroLabel15
        '
        Me.MetroLabel15.AutoSize = True
        Me.MetroLabel15.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel15.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel15.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroLabel15.Location = New System.Drawing.Point(28, 36)
        Me.MetroLabel15.Name = "MetroLabel15"
        Me.MetroLabel15.Size = New System.Drawing.Size(34, 15)
        Me.MetroLabel15.TabIndex = 29
        Me.MetroLabel15.Text = "Datei"
        '
        'SelectFile_btn
        '
        Me.SelectFile_btn.BackColor = System.Drawing.Color.Transparent
        Me.SelectFile_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SelectFile_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.SelectFile_btn.DefaultColor = System.Drawing.Color.White
        Me.SelectFile_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.SelectFile_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.SelectFile_btn.ForeColor = System.Drawing.Color.Black
        Me.SelectFile_btn.HoverColor = System.Drawing.Color.White
        Me.SelectFile_btn.Location = New System.Drawing.Point(31, 50)
        Me.SelectFile_btn.Name = "SelectFile_btn"
        Me.SelectFile_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.SelectFile_btn.RoundingArc = 24
        Me.SelectFile_btn.Size = New System.Drawing.Size(316, 24)
        Me.SelectFile_btn.TabIndex = 30
        Me.SelectFile_btn.Text = "Datei auswählen (max. 150 MB)"
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel1.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroLabel1.Location = New System.Drawing.Point(28, 81)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(29, 15)
        Me.MetroLabel1.TabIndex = 32
        Me.MetroLabel1.Text = "Titel"
        '
        'ObjectTitel_txtbox
        '
        Me.ObjectTitel_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ObjectTitel_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ObjectTitel_txtbox.DefaultColor = System.Drawing.Color.White
        Me.ObjectTitel_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ObjectTitel_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ObjectTitel_txtbox.ForeColor = System.Drawing.Color.Black
        Me.ObjectTitel_txtbox.HideSelection = False
        Me.ObjectTitel_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ObjectTitel_txtbox.Location = New System.Drawing.Point(31, 95)
        Me.ObjectTitel_txtbox.MaxLength = 100
        Me.ObjectTitel_txtbox.Name = "ObjectTitel_txtbox"
        Me.ObjectTitel_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.ObjectTitel_txtbox.Size = New System.Drawing.Size(346, 23)
        Me.ObjectTitel_txtbox.TabIndex = 33
        Me.ObjectTitel_txtbox.Watermark = "Titel eingeben"
        '
        'ObjectVersion_txtbox
        '
        Me.ObjectVersion_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ObjectVersion_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ObjectVersion_txtbox.DefaultColor = System.Drawing.Color.White
        Me.ObjectVersion_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ObjectVersion_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ObjectVersion_txtbox.ForeColor = System.Drawing.Color.Black
        Me.ObjectVersion_txtbox.HideSelection = False
        Me.ObjectVersion_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ObjectVersion_txtbox.Location = New System.Drawing.Point(31, 139)
        Me.ObjectVersion_txtbox.MaxLength = 20
        Me.ObjectVersion_txtbox.Name = "ObjectVersion_txtbox"
        Me.ObjectVersion_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.ObjectVersion_txtbox.Size = New System.Drawing.Size(346, 23)
        Me.ObjectVersion_txtbox.TabIndex = 35
        Me.ObjectVersion_txtbox.Watermark = "Version eingeben z.b. wie: 1.0 Beta/Alpha, 2.04c oder andere..."
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel2.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroLabel2.Location = New System.Drawing.Point(28, 125)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(45, 15)
        Me.MetroLabel2.TabIndex = 34
        Me.MetroLabel2.Text = "Version"
        '
        'Unfinished_chkbox
        '
        Me.Unfinished_chkbox.BackColor = System.Drawing.Color.White
        Me.Unfinished_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Unfinished_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Unfinished_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Unfinished_chkbox.CheckerSymbol = MetroSuite.MetroChecker.MetroCheckerSymbol.BoxWithTick
        Me.Unfinished_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Unfinished_chkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Unfinished_chkbox.ForeColor = System.Drawing.Color.Black
        Me.Unfinished_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.Unfinished_chkbox.Location = New System.Drawing.Point(31, 306)
        Me.Unfinished_chkbox.Name = "Unfinished_chkbox"
        Me.Unfinished_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.Unfinished_chkbox.Size = New System.Drawing.Size(70, 14)
        Me.Unfinished_chkbox.TabIndex = 36
        Me.Unfinished_chkbox.Text = "Unfertig?"
        '
        'MetroLabel3
        '
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel3.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroLabel3.Location = New System.Drawing.Point(28, 169)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(86, 15)
        Me.MetroLabel3.TabIndex = 37
        Me.MetroLabel3.Text = "Engine-Version"
        '
        'EngineVersion_cmbbox
        '
        Me.EngineVersion_cmbbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.EngineVersion_cmbbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.EngineVersion_cmbbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.EngineVersion_cmbbox.DefaultColor = System.Drawing.Color.White
        Me.EngineVersion_cmbbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.EngineVersion_cmbbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.EngineVersion_cmbbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.EngineVersion_cmbbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.EngineVersion_cmbbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.EngineVersion_cmbbox.ForeColor = System.Drawing.Color.Black
        Me.EngineVersion_cmbbox.FormattingEnabled = True
        Me.EngineVersion_cmbbox.Items.AddRange(New Object() {"OpenClonk", "Clonk Rage", "Clonk Endeavour", "Clonk Planet", "Clonk 4"})
        Me.EngineVersion_cmbbox.Location = New System.Drawing.Point(31, 184)
        Me.EngineVersion_cmbbox.Name = "EngineVersion_cmbbox"
        Me.EngineVersion_cmbbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.EngineVersion_cmbbox.Size = New System.Drawing.Size(346, 24)
        Me.EngineVersion_cmbbox.TabIndex = 38
        '
        'CategoryOne_cmbbox
        '
        Me.CategoryOne_cmbbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CategoryOne_cmbbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CategoryOne_cmbbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CategoryOne_cmbbox.DefaultColor = System.Drawing.Color.White
        Me.CategoryOne_cmbbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CategoryOne_cmbbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CategoryOne_cmbbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CategoryOne_cmbbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CategoryOne_cmbbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CategoryOne_cmbbox.ForeColor = System.Drawing.Color.Black
        Me.CategoryOne_cmbbox.FormattingEnabled = True
        Me.CategoryOne_cmbbox.Items.AddRange(New Object() {"Szenario", "Objekt", "Dokument", "Komplettpaket (.zip)"})
        Me.CategoryOne_cmbbox.Location = New System.Drawing.Point(31, 229)
        Me.CategoryOne_cmbbox.Name = "CategoryOne_cmbbox"
        Me.CategoryOne_cmbbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CategoryOne_cmbbox.Size = New System.Drawing.Size(146, 24)
        Me.CategoryOne_cmbbox.TabIndex = 40
        '
        'MetroLabel4
        '
        Me.MetroLabel4.AutoSize = True
        Me.MetroLabel4.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel4.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroLabel4.Location = New System.Drawing.Point(28, 214)
        Me.MetroLabel4.Name = "MetroLabel4"
        Me.MetroLabel4.Size = New System.Drawing.Size(57, 15)
        Me.MetroLabel4.TabIndex = 39
        Me.MetroLabel4.Text = "Kategorie"
        '
        'Players_txtbox
        '
        Me.Players_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Players_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Players_txtbox.DefaultColor = System.Drawing.Color.White
        Me.Players_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Players_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Players_txtbox.ForeColor = System.Drawing.Color.Black
        Me.Players_txtbox.HideSelection = False
        Me.Players_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Players_txtbox.Location = New System.Drawing.Point(31, 273)
        Me.Players_txtbox.MaxLength = 20
        Me.Players_txtbox.Name = "Players_txtbox"
        Me.Players_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Players_txtbox.Size = New System.Drawing.Size(346, 23)
        Me.Players_txtbox.TabIndex = 42
        Me.Players_txtbox.Watermark = "Ausgelegt für ... Spieler"
        '
        'MetroLabel5
        '
        Me.MetroLabel5.AutoSize = True
        Me.MetroLabel5.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel5.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroLabel5.Location = New System.Drawing.Point(28, 259)
        Me.MetroLabel5.Name = "MetroLabel5"
        Me.MetroLabel5.Size = New System.Drawing.Size(81, 15)
        Me.MetroLabel5.TabIndex = 41
        Me.MetroLabel5.Text = "Anzahl Spieler"
        '
        'MetroLabel6
        '
        Me.MetroLabel6.AutoSize = True
        Me.MetroLabel6.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel6.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroLabel6.Location = New System.Drawing.Point(28, 327)
        Me.MetroLabel6.Name = "MetroLabel6"
        Me.MetroLabel6.Size = New System.Drawing.Size(79, 15)
        Me.MetroLabel6.TabIndex = 43
        Me.MetroLabel6.Text = "Beschreibung"
        '
        'desc_txtbox
        '
        Me.desc_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.desc_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.desc_txtbox.DefaultColor = System.Drawing.Color.White
        Me.desc_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.desc_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.desc_txtbox.ForeColor = System.Drawing.Color.Black
        Me.desc_txtbox.HideSelection = False
        Me.desc_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.desc_txtbox.Location = New System.Drawing.Point(31, 342)
        Me.desc_txtbox.Multiline = True
        Me.desc_txtbox.Name = "desc_txtbox"
        Me.desc_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.desc_txtbox.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.desc_txtbox.Size = New System.Drawing.Size(346, 90)
        Me.desc_txtbox.TabIndex = 44
        Me.desc_txtbox.Watermark = "Beschreibung eingeben"
        '
        'upload_btn
        '
        Me.upload_btn.BackColor = System.Drawing.Color.Transparent
        Me.upload_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.upload_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.upload_btn.DefaultColor = System.Drawing.Color.White
        Me.upload_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.upload_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.upload_btn.ForeColor = System.Drawing.Color.Black
        Me.upload_btn.HoverColor = System.Drawing.Color.White
        Me.upload_btn.Location = New System.Drawing.Point(31, 446)
        Me.upload_btn.Name = "upload_btn"
        Me.upload_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.upload_btn.RoundingArc = 24
        Me.upload_btn.Size = New System.Drawing.Size(346, 24)
        Me.upload_btn.TabIndex = 45
        Me.upload_btn.Text = "Hochladen"
        '
        'CategorySzenario_cmbbox
        '
        Me.CategorySzenario_cmbbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CategorySzenario_cmbbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CategorySzenario_cmbbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CategorySzenario_cmbbox.DefaultColor = System.Drawing.Color.White
        Me.CategorySzenario_cmbbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CategorySzenario_cmbbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CategorySzenario_cmbbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CategorySzenario_cmbbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CategorySzenario_cmbbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CategorySzenario_cmbbox.ForeColor = System.Drawing.Color.Black
        Me.CategorySzenario_cmbbox.FormattingEnabled = True
        Me.CategorySzenario_cmbbox.Items.AddRange(New Object() {"Action", "Adventure", "Aufbau / Siedlung", "Back To The Roots", "Demo / Film", "Experimentell", "Flintregen", "Melee", "RPG", "Sonstiges"})
        Me.CategorySzenario_cmbbox.Location = New System.Drawing.Point(183, 229)
        Me.CategorySzenario_cmbbox.Name = "CategorySzenario_cmbbox"
        Me.CategorySzenario_cmbbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CategorySzenario_cmbbox.Size = New System.Drawing.Size(194, 24)
        Me.CategorySzenario_cmbbox.TabIndex = 46
        Me.CategorySzenario_cmbbox.Visible = False
        '
        'CategoryObject_cmbbox
        '
        Me.CategoryObject_cmbbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CategoryObject_cmbbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CategoryObject_cmbbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CategoryObject_cmbbox.DefaultColor = System.Drawing.Color.White
        Me.CategoryObject_cmbbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CategoryObject_cmbbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CategoryObject_cmbbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CategoryObject_cmbbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CategoryObject_cmbbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CategoryObject_cmbbox.ForeColor = System.Drawing.Color.Black
        Me.CategoryObject_cmbbox.FormattingEnabled = True
        Me.CategoryObject_cmbbox.Items.AddRange(New Object() {"Clonk", "Fortbewegungsmittel", "Gebäude", "Regel", "Sonstiges", "Spielziel", "Tier", "Umgebung", "Waffen / Militärisches"})
        Me.CategoryObject_cmbbox.Location = New System.Drawing.Point(183, 229)
        Me.CategoryObject_cmbbox.Name = "CategoryObject_cmbbox"
        Me.CategoryObject_cmbbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CategoryObject_cmbbox.Size = New System.Drawing.Size(194, 24)
        Me.CategoryObject_cmbbox.TabIndex = 47
        Me.CategoryObject_cmbbox.Visible = False
        '
        'categoryDocument_cmbbox
        '
        Me.categoryDocument_cmbbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.categoryDocument_cmbbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.categoryDocument_cmbbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.categoryDocument_cmbbox.DefaultColor = System.Drawing.Color.White
        Me.categoryDocument_cmbbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.categoryDocument_cmbbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.categoryDocument_cmbbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.categoryDocument_cmbbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.categoryDocument_cmbbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.categoryDocument_cmbbox.ForeColor = System.Drawing.Color.Black
        Me.categoryDocument_cmbbox.FormattingEnabled = True
        Me.categoryDocument_cmbbox.Items.AddRange(New Object() {"Für Entwickler", "Skripte", "Sonstiges"})
        Me.categoryDocument_cmbbox.Location = New System.Drawing.Point(183, 229)
        Me.categoryDocument_cmbbox.Name = "categoryDocument_cmbbox"
        Me.categoryDocument_cmbbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.categoryDocument_cmbbox.Size = New System.Drawing.Size(194, 24)
        Me.categoryDocument_cmbbox.TabIndex = 48
        Me.categoryDocument_cmbbox.Visible = False
        '
        'CompletePackageInformation_lbl
        '
        Me.CompletePackageInformation_lbl.BackColor = System.Drawing.Color.Transparent
        Me.CompletePackageInformation_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CompletePackageInformation_lbl.ForeColor = System.Drawing.Color.Gainsboro
        Me.CompletePackageInformation_lbl.Location = New System.Drawing.Point(183, 226)
        Me.CompletePackageInformation_lbl.Name = "CompletePackageInformation_lbl"
        Me.CompletePackageInformation_lbl.Size = New System.Drawing.Size(194, 33)
        Me.CompletePackageInformation_lbl.TabIndex = 49
        Me.CompletePackageInformation_lbl.Text = "In Beschreibung beschreiben was das Komplettpaket alles liefert."
        Me.CompletePackageInformation_lbl.Visible = False
        '
        'FileStatus_picbox
        '
        Me.FileStatus_picbox.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.clonk_help
        Me.FileStatus_picbox.Location = New System.Drawing.Point(353, 50)
        Me.FileStatus_picbox.Name = "FileStatus_picbox"
        Me.FileStatus_picbox.Size = New System.Drawing.Size(24, 24)
        Me.FileStatus_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.FileStatus_picbox.TabIndex = 31
        Me.FileStatus_picbox.TabStop = False
        '
        'loading_pnl
        '
        Me.loading_pnl.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.loading_pnl.Controls.Add(Me.UploadingStatus_lbl)
        Me.loading_pnl.Controls.Add(Me.Uploading_picbox)
        Me.loading_pnl.Location = New System.Drawing.Point(1, 159)
        Me.loading_pnl.Name = "loading_pnl"
        Me.loading_pnl.Size = New System.Drawing.Size(403, 167)
        Me.loading_pnl.TabIndex = 50
        Me.loading_pnl.Visible = False
        '
        'UploadingStatus_lbl
        '
        Me.UploadingStatus_lbl.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.UploadingStatus_lbl.BackColor = System.Drawing.Color.Transparent
        Me.UploadingStatus_lbl.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.UploadingStatus_lbl.ForeColor = System.Drawing.Color.DarkGray
        Me.UploadingStatus_lbl.Location = New System.Drawing.Point(3, 89)
        Me.UploadingStatus_lbl.Name = "UploadingStatus_lbl"
        Me.UploadingStatus_lbl.Size = New System.Drawing.Size(394, 71)
        Me.UploadingStatus_lbl.TabIndex = 9
        Me.UploadingStatus_lbl.Text = "Dein Objekt wird gerade hochgeladen..."
        Me.UploadingStatus_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Uploading_picbox
        '
        Me.Uploading_picbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Uploading_picbox.BackColor = System.Drawing.Color.Transparent
        Me.Uploading_picbox.Image = CType(resources.GetObject("Uploading_picbox.Image"), System.Drawing.Image)
        Me.Uploading_picbox.Location = New System.Drawing.Point(165, 14)
        Me.Uploading_picbox.Name = "Uploading_picbox"
        Me.Uploading_picbox.Size = New System.Drawing.Size(72, 72)
        Me.Uploading_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.Uploading_picbox.TabIndex = 8
        Me.Uploading_picbox.TabStop = False
        '
        'UploadObjectFrm
        '
        Me.AllowResize = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(405, 484)
        Me.Controls.Add(Me.loading_pnl)
        Me.Controls.Add(Me.upload_btn)
        Me.Controls.Add(Me.desc_txtbox)
        Me.Controls.Add(Me.MetroLabel6)
        Me.Controls.Add(Me.Players_txtbox)
        Me.Controls.Add(Me.MetroLabel5)
        Me.Controls.Add(Me.MetroLabel4)
        Me.Controls.Add(Me.EngineVersion_cmbbox)
        Me.Controls.Add(Me.MetroLabel3)
        Me.Controls.Add(Me.Unfinished_chkbox)
        Me.Controls.Add(Me.ObjectVersion_txtbox)
        Me.Controls.Add(Me.MetroLabel2)
        Me.Controls.Add(Me.ObjectTitel_txtbox)
        Me.Controls.Add(Me.MetroLabel1)
        Me.Controls.Add(Me.FileStatus_picbox)
        Me.Controls.Add(Me.SelectFile_btn)
        Me.Controls.Add(Me.MetroLabel15)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Controls.Add(Me.CategoryOne_cmbbox)
        Me.Controls.Add(Me.CompletePackageInformation_lbl)
        Me.Controls.Add(Me.categoryDocument_cmbbox)
        Me.Controls.Add(Me.CategoryObject_cmbbox)
        Me.Controls.Add(Me.CategorySzenario_cmbbox)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "UploadObjectFrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "Neues Objekt hochladen"
        Me.controlbox_pnl.ResumeLayout(False)
        CType(Me.FileStatus_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.loading_pnl.ResumeLayout(False)
        CType(Me.Uploading_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Friend WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel15 As MetroSuite.MetroLabel
    Friend WithEvents SelectFile_btn As MetroSuite.MetroButton
    Friend WithEvents FileStatus_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents MetroLabel1 As MetroSuite.MetroLabel
    Friend WithEvents ObjectTitel_txtbox As MetroSuite.MetroTextbox
    Friend WithEvents ObjectVersion_txtbox As MetroSuite.MetroTextbox
    Friend WithEvents MetroLabel2 As MetroSuite.MetroLabel
    Friend WithEvents Unfinished_chkbox As MetroSuite.MetroChecker
    Friend WithEvents MetroLabel3 As MetroSuite.MetroLabel
    Friend WithEvents EngineVersion_cmbbox As MetroSuite.MetroComboBox
    Friend WithEvents CategoryOne_cmbbox As MetroSuite.MetroComboBox
    Friend WithEvents MetroLabel4 As MetroSuite.MetroLabel
    Friend WithEvents Players_txtbox As MetroSuite.MetroTextbox
    Friend WithEvents MetroLabel5 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel6 As MetroSuite.MetroLabel
    Friend WithEvents desc_txtbox As MetroSuite.MetroTextbox
    Friend WithEvents upload_btn As MetroSuite.MetroButton
    Friend WithEvents CategorySzenario_cmbbox As MetroSuite.MetroComboBox
    Friend WithEvents CategoryObject_cmbbox As MetroSuite.MetroComboBox
    Friend WithEvents categoryDocument_cmbbox As MetroSuite.MetroComboBox
    Friend WithEvents CompletePackageInformation_lbl As MetroSuite.MetroLabel
    Friend WithEvents loading_pnl As System.Windows.Forms.Panel
    Friend WithEvents Uploading_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents UploadingStatus_lbl As MetroSuite.MetroLabel
End Class
