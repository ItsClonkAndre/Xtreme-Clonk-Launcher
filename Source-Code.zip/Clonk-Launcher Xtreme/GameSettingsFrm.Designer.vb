﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GameSettingsFrm
    Inherits MetroSuite.MetroForm

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GameSettingsFrm))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.MetroTabControl1 = New MetroSuite.MetroTabControl()
        Me.OpenClonk_tp = New System.Windows.Forms.TabPage()
        Me.close_btn = New MetroSuite.MetroButton()
        Me.OpenClonkAccept_btn = New MetroSuite.MetroButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.OpenClonkSound_trckbar = New MetroSuite.MetroTrackbar()
        Me.MetroLabel13 = New MetroSuite.MetroLabel()
        Me.OpenClonkMusic_trckbar = New MetroSuite.MetroTrackbar()
        Me.MetroLabel12 = New MetroSuite.MetroLabel()
        Me.OpenClonkGameSound_chkbox = New MetroSuite.MetroChecker()
        Me.OpenClonkGameMusic_chkbox = New MetroSuite.MetroChecker()
        Me.OpenClonkMenuSound_chkbox = New MetroSuite.MetroChecker()
        Me.OpenClonkMenuMusic_chkbox = New MetroSuite.MetroChecker()
        Me.MetroLabel11 = New MetroSuite.MetroLabel()
        Me.OpenClonkResolutionY_nud = New System.Windows.Forms.NumericUpDown()
        Me.MetroLabel10 = New MetroSuite.MetroLabel()
        Me.OpenClonkResolutionX_nud = New System.Windows.Forms.NumericUpDown()
        Me.MetroLabel9 = New MetroSuite.MetroLabel()
        Me.MetroLabel8 = New MetroSuite.MetroLabel()
        Me.OpenClonkWindowed_chkbox = New MetroSuite.MetroChecker()
        Me.OpenClonkMultiSampling_chkbox = New MetroSuite.MetroChecker()
        Me.OpenClonkMenuTransparency_chkbox = New MetroSuite.MetroChecker()
        Me.MetroLabel7 = New MetroSuite.MetroLabel()
        Me.OpenClonkLanguage_cmdbox = New MetroSuite.MetroComboBox()
        Me.MetroLabel6 = New MetroSuite.MetroLabel()
        Me.MetroLabel19 = New MetroSuite.MetroLabel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.OpenClonkSize_lbl = New MetroSuite.MetroLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MetroLabel1 = New MetroSuite.MetroLabel()
        Me.LegacyClonk_tp = New System.Windows.Forms.TabPage()
        Me.close1_btn = New MetroSuite.MetroButton()
        Me.LegacyClonkAccept_btn = New MetroSuite.MetroButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LegacyClonkScale_trckbar = New MetroSuite.MetroTrackbar()
        Me.ScaleCount_lbl = New MetroSuite.MetroLabel()
        Me.LegacyClonkShader_chkbox = New MetroSuite.MetroChecker()
        Me.LegacyClonkSound_trckbar = New MetroSuite.MetroTrackbar()
        Me.MetroLabel14 = New MetroSuite.MetroLabel()
        Me.LegacyClonkMusic_trckbar = New MetroSuite.MetroTrackbar()
        Me.MetroLabel15 = New MetroSuite.MetroLabel()
        Me.LegacyClonkGameSound_chkbox = New MetroSuite.MetroChecker()
        Me.LegacyClonkGameMusic_chkbox = New MetroSuite.MetroChecker()
        Me.LegacyClonkMenuSound_chkbox = New MetroSuite.MetroChecker()
        Me.LegacyClonkMenuMusic_chkbox = New MetroSuite.MetroChecker()
        Me.MetroLabel16 = New MetroSuite.MetroLabel()
        Me.LegacyClonkResolutionY_nud = New System.Windows.Forms.NumericUpDown()
        Me.MetroLabel17 = New MetroSuite.MetroLabel()
        Me.LegacyClonkResolutionX_nud = New System.Windows.Forms.NumericUpDown()
        Me.MetroLabel18 = New MetroSuite.MetroLabel()
        Me.MetroLabel20 = New MetroSuite.MetroLabel()
        Me.LegacyClonkWindowed_chkbox = New MetroSuite.MetroChecker()
        Me.LegacyClonkMaximized_chkbox = New MetroSuite.MetroChecker()
        Me.LegacyClonkNewGfxCfg_chkbox = New MetroSuite.MetroChecker()
        Me.MetroLabel21 = New MetroSuite.MetroLabel()
        Me.LegacyClonkLanguage_cmdbox = New MetroSuite.MetroComboBox()
        Me.MetroLabel22 = New MetroSuite.MetroLabel()
        Me.MetroLabel23 = New MetroSuite.MetroLabel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.LegacyClonkSize_lbl = New MetroSuite.MetroLabel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.MetroLabel2 = New MetroSuite.MetroLabel()
        Me.ClonkEndeavour_tp = New System.Windows.Forms.TabPage()
        Me.close2_btn = New MetroSuite.MetroButton()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.ClonkEndeavourPXSGfx_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkEndeavourGameSound_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkEndeavourGameMusic_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkEndeavourMenuSound_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkEndeavourMenuMusic_chkbox = New MetroSuite.MetroChecker()
        Me.MetroLabel28 = New MetroSuite.MetroLabel()
        Me.ClonkEndeavourResolutionY_nud = New System.Windows.Forms.NumericUpDown()
        Me.MetroLabel29 = New MetroSuite.MetroLabel()
        Me.ClonkEndeavourResolutionX_nud = New System.Windows.Forms.NumericUpDown()
        Me.MetroLabel30 = New MetroSuite.MetroLabel()
        Me.MetroLabel31 = New MetroSuite.MetroLabel()
        Me.ClonkEndeavourNewGfxCfg_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkEndeavourMenuTransparency_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkEndeavourNewGfxCfgGL_chkbox = New MetroSuite.MetroChecker()
        Me.MetroLabel32 = New MetroSuite.MetroLabel()
        Me.ClonkEndeavourLanguage_cmdbox = New MetroSuite.MetroComboBox()
        Me.MetroLabel33 = New MetroSuite.MetroLabel()
        Me.MetroLabel34 = New MetroSuite.MetroLabel()
        Me.ClonkEndeavourAccept_btn = New MetroSuite.MetroButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.ClonkEndeavourSize_lbl = New MetroSuite.MetroLabel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.MetroLabel3 = New MetroSuite.MetroLabel()
        Me.ClonkPlanetClonk4_tp = New System.Windows.Forms.TabPage()
        Me.close3_btn = New MetroSuite.MetroButton()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkPlanetClonk4PXSGfx_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkPlanetClonk4GameSound_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkPlanetClonk4GameMusic_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkPlanetClonk4MenuSound_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkPlanetClonk4MenuMusic_chkbox = New MetroSuite.MetroChecker()
        Me.MetroLabel25 = New MetroSuite.MetroLabel()
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox = New MetroSuite.MetroChecker()
        Me.ClonkPlanetClonk4MenuTransparency_chkbox = New MetroSuite.MetroChecker()
        Me.MetroLabel36 = New MetroSuite.MetroLabel()
        Me.ClonkPlanetClonk4Language_cmdbox = New MetroSuite.MetroComboBox()
        Me.MetroLabel37 = New MetroSuite.MetroLabel()
        Me.MetroLabel38 = New MetroSuite.MetroLabel()
        Me.ClonkPlanetClonk4Accept_btn = New MetroSuite.MetroButton()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Clonk4Size_lbl = New MetroSuite.MetroLabel()
        Me.ClonkPlanetSize_lbl = New MetroSuite.MetroLabel()
        Me.MetroLabel5 = New MetroSuite.MetroLabel()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.MetroLabel4 = New MetroSuite.MetroLabel()
        Me.controlbox_pnl.SuspendLayout()
        Me.MetroTabControl1.SuspendLayout()
        Me.OpenClonk_tp.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.OpenClonkResolutionY_nud, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OpenClonkResolutionX_nud, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LegacyClonk_tp.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.LegacyClonkResolutionY_nud, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LegacyClonkResolutionX_nud, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ClonkEndeavour_tp.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.ClonkEndeavourResolutionY_nud, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClonkEndeavourResolutionX_nud, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ClonkPlanetClonk4_tp.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(318, 3)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 4
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Enabled = False
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Enabled = False
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Appearance = System.Windows.Forms.Appearance.Normal
        Me.MetroTabControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MetroTabControl1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.MetroTabControl1.Controls.Add(Me.OpenClonk_tp)
        Me.MetroTabControl1.Controls.Add(Me.LegacyClonk_tp)
        Me.MetroTabControl1.Controls.Add(Me.ClonkEndeavour_tp)
        Me.MetroTabControl1.Controls.Add(Me.ClonkPlanetClonk4_tp)
        Me.MetroTabControl1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTabControl1.ForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.HasAnimation = False
        Me.MetroTabControl1.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(106, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.MetroTabControl1.HeaderItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.HotTrack = True
        Me.MetroTabControl1.HoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.HoverColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.ItemSize = New System.Drawing.Size(11, 40)
        Me.MetroTabControl1.Location = New System.Drawing.Point(1, 36)
        Me.MetroTabControl1.Multiline = True
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedForeColor = System.Drawing.Color.White
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.SelectedItemColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedItemLineColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedTabIsBold = False
        Me.MetroTabControl1.Size = New System.Drawing.Size(376, 346)
        Me.MetroTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MetroTabControl1.TabContainerColor = System.Drawing.Color.White
        Me.MetroTabControl1.TabIndex = 5
        '
        'OpenClonk_tp
        '
        Me.OpenClonk_tp.AutoScroll = True
        Me.OpenClonk_tp.BackColor = System.Drawing.Color.White
        Me.OpenClonk_tp.Controls.Add(Me.close_btn)
        Me.OpenClonk_tp.Controls.Add(Me.OpenClonkAccept_btn)
        Me.OpenClonk_tp.Controls.Add(Me.GroupBox2)
        Me.OpenClonk_tp.Controls.Add(Me.GroupBox1)
        Me.OpenClonk_tp.Controls.Add(Me.PictureBox1)
        Me.OpenClonk_tp.Controls.Add(Me.MetroLabel1)
        Me.OpenClonk_tp.Location = New System.Drawing.Point(44, 4)
        Me.OpenClonk_tp.Name = "OpenClonk_tp"
        Me.OpenClonk_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.OpenClonk_tp.Size = New System.Drawing.Size(328, 338)
        Me.OpenClonk_tp.TabIndex = 0
        Me.OpenClonk_tp.Text = "OC"
        '
        'close_btn
        '
        Me.close_btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.close_btn.BackColor = System.Drawing.Color.Transparent
        Me.close_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.close_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.close_btn.DefaultColor = System.Drawing.Color.White
        Me.close_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.close_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.close_btn.HoverColor = System.Drawing.Color.White
        Me.close_btn.Location = New System.Drawing.Point(8, 589)
        Me.close_btn.Name = "close_btn"
        Me.close_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.close_btn.RoundingArc = 23
        Me.close_btn.Size = New System.Drawing.Size(263, 23)
        Me.close_btn.TabIndex = 40
        Me.close_btn.Text = "Abbrechen"
        '
        'OpenClonkAccept_btn
        '
        Me.OpenClonkAccept_btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OpenClonkAccept_btn.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkAccept_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkAccept_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkAccept_btn.DefaultColor = System.Drawing.Color.White
        Me.OpenClonkAccept_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.OpenClonkAccept_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.OpenClonkAccept_btn.HoverColor = System.Drawing.Color.White
        Me.OpenClonkAccept_btn.Location = New System.Drawing.Point(8, 560)
        Me.OpenClonkAccept_btn.Name = "OpenClonkAccept_btn"
        Me.OpenClonkAccept_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkAccept_btn.RoundingArc = 23
        Me.OpenClonkAccept_btn.Size = New System.Drawing.Size(263, 23)
        Me.OpenClonkAccept_btn.TabIndex = 39
        Me.OpenClonkAccept_btn.Text = "Übernehmen"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.OpenClonkSound_trckbar)
        Me.GroupBox2.Controls.Add(Me.MetroLabel13)
        Me.GroupBox2.Controls.Add(Me.OpenClonkMusic_trckbar)
        Me.GroupBox2.Controls.Add(Me.MetroLabel12)
        Me.GroupBox2.Controls.Add(Me.OpenClonkGameSound_chkbox)
        Me.GroupBox2.Controls.Add(Me.OpenClonkGameMusic_chkbox)
        Me.GroupBox2.Controls.Add(Me.OpenClonkMenuSound_chkbox)
        Me.GroupBox2.Controls.Add(Me.OpenClonkMenuMusic_chkbox)
        Me.GroupBox2.Controls.Add(Me.MetroLabel11)
        Me.GroupBox2.Controls.Add(Me.OpenClonkResolutionY_nud)
        Me.GroupBox2.Controls.Add(Me.MetroLabel10)
        Me.GroupBox2.Controls.Add(Me.OpenClonkResolutionX_nud)
        Me.GroupBox2.Controls.Add(Me.MetroLabel9)
        Me.GroupBox2.Controls.Add(Me.MetroLabel8)
        Me.GroupBox2.Controls.Add(Me.OpenClonkWindowed_chkbox)
        Me.GroupBox2.Controls.Add(Me.OpenClonkMultiSampling_chkbox)
        Me.GroupBox2.Controls.Add(Me.OpenClonkMenuTransparency_chkbox)
        Me.GroupBox2.Controls.Add(Me.MetroLabel7)
        Me.GroupBox2.Controls.Add(Me.OpenClonkLanguage_cmdbox)
        Me.GroupBox2.Controls.Add(Me.MetroLabel6)
        Me.GroupBox2.Controls.Add(Me.MetroLabel19)
        Me.GroupBox2.ForeColor = System.Drawing.Color.DarkGray
        Me.GroupBox2.Location = New System.Drawing.Point(8, 133)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(263, 421)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Optionen"
        '
        'OpenClonkSound_trckbar
        '
        Me.OpenClonkSound_trckbar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OpenClonkSound_trckbar.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkSound_trckbar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkSound_trckbar.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkSound_trckbar.GradientColor = System.Drawing.Color.Red
        Me.OpenClonkSound_trckbar.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.OpenClonkSound_trckbar.LeftColor = System.Drawing.Color.Lime
        Me.OpenClonkSound_trckbar.Location = New System.Drawing.Point(10, 381)
        Me.OpenClonkSound_trckbar.Name = "OpenClonkSound_trckbar"
        Me.OpenClonkSound_trckbar.RegionColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.OpenClonkSound_trckbar.RightColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.OpenClonkSound_trckbar.Size = New System.Drawing.Size(231, 23)
        Me.OpenClonkSound_trckbar.SliderColor = System.Drawing.Color.White
        Me.OpenClonkSound_trckbar.TabIndex = 51
        Me.OpenClonkSound_trckbar.Value = 100
        '
        'MetroLabel13
        '
        Me.MetroLabel13.AutoSize = True
        Me.MetroLabel13.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel13.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel13.Location = New System.Drawing.Point(6, 359)
        Me.MetroLabel13.Name = "MetroLabel13"
        Me.MetroLabel13.Size = New System.Drawing.Size(48, 19)
        Me.MetroLabel13.TabIndex = 50
        Me.MetroLabel13.Text = "Sound"
        '
        'OpenClonkMusic_trckbar
        '
        Me.OpenClonkMusic_trckbar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OpenClonkMusic_trckbar.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkMusic_trckbar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkMusic_trckbar.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkMusic_trckbar.GradientColor = System.Drawing.Color.Red
        Me.OpenClonkMusic_trckbar.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.OpenClonkMusic_trckbar.LeftColor = System.Drawing.Color.Lime
        Me.OpenClonkMusic_trckbar.Location = New System.Drawing.Point(10, 333)
        Me.OpenClonkMusic_trckbar.Name = "OpenClonkMusic_trckbar"
        Me.OpenClonkMusic_trckbar.RegionColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.OpenClonkMusic_trckbar.RightColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.OpenClonkMusic_trckbar.Size = New System.Drawing.Size(231, 23)
        Me.OpenClonkMusic_trckbar.SliderColor = System.Drawing.Color.White
        Me.OpenClonkMusic_trckbar.TabIndex = 49
        Me.OpenClonkMusic_trckbar.Value = 100
        '
        'MetroLabel12
        '
        Me.MetroLabel12.AutoSize = True
        Me.MetroLabel12.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel12.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel12.Location = New System.Drawing.Point(6, 311)
        Me.MetroLabel12.Name = "MetroLabel12"
        Me.MetroLabel12.Size = New System.Drawing.Size(45, 19)
        Me.MetroLabel12.TabIndex = 48
        Me.MetroLabel12.Text = "Music"
        '
        'OpenClonkGameSound_chkbox
        '
        Me.OpenClonkGameSound_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkGameSound_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkGameSound_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkGameSound_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkGameSound_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.OpenClonkGameSound_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.OpenClonkGameSound_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.OpenClonkGameSound_chkbox.Location = New System.Drawing.Point(9, 285)
        Me.OpenClonkGameSound_chkbox.Name = "OpenClonkGameSound_chkbox"
        Me.OpenClonkGameSound_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.OpenClonkGameSound_chkbox.Size = New System.Drawing.Size(95, 14)
        Me.OpenClonkGameSound_chkbox.TabIndex = 47
        Me.OpenClonkGameSound_chkbox.Text = "GameSound"
        '
        'OpenClonkGameMusic_chkbox
        '
        Me.OpenClonkGameMusic_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkGameMusic_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkGameMusic_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkGameMusic_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkGameMusic_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.OpenClonkGameMusic_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.OpenClonkGameMusic_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.OpenClonkGameMusic_chkbox.Location = New System.Drawing.Point(9, 265)
        Me.OpenClonkGameMusic_chkbox.Name = "OpenClonkGameMusic_chkbox"
        Me.OpenClonkGameMusic_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.OpenClonkGameMusic_chkbox.Size = New System.Drawing.Size(91, 14)
        Me.OpenClonkGameMusic_chkbox.TabIndex = 46
        Me.OpenClonkGameMusic_chkbox.Text = "GameMusic"
        '
        'OpenClonkMenuSound_chkbox
        '
        Me.OpenClonkMenuSound_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkMenuSound_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkMenuSound_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkMenuSound_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkMenuSound_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.OpenClonkMenuSound_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.OpenClonkMenuSound_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.OpenClonkMenuSound_chkbox.Location = New System.Drawing.Point(9, 245)
        Me.OpenClonkMenuSound_chkbox.Name = "OpenClonkMenuSound_chkbox"
        Me.OpenClonkMenuSound_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.OpenClonkMenuSound_chkbox.Size = New System.Drawing.Size(94, 14)
        Me.OpenClonkMenuSound_chkbox.TabIndex = 45
        Me.OpenClonkMenuSound_chkbox.Text = "MenuSound"
        '
        'OpenClonkMenuMusic_chkbox
        '
        Me.OpenClonkMenuMusic_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkMenuMusic_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkMenuMusic_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkMenuMusic_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkMenuMusic_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.OpenClonkMenuMusic_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.OpenClonkMenuMusic_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.OpenClonkMenuMusic_chkbox.Location = New System.Drawing.Point(9, 225)
        Me.OpenClonkMenuMusic_chkbox.Name = "OpenClonkMenuMusic_chkbox"
        Me.OpenClonkMenuMusic_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.OpenClonkMenuMusic_chkbox.Size = New System.Drawing.Size(91, 14)
        Me.OpenClonkMenuMusic_chkbox.TabIndex = 44
        Me.OpenClonkMenuMusic_chkbox.Text = "MenuMusic"
        '
        'MetroLabel11
        '
        Me.MetroLabel11.AutoSize = True
        Me.MetroLabel11.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel11.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel11.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel11.Location = New System.Drawing.Point(11, 201)
        Me.MetroLabel11.Name = "MetroLabel11"
        Me.MetroLabel11.Size = New System.Drawing.Size(77, 21)
        Me.MetroLabel11.TabIndex = 43
        Me.MetroLabel11.Text = "- Sound -"
        '
        'OpenClonkResolutionY_nud
        '
        Me.OpenClonkResolutionY_nud.Location = New System.Drawing.Point(213, 167)
        Me.OpenClonkResolutionY_nud.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.OpenClonkResolutionY_nud.Name = "OpenClonkResolutionY_nud"
        Me.OpenClonkResolutionY_nud.Size = New System.Drawing.Size(60, 23)
        Me.OpenClonkResolutionY_nud.TabIndex = 42
        Me.OpenClonkResolutionY_nud.Value = New Decimal(New Integer() {1080, 0, 0, 0})
        '
        'MetroLabel10
        '
        Me.MetroLabel10.AutoSize = True
        Me.MetroLabel10.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel10.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel10.Location = New System.Drawing.Point(187, 167)
        Me.MetroLabel10.Name = "MetroLabel10"
        Me.MetroLabel10.Size = New System.Drawing.Size(20, 19)
        Me.MetroLabel10.TabIndex = 41
        Me.MetroLabel10.Text = "Y:"
        '
        'OpenClonkResolutionX_nud
        '
        Me.OpenClonkResolutionX_nud.Location = New System.Drawing.Point(112, 167)
        Me.OpenClonkResolutionX_nud.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.OpenClonkResolutionX_nud.Name = "OpenClonkResolutionX_nud"
        Me.OpenClonkResolutionX_nud.Size = New System.Drawing.Size(60, 23)
        Me.OpenClonkResolutionX_nud.TabIndex = 40
        Me.OpenClonkResolutionX_nud.Value = New Decimal(New Integer() {1920, 0, 0, 0})
        '
        'MetroLabel9
        '
        Me.MetroLabel9.AutoSize = True
        Me.MetroLabel9.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel9.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel9.Location = New System.Drawing.Point(86, 167)
        Me.MetroLabel9.Name = "MetroLabel9"
        Me.MetroLabel9.Size = New System.Drawing.Size(20, 19)
        Me.MetroLabel9.TabIndex = 39
        Me.MetroLabel9.Text = "X:"
        '
        'MetroLabel8
        '
        Me.MetroLabel8.AutoSize = True
        Me.MetroLabel8.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel8.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel8.Location = New System.Drawing.Point(6, 167)
        Me.MetroLabel8.Name = "MetroLabel8"
        Me.MetroLabel8.Size = New System.Drawing.Size(74, 19)
        Me.MetroLabel8.TabIndex = 38
        Me.MetroLabel8.Text = "Auflösung:"
        '
        'OpenClonkWindowed_chkbox
        '
        Me.OpenClonkWindowed_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkWindowed_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkWindowed_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkWindowed_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkWindowed_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.OpenClonkWindowed_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.OpenClonkWindowed_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.OpenClonkWindowed_chkbox.Location = New System.Drawing.Point(9, 144)
        Me.OpenClonkWindowed_chkbox.Name = "OpenClonkWindowed_chkbox"
        Me.OpenClonkWindowed_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.OpenClonkWindowed_chkbox.Size = New System.Drawing.Size(86, 14)
        Me.OpenClonkWindowed_chkbox.TabIndex = 37
        Me.OpenClonkWindowed_chkbox.Text = "Windowed"
        '
        'OpenClonkMultiSampling_chkbox
        '
        Me.OpenClonkMultiSampling_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkMultiSampling_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkMultiSampling_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkMultiSampling_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkMultiSampling_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.OpenClonkMultiSampling_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.OpenClonkMultiSampling_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.OpenClonkMultiSampling_chkbox.Location = New System.Drawing.Point(9, 124)
        Me.OpenClonkMultiSampling_chkbox.Name = "OpenClonkMultiSampling_chkbox"
        Me.OpenClonkMultiSampling_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.OpenClonkMultiSampling_chkbox.Size = New System.Drawing.Size(109, 14)
        Me.OpenClonkMultiSampling_chkbox.TabIndex = 36
        Me.OpenClonkMultiSampling_chkbox.Text = "MultiSampling"
        '
        'OpenClonkMenuTransparency_chkbox
        '
        Me.OpenClonkMenuTransparency_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkMenuTransparency_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonkMenuTransparency_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkMenuTransparency_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkMenuTransparency_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.OpenClonkMenuTransparency_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.OpenClonkMenuTransparency_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.OpenClonkMenuTransparency_chkbox.Location = New System.Drawing.Point(9, 104)
        Me.OpenClonkMenuTransparency_chkbox.Name = "OpenClonkMenuTransparency_chkbox"
        Me.OpenClonkMenuTransparency_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.OpenClonkMenuTransparency_chkbox.Size = New System.Drawing.Size(136, 14)
        Me.OpenClonkMenuTransparency_chkbox.TabIndex = 35
        Me.OpenClonkMenuTransparency_chkbox.Text = "MenuTransparency"
        '
        'MetroLabel7
        '
        Me.MetroLabel7.AutoSize = True
        Me.MetroLabel7.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel7.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel7.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel7.Location = New System.Drawing.Point(11, 80)
        Me.MetroLabel7.Name = "MetroLabel7"
        Me.MetroLabel7.Size = New System.Drawing.Size(73, 21)
        Me.MetroLabel7.TabIndex = 34
        Me.MetroLabel7.Text = "- Grafik -"
        '
        'OpenClonkLanguage_cmdbox
        '
        Me.OpenClonkLanguage_cmdbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkLanguage_cmdbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkLanguage_cmdbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonkLanguage_cmdbox.DefaultColor = System.Drawing.Color.White
        Me.OpenClonkLanguage_cmdbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.OpenClonkLanguage_cmdbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.OpenClonkLanguage_cmdbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OpenClonkLanguage_cmdbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OpenClonkLanguage_cmdbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.OpenClonkLanguage_cmdbox.ForeColor = System.Drawing.Color.Black
        Me.OpenClonkLanguage_cmdbox.FormattingEnabled = True
        Me.OpenClonkLanguage_cmdbox.Items.AddRange(New Object() {"DE - Deutsch", "US - English"})
        Me.OpenClonkLanguage_cmdbox.Location = New System.Drawing.Point(72, 43)
        Me.OpenClonkLanguage_cmdbox.Name = "OpenClonkLanguage_cmdbox"
        Me.OpenClonkLanguage_cmdbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonkLanguage_cmdbox.Size = New System.Drawing.Size(163, 24)
        Me.OpenClonkLanguage_cmdbox.TabIndex = 33
        '
        'MetroLabel6
        '
        Me.MetroLabel6.AutoSize = True
        Me.MetroLabel6.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel6.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel6.Location = New System.Drawing.Point(6, 44)
        Me.MetroLabel6.Name = "MetroLabel6"
        Me.MetroLabel6.Size = New System.Drawing.Size(60, 19)
        Me.MetroLabel6.TabIndex = 32
        Me.MetroLabel6.Text = "Sprache:"
        '
        'MetroLabel19
        '
        Me.MetroLabel19.AutoSize = True
        Me.MetroLabel19.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel19.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel19.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel19.Location = New System.Drawing.Point(11, 21)
        Me.MetroLabel19.Name = "MetroLabel19"
        Me.MetroLabel19.Size = New System.Drawing.Size(104, 21)
        Me.MetroLabel19.TabIndex = 31
        Me.MetroLabel19.Text = "- Allgemein -"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.OpenClonkSize_lbl)
        Me.GroupBox1.ForeColor = System.Drawing.Color.DarkGray
        Me.GroupBox1.Location = New System.Drawing.Point(8, 83)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(263, 44)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Details"
        '
        'OpenClonkSize_lbl
        '
        Me.OpenClonkSize_lbl.AutoSize = True
        Me.OpenClonkSize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonkSize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.OpenClonkSize_lbl.Location = New System.Drawing.Point(6, 19)
        Me.OpenClonkSize_lbl.Name = "OpenClonkSize_lbl"
        Me.OpenClonkSize_lbl.Size = New System.Drawing.Size(145, 15)
        Me.OpenClonkSize_lbl.TabIndex = 0
        Me.OpenClonkSize_lbl.Text = "Größe auf Datenträger: %s"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.OpenClonkSymbol
        Me.PictureBox1.Location = New System.Drawing.Point(139, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(0, 32)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'MetroLabel1
        '
        Me.MetroLabel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel1.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.MetroLabel1.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel1.Location = New System.Drawing.Point(49, 50)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(179, 25)
        Me.MetroLabel1.TabIndex = 1
        Me.MetroLabel1.Text = "OpenClonk"
        Me.MetroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LegacyClonk_tp
        '
        Me.LegacyClonk_tp.AutoScroll = True
        Me.LegacyClonk_tp.BackColor = System.Drawing.Color.White
        Me.LegacyClonk_tp.Controls.Add(Me.close1_btn)
        Me.LegacyClonk_tp.Controls.Add(Me.LegacyClonkAccept_btn)
        Me.LegacyClonk_tp.Controls.Add(Me.GroupBox3)
        Me.LegacyClonk_tp.Controls.Add(Me.GroupBox4)
        Me.LegacyClonk_tp.Controls.Add(Me.PictureBox2)
        Me.LegacyClonk_tp.Controls.Add(Me.MetroLabel2)
        Me.LegacyClonk_tp.Location = New System.Drawing.Point(44, 4)
        Me.LegacyClonk_tp.Name = "LegacyClonk_tp"
        Me.LegacyClonk_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.LegacyClonk_tp.Size = New System.Drawing.Size(328, 338)
        Me.LegacyClonk_tp.TabIndex = 1
        Me.LegacyClonk_tp.Text = "LC"
        '
        'close1_btn
        '
        Me.close1_btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.close1_btn.BackColor = System.Drawing.Color.Transparent
        Me.close1_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.close1_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.close1_btn.DefaultColor = System.Drawing.Color.White
        Me.close1_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.close1_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.close1_btn.HoverColor = System.Drawing.Color.White
        Me.close1_btn.Location = New System.Drawing.Point(8, 633)
        Me.close1_btn.Name = "close1_btn"
        Me.close1_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.close1_btn.RoundingArc = 23
        Me.close1_btn.Size = New System.Drawing.Size(263, 23)
        Me.close1_btn.TabIndex = 52
        Me.close1_btn.Text = "Abbrechen"
        '
        'LegacyClonkAccept_btn
        '
        Me.LegacyClonkAccept_btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LegacyClonkAccept_btn.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkAccept_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkAccept_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkAccept_btn.DefaultColor = System.Drawing.Color.White
        Me.LegacyClonkAccept_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.LegacyClonkAccept_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.LegacyClonkAccept_btn.HoverColor = System.Drawing.Color.White
        Me.LegacyClonkAccept_btn.Location = New System.Drawing.Point(8, 604)
        Me.LegacyClonkAccept_btn.Name = "LegacyClonkAccept_btn"
        Me.LegacyClonkAccept_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkAccept_btn.RoundingArc = 23
        Me.LegacyClonkAccept_btn.Size = New System.Drawing.Size(263, 23)
        Me.LegacyClonkAccept_btn.TabIndex = 52
        Me.LegacyClonkAccept_btn.Text = "Übernehmen"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkScale_trckbar)
        Me.GroupBox3.Controls.Add(Me.ScaleCount_lbl)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkShader_chkbox)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkSound_trckbar)
        Me.GroupBox3.Controls.Add(Me.MetroLabel14)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkMusic_trckbar)
        Me.GroupBox3.Controls.Add(Me.MetroLabel15)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkGameSound_chkbox)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkGameMusic_chkbox)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkMenuSound_chkbox)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkMenuMusic_chkbox)
        Me.GroupBox3.Controls.Add(Me.MetroLabel16)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkResolutionY_nud)
        Me.GroupBox3.Controls.Add(Me.MetroLabel17)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkResolutionX_nud)
        Me.GroupBox3.Controls.Add(Me.MetroLabel18)
        Me.GroupBox3.Controls.Add(Me.MetroLabel20)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkWindowed_chkbox)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkMaximized_chkbox)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkNewGfxCfg_chkbox)
        Me.GroupBox3.Controls.Add(Me.MetroLabel21)
        Me.GroupBox3.Controls.Add(Me.LegacyClonkLanguage_cmdbox)
        Me.GroupBox3.Controls.Add(Me.MetroLabel22)
        Me.GroupBox3.Controls.Add(Me.MetroLabel23)
        Me.GroupBox3.ForeColor = System.Drawing.Color.DarkGray
        Me.GroupBox3.Location = New System.Drawing.Point(8, 133)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(263, 464)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Optionen"
        '
        'LegacyClonkScale_trckbar
        '
        Me.LegacyClonkScale_trckbar.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkScale_trckbar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkScale_trckbar.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkScale_trckbar.GradientColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(163, Byte), Integer))
        Me.LegacyClonkScale_trckbar.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LegacyClonkScale_trckbar.LeftColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkScale_trckbar.Location = New System.Drawing.Point(101, 216)
        Me.LegacyClonkScale_trckbar.Maximum = 300
        Me.LegacyClonkScale_trckbar.Minimum = 100
        Me.LegacyClonkScale_trckbar.Name = "LegacyClonkScale_trckbar"
        Me.LegacyClonkScale_trckbar.RegionColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LegacyClonkScale_trckbar.RightColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.LegacyClonkScale_trckbar.Size = New System.Drawing.Size(172, 23)
        Me.LegacyClonkScale_trckbar.SliderColor = System.Drawing.Color.White
        Me.LegacyClonkScale_trckbar.TabIndex = 54
        Me.LegacyClonkScale_trckbar.Value = 100
        '
        'ScaleCount_lbl
        '
        Me.ScaleCount_lbl.AutoSize = True
        Me.ScaleCount_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ScaleCount_lbl.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ScaleCount_lbl.Location = New System.Drawing.Point(6, 217)
        Me.ScaleCount_lbl.Name = "ScaleCount_lbl"
        Me.ScaleCount_lbl.Size = New System.Drawing.Size(89, 19)
        Me.ScaleCount_lbl.TabIndex = 53
        Me.ScaleCount_lbl.Text = "Scale (100%):"
        '
        'LegacyClonkShader_chkbox
        '
        Me.LegacyClonkShader_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkShader_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkShader_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkShader_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkShader_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.LegacyClonkShader_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.LegacyClonkShader_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.LegacyClonkShader_chkbox.Location = New System.Drawing.Point(9, 164)
        Me.LegacyClonkShader_chkbox.Name = "LegacyClonkShader_chkbox"
        Me.LegacyClonkShader_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.LegacyClonkShader_chkbox.Size = New System.Drawing.Size(63, 14)
        Me.LegacyClonkShader_chkbox.TabIndex = 52
        Me.LegacyClonkShader_chkbox.Text = "Shader"
        '
        'LegacyClonkSound_trckbar
        '
        Me.LegacyClonkSound_trckbar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LegacyClonkSound_trckbar.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkSound_trckbar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkSound_trckbar.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkSound_trckbar.GradientColor = System.Drawing.Color.Red
        Me.LegacyClonkSound_trckbar.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LegacyClonkSound_trckbar.LeftColor = System.Drawing.Color.Lime
        Me.LegacyClonkSound_trckbar.Location = New System.Drawing.Point(10, 423)
        Me.LegacyClonkSound_trckbar.Name = "LegacyClonkSound_trckbar"
        Me.LegacyClonkSound_trckbar.RegionColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LegacyClonkSound_trckbar.RightColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.LegacyClonkSound_trckbar.Size = New System.Drawing.Size(231, 23)
        Me.LegacyClonkSound_trckbar.SliderColor = System.Drawing.Color.White
        Me.LegacyClonkSound_trckbar.TabIndex = 51
        Me.LegacyClonkSound_trckbar.Value = 100
        '
        'MetroLabel14
        '
        Me.MetroLabel14.AutoSize = True
        Me.MetroLabel14.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel14.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel14.Location = New System.Drawing.Point(6, 401)
        Me.MetroLabel14.Name = "MetroLabel14"
        Me.MetroLabel14.Size = New System.Drawing.Size(48, 19)
        Me.MetroLabel14.TabIndex = 50
        Me.MetroLabel14.Text = "Sound"
        '
        'LegacyClonkMusic_trckbar
        '
        Me.LegacyClonkMusic_trckbar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LegacyClonkMusic_trckbar.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkMusic_trckbar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkMusic_trckbar.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkMusic_trckbar.GradientColor = System.Drawing.Color.Red
        Me.LegacyClonkMusic_trckbar.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LegacyClonkMusic_trckbar.LeftColor = System.Drawing.Color.Lime
        Me.LegacyClonkMusic_trckbar.Location = New System.Drawing.Point(10, 375)
        Me.LegacyClonkMusic_trckbar.Name = "LegacyClonkMusic_trckbar"
        Me.LegacyClonkMusic_trckbar.RegionColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LegacyClonkMusic_trckbar.RightColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.LegacyClonkMusic_trckbar.Size = New System.Drawing.Size(231, 23)
        Me.LegacyClonkMusic_trckbar.SliderColor = System.Drawing.Color.White
        Me.LegacyClonkMusic_trckbar.TabIndex = 49
        Me.LegacyClonkMusic_trckbar.Value = 100
        '
        'MetroLabel15
        '
        Me.MetroLabel15.AutoSize = True
        Me.MetroLabel15.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel15.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel15.Location = New System.Drawing.Point(6, 353)
        Me.MetroLabel15.Name = "MetroLabel15"
        Me.MetroLabel15.Size = New System.Drawing.Size(45, 19)
        Me.MetroLabel15.TabIndex = 48
        Me.MetroLabel15.Text = "Music"
        '
        'LegacyClonkGameSound_chkbox
        '
        Me.LegacyClonkGameSound_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkGameSound_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkGameSound_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkGameSound_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkGameSound_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.LegacyClonkGameSound_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.LegacyClonkGameSound_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.LegacyClonkGameSound_chkbox.Location = New System.Drawing.Point(9, 329)
        Me.LegacyClonkGameSound_chkbox.Name = "LegacyClonkGameSound_chkbox"
        Me.LegacyClonkGameSound_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.LegacyClonkGameSound_chkbox.Size = New System.Drawing.Size(95, 14)
        Me.LegacyClonkGameSound_chkbox.TabIndex = 47
        Me.LegacyClonkGameSound_chkbox.Text = "GameSound"
        '
        'LegacyClonkGameMusic_chkbox
        '
        Me.LegacyClonkGameMusic_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkGameMusic_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkGameMusic_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkGameMusic_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkGameMusic_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.LegacyClonkGameMusic_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.LegacyClonkGameMusic_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.LegacyClonkGameMusic_chkbox.Location = New System.Drawing.Point(9, 309)
        Me.LegacyClonkGameMusic_chkbox.Name = "LegacyClonkGameMusic_chkbox"
        Me.LegacyClonkGameMusic_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.LegacyClonkGameMusic_chkbox.Size = New System.Drawing.Size(91, 14)
        Me.LegacyClonkGameMusic_chkbox.TabIndex = 46
        Me.LegacyClonkGameMusic_chkbox.Text = "GameMusic"
        '
        'LegacyClonkMenuSound_chkbox
        '
        Me.LegacyClonkMenuSound_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkMenuSound_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkMenuSound_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkMenuSound_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkMenuSound_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.LegacyClonkMenuSound_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.LegacyClonkMenuSound_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.LegacyClonkMenuSound_chkbox.Location = New System.Drawing.Point(9, 289)
        Me.LegacyClonkMenuSound_chkbox.Name = "LegacyClonkMenuSound_chkbox"
        Me.LegacyClonkMenuSound_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.LegacyClonkMenuSound_chkbox.Size = New System.Drawing.Size(94, 14)
        Me.LegacyClonkMenuSound_chkbox.TabIndex = 45
        Me.LegacyClonkMenuSound_chkbox.Text = "MenuSound"
        '
        'LegacyClonkMenuMusic_chkbox
        '
        Me.LegacyClonkMenuMusic_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkMenuMusic_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkMenuMusic_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkMenuMusic_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkMenuMusic_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.LegacyClonkMenuMusic_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.LegacyClonkMenuMusic_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.LegacyClonkMenuMusic_chkbox.Location = New System.Drawing.Point(9, 269)
        Me.LegacyClonkMenuMusic_chkbox.Name = "LegacyClonkMenuMusic_chkbox"
        Me.LegacyClonkMenuMusic_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.LegacyClonkMenuMusic_chkbox.Size = New System.Drawing.Size(91, 14)
        Me.LegacyClonkMenuMusic_chkbox.TabIndex = 44
        Me.LegacyClonkMenuMusic_chkbox.Text = "MenuMusic"
        '
        'MetroLabel16
        '
        Me.MetroLabel16.AutoSize = True
        Me.MetroLabel16.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel16.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel16.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel16.Location = New System.Drawing.Point(11, 245)
        Me.MetroLabel16.Name = "MetroLabel16"
        Me.MetroLabel16.Size = New System.Drawing.Size(77, 21)
        Me.MetroLabel16.TabIndex = 43
        Me.MetroLabel16.Text = "- Sound -"
        '
        'LegacyClonkResolutionY_nud
        '
        Me.LegacyClonkResolutionY_nud.Location = New System.Drawing.Point(213, 187)
        Me.LegacyClonkResolutionY_nud.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.LegacyClonkResolutionY_nud.Name = "LegacyClonkResolutionY_nud"
        Me.LegacyClonkResolutionY_nud.Size = New System.Drawing.Size(60, 23)
        Me.LegacyClonkResolutionY_nud.TabIndex = 42
        Me.LegacyClonkResolutionY_nud.Value = New Decimal(New Integer() {1080, 0, 0, 0})
        '
        'MetroLabel17
        '
        Me.MetroLabel17.AutoSize = True
        Me.MetroLabel17.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel17.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel17.Location = New System.Drawing.Point(187, 187)
        Me.MetroLabel17.Name = "MetroLabel17"
        Me.MetroLabel17.Size = New System.Drawing.Size(20, 19)
        Me.MetroLabel17.TabIndex = 41
        Me.MetroLabel17.Text = "Y:"
        '
        'LegacyClonkResolutionX_nud
        '
        Me.LegacyClonkResolutionX_nud.Location = New System.Drawing.Point(112, 187)
        Me.LegacyClonkResolutionX_nud.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.LegacyClonkResolutionX_nud.Name = "LegacyClonkResolutionX_nud"
        Me.LegacyClonkResolutionX_nud.Size = New System.Drawing.Size(60, 23)
        Me.LegacyClonkResolutionX_nud.TabIndex = 40
        Me.LegacyClonkResolutionX_nud.Value = New Decimal(New Integer() {1920, 0, 0, 0})
        '
        'MetroLabel18
        '
        Me.MetroLabel18.AutoSize = True
        Me.MetroLabel18.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel18.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel18.Location = New System.Drawing.Point(86, 187)
        Me.MetroLabel18.Name = "MetroLabel18"
        Me.MetroLabel18.Size = New System.Drawing.Size(20, 19)
        Me.MetroLabel18.TabIndex = 39
        Me.MetroLabel18.Text = "X:"
        '
        'MetroLabel20
        '
        Me.MetroLabel20.AutoSize = True
        Me.MetroLabel20.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel20.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel20.Location = New System.Drawing.Point(6, 187)
        Me.MetroLabel20.Name = "MetroLabel20"
        Me.MetroLabel20.Size = New System.Drawing.Size(74, 19)
        Me.MetroLabel20.TabIndex = 38
        Me.MetroLabel20.Text = "Auflösung:"
        '
        'LegacyClonkWindowed_chkbox
        '
        Me.LegacyClonkWindowed_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkWindowed_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkWindowed_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkWindowed_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkWindowed_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.LegacyClonkWindowed_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.LegacyClonkWindowed_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.LegacyClonkWindowed_chkbox.Location = New System.Drawing.Point(9, 124)
        Me.LegacyClonkWindowed_chkbox.Name = "LegacyClonkWindowed_chkbox"
        Me.LegacyClonkWindowed_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.LegacyClonkWindowed_chkbox.Size = New System.Drawing.Size(86, 14)
        Me.LegacyClonkWindowed_chkbox.TabIndex = 37
        Me.LegacyClonkWindowed_chkbox.Text = "Windowed"
        '
        'LegacyClonkMaximized_chkbox
        '
        Me.LegacyClonkMaximized_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkMaximized_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkMaximized_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkMaximized_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkMaximized_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.LegacyClonkMaximized_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.LegacyClonkMaximized_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.LegacyClonkMaximized_chkbox.Location = New System.Drawing.Point(9, 104)
        Me.LegacyClonkMaximized_chkbox.Name = "LegacyClonkMaximized_chkbox"
        Me.LegacyClonkMaximized_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.LegacyClonkMaximized_chkbox.Size = New System.Drawing.Size(86, 14)
        Me.LegacyClonkMaximized_chkbox.TabIndex = 36
        Me.LegacyClonkMaximized_chkbox.Text = "Maximized"
        '
        'LegacyClonkNewGfxCfg_chkbox
        '
        Me.LegacyClonkNewGfxCfg_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkNewGfxCfg_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LegacyClonkNewGfxCfg_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkNewGfxCfg_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkNewGfxCfg_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.LegacyClonkNewGfxCfg_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.LegacyClonkNewGfxCfg_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.LegacyClonkNewGfxCfg_chkbox.Location = New System.Drawing.Point(9, 144)
        Me.LegacyClonkNewGfxCfg_chkbox.Name = "LegacyClonkNewGfxCfg_chkbox"
        Me.LegacyClonkNewGfxCfg_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.LegacyClonkNewGfxCfg_chkbox.Size = New System.Drawing.Size(89, 14)
        Me.LegacyClonkNewGfxCfg_chkbox.TabIndex = 35
        Me.LegacyClonkNewGfxCfg_chkbox.Text = "NewGfxCfg"
        '
        'MetroLabel21
        '
        Me.MetroLabel21.AutoSize = True
        Me.MetroLabel21.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel21.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel21.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel21.Location = New System.Drawing.Point(11, 80)
        Me.MetroLabel21.Name = "MetroLabel21"
        Me.MetroLabel21.Size = New System.Drawing.Size(73, 21)
        Me.MetroLabel21.TabIndex = 34
        Me.MetroLabel21.Text = "- Grafik -"
        '
        'LegacyClonkLanguage_cmdbox
        '
        Me.LegacyClonkLanguage_cmdbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkLanguage_cmdbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkLanguage_cmdbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LegacyClonkLanguage_cmdbox.DefaultColor = System.Drawing.Color.White
        Me.LegacyClonkLanguage_cmdbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.LegacyClonkLanguage_cmdbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.LegacyClonkLanguage_cmdbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.LegacyClonkLanguage_cmdbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LegacyClonkLanguage_cmdbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.LegacyClonkLanguage_cmdbox.ForeColor = System.Drawing.Color.Black
        Me.LegacyClonkLanguage_cmdbox.FormattingEnabled = True
        Me.LegacyClonkLanguage_cmdbox.Items.AddRange(New Object() {"DE", "US", "LD", "LU"})
        Me.LegacyClonkLanguage_cmdbox.Location = New System.Drawing.Point(72, 43)
        Me.LegacyClonkLanguage_cmdbox.Name = "LegacyClonkLanguage_cmdbox"
        Me.LegacyClonkLanguage_cmdbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LegacyClonkLanguage_cmdbox.Size = New System.Drawing.Size(163, 24)
        Me.LegacyClonkLanguage_cmdbox.TabIndex = 33
        '
        'MetroLabel22
        '
        Me.MetroLabel22.AutoSize = True
        Me.MetroLabel22.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel22.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel22.Location = New System.Drawing.Point(6, 44)
        Me.MetroLabel22.Name = "MetroLabel22"
        Me.MetroLabel22.Size = New System.Drawing.Size(60, 19)
        Me.MetroLabel22.TabIndex = 32
        Me.MetroLabel22.Text = "Sprache:"
        '
        'MetroLabel23
        '
        Me.MetroLabel23.AutoSize = True
        Me.MetroLabel23.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel23.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel23.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel23.Location = New System.Drawing.Point(11, 21)
        Me.MetroLabel23.Name = "MetroLabel23"
        Me.MetroLabel23.Size = New System.Drawing.Size(104, 21)
        Me.MetroLabel23.TabIndex = 31
        Me.MetroLabel23.Text = "- Allgemein -"
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.LegacyClonkSize_lbl)
        Me.GroupBox4.ForeColor = System.Drawing.Color.DarkGray
        Me.GroupBox4.Location = New System.Drawing.Point(8, 83)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(263, 44)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Details"
        '
        'LegacyClonkSize_lbl
        '
        Me.LegacyClonkSize_lbl.AutoSize = True
        Me.LegacyClonkSize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.LegacyClonkSize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.LegacyClonkSize_lbl.Location = New System.Drawing.Point(6, 19)
        Me.LegacyClonkSize_lbl.Name = "LegacyClonkSize_lbl"
        Me.LegacyClonkSize_lbl.Size = New System.Drawing.Size(145, 15)
        Me.LegacyClonkSize_lbl.TabIndex = 0
        Me.LegacyClonkSize_lbl.Text = "Größe auf Datenträger: %s"
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.LegacyClonkSymbol
        Me.PictureBox2.Location = New System.Drawing.Point(139, 12)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(0, 32)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 4
        Me.PictureBox2.TabStop = False
        '
        'MetroLabel2
        '
        Me.MetroLabel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel2.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.MetroLabel2.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel2.Location = New System.Drawing.Point(49, 50)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(179, 25)
        Me.MetroLabel2.TabIndex = 3
        Me.MetroLabel2.Text = "LegacyClonk"
        Me.MetroLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ClonkEndeavour_tp
        '
        Me.ClonkEndeavour_tp.AutoScroll = True
        Me.ClonkEndeavour_tp.BackColor = System.Drawing.Color.White
        Me.ClonkEndeavour_tp.Controls.Add(Me.close2_btn)
        Me.ClonkEndeavour_tp.Controls.Add(Me.GroupBox5)
        Me.ClonkEndeavour_tp.Controls.Add(Me.ClonkEndeavourAccept_btn)
        Me.ClonkEndeavour_tp.Controls.Add(Me.GroupBox6)
        Me.ClonkEndeavour_tp.Controls.Add(Me.PictureBox3)
        Me.ClonkEndeavour_tp.Controls.Add(Me.MetroLabel3)
        Me.ClonkEndeavour_tp.Location = New System.Drawing.Point(44, 4)
        Me.ClonkEndeavour_tp.Name = "ClonkEndeavour_tp"
        Me.ClonkEndeavour_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.ClonkEndeavour_tp.Size = New System.Drawing.Size(328, 338)
        Me.ClonkEndeavour_tp.TabIndex = 2
        Me.ClonkEndeavour_tp.Text = "CE"
        '
        'close2_btn
        '
        Me.close2_btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.close2_btn.BackColor = System.Drawing.Color.Transparent
        Me.close2_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.close2_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.close2_btn.DefaultColor = System.Drawing.Color.White
        Me.close2_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.close2_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.close2_btn.HoverColor = System.Drawing.Color.White
        Me.close2_btn.Location = New System.Drawing.Point(8, 500)
        Me.close2_btn.Name = "close2_btn"
        Me.close2_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.close2_btn.RoundingArc = 23
        Me.close2_btn.Size = New System.Drawing.Size(263, 23)
        Me.close2_btn.TabIndex = 53
        Me.close2_btn.Text = "Abbrechen"
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourPXSGfx_chkbox)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourGameSound_chkbox)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourGameMusic_chkbox)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourMenuSound_chkbox)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourMenuMusic_chkbox)
        Me.GroupBox5.Controls.Add(Me.MetroLabel28)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourResolutionY_nud)
        Me.GroupBox5.Controls.Add(Me.MetroLabel29)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourResolutionX_nud)
        Me.GroupBox5.Controls.Add(Me.MetroLabel30)
        Me.GroupBox5.Controls.Add(Me.MetroLabel31)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourNewGfxCfg_chkbox)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourMenuTransparency_chkbox)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourNewGfxCfgGL_chkbox)
        Me.GroupBox5.Controls.Add(Me.MetroLabel32)
        Me.GroupBox5.Controls.Add(Me.ClonkEndeavourLanguage_cmdbox)
        Me.GroupBox5.Controls.Add(Me.MetroLabel33)
        Me.GroupBox5.Controls.Add(Me.MetroLabel34)
        Me.GroupBox5.ForeColor = System.Drawing.Color.DarkGray
        Me.GroupBox5.Location = New System.Drawing.Point(8, 133)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(263, 332)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Optionen"
        '
        'ClonkEndeavourPXSGfx_chkbox
        '
        Me.ClonkEndeavourPXSGfx_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourPXSGfx_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkEndeavourPXSGfx_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourPXSGfx_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourPXSGfx_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkEndeavourPXSGfx_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkEndeavourPXSGfx_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkEndeavourPXSGfx_chkbox.Location = New System.Drawing.Point(9, 164)
        Me.ClonkEndeavourPXSGfx_chkbox.Name = "ClonkEndeavourPXSGfx_chkbox"
        Me.ClonkEndeavourPXSGfx_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkEndeavourPXSGfx_chkbox.Size = New System.Drawing.Size(64, 14)
        Me.ClonkEndeavourPXSGfx_chkbox.TabIndex = 52
        Me.ClonkEndeavourPXSGfx_chkbox.Text = "PXSGfx"
        '
        'ClonkEndeavourGameSound_chkbox
        '
        Me.ClonkEndeavourGameSound_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourGameSound_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkEndeavourGameSound_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourGameSound_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourGameSound_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkEndeavourGameSound_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkEndeavourGameSound_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkEndeavourGameSound_chkbox.Location = New System.Drawing.Point(9, 300)
        Me.ClonkEndeavourGameSound_chkbox.Name = "ClonkEndeavourGameSound_chkbox"
        Me.ClonkEndeavourGameSound_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkEndeavourGameSound_chkbox.Size = New System.Drawing.Size(95, 14)
        Me.ClonkEndeavourGameSound_chkbox.TabIndex = 47
        Me.ClonkEndeavourGameSound_chkbox.Text = "GameSound"
        '
        'ClonkEndeavourGameMusic_chkbox
        '
        Me.ClonkEndeavourGameMusic_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourGameMusic_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkEndeavourGameMusic_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourGameMusic_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourGameMusic_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkEndeavourGameMusic_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkEndeavourGameMusic_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkEndeavourGameMusic_chkbox.Location = New System.Drawing.Point(9, 280)
        Me.ClonkEndeavourGameMusic_chkbox.Name = "ClonkEndeavourGameMusic_chkbox"
        Me.ClonkEndeavourGameMusic_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkEndeavourGameMusic_chkbox.Size = New System.Drawing.Size(91, 14)
        Me.ClonkEndeavourGameMusic_chkbox.TabIndex = 46
        Me.ClonkEndeavourGameMusic_chkbox.Text = "GameMusic"
        '
        'ClonkEndeavourMenuSound_chkbox
        '
        Me.ClonkEndeavourMenuSound_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourMenuSound_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkEndeavourMenuSound_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourMenuSound_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourMenuSound_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkEndeavourMenuSound_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkEndeavourMenuSound_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkEndeavourMenuSound_chkbox.Location = New System.Drawing.Point(9, 260)
        Me.ClonkEndeavourMenuSound_chkbox.Name = "ClonkEndeavourMenuSound_chkbox"
        Me.ClonkEndeavourMenuSound_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkEndeavourMenuSound_chkbox.Size = New System.Drawing.Size(94, 14)
        Me.ClonkEndeavourMenuSound_chkbox.TabIndex = 45
        Me.ClonkEndeavourMenuSound_chkbox.Text = "MenuSound"
        '
        'ClonkEndeavourMenuMusic_chkbox
        '
        Me.ClonkEndeavourMenuMusic_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourMenuMusic_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkEndeavourMenuMusic_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourMenuMusic_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourMenuMusic_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkEndeavourMenuMusic_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkEndeavourMenuMusic_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkEndeavourMenuMusic_chkbox.Location = New System.Drawing.Point(9, 240)
        Me.ClonkEndeavourMenuMusic_chkbox.Name = "ClonkEndeavourMenuMusic_chkbox"
        Me.ClonkEndeavourMenuMusic_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkEndeavourMenuMusic_chkbox.Size = New System.Drawing.Size(91, 14)
        Me.ClonkEndeavourMenuMusic_chkbox.TabIndex = 44
        Me.ClonkEndeavourMenuMusic_chkbox.Text = "MenuMusic"
        '
        'MetroLabel28
        '
        Me.MetroLabel28.AutoSize = True
        Me.MetroLabel28.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel28.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel28.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel28.Location = New System.Drawing.Point(11, 216)
        Me.MetroLabel28.Name = "MetroLabel28"
        Me.MetroLabel28.Size = New System.Drawing.Size(77, 21)
        Me.MetroLabel28.TabIndex = 43
        Me.MetroLabel28.Text = "- Sound -"
        '
        'ClonkEndeavourResolutionY_nud
        '
        Me.ClonkEndeavourResolutionY_nud.Location = New System.Drawing.Point(213, 187)
        Me.ClonkEndeavourResolutionY_nud.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.ClonkEndeavourResolutionY_nud.Name = "ClonkEndeavourResolutionY_nud"
        Me.ClonkEndeavourResolutionY_nud.Size = New System.Drawing.Size(60, 23)
        Me.ClonkEndeavourResolutionY_nud.TabIndex = 42
        Me.ClonkEndeavourResolutionY_nud.Value = New Decimal(New Integer() {1080, 0, 0, 0})
        '
        'MetroLabel29
        '
        Me.MetroLabel29.AutoSize = True
        Me.MetroLabel29.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel29.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel29.Location = New System.Drawing.Point(187, 187)
        Me.MetroLabel29.Name = "MetroLabel29"
        Me.MetroLabel29.Size = New System.Drawing.Size(20, 19)
        Me.MetroLabel29.TabIndex = 41
        Me.MetroLabel29.Text = "Y:"
        '
        'ClonkEndeavourResolutionX_nud
        '
        Me.ClonkEndeavourResolutionX_nud.Location = New System.Drawing.Point(112, 187)
        Me.ClonkEndeavourResolutionX_nud.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.ClonkEndeavourResolutionX_nud.Name = "ClonkEndeavourResolutionX_nud"
        Me.ClonkEndeavourResolutionX_nud.Size = New System.Drawing.Size(60, 23)
        Me.ClonkEndeavourResolutionX_nud.TabIndex = 40
        Me.ClonkEndeavourResolutionX_nud.Value = New Decimal(New Integer() {1920, 0, 0, 0})
        '
        'MetroLabel30
        '
        Me.MetroLabel30.AutoSize = True
        Me.MetroLabel30.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel30.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel30.Location = New System.Drawing.Point(86, 187)
        Me.MetroLabel30.Name = "MetroLabel30"
        Me.MetroLabel30.Size = New System.Drawing.Size(20, 19)
        Me.MetroLabel30.TabIndex = 39
        Me.MetroLabel30.Text = "X:"
        '
        'MetroLabel31
        '
        Me.MetroLabel31.AutoSize = True
        Me.MetroLabel31.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel31.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel31.Location = New System.Drawing.Point(6, 187)
        Me.MetroLabel31.Name = "MetroLabel31"
        Me.MetroLabel31.Size = New System.Drawing.Size(74, 19)
        Me.MetroLabel31.TabIndex = 38
        Me.MetroLabel31.Text = "Auflösung:"
        '
        'ClonkEndeavourNewGfxCfg_chkbox
        '
        Me.ClonkEndeavourNewGfxCfg_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourNewGfxCfg_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkEndeavourNewGfxCfg_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfg_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfg_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfg_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkEndeavourNewGfxCfg_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfg_chkbox.Location = New System.Drawing.Point(9, 124)
        Me.ClonkEndeavourNewGfxCfg_chkbox.Name = "ClonkEndeavourNewGfxCfg_chkbox"
        Me.ClonkEndeavourNewGfxCfg_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfg_chkbox.Size = New System.Drawing.Size(89, 14)
        Me.ClonkEndeavourNewGfxCfg_chkbox.TabIndex = 37
        Me.ClonkEndeavourNewGfxCfg_chkbox.Text = "NewGfxCfg"
        '
        'ClonkEndeavourMenuTransparency_chkbox
        '
        Me.ClonkEndeavourMenuTransparency_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourMenuTransparency_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkEndeavourMenuTransparency_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourMenuTransparency_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourMenuTransparency_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkEndeavourMenuTransparency_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkEndeavourMenuTransparency_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkEndeavourMenuTransparency_chkbox.Location = New System.Drawing.Point(9, 104)
        Me.ClonkEndeavourMenuTransparency_chkbox.Name = "ClonkEndeavourMenuTransparency_chkbox"
        Me.ClonkEndeavourMenuTransparency_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkEndeavourMenuTransparency_chkbox.Size = New System.Drawing.Size(136, 14)
        Me.ClonkEndeavourMenuTransparency_chkbox.TabIndex = 36
        Me.ClonkEndeavourMenuTransparency_chkbox.Text = "MenuTransparency"
        '
        'ClonkEndeavourNewGfxCfgGL_chkbox
        '
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.Location = New System.Drawing.Point(9, 144)
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.Name = "ClonkEndeavourNewGfxCfgGL_chkbox"
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.Size = New System.Drawing.Size(105, 14)
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.TabIndex = 35
        Me.ClonkEndeavourNewGfxCfgGL_chkbox.Text = "NewGfxCfgGL"
        '
        'MetroLabel32
        '
        Me.MetroLabel32.AutoSize = True
        Me.MetroLabel32.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel32.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel32.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel32.Location = New System.Drawing.Point(11, 80)
        Me.MetroLabel32.Name = "MetroLabel32"
        Me.MetroLabel32.Size = New System.Drawing.Size(73, 21)
        Me.MetroLabel32.TabIndex = 34
        Me.MetroLabel32.Text = "- Grafik -"
        '
        'ClonkEndeavourLanguage_cmdbox
        '
        Me.ClonkEndeavourLanguage_cmdbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourLanguage_cmdbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourLanguage_cmdbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourLanguage_cmdbox.DefaultColor = System.Drawing.Color.White
        Me.ClonkEndeavourLanguage_cmdbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClonkEndeavourLanguage_cmdbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ClonkEndeavourLanguage_cmdbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ClonkEndeavourLanguage_cmdbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ClonkEndeavourLanguage_cmdbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClonkEndeavourLanguage_cmdbox.ForeColor = System.Drawing.Color.Black
        Me.ClonkEndeavourLanguage_cmdbox.FormattingEnabled = True
        Me.ClonkEndeavourLanguage_cmdbox.Items.AddRange(New Object() {"DE - Deutsch", "US - English"})
        Me.ClonkEndeavourLanguage_cmdbox.Location = New System.Drawing.Point(72, 43)
        Me.ClonkEndeavourLanguage_cmdbox.Name = "ClonkEndeavourLanguage_cmdbox"
        Me.ClonkEndeavourLanguage_cmdbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourLanguage_cmdbox.Size = New System.Drawing.Size(163, 24)
        Me.ClonkEndeavourLanguage_cmdbox.TabIndex = 33
        '
        'MetroLabel33
        '
        Me.MetroLabel33.AutoSize = True
        Me.MetroLabel33.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel33.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel33.Location = New System.Drawing.Point(6, 44)
        Me.MetroLabel33.Name = "MetroLabel33"
        Me.MetroLabel33.Size = New System.Drawing.Size(60, 19)
        Me.MetroLabel33.TabIndex = 32
        Me.MetroLabel33.Text = "Sprache:"
        '
        'MetroLabel34
        '
        Me.MetroLabel34.AutoSize = True
        Me.MetroLabel34.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel34.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel34.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel34.Location = New System.Drawing.Point(11, 21)
        Me.MetroLabel34.Name = "MetroLabel34"
        Me.MetroLabel34.Size = New System.Drawing.Size(104, 21)
        Me.MetroLabel34.TabIndex = 31
        Me.MetroLabel34.Text = "- Allgemein -"
        '
        'ClonkEndeavourAccept_btn
        '
        Me.ClonkEndeavourAccept_btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClonkEndeavourAccept_btn.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourAccept_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkEndeavourAccept_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkEndeavourAccept_btn.DefaultColor = System.Drawing.Color.White
        Me.ClonkEndeavourAccept_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClonkEndeavourAccept_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClonkEndeavourAccept_btn.HoverColor = System.Drawing.Color.White
        Me.ClonkEndeavourAccept_btn.Location = New System.Drawing.Point(8, 471)
        Me.ClonkEndeavourAccept_btn.Name = "ClonkEndeavourAccept_btn"
        Me.ClonkEndeavourAccept_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkEndeavourAccept_btn.RoundingArc = 23
        Me.ClonkEndeavourAccept_btn.Size = New System.Drawing.Size(263, 23)
        Me.ClonkEndeavourAccept_btn.TabIndex = 54
        Me.ClonkEndeavourAccept_btn.Text = "Übernehmen"
        '
        'GroupBox6
        '
        Me.GroupBox6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox6.Controls.Add(Me.ClonkEndeavourSize_lbl)
        Me.GroupBox6.ForeColor = System.Drawing.Color.DarkGray
        Me.GroupBox6.Location = New System.Drawing.Point(8, 83)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(263, 44)
        Me.GroupBox6.TabIndex = 7
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Details"
        '
        'ClonkEndeavourSize_lbl
        '
        Me.ClonkEndeavourSize_lbl.AutoSize = True
        Me.ClonkEndeavourSize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourSize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClonkEndeavourSize_lbl.Location = New System.Drawing.Point(6, 19)
        Me.ClonkEndeavourSize_lbl.Name = "ClonkEndeavourSize_lbl"
        Me.ClonkEndeavourSize_lbl.Size = New System.Drawing.Size(145, 15)
        Me.ClonkEndeavourSize_lbl.TabIndex = 0
        Me.ClonkEndeavourSize_lbl.Text = "Größe auf Datenträger: %s"
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.ClonkEndeavourSymbol
        Me.PictureBox3.Location = New System.Drawing.Point(139, 12)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(0, 32)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 6
        Me.PictureBox3.TabStop = False
        '
        'MetroLabel3
        '
        Me.MetroLabel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel3.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel3.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.MetroLabel3.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel3.Location = New System.Drawing.Point(57, 50)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(162, 25)
        Me.MetroLabel3.TabIndex = 5
        Me.MetroLabel3.Text = "Clonk Endeavour"
        Me.MetroLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ClonkPlanetClonk4_tp
        '
        Me.ClonkPlanetClonk4_tp.AutoScroll = True
        Me.ClonkPlanetClonk4_tp.BackColor = System.Drawing.Color.White
        Me.ClonkPlanetClonk4_tp.Controls.Add(Me.close3_btn)
        Me.ClonkPlanetClonk4_tp.Controls.Add(Me.GroupBox7)
        Me.ClonkPlanetClonk4_tp.Controls.Add(Me.ClonkPlanetClonk4Accept_btn)
        Me.ClonkPlanetClonk4_tp.Controls.Add(Me.GroupBox8)
        Me.ClonkPlanetClonk4_tp.Controls.Add(Me.MetroLabel5)
        Me.ClonkPlanetClonk4_tp.Controls.Add(Me.PictureBox6)
        Me.ClonkPlanetClonk4_tp.Controls.Add(Me.PictureBox4)
        Me.ClonkPlanetClonk4_tp.Controls.Add(Me.MetroLabel4)
        Me.ClonkPlanetClonk4_tp.Location = New System.Drawing.Point(44, 4)
        Me.ClonkPlanetClonk4_tp.Name = "ClonkPlanetClonk4_tp"
        Me.ClonkPlanetClonk4_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.ClonkPlanetClonk4_tp.Size = New System.Drawing.Size(328, 338)
        Me.ClonkPlanetClonk4_tp.TabIndex = 3
        Me.ClonkPlanetClonk4_tp.Text = "CP/C4"
        '
        'close3_btn
        '
        Me.close3_btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.close3_btn.BackColor = System.Drawing.Color.Transparent
        Me.close3_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.close3_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.close3_btn.DefaultColor = System.Drawing.Color.White
        Me.close3_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.close3_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.close3_btn.HoverColor = System.Drawing.Color.White
        Me.close3_btn.Location = New System.Drawing.Point(8, 487)
        Me.close3_btn.Name = "close3_btn"
        Me.close3_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.close3_btn.RoundingArc = 23
        Me.close3_btn.Size = New System.Drawing.Size(263, 23)
        Me.close3_btn.TabIndex = 56
        Me.close3_btn.Text = "Abbrechen"
        '
        'GroupBox7
        '
        Me.GroupBox7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox7.Controls.Add(Me.ClonkPlanetClonk4GameSoundLoops_chkbox)
        Me.GroupBox7.Controls.Add(Me.ClonkPlanetClonk4PXSGfx_chkbox)
        Me.GroupBox7.Controls.Add(Me.ClonkPlanetClonk4GameSound_chkbox)
        Me.GroupBox7.Controls.Add(Me.ClonkPlanetClonk4GameMusic_chkbox)
        Me.GroupBox7.Controls.Add(Me.ClonkPlanetClonk4MenuSound_chkbox)
        Me.GroupBox7.Controls.Add(Me.ClonkPlanetClonk4MenuMusic_chkbox)
        Me.GroupBox7.Controls.Add(Me.MetroLabel25)
        Me.GroupBox7.Controls.Add(Me.ClonkPlanetClonk4NewGfxCfg_chkbox)
        Me.GroupBox7.Controls.Add(Me.ClonkPlanetClonk4MenuTransparency_chkbox)
        Me.GroupBox7.Controls.Add(Me.MetroLabel36)
        Me.GroupBox7.Controls.Add(Me.ClonkPlanetClonk4Language_cmdbox)
        Me.GroupBox7.Controls.Add(Me.MetroLabel37)
        Me.GroupBox7.Controls.Add(Me.MetroLabel38)
        Me.GroupBox7.ForeColor = System.Drawing.Color.DarkGray
        Me.GroupBox7.Location = New System.Drawing.Point(8, 158)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(263, 294)
        Me.GroupBox7.TabIndex = 55
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Optionen"
        '
        'ClonkPlanetClonk4GameSoundLoops_chkbox
        '
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.Location = New System.Drawing.Point(9, 270)
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.Name = "ClonkPlanetClonk4GameSoundLoops_chkbox"
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.Size = New System.Drawing.Size(131, 14)
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.TabIndex = 53
        Me.ClonkPlanetClonk4GameSoundLoops_chkbox.Text = "GameSoundLoops"
        '
        'ClonkPlanetClonk4PXSGfx_chkbox
        '
        Me.ClonkPlanetClonk4PXSGfx_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetClonk4PXSGfx_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkPlanetClonk4PXSGfx_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4PXSGfx_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4PXSGfx_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkPlanetClonk4PXSGfx_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkPlanetClonk4PXSGfx_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkPlanetClonk4PXSGfx_chkbox.Location = New System.Drawing.Point(9, 144)
        Me.ClonkPlanetClonk4PXSGfx_chkbox.Name = "ClonkPlanetClonk4PXSGfx_chkbox"
        Me.ClonkPlanetClonk4PXSGfx_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkPlanetClonk4PXSGfx_chkbox.Size = New System.Drawing.Size(64, 14)
        Me.ClonkPlanetClonk4PXSGfx_chkbox.TabIndex = 52
        Me.ClonkPlanetClonk4PXSGfx_chkbox.Text = "PXSGfx"
        '
        'ClonkPlanetClonk4GameSound_chkbox
        '
        Me.ClonkPlanetClonk4GameSound_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetClonk4GameSound_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkPlanetClonk4GameSound_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4GameSound_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4GameSound_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkPlanetClonk4GameSound_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkPlanetClonk4GameSound_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkPlanetClonk4GameSound_chkbox.Location = New System.Drawing.Point(9, 250)
        Me.ClonkPlanetClonk4GameSound_chkbox.Name = "ClonkPlanetClonk4GameSound_chkbox"
        Me.ClonkPlanetClonk4GameSound_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkPlanetClonk4GameSound_chkbox.Size = New System.Drawing.Size(95, 14)
        Me.ClonkPlanetClonk4GameSound_chkbox.TabIndex = 47
        Me.ClonkPlanetClonk4GameSound_chkbox.Text = "GameSound"
        '
        'ClonkPlanetClonk4GameMusic_chkbox
        '
        Me.ClonkPlanetClonk4GameMusic_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetClonk4GameMusic_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkPlanetClonk4GameMusic_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4GameMusic_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4GameMusic_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkPlanetClonk4GameMusic_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkPlanetClonk4GameMusic_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkPlanetClonk4GameMusic_chkbox.Location = New System.Drawing.Point(9, 230)
        Me.ClonkPlanetClonk4GameMusic_chkbox.Name = "ClonkPlanetClonk4GameMusic_chkbox"
        Me.ClonkPlanetClonk4GameMusic_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkPlanetClonk4GameMusic_chkbox.Size = New System.Drawing.Size(91, 14)
        Me.ClonkPlanetClonk4GameMusic_chkbox.TabIndex = 46
        Me.ClonkPlanetClonk4GameMusic_chkbox.Text = "GameMusic"
        '
        'ClonkPlanetClonk4MenuSound_chkbox
        '
        Me.ClonkPlanetClonk4MenuSound_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetClonk4MenuSound_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkPlanetClonk4MenuSound_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4MenuSound_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4MenuSound_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkPlanetClonk4MenuSound_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkPlanetClonk4MenuSound_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkPlanetClonk4MenuSound_chkbox.Location = New System.Drawing.Point(9, 210)
        Me.ClonkPlanetClonk4MenuSound_chkbox.Name = "ClonkPlanetClonk4MenuSound_chkbox"
        Me.ClonkPlanetClonk4MenuSound_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkPlanetClonk4MenuSound_chkbox.Size = New System.Drawing.Size(94, 14)
        Me.ClonkPlanetClonk4MenuSound_chkbox.TabIndex = 45
        Me.ClonkPlanetClonk4MenuSound_chkbox.Text = "MenuSound"
        '
        'ClonkPlanetClonk4MenuMusic_chkbox
        '
        Me.ClonkPlanetClonk4MenuMusic_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetClonk4MenuMusic_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkPlanetClonk4MenuMusic_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4MenuMusic_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4MenuMusic_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkPlanetClonk4MenuMusic_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkPlanetClonk4MenuMusic_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkPlanetClonk4MenuMusic_chkbox.Location = New System.Drawing.Point(9, 190)
        Me.ClonkPlanetClonk4MenuMusic_chkbox.Name = "ClonkPlanetClonk4MenuMusic_chkbox"
        Me.ClonkPlanetClonk4MenuMusic_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkPlanetClonk4MenuMusic_chkbox.Size = New System.Drawing.Size(91, 14)
        Me.ClonkPlanetClonk4MenuMusic_chkbox.TabIndex = 44
        Me.ClonkPlanetClonk4MenuMusic_chkbox.Text = "MenuMusic"
        '
        'MetroLabel25
        '
        Me.MetroLabel25.AutoSize = True
        Me.MetroLabel25.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel25.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel25.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel25.Location = New System.Drawing.Point(11, 166)
        Me.MetroLabel25.Name = "MetroLabel25"
        Me.MetroLabel25.Size = New System.Drawing.Size(77, 21)
        Me.MetroLabel25.TabIndex = 43
        Me.MetroLabel25.Text = "- Sound -"
        '
        'ClonkPlanetClonk4NewGfxCfg_chkbox
        '
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.Location = New System.Drawing.Point(9, 124)
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.Name = "ClonkPlanetClonk4NewGfxCfg_chkbox"
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.Size = New System.Drawing.Size(89, 14)
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.TabIndex = 37
        Me.ClonkPlanetClonk4NewGfxCfg_chkbox.Text = "NewGfxCfg"
        '
        'ClonkPlanetClonk4MenuTransparency_chkbox
        '
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.Location = New System.Drawing.Point(9, 104)
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.Name = "ClonkPlanetClonk4MenuTransparency_chkbox"
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.Size = New System.Drawing.Size(136, 14)
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.TabIndex = 36
        Me.ClonkPlanetClonk4MenuTransparency_chkbox.Text = "MenuTransparency"
        '
        'MetroLabel36
        '
        Me.MetroLabel36.AutoSize = True
        Me.MetroLabel36.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel36.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel36.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel36.Location = New System.Drawing.Point(11, 80)
        Me.MetroLabel36.Name = "MetroLabel36"
        Me.MetroLabel36.Size = New System.Drawing.Size(73, 21)
        Me.MetroLabel36.TabIndex = 34
        Me.MetroLabel36.Text = "- Grafik -"
        '
        'ClonkPlanetClonk4Language_cmdbox
        '
        Me.ClonkPlanetClonk4Language_cmdbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4Language_cmdbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4Language_cmdbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4Language_cmdbox.DefaultColor = System.Drawing.Color.White
        Me.ClonkPlanetClonk4Language_cmdbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClonkPlanetClonk4Language_cmdbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ClonkPlanetClonk4Language_cmdbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ClonkPlanetClonk4Language_cmdbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ClonkPlanetClonk4Language_cmdbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClonkPlanetClonk4Language_cmdbox.ForeColor = System.Drawing.Color.Black
        Me.ClonkPlanetClonk4Language_cmdbox.FormattingEnabled = True
        Me.ClonkPlanetClonk4Language_cmdbox.Items.AddRange(New Object() {"DE", "US"})
        Me.ClonkPlanetClonk4Language_cmdbox.Location = New System.Drawing.Point(72, 43)
        Me.ClonkPlanetClonk4Language_cmdbox.Name = "ClonkPlanetClonk4Language_cmdbox"
        Me.ClonkPlanetClonk4Language_cmdbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4Language_cmdbox.Size = New System.Drawing.Size(163, 24)
        Me.ClonkPlanetClonk4Language_cmdbox.TabIndex = 33
        '
        'MetroLabel37
        '
        Me.MetroLabel37.AutoSize = True
        Me.MetroLabel37.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel37.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MetroLabel37.Location = New System.Drawing.Point(6, 44)
        Me.MetroLabel37.Name = "MetroLabel37"
        Me.MetroLabel37.Size = New System.Drawing.Size(60, 19)
        Me.MetroLabel37.TabIndex = 32
        Me.MetroLabel37.Text = "Sprache:"
        '
        'MetroLabel38
        '
        Me.MetroLabel38.AutoSize = True
        Me.MetroLabel38.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel38.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel38.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.MetroLabel38.Location = New System.Drawing.Point(11, 21)
        Me.MetroLabel38.Name = "MetroLabel38"
        Me.MetroLabel38.Size = New System.Drawing.Size(104, 21)
        Me.MetroLabel38.TabIndex = 31
        Me.MetroLabel38.Text = "- Allgemein -"
        '
        'ClonkPlanetClonk4Accept_btn
        '
        Me.ClonkPlanetClonk4Accept_btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClonkPlanetClonk4Accept_btn.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetClonk4Accept_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkPlanetClonk4Accept_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkPlanetClonk4Accept_btn.DefaultColor = System.Drawing.Color.White
        Me.ClonkPlanetClonk4Accept_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClonkPlanetClonk4Accept_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClonkPlanetClonk4Accept_btn.HoverColor = System.Drawing.Color.White
        Me.ClonkPlanetClonk4Accept_btn.Location = New System.Drawing.Point(8, 458)
        Me.ClonkPlanetClonk4Accept_btn.Name = "ClonkPlanetClonk4Accept_btn"
        Me.ClonkPlanetClonk4Accept_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkPlanetClonk4Accept_btn.RoundingArc = 23
        Me.ClonkPlanetClonk4Accept_btn.Size = New System.Drawing.Size(263, 23)
        Me.ClonkPlanetClonk4Accept_btn.TabIndex = 57
        Me.ClonkPlanetClonk4Accept_btn.Text = "Übernehmen"
        '
        'GroupBox8
        '
        Me.GroupBox8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox8.Controls.Add(Me.Clonk4Size_lbl)
        Me.GroupBox8.Controls.Add(Me.ClonkPlanetSize_lbl)
        Me.GroupBox8.ForeColor = System.Drawing.Color.DarkGray
        Me.GroupBox8.Location = New System.Drawing.Point(8, 94)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(263, 58)
        Me.GroupBox8.TabIndex = 9
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Details"
        '
        'Clonk4Size_lbl
        '
        Me.Clonk4Size_lbl.AutoSize = True
        Me.Clonk4Size_lbl.BackColor = System.Drawing.Color.Transparent
        Me.Clonk4Size_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Clonk4Size_lbl.Location = New System.Drawing.Point(6, 36)
        Me.Clonk4Size_lbl.Name = "Clonk4Size_lbl"
        Me.Clonk4Size_lbl.Size = New System.Drawing.Size(196, 15)
        Me.Clonk4Size_lbl.TabIndex = 1
        Me.Clonk4Size_lbl.Text = "Clonk 4 - Größe auf Datenträger: %s"
        '
        'ClonkPlanetSize_lbl
        '
        Me.ClonkPlanetSize_lbl.AutoSize = True
        Me.ClonkPlanetSize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetSize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClonkPlanetSize_lbl.Location = New System.Drawing.Point(6, 19)
        Me.ClonkPlanetSize_lbl.Name = "ClonkPlanetSize_lbl"
        Me.ClonkPlanetSize_lbl.Size = New System.Drawing.Size(223, 15)
        Me.ClonkPlanetSize_lbl.TabIndex = 0
        Me.ClonkPlanetSize_lbl.Text = "Clonk Planet - Größe auf Datenträger: %s"
        '
        'MetroLabel5
        '
        Me.MetroLabel5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel5.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel5.Font = New System.Drawing.Font("Segoe UI", 7.0!)
        Me.MetroLabel5.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel5.Location = New System.Drawing.Point(31, 75)
        Me.MetroLabel5.Name = "MetroLabel5"
        Me.MetroLabel5.Size = New System.Drawing.Size(214, 16)
        Me.MetroLabel5.TabIndex = 8
        Me.MetroLabel5.Text = "(Clonk Planet und Clonk 4 teilen sich die Einstellungen)"
        Me.MetroLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox6
        '
        Me.PictureBox6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox6.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.Clonk4Symbol
        Me.PictureBox6.Location = New System.Drawing.Point(140, 12)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 7
        Me.PictureBox6.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox4.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.ClonkPlanetSymbol
        Me.PictureBox4.Location = New System.Drawing.Point(102, 12)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 6
        Me.PictureBox4.TabStop = False
        '
        'MetroLabel4
        '
        Me.MetroLabel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel4.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel4.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.MetroLabel4.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel4.Location = New System.Drawing.Point(29, 50)
        Me.MetroLabel4.Name = "MetroLabel4"
        Me.MetroLabel4.Size = New System.Drawing.Size(219, 25)
        Me.MetroLabel4.TabIndex = 5
        Me.MetroLabel4.Text = "Clonk Planet / Clonk 4"
        Me.MetroLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GameSettingsFrm
        '
        Me.AllowResize = False
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(378, 394)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "GameSettingsFrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "Spieleinstellungen"
        Me.controlbox_pnl.ResumeLayout(False)
        Me.MetroTabControl1.ResumeLayout(False)
        Me.OpenClonk_tp.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.OpenClonkResolutionY_nud, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OpenClonkResolutionX_nud, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LegacyClonk_tp.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.LegacyClonkResolutionY_nud, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LegacyClonkResolutionX_nud, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ClonkEndeavour_tp.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.ClonkEndeavourResolutionY_nud, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClonkEndeavourResolutionX_nud, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ClonkPlanetClonk4_tp.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents controlbox_pnl As Panel
    Friend WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents MetroTabControl1 As MetroSuite.MetroTabControl
    Friend WithEvents OpenClonk_tp As TabPage
    Friend WithEvents LegacyClonk_tp As TabPage
    Friend WithEvents ClonkEndeavour_tp As TabPage
    Friend WithEvents ClonkPlanetClonk4_tp As TabPage
    Friend WithEvents MetroLabel1 As MetroSuite.MetroLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents MetroLabel2 As MetroSuite.MetroLabel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents MetroLabel3 As MetroSuite.MetroLabel
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents MetroLabel4 As MetroSuite.MetroLabel
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents MetroLabel5 As MetroSuite.MetroLabel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents OpenClonkSize_lbl As MetroSuite.MetroLabel
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents LegacyClonkSize_lbl As MetroSuite.MetroLabel
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents ClonkEndeavourSize_lbl As MetroSuite.MetroLabel
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents ClonkPlanetSize_lbl As MetroSuite.MetroLabel
    Friend WithEvents Clonk4Size_lbl As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel6 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel19 As MetroSuite.MetroLabel
    Friend WithEvents OpenClonkLanguage_cmdbox As MetroSuite.MetroComboBox
    Friend WithEvents MetroLabel7 As MetroSuite.MetroLabel
    Friend WithEvents OpenClonkMenuTransparency_chkbox As MetroSuite.MetroChecker
    Friend WithEvents OpenClonkMultiSampling_chkbox As MetroSuite.MetroChecker
    Friend WithEvents OpenClonkWindowed_chkbox As MetroSuite.MetroChecker
    Friend WithEvents OpenClonkResolutionY_nud As NumericUpDown
    Friend WithEvents MetroLabel10 As MetroSuite.MetroLabel
    Friend WithEvents OpenClonkResolutionX_nud As NumericUpDown
    Friend WithEvents MetroLabel9 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel8 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel11 As MetroSuite.MetroLabel
    Friend WithEvents OpenClonkMenuMusic_chkbox As MetroSuite.MetroChecker
    Friend WithEvents OpenClonkMenuSound_chkbox As MetroSuite.MetroChecker
    Friend WithEvents OpenClonkGameSound_chkbox As MetroSuite.MetroChecker
    Friend WithEvents OpenClonkGameMusic_chkbox As MetroSuite.MetroChecker
    Friend WithEvents MetroLabel12 As MetroSuite.MetroLabel
    Friend WithEvents OpenClonkMusic_trckbar As MetroSuite.MetroTrackbar
    Friend WithEvents OpenClonkSound_trckbar As MetroSuite.MetroTrackbar
    Friend WithEvents MetroLabel13 As MetroSuite.MetroLabel
    Friend WithEvents close_btn As MetroSuite.MetroButton
    Friend WithEvents OpenClonkAccept_btn As MetroSuite.MetroButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents LegacyClonkSound_trckbar As MetroSuite.MetroTrackbar
    Friend WithEvents MetroLabel14 As MetroSuite.MetroLabel
    Friend WithEvents LegacyClonkMusic_trckbar As MetroSuite.MetroTrackbar
    Friend WithEvents MetroLabel15 As MetroSuite.MetroLabel
    Friend WithEvents LegacyClonkGameSound_chkbox As MetroSuite.MetroChecker
    Friend WithEvents LegacyClonkGameMusic_chkbox As MetroSuite.MetroChecker
    Friend WithEvents LegacyClonkMenuSound_chkbox As MetroSuite.MetroChecker
    Friend WithEvents LegacyClonkMenuMusic_chkbox As MetroSuite.MetroChecker
    Friend WithEvents MetroLabel16 As MetroSuite.MetroLabel
    Friend WithEvents LegacyClonkResolutionY_nud As NumericUpDown
    Friend WithEvents MetroLabel17 As MetroSuite.MetroLabel
    Friend WithEvents LegacyClonkResolutionX_nud As NumericUpDown
    Friend WithEvents MetroLabel18 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel20 As MetroSuite.MetroLabel
    Friend WithEvents LegacyClonkWindowed_chkbox As MetroSuite.MetroChecker
    Friend WithEvents LegacyClonkMaximized_chkbox As MetroSuite.MetroChecker
    Friend WithEvents LegacyClonkNewGfxCfg_chkbox As MetroSuite.MetroChecker
    Friend WithEvents MetroLabel21 As MetroSuite.MetroLabel
    Friend WithEvents LegacyClonkLanguage_cmdbox As MetroSuite.MetroComboBox
    Friend WithEvents MetroLabel22 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel23 As MetroSuite.MetroLabel
    Friend WithEvents close1_btn As MetroSuite.MetroButton
    Friend WithEvents LegacyClonkAccept_btn As MetroSuite.MetroButton
    Friend WithEvents LegacyClonkShader_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ScaleCount_lbl As MetroSuite.MetroLabel
    Friend WithEvents LegacyClonkScale_trckbar As MetroSuite.MetroTrackbar
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents ClonkEndeavourPXSGfx_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkEndeavourGameSound_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkEndeavourGameMusic_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkEndeavourMenuSound_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkEndeavourMenuMusic_chkbox As MetroSuite.MetroChecker
    Friend WithEvents MetroLabel28 As MetroSuite.MetroLabel
    Friend WithEvents ClonkEndeavourResolutionY_nud As NumericUpDown
    Friend WithEvents MetroLabel29 As MetroSuite.MetroLabel
    Friend WithEvents ClonkEndeavourResolutionX_nud As NumericUpDown
    Friend WithEvents MetroLabel30 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel31 As MetroSuite.MetroLabel
    Friend WithEvents ClonkEndeavourNewGfxCfg_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkEndeavourMenuTransparency_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkEndeavourNewGfxCfgGL_chkbox As MetroSuite.MetroChecker
    Friend WithEvents MetroLabel32 As MetroSuite.MetroLabel
    Friend WithEvents ClonkEndeavourLanguage_cmdbox As MetroSuite.MetroComboBox
    Friend WithEvents MetroLabel33 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel34 As MetroSuite.MetroLabel
    Friend WithEvents close2_btn As MetroSuite.MetroButton
    Friend WithEvents ClonkEndeavourAccept_btn As MetroSuite.MetroButton
    Friend WithEvents close3_btn As MetroSuite.MetroButton
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents ClonkPlanetClonk4PXSGfx_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkPlanetClonk4GameSound_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkPlanetClonk4GameMusic_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkPlanetClonk4MenuSound_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkPlanetClonk4MenuMusic_chkbox As MetroSuite.MetroChecker
    Friend WithEvents MetroLabel25 As MetroSuite.MetroLabel
    Friend WithEvents ClonkPlanetClonk4NewGfxCfg_chkbox As MetroSuite.MetroChecker
    Friend WithEvents ClonkPlanetClonk4MenuTransparency_chkbox As MetroSuite.MetroChecker
    Friend WithEvents MetroLabel36 As MetroSuite.MetroLabel
    Friend WithEvents ClonkPlanetClonk4Language_cmdbox As MetroSuite.MetroComboBox
    Friend WithEvents MetroLabel37 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel38 As MetroSuite.MetroLabel
    Friend WithEvents ClonkPlanetClonk4Accept_btn As MetroSuite.MetroButton
    Friend WithEvents ClonkPlanetClonk4GameSoundLoops_chkbox As MetroSuite.MetroChecker
End Class
