﻿'Option Strict On
Imports MetroSuite.Extension
Imports MetroSuite
Imports MadMilkman.Ini

Public Class Friends : Inherits MetroSuite.MetroForm

#Region "ControlBox"

    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        Me.Hide()
    End Sub
    Private Sub controlbox_nmaximize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_nmaximize_lbl.Click
        If controlbox_nmaximize_lbl.Text = "□" Then
            controlbox_nmaximize_lbl.Text = "■"
            Me.WindowState = FormWindowState.Normal
        Else
            controlbox_nmaximize_lbl.Text = "□"
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub
    Private Sub controlbox_minimize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_minimize_lbl.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter, controlbox_nmaximize_lbl.MouseEnter, controlbox_minimize_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave, controlbox_nmaximize_lbl.MouseLeave, controlbox_minimize_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

#End Region

#Region "Theme"

    Public Sub ApplyTheme()
        Try
            Dim myTheme As New Styles.Themes.MetroSuiteTheme
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            If IO.File.Exists(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme")) Then ' If file exists
                myTheme = myTheme.FromFile(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme"))
            Else ' If not
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

#End Region

#Region " Functions "

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

#End Region

    ' Delegates
    Delegate Sub AddNewOpenedUserDelegate(ByVal Target As Control, ByVal _Text As String)
    Delegate Sub AddFriendDelegate(ByVal Target As Control, ByVal _Text As String)

    ' List's
    Private ListOfUsers As New List(Of Object)

#Region " Network "

    Private Sub UTC_UTicketArrived(sSenderID As String, bSentToAll As Boolean, sCommand As String, oUserData As List(Of Object))
        Select Case sCommand
            Case "Command:Message"
                'Chat_tbcntrl.Invoke(New WriteTextDelegate(AddressOf AddTabPage), oUserData) ' DO NOT UNCOMMENT UNTIL FUNCTION WORKS

                Dim SendingTime As String = "[" & TimeOfDay & "]"
                chat_lb.Items.Add(SendingTime & " " & oUserData(1).ToString & ": " & oUserData(0).ToString)

            Case "Server:Restart"
                Dim SendingTime As String = "[" & TimeOfDay & "]"
                chat_lb.Items.Add(SendingTime & " - ACHTUNG - Der Server wird in wenigen Minuten neu gestartet. Grund: " & oUserData(0).ToString)

            Case "Server:Shutdown"
                Dim SendingTime As String = "[" & TimeOfDay & "]"
                chat_lb.Items.Add(SendingTime & " - ACHTUNG - Der Server wird in wenigen Minuten heruntergefahren. Grund: " & oUserData(0).ToString)

            Case "Chat:GettingAllUsers"
                ListOfUsers = oUserData

                UserInOpenChat_flp2.Controls.Clear() ' Clears the List

                Try
                    For Each _username As String In oUserData
                        Dim _Params(1) As Object
                        _Params(0) = UserInOpenChat_flp2
                        _Params(1) = _username
                        Me.Invoke(New AddNewOpenedUserDelegate(AddressOf AddNewOpenedUserDelegate_Sub), _Params) ' Add User
                    Next
                Catch ex As Exception
                    MessageBox.Show(ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

            Case "Chat:GettingAllFriends"
                Try
                    For Each _strRow As String In oUserData
                        Dim _Params(1) As Object
                        _Params(0) = friends_flp1
                        _Params(1) = _strRow
                        Me.Invoke(New AddFriendDelegate(AddressOf AddFriendDelegate_Sub), _Params) ' Add Friend
                    Next
                Catch ex As Exception
                    MessageBox.Show(ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

            Case "RefreshAll"
                Networking.UTC.sendUTicket("@all", "Chat:RequestAllUsers", QClipboard.AccountName)
                Networking.UTC.sendUTicket("@all", "Chat:RequestAllFriends", QClipboard.AccountName)



                'ListOfUsers = oUserData

                'friends_flp1.Controls.Clear()

                '' Create @all button
                'Dim _newALL As New MetroButton
                '_newALL.Name = "@all"
                '_newALL.Text = "@all"
                '_newALL.DrawBorder = False
                '_newALL.ForeColor = Color.White
                '_newALL.DefaultColor = Color.Black
                '_newALL.HoverColor = Color.FromArgb(255, 64, 64, 64)
                'AddHandler _newALL.Click, AddressOf userClick
                'friends_flp1.Controls.Add(_newALL)

        End Select
    End Sub

    Private Sub UTC_IDlistChanged(sIDs As List(Of String))
        Networking.UTC.sendUTicket("@all", "Chat:RequestAllUsers", QClipboard.AccountName)
        'friends_flp1.Controls.Clear()

        '' Create @all button
        'Dim _newALL As New MetroButton
        '_newALL.Name = "@all"
        '_newALL.Text = "@all"
        '_newALL.DrawBorder = False
        '_newALL.ForeColor = Color.White
        '_newALL.DefaultColor = Color.Black
        '_newALL.HoverColor = Color.FromArgb(255, 64, 64, 64)
        'AddHandler _newALL.Click, AddressOf userClick
        'friends_flp1.Controls.Add(_newALL)

        'For i = 0 To ListOfUsers.Count - 1
        '    MsgBox(ListOfUsers(i).ToString)
        '    Dim _newUser As New MetroButton
        '    _newUser.Name = ListOfUsers(i).ToString
        '    _newUser.Text = ListOfUsers(i).ToString

        '    _newUser.DrawBorder = False
        '    _newUser.ForeColor = Color.White
        '    _newUser.DefaultColor = Color.Black
        '    _newUser.HoverColor = Color.FromArgb(255, 64, 64, 64)

        '    AddHandler _newUser.Click, AddressOf userClick

        '    friends_flp1.Controls.Add(_newUser)
        'Next
    End Sub

    ' EXPERIMENTAL
#Region " -X- TESTING CHAT -X- "
    Delegate Sub WriteTextDelegate(ByVal ListOfData As List(Of Object))
    Private Sub AddTabPage(ByVal ListOfData As List(Of Object))
        Try
            Dim SendingTime As String = "[" & TimeOfDay & "]"
            If Chat_tbcntrl.TabPages.ContainsKey(ListOfData(1).ToString) Then
                DirectCast(Chat_tbcntrl.TabPages.Item(Chat_tbcntrl.SelectedIndex).Controls.Item(0), ListBox).Items.Add(SendingTime & " " & ListOfData(1).ToString & ": " & ListOfData(0).ToString)
            Else
                If Not ListOfData(1).ToString = QClipboard.AccountName Then
                    Dim ChatPage As New TabPage
                    Dim _ListBox As New ListBox

                    ChatPage.Text = ListOfData(1).ToString
                    ChatPage.Name = ListOfData(1).ToString
                    _ListBox.Dock = DockStyle.Fill

                    ChatPage.Controls.Add(_ListBox)
                    Chat_tbcntrl.TabPages.Add(ChatPage)

                    DirectCast(Chat_tbcntrl.TabPages.Item(Chat_tbcntrl.SelectedIndex).Controls.Item(0), ListBox).Items.Add(SendingTime & " " & ListOfData(1).ToString & ": " & ListOfData(0).ToString)
                Else
                    DirectCast(Chat_tbcntrl.TabPages.Item(Chat_tbcntrl.SelectedIndex).Controls.Item(0), ListBox).Items.Add(SendingTime & " " & ListOfData(1).ToString & ": " & ListOfData(0).ToString)
                End If
            End If
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Fehler beim empfangen einer Nachricht." & vbNewLine & ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub
#End Region
#End Region

#Region " Delegates Subs "

    Public Sub AddNewOpenedUserDelegate_Sub(ByVal Target As Control, ByVal _Text As String)
        If _Text.Contains(QClipboard.AccountName) Then
            Dim _NewUser As New UserUC
            _NewUser.Name = _Text
            _NewUser.username_lbl.Text = _Text
            _NewUser.username_lbl.Dock = DockStyle.Fill
            _NewUser.AddFriend_ll.Visible = False
            Target.Controls.Add(_NewUser)
        Else
            If Not _Text.Contains("ADMIN") Then
                Dim _NewUser As New UserUC
                _NewUser.Name = _Text
                _NewUser.username_lbl.Text = _Text
                Target.Controls.Add(_NewUser)
            End If
        End If
    End Sub

    Public Sub AddFriendDelegate_Sub(ByVal Target As Control, ByVal _Text As String)
        Dim _NewFriend As New FriendUC
        Dim FriendName As String = _Text.Split(CChar("|"))(0)
        Dim FriendID As String = _Text.Split(CChar("|"))(1)

        _NewFriend.Name = FriendName
        _NewFriend.username_lbl.Text = FriendName & "#" & FriendID
        Target.Controls.Add(_NewFriend)
    End Sub

#End Region

    Private Sub Friends_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'AddHandler
        If Not Networking.IsObjectNothing Then
            AddHandler Networking.UTC.UTicketArrived, AddressOf UTC_UTicketArrived
            AddHandler Networking.UTC.IDlistChanged, AddressOf UTC_IDlistChanged
        End If

        ApplyTheme() ' Set Theme

        Control.CheckForIllegalCrossThreadCalls = False

        ' CheckLoggedInMode
        If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
            user_picbox.Image = My.Resources.clonk_user_loggedin
            username_lbl.Text = QClipboard.AccountName
        Else
            user_picbox.Image = My.Resources.clonk_user_unknown
            username_lbl.Text = "Anonym"
        End If

        ' RequestAllUsers
        Networking.UTC.sendUTicket("@all", "Chat:RequestAllUsers", QClipboard.AccountName)
        Networking.UTC.sendUTicket("@all", "Chat:RequestAllFriends", QClipboard.AccountName)
    End Sub

    Private Sub send_btn_Click(sender As Object, e As EventArgs) Handles send_btn.Click
        If Chat_tbcntrl.TabPages.Count = 0 Then
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Kein aktiver Chat.")
            _newMsg.ShowDialog()
        Else
            If String.IsNullOrWhiteSpace(message_txtbox.Text) Then
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Text zum senden eingeben.")
                _newMsg.ShowDialog()
            Else
                Dim ListOfData As New List(Of Object)
                ListOfData.Add(message_txtbox.Text)
                ListOfData.Add(QClipboard.AccountName)
                Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                message_txtbox.Text = "" ' Clear Input
            End If
        End If
    End Sub


    '    Dim NewFrnd As New FriendUC
    '    NewFrnd.Name = "ANDREW"
    '    NewFrnd.username_lbl.Text = "ANDREW"
    '    NewFrnd.user_picbox.Image = My.Resources.clonk_user_loggedin
    '    friends_flp1.Controls.Add(NewFrnd)

End Class