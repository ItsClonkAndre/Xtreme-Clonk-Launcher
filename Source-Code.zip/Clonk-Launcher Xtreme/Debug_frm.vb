﻿Option Strict On
Public Class Debug_frm

#Region " Lock "

    Private Sub enter_btn_Click(sender As Object, e As EventArgs) Handles enter_btn.Click
        If pw_txtbox.Text = "11012020" Then
            lock_pnl.Visible = False
        Else
            pw_txtbox.Text = ""
        End If
    End Sub

    Private Sub close_btn_Click(sender As Object, e As EventArgs) Handles close_btn.Click
        Me.Close()
    End Sub

#End Region

    Private Sub Debug_frm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LastDayDateValue_lbl.Text = "Value: " & My.Settings.LastDayDate.ToString
        SurveyCompletedValue_lbl.Text = "Value: " & My.Settings.SurveyCompleted.ToString
    End Sub

    Private Sub ResetLastDayDate_btn_Click(sender As Object, e As EventArgs) Handles ResetLastDayDate_btn.Click
        MessageBox.Show("Current Day of Week: " & Date.Today.DayOfWeek & Environment.NewLine & "Current Setting: " & My.Settings.LastDayDate.ToString, "Before")

        My.Settings.LastDayDate = 9
        My.Settings.Save()

        LastDayDateValue_lbl.Text = "Value: " & My.Settings.LastDayDate.ToString
        MessageBox.Show("Current Day of Week: " & Date.Today.DayOfWeek & Environment.NewLine & "New Setting: " & My.Settings.LastDayDate.ToString, "After")
    End Sub

    Private Sub ResetSurveyCompleted_btn_Click(sender As Object, e As EventArgs) Handles ResetSurveyCompleted_btn.Click
        MessageBox.Show("Current Setting: " & My.Settings.SurveyCompleted.ToString, "Before")

        My.Settings.SurveyCompleted = False
        My.Settings.Save()

        SurveyCompletedValue_lbl.Text = "Value: " & My.Settings.SurveyCompleted.ToString
        MessageBox.Show("New Setting: " & My.Settings.SurveyCompleted.ToString, "After")
    End Sub

    Private Sub GetOpenedIP_btn_Click(sender As Object, e As EventArgs) Handles GetOpenedIP_btn.Click
        Networking.GetOpenedIP()
    End Sub

End Class