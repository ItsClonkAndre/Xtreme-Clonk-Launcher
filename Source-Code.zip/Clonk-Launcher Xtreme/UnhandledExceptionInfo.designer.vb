﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UnhandledExceptionInfo
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UnhandledExceptionInfo))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MetroLabel1 = New MetroSuite.MetroLabel()
        Me.QuitAndSend_btn = New MetroSuite.MetroButton()
        Me.Continue_btn = New MetroSuite.MetroButton()
        Me.QuitWithoutSending_btn = New MetroSuite.MetroButton()
        Me.MetroLabel2 = New MetroSuite.MetroLabel()
        Me.MetroLabel3 = New MetroSuite.MetroLabel()
        Me.Details_txtbox = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.ExceptionText_txtbox = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.controlbox_pnl.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(345, 3)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 2
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Enabled = False
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Enabled = False
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.sad_smiley
        Me.PictureBox1.Location = New System.Drawing.Point(157, 42)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(90, 90)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'MetroLabel1
        '
        Me.MetroLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel1.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.MetroLabel1.ForeColor = System.Drawing.Color.Red
        Me.MetroLabel1.Location = New System.Drawing.Point(12, 140)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(381, 53)
        Me.MetroLabel1.TabIndex = 4
        Me.MetroLabel1.Text = "An unhandled exception has occurred in this application. You can try to continue," &
    " but the application might be unstable."
        Me.MetroLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'QuitAndSend_btn
        '
        Me.QuitAndSend_btn.BackColor = System.Drawing.Color.Transparent
        Me.QuitAndSend_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.QuitAndSend_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.QuitAndSend_btn.DefaultColor = System.Drawing.Color.White
        Me.QuitAndSend_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.QuitAndSend_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.QuitAndSend_btn.HoverColor = System.Drawing.Color.White
        Me.QuitAndSend_btn.Location = New System.Drawing.Point(248, 441)
        Me.QuitAndSend_btn.Name = "QuitAndSend_btn"
        Me.QuitAndSend_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.QuitAndSend_btn.RoundingArc = 23
        Me.QuitAndSend_btn.Size = New System.Drawing.Size(122, 23)
        Me.QuitAndSend_btn.TabIndex = 5
        Me.QuitAndSend_btn.Text = "Quit and send report"
        '
        'Continue_btn
        '
        Me.Continue_btn.BackColor = System.Drawing.Color.Transparent
        Me.Continue_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Continue_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Continue_btn.DefaultColor = System.Drawing.Color.White
        Me.Continue_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Continue_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Continue_btn.HoverColor = System.Drawing.Color.White
        Me.Continue_btn.Location = New System.Drawing.Point(35, 441)
        Me.Continue_btn.Name = "Continue_btn"
        Me.Continue_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Continue_btn.RoundingArc = 23
        Me.Continue_btn.Size = New System.Drawing.Size(75, 23)
        Me.Continue_btn.TabIndex = 6
        Me.Continue_btn.Text = "Continue"
        '
        'QuitWithoutSending_btn
        '
        Me.QuitWithoutSending_btn.BackColor = System.Drawing.Color.Transparent
        Me.QuitWithoutSending_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.QuitWithoutSending_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.QuitWithoutSending_btn.DefaultColor = System.Drawing.Color.White
        Me.QuitWithoutSending_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.QuitWithoutSending_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.QuitWithoutSending_btn.HoverColor = System.Drawing.Color.White
        Me.QuitWithoutSending_btn.Location = New System.Drawing.Point(116, 441)
        Me.QuitWithoutSending_btn.Name = "QuitWithoutSending_btn"
        Me.QuitWithoutSending_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.QuitWithoutSending_btn.RoundingArc = 23
        Me.QuitWithoutSending_btn.Size = New System.Drawing.Size(126, 23)
        Me.QuitWithoutSending_btn.TabIndex = 7
        Me.QuitWithoutSending_btn.Text = "Quit without sending"
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel2.Font = New System.Drawing.Font("Segoe UI", 10.75!)
        Me.MetroLabel2.Location = New System.Drawing.Point(12, 272)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(113, 20)
        Me.MetroLabel2.TabIndex = 9
        Me.MetroLabel2.Text = "- Exception text"
        Me.MetroLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'MetroLabel3
        '
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel3.Font = New System.Drawing.Font("Segoe UI", 10.75!)
        Me.MetroLabel3.Location = New System.Drawing.Point(12, 193)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(65, 20)
        Me.MetroLabel3.TabIndex = 10
        Me.MetroLabel3.Text = "- Details"
        Me.MetroLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Details_txtbox
        '
        Me.Details_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Details_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Details_txtbox.DefaultColor = System.Drawing.Color.White
        Me.Details_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Details_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Details_txtbox.ForeColor = System.Drawing.Color.Black
        Me.Details_txtbox.HideSelection = False
        Me.Details_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Details_txtbox.Location = New System.Drawing.Point(12, 216)
        Me.Details_txtbox.Multiline = True
        Me.Details_txtbox.Name = "Details_txtbox"
        Me.Details_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Details_txtbox.ReadOnly = True
        Me.Details_txtbox.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.Details_txtbox.Size = New System.Drawing.Size(381, 53)
        Me.Details_txtbox.TabIndex = 11
        Me.Details_txtbox.Text = "AdvancedScrollableLabel1"
        '
        'ExceptionText_txtbox
        '
        Me.ExceptionText_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ExceptionText_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ExceptionText_txtbox.DefaultColor = System.Drawing.Color.White
        Me.ExceptionText_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ExceptionText_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ExceptionText_txtbox.ForeColor = System.Drawing.Color.Black
        Me.ExceptionText_txtbox.HideSelection = False
        Me.ExceptionText_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ExceptionText_txtbox.Location = New System.Drawing.Point(12, 295)
        Me.ExceptionText_txtbox.Multiline = True
        Me.ExceptionText_txtbox.Name = "ExceptionText_txtbox"
        Me.ExceptionText_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.ExceptionText_txtbox.ReadOnly = True
        Me.ExceptionText_txtbox.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.ExceptionText_txtbox.Size = New System.Drawing.Size(381, 137)
        Me.ExceptionText_txtbox.TabIndex = 8
        Me.ExceptionText_txtbox.Text = "AdvancedScrollableLabel1"
        '
        'UnhandledExceptionInfo
        '
        Me.AllowResize = False
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(405, 476)
        Me.Controls.Add(Me.Details_txtbox)
        Me.Controls.Add(Me.MetroLabel3)
        Me.Controls.Add(Me.MetroLabel2)
        Me.Controls.Add(Me.ExceptionText_txtbox)
        Me.Controls.Add(Me.QuitWithoutSending_btn)
        Me.Controls.Add(Me.Continue_btn)
        Me.Controls.Add(Me.QuitAndSend_btn)
        Me.Controls.Add(Me.MetroLabel1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "UnhandledExceptionInfo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "Xtreme-Clonk-Launcher | ERROR"
        Me.controlbox_pnl.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Public WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Public WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Public WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MetroLabel1 As MetroSuite.MetroLabel
    Friend WithEvents QuitAndSend_btn As MetroSuite.MetroButton
    Friend WithEvents Continue_btn As MetroSuite.MetroButton
    Friend WithEvents QuitWithoutSending_btn As MetroSuite.MetroButton
    Friend WithEvents ExceptionText_txtbox As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
    Friend WithEvents MetroLabel2 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel3 As MetroSuite.MetroLabel
    Friend WithEvents Details_txtbox As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
End Class
