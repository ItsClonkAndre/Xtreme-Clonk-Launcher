﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CCANObjectPreviewFrm
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CCANObjectPreviewFrm))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.CCANtitle_lbl = New MetroSuite.MetroLabel()
        Me.MetroLabel2 = New MetroSuite.MetroLabel()
        Me.Unready_lbl = New MetroSuite.MetroLabel()
        Me.CCANversion_lbl = New MetroSuite.MetroLabel()
        Me.CCANplayercount_lbl = New MetroSuite.MetroLabel()
        Me.CCANgameversion_lbl = New MetroSuite.MetroLabel()
        Me.CCANcategory_lbl = New MetroSuite.MetroLabel()
        Me.AllComments_flp = New System.Windows.Forms.FlowLayoutPanel()
        Me.MetroLabel7 = New MetroSuite.MetroLabel()
        Me.comment_txtbox = New MetroSuite.MetroTextbox()
        Me.RateObject_btn = New MetroSuite.MetroButton()
        Me.CommentsCount_lbl = New MetroSuite.MetroLabel()
        Me.download_btn = New MetroSuite.MetroButton()
        Me.CCANauthor_lbl = New MetroSuite.MetroLabel()
        Me.UploadDate_lbl = New MetroSuite.MetroLabel()
        Me.Characters_mbar = New MetroSuite.MetroProgressbar()
        Me.LoadingComments_picbox = New System.Windows.Forms.PictureBox()
        Me.CCANdesc_rtb = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.CommentRating_sr = New Xtreme_Clonk_Launcher.StarRating()
        Me.AverageRating_sr = New Xtreme_Clonk_Launcher.StarRating()
        Me.ShowNewestFirst_chkbox = New MetroSuite.MetroChecker()
        Me.DeleteObject_btn = New MetroSuite.MetroButton()
        Me.controlbox_pnl.SuspendLayout()
        CType(Me.LoadingComments_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(883, 3)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 2
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Enabled = False
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.Black
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Enabled = False
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.Black
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'CCANtitle_lbl
        '
        Me.CCANtitle_lbl.BackColor = System.Drawing.Color.Transparent
        Me.CCANtitle_lbl.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CCANtitle_lbl.Location = New System.Drawing.Point(24, 37)
        Me.CCANtitle_lbl.Name = "CCANtitle_lbl"
        Me.CCANtitle_lbl.Size = New System.Drawing.Size(895, 26)
        Me.CCANtitle_lbl.TabIndex = 3
        Me.CCANtitle_lbl.Text = "TITEL VOM OBJEKT"
        Me.CCANtitle_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel2.Location = New System.Drawing.Point(18, 228)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(79, 15)
        Me.MetroLabel2.TabIndex = 5
        Me.MetroLabel2.Text = "Beschreibung"
        '
        'Unready_lbl
        '
        Me.Unready_lbl.BackColor = System.Drawing.Color.Transparent
        Me.Unready_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Unready_lbl.ForeColor = System.Drawing.Color.Red
        Me.Unready_lbl.Location = New System.Drawing.Point(26, 185)
        Me.Unready_lbl.Name = "Unready_lbl"
        Me.Unready_lbl.Size = New System.Drawing.Size(890, 15)
        Me.Unready_lbl.TabIndex = 10
        Me.Unready_lbl.Text = "Unfertig"
        Me.Unready_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Unready_lbl.Visible = False
        '
        'CCANversion_lbl
        '
        Me.CCANversion_lbl.BackColor = System.Drawing.Color.Transparent
        Me.CCANversion_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANversion_lbl.Location = New System.Drawing.Point(26, 164)
        Me.CCANversion_lbl.Name = "CCANversion_lbl"
        Me.CCANversion_lbl.Size = New System.Drawing.Size(890, 15)
        Me.CCANversion_lbl.TabIndex = 11
        Me.CCANversion_lbl.Text = "Version: 2.03c"
        Me.CCANversion_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CCANplayercount_lbl
        '
        Me.CCANplayercount_lbl.BackColor = System.Drawing.Color.Transparent
        Me.CCANplayercount_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANplayercount_lbl.Location = New System.Drawing.Point(26, 149)
        Me.CCANplayercount_lbl.Name = "CCANplayercount_lbl"
        Me.CCANplayercount_lbl.Size = New System.Drawing.Size(890, 15)
        Me.CCANplayercount_lbl.TabIndex = 12
        Me.CCANplayercount_lbl.Text = "Spieleranzahl: 1 - 4"
        Me.CCANplayercount_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CCANgameversion_lbl
        '
        Me.CCANgameversion_lbl.BackColor = System.Drawing.Color.Transparent
        Me.CCANgameversion_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANgameversion_lbl.Location = New System.Drawing.Point(26, 119)
        Me.CCANgameversion_lbl.Name = "CCANgameversion_lbl"
        Me.CCANgameversion_lbl.Size = New System.Drawing.Size(890, 15)
        Me.CCANgameversion_lbl.TabIndex = 13
        Me.CCANgameversion_lbl.Text = "Spielversion: Clonk Rage"
        Me.CCANgameversion_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CCANcategory_lbl
        '
        Me.CCANcategory_lbl.BackColor = System.Drawing.Color.Transparent
        Me.CCANcategory_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANcategory_lbl.Location = New System.Drawing.Point(26, 134)
        Me.CCANcategory_lbl.Name = "CCANcategory_lbl"
        Me.CCANcategory_lbl.Size = New System.Drawing.Size(890, 15)
        Me.CCANcategory_lbl.TabIndex = 14
        Me.CCANcategory_lbl.Text = "Kategorie: Szenario, Action"
        Me.CCANcategory_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'AllComments_flp
        '
        Me.AllComments_flp.AutoScroll = True
        Me.AllComments_flp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.AllComments_flp.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.AllComments_flp.Location = New System.Drawing.Point(12, 403)
        Me.AllComments_flp.Name = "AllComments_flp"
        Me.AllComments_flp.Size = New System.Drawing.Size(919, 122)
        Me.AllComments_flp.TabIndex = 16
        Me.AllComments_flp.WrapContents = False
        '
        'MetroLabel7
        '
        Me.MetroLabel7.AutoSize = True
        Me.MetroLabel7.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel7.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel7.Location = New System.Drawing.Point(18, 540)
        Me.MetroLabel7.Name = "MetroLabel7"
        Me.MetroLabel7.Size = New System.Drawing.Size(138, 15)
        Me.MetroLabel7.TabIndex = 17
        Me.MetroLabel7.Text = "Eine Bewertung abgeben"
        '
        'comment_txtbox
        '
        Me.comment_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.comment_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.comment_txtbox.DefaultColor = System.Drawing.Color.White
        Me.comment_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.comment_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.comment_txtbox.ForeColor = System.Drawing.Color.Black
        Me.comment_txtbox.HideSelection = False
        Me.comment_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.comment_txtbox.Location = New System.Drawing.Point(42, 558)
        Me.comment_txtbox.MaxLength = 350
        Me.comment_txtbox.Name = "comment_txtbox"
        Me.comment_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.comment_txtbox.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.comment_txtbox.Size = New System.Drawing.Size(672, 24)
        Me.comment_txtbox.TabIndex = 18
        Me.comment_txtbox.Watermark = "Bewertung schreiben"
        '
        'RateObject_btn
        '
        Me.RateObject_btn.BackColor = System.Drawing.Color.Transparent
        Me.RateObject_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RateObject_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.RateObject_btn.DefaultColor = System.Drawing.Color.White
        Me.RateObject_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.RateObject_btn.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RateObject_btn.HoverColor = System.Drawing.Color.White
        Me.RateObject_btn.Location = New System.Drawing.Point(846, 558)
        Me.RateObject_btn.Name = "RateObject_btn"
        Me.RateObject_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.RateObject_btn.RoundingArc = 24
        Me.RateObject_btn.Size = New System.Drawing.Size(85, 24)
        Me.RateObject_btn.TabIndex = 20
        Me.RateObject_btn.Text = "Bewerten"
        '
        'CommentsCount_lbl
        '
        Me.CommentsCount_lbl.AutoSize = True
        Me.CommentsCount_lbl.BackColor = System.Drawing.Color.Transparent
        Me.CommentsCount_lbl.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CommentsCount_lbl.Location = New System.Drawing.Point(18, 385)
        Me.CommentsCount_lbl.Name = "CommentsCount_lbl"
        Me.CommentsCount_lbl.Size = New System.Drawing.Size(118, 15)
        Me.CommentsCount_lbl.TabIndex = 21
        Me.CommentsCount_lbl.Text = "Alle Bewertungen (0)"
        '
        'download_btn
        '
        Me.download_btn.BackColor = System.Drawing.Color.Transparent
        Me.download_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.download_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.download_btn.DefaultColor = System.Drawing.Color.White
        Me.download_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.download_btn.Font = New System.Drawing.Font("Arial", 10.75!, System.Drawing.FontStyle.Bold)
        Me.download_btn.HoverColor = System.Drawing.Color.White
        Me.download_btn.Location = New System.Drawing.Point(384, 201)
        Me.download_btn.Name = "download_btn"
        Me.download_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.download_btn.RoundingArc = 35
        Me.download_btn.Size = New System.Drawing.Size(174, 35)
        Me.download_btn.TabIndex = 23
        Me.download_btn.Text = "Herunterladen"
        '
        'CCANauthor_lbl
        '
        Me.CCANauthor_lbl.BackColor = System.Drawing.Color.Transparent
        Me.CCANauthor_lbl.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CCANauthor_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANauthor_lbl.Location = New System.Drawing.Point(26, 104)
        Me.CCANauthor_lbl.Name = "CCANauthor_lbl"
        Me.CCANauthor_lbl.Size = New System.Drawing.Size(890, 15)
        Me.CCANauthor_lbl.TabIndex = 24
        Me.CCANauthor_lbl.Text = "Autor: AUTORNAME"
        Me.CCANauthor_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'UploadDate_lbl
        '
        Me.UploadDate_lbl.BackColor = System.Drawing.Color.Transparent
        Me.UploadDate_lbl.Font = New System.Drawing.Font("Segoe UI", 7.0!)
        Me.UploadDate_lbl.Location = New System.Drawing.Point(26, 60)
        Me.UploadDate_lbl.Name = "UploadDate_lbl"
        Me.UploadDate_lbl.Size = New System.Drawing.Size(890, 12)
        Me.UploadDate_lbl.TabIndex = 25
        Me.UploadDate_lbl.Text = "Hochgeladen am: 01.01.2019 - 00:00"
        Me.UploadDate_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Characters_mbar
        '
        Me.Characters_mbar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Characters_mbar.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Characters_mbar.DefaultColor = System.Drawing.Color.White
        Me.Characters_mbar.Font = New System.Drawing.Font("Segoe UI", 7.0!)
        Me.Characters_mbar.ForeColor = System.Drawing.Color.Black
        Me.Characters_mbar.GradientColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(163, Byte), Integer))
        Me.Characters_mbar.Location = New System.Drawing.Point(12, 558)
        Me.Characters_mbar.Maximum = 350
        Me.Characters_mbar.Name = "Characters_mbar"
        Me.Characters_mbar.ProgressColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Characters_mbar.RoundingArc = 24
        Me.Characters_mbar.ShowValueAsText = True
        Me.Characters_mbar.Size = New System.Drawing.Size(24, 24)
        Me.Characters_mbar.TabIndex = 27
        Me.Characters_mbar.UseGradient = False
        Me.Characters_mbar.Value = 0
        '
        'LoadingComments_picbox
        '
        Me.LoadingComments_picbox.BackColor = System.Drawing.Color.Transparent
        Me.LoadingComments_picbox.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.Loading_BlueFast
        Me.LoadingComments_picbox.Location = New System.Drawing.Point(913, 384)
        Me.LoadingComments_picbox.Name = "LoadingComments_picbox"
        Me.LoadingComments_picbox.Size = New System.Drawing.Size(18, 18)
        Me.LoadingComments_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.LoadingComments_picbox.TabIndex = 28
        Me.LoadingComments_picbox.TabStop = False
        Me.LoadingComments_picbox.Visible = False
        '
        'CCANdesc_rtb
        '
        Me.CCANdesc_rtb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CCANdesc_rtb.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CCANdesc_rtb.DefaultColor = System.Drawing.Color.White
        Me.CCANdesc_rtb.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CCANdesc_rtb.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANdesc_rtb.ForeColor = System.Drawing.Color.Black
        Me.CCANdesc_rtb.HideSelection = False
        Me.CCANdesc_rtb.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CCANdesc_rtb.Location = New System.Drawing.Point(12, 246)
        Me.CCANdesc_rtb.Multiline = True
        Me.CCANdesc_rtb.Name = "CCANdesc_rtb"
        Me.CCANdesc_rtb.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.CCANdesc_rtb.ReadOnly = True
        Me.CCANdesc_rtb.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.CCANdesc_rtb.Size = New System.Drawing.Size(919, 136)
        Me.CCANdesc_rtb.TabIndex = 26
        Me.CCANdesc_rtb.Text = "AdvancedScrollableLabel1"
        '
        'CommentRating_sr
        '
        Me.CommentRating_sr.BackColor = System.Drawing.Color.Transparent
        Me.CommentRating_sr.Location = New System.Drawing.Point(720, 558)
        Me.CommentRating_sr.Name = "CommentRating_sr"
        Me.CommentRating_sr.NotClickable = False
        Me.CommentRating_sr.Size = New System.Drawing.Size(120, 24)
        Me.CommentRating_sr.StarCount = 5
        Me.CommentRating_sr.StarGold = Nothing
        Me.CommentRating_sr.StarGray = Nothing
        Me.CommentRating_sr.StarHeight = 24
        Me.CommentRating_sr.StarWidth = 24
        Me.CommentRating_sr.TabIndex = 19
        Me.CommentRating_sr.Value = 0
        '
        'AverageRating_sr
        '
        Me.AverageRating_sr.BackColor = System.Drawing.Color.Transparent
        Me.AverageRating_sr.Location = New System.Drawing.Point(411, 74)
        Me.AverageRating_sr.Name = "AverageRating_sr"
        Me.AverageRating_sr.NotClickable = True
        Me.AverageRating_sr.Size = New System.Drawing.Size(120, 24)
        Me.AverageRating_sr.StarCount = 5
        Me.AverageRating_sr.StarGold = Nothing
        Me.AverageRating_sr.StarGray = Nothing
        Me.AverageRating_sr.StarHeight = 24
        Me.AverageRating_sr.StarWidth = 24
        Me.AverageRating_sr.TabIndex = 15
        Me.AverageRating_sr.Value = 0
        '
        'ShowNewestFirst_chkbox
        '
        Me.ShowNewestFirst_chkbox.BackColor = System.Drawing.Color.White
        Me.ShowNewestFirst_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ShowNewestFirst_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ShowNewestFirst_chkbox.Checked = True
        Me.ShowNewestFirst_chkbox.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ShowNewestFirst_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ShowNewestFirst_chkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ShowNewestFirst_chkbox.ForeColor = System.Drawing.Color.Black
        Me.ShowNewestFirst_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.ShowNewestFirst_chkbox.Location = New System.Drawing.Point(760, 386)
        Me.ShowNewestFirst_chkbox.Name = "ShowNewestFirst_chkbox"
        Me.ShowNewestFirst_chkbox.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.ShowNewestFirst_chkbox.Size = New System.Drawing.Size(147, 14)
        Me.ShowNewestFirst_chkbox.TabIndex = 29
        Me.ShowNewestFirst_chkbox.Text = "Neuste zuerst anzeigen"
        '
        'DeleteObject_btn
        '
        Me.DeleteObject_btn.BackColor = System.Drawing.Color.Transparent
        Me.DeleteObject_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeleteObject_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.DeleteObject_btn.DefaultColor = System.Drawing.Color.White
        Me.DeleteObject_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.DeleteObject_btn.Font = New System.Drawing.Font("Arial", 10.75!, System.Drawing.FontStyle.Bold)
        Me.DeleteObject_btn.ForeColor = System.Drawing.Color.Red
        Me.DeleteObject_btn.HoverColor = System.Drawing.Color.White
        Me.DeleteObject_btn.Location = New System.Drawing.Point(564, 201)
        Me.DeleteObject_btn.Name = "DeleteObject_btn"
        Me.DeleteObject_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.DeleteObject_btn.RoundingArc = 35
        Me.DeleteObject_btn.Size = New System.Drawing.Size(174, 35)
        Me.DeleteObject_btn.TabIndex = 30
        Me.DeleteObject_btn.Text = "Vom Server löschen"
        Me.DeleteObject_btn.Visible = False
        '
        'CCANObjectPreviewFrm
        '
        Me.AllowResize = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.CCANbg1
        Me.ClientSize = New System.Drawing.Size(943, 604)
        Me.Controls.Add(Me.DeleteObject_btn)
        Me.Controls.Add(Me.ShowNewestFirst_chkbox)
        Me.Controls.Add(Me.LoadingComments_picbox)
        Me.Controls.Add(Me.Characters_mbar)
        Me.Controls.Add(Me.UploadDate_lbl)
        Me.Controls.Add(Me.CCANtitle_lbl)
        Me.Controls.Add(Me.CCANdesc_rtb)
        Me.Controls.Add(Me.CCANauthor_lbl)
        Me.Controls.Add(Me.download_btn)
        Me.Controls.Add(Me.CommentsCount_lbl)
        Me.Controls.Add(Me.RateObject_btn)
        Me.Controls.Add(Me.CommentRating_sr)
        Me.Controls.Add(Me.comment_txtbox)
        Me.Controls.Add(Me.MetroLabel7)
        Me.Controls.Add(Me.AllComments_flp)
        Me.Controls.Add(Me.AverageRating_sr)
        Me.Controls.Add(Me.CCANcategory_lbl)
        Me.Controls.Add(Me.CCANgameversion_lbl)
        Me.Controls.Add(Me.CCANplayercount_lbl)
        Me.Controls.Add(Me.CCANversion_lbl)
        Me.Controls.Add(Me.Unready_lbl)
        Me.Controls.Add(Me.MetroLabel2)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CCANObjectPreviewFrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "CCAN | OBJECTTITLE"
        Me.controlbox_pnl.ResumeLayout(False)
        CType(Me.LoadingComments_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Friend WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents CCANtitle_lbl As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel2 As MetroSuite.MetroLabel
    Friend WithEvents Unready_lbl As MetroSuite.MetroLabel
    Friend WithEvents CCANversion_lbl As MetroSuite.MetroLabel
    Friend WithEvents CCANplayercount_lbl As MetroSuite.MetroLabel
    Friend WithEvents CCANgameversion_lbl As MetroSuite.MetroLabel
    Friend WithEvents CCANcategory_lbl As MetroSuite.MetroLabel
    Friend WithEvents AverageRating_sr As Xtreme_Clonk_Launcher.StarRating
    Friend WithEvents AllComments_flp As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents MetroLabel7 As MetroSuite.MetroLabel
    Friend WithEvents comment_txtbox As MetroSuite.MetroTextbox
    Friend WithEvents CommentRating_sr As Xtreme_Clonk_Launcher.StarRating
    Friend WithEvents RateObject_btn As MetroSuite.MetroButton
    Friend WithEvents CommentsCount_lbl As MetroSuite.MetroLabel
    Friend WithEvents download_btn As MetroSuite.MetroButton
    Friend WithEvents CCANauthor_lbl As MetroSuite.MetroLabel
    Friend WithEvents UploadDate_lbl As MetroSuite.MetroLabel
    Friend WithEvents CCANdesc_rtb As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
    Friend WithEvents Characters_mbar As MetroSuite.MetroProgressbar
    Friend WithEvents LoadingComments_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents ShowNewestFirst_chkbox As MetroSuite.MetroChecker
    Friend WithEvents DeleteObject_btn As MetroSuite.MetroButton
End Class
