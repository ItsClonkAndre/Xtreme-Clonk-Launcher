﻿Option Strict On
Imports MetroSuite
Imports MetroSuite.Extension
Imports MadMilkman.Ini
Imports Microsoft.Win32
Public Class GameSettingsFrm : Inherits MetroForm

#Region "ControlBox"

    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        Me.Dispose()
    End Sub
    Private Sub controlbox_nmaximize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_nmaximize_lbl.Click
        If controlbox_nmaximize_lbl.Text = "□" Then
            controlbox_nmaximize_lbl.Text = "■"
            Me.WindowState = FormWindowState.Normal
        Else
            controlbox_nmaximize_lbl.Text = "□"
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub
    Private Sub controlbox_minimize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_minimize_lbl.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter, controlbox_nmaximize_lbl.MouseEnter, controlbox_minimize_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave, controlbox_nmaximize_lbl.MouseLeave, controlbox_minimize_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

#End Region

#Region "Functions"

    Public Sub ApplyTheme()
        Try
            Dim myTheme As New Styles.Themes.MetroSuiteTheme
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            If IO.File.Exists(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme")) Then ' If file exists
                myTheme = myTheme.FromFile(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme"))
            Else ' If not
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Private Sub ReloadSettings(ByVal _GameName As String)
        Select Case _GameName
            Case "OpenClonk"
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\OpenClonk Project\OpenClonk\General", True) ' General
                    OpenClonkLanguage_cmdbox.SelectedItem = Key.GetValue("Language")
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\OpenClonk Project\OpenClonk\Graphics", True) ' Graphics
                    OpenClonkMenuTransparency_chkbox.Checked = CBool(Key.GetValue("MenuTransparency"))
                    OpenClonkMultiSampling_chkbox.Checked = CBool(Key.GetValue("MultiSampling"))
                    OpenClonkWindowed_chkbox.Checked = CBool(Key.GetValue("Windowed"))

                    OpenClonkResolutionX_nud.Value = CInt(Key.GetValue("ResolutionX"))
                    OpenClonkResolutionY_nud.Value = CInt(Key.GetValue("ResolutionY"))
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\OpenClonk Project\OpenClonk\Sound", True) ' Sound
                    OpenClonkMenuMusic_chkbox.Checked = CBool(Key.GetValue("MenuMusic"))
                    OpenClonkMenuSound_chkbox.Checked = CBool(Key.GetValue("MenuSound"))
                    OpenClonkGameMusic_chkbox.Checked = CBool(Key.GetValue("Music"))
                    OpenClonkGameSound_chkbox.Checked = CBool(Key.GetValue("Sound"))

                    OpenClonkMusic_trckbar.Value = CInt(Key.GetValue("MusicVolume2"))
                    OpenClonkSound_trckbar.Value = CInt(Key.GetValue("SoundVolume"))
                End Using

            Case "LegacyClonk"
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\LegacyClonk Team\LegacyClonk\General", True) ' General
                    LegacyClonkLanguage_cmdbox.SelectedItem = Key.GetValue("Language")
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\LegacyClonk Team\LegacyClonk\Graphics", True) ' Graphics
                    LegacyClonkMaximized_chkbox.Checked = CBool(Key.GetValue("Maximized"))
                    LegacyClonkWindowed_chkbox.Checked = CBool(Key.GetValue("Windowed"))
                    LegacyClonkNewGfxCfg_chkbox.Checked = CBool(Key.GetValue("NewGfxCfg"))
                    LegacyClonkShader_chkbox.Checked = CBool(Key.GetValue("Shader"))

                    LegacyClonkResolutionX_nud.Value = CInt(Key.GetValue("ResolutionX"))
                    LegacyClonkResolutionY_nud.Value = CInt(Key.GetValue("ResolutionY"))
                    LegacyClonkScale_trckbar.Value = CInt(Key.GetValue("Scale"))
                    ScaleCount_lbl.Text = "Scale (" & CStr(Key.GetValue("Scale")) & "%): "
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\LegacyClonk Team\LegacyClonk\Sound", True) ' Sound
                    LegacyClonkMenuMusic_chkbox.Checked = CBool(Key.GetValue("MenuMusic"))
                    LegacyClonkMenuSound_chkbox.Checked = CBool(Key.GetValue("MenuSound"))
                    LegacyClonkGameMusic_chkbox.Checked = CBool(Key.GetValue("Music"))
                    LegacyClonkGameSound_chkbox.Checked = CBool(Key.GetValue("Sound"))

                    LegacyClonkMusic_trckbar.Value = CInt(Key.GetValue("MusicVolume"))
                    LegacyClonkSound_trckbar.Value = CInt(Key.GetValue("SoundVolume"))
                End Using

            Case "ClonkEndeavour"
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk Endeavour\General", True) ' General
                    ClonkEndeavourLanguage_cmdbox.SelectedItem = Key.GetValue("Language")
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk Endeavour\Graphics", True) ' Graphics
                    ClonkEndeavourMenuTransparency_chkbox.Checked = CBool(Key.GetValue("MenuTransparency"))
                    ClonkEndeavourNewGfxCfg_chkbox.Checked = CBool(Key.GetValue("NewGfxCfg"))
                    ClonkEndeavourNewGfxCfgGL_chkbox.Checked = CBool(Key.GetValue("NewGfxCfgGL"))
                    ClonkEndeavourPXSGfx_chkbox.Checked = CBool(Key.GetValue("PXSGfx"))

                    ClonkEndeavourResolutionX_nud.Value = CInt(Key.GetValue("ResolutionX"))
                    ClonkEndeavourResolutionY_nud.Value = CInt(Key.GetValue("ResolutionY"))
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk Endeavour\Sound", True) ' Sound
                    ClonkEndeavourMenuMusic_chkbox.Checked = CBool(Key.GetValue("FEMusic"))
                    ClonkEndeavourMenuSound_chkbox.Checked = CBool(Key.GetValue("FESamples"))
                    ClonkEndeavourGameMusic_chkbox.Checked = CBool(Key.GetValue("RXMusic"))
                    ClonkEndeavourGameSound_chkbox.Checked = CBool(Key.GetValue("RXSound"))
                End Using

            Case "ClonkPlanet"
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk 4\General", True) ' General
                    ClonkPlanetClonk4Language_cmdbox.SelectedItem = Key.GetValue("Language")
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk 4\Graphics", True) ' Graphics
                    ClonkPlanetClonk4MenuTransparency_chkbox.Checked = CBool(Key.GetValue("MenuTransparency"))
                    ClonkPlanetClonk4NewGfxCfg_chkbox.Checked = CBool(Key.GetValue("NewGfxCfg"))
                    ClonkPlanetClonk4PXSGfx_chkbox.Checked = CBool(Key.GetValue("PXSGfx"))
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk 4\Sound", True) ' Sound
                    ClonkPlanetClonk4MenuMusic_chkbox.Checked = CBool(Key.GetValue("FEMusic"))
                    ClonkPlanetClonk4MenuSound_chkbox.Checked = CBool(Key.GetValue("FESamples"))
                    ClonkPlanetClonk4GameMusic_chkbox.Checked = CBool(Key.GetValue("RXMusic"))
                    ClonkPlanetClonk4GameSound_chkbox.Checked = CBool(Key.GetValue("RXSound"))
                    ClonkPlanetClonk4GameSoundLoops_chkbox.Checked = CBool(Key.GetValue("RXSoundLoops"))
                End Using

            Case "Clonk4"
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk 4\General", True) ' General
                    ClonkPlanetClonk4Language_cmdbox.SelectedItem = Key.GetValue("Language")
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk 4\Graphics", True) ' Graphics
                    ClonkPlanetClonk4MenuTransparency_chkbox.Checked = CBool(Key.GetValue("MenuTransparency"))
                    ClonkPlanetClonk4NewGfxCfg_chkbox.Checked = CBool(Key.GetValue("NewGfxCfg"))
                    ClonkPlanetClonk4PXSGfx_chkbox.Checked = CBool(Key.GetValue("PXSGfx"))
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk 4\Sound", True) ' Sound
                    ClonkPlanetClonk4MenuMusic_chkbox.Checked = CBool(Key.GetValue("FEMusic"))
                    ClonkPlanetClonk4MenuSound_chkbox.Checked = CBool(Key.GetValue("FESamples"))
                    ClonkPlanetClonk4GameMusic_chkbox.Checked = CBool(Key.GetValue("RXMusic"))
                    ClonkPlanetClonk4GameSound_chkbox.Checked = CBool(Key.GetValue("RXSound"))
                    ClonkPlanetClonk4GameSoundLoops_chkbox.Checked = CBool(Key.GetValue("RXSoundLoops"))
                End Using
            Case Else
                MessageBox.Show("Error while reading: No Input.", "Error")
        End Select
    End Sub

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

#End Region

    Private GameName As String
    Public Sub New(ByVal _GameName As String)
        InitializeComponent()
        GameName = _GameName
    End Sub
    Private Sub GameSettingsFrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ApplyTheme() ' ApplyTheme

        ' Setup TabControl
        With MetroTabControl1
            .SuspendLayout()
            .SizeMode = TabSizeMode.Fixed
            .ItemSize = New Size(1, 1)
            .Appearance = CType(TabAppearance.Buttons, Appearance)
            .ResumeLayout()
        End With

        ' Reload Game Settings
        ReloadSettings(GameName)

        ' Game
        Select Case GameName
            Case "OpenClonk"
                MetroTabControl1.SelectedTab = OpenClonk_tp
            Case "LegacyClonk"
                MetroTabControl1.SelectedTab = LegacyClonk_tp
            Case "ClonkEndeavour"
                MetroTabControl1.SelectedTab = ClonkEndeavour_tp
            Case "ClonkPlanet"
                MetroTabControl1.SelectedTab = ClonkPlanetClonk4_tp
            Case "Clonk4"
                MetroTabControl1.SelectedTab = ClonkPlanetClonk4_tp
        End Select
    End Sub

    Private Sub LegacyClonkScale_trckbar_Scroll(sender As Object, e As MetroTrackbar.TrackbarEventArgs) Handles LegacyClonkScale_trckbar.Scroll
        ScaleCount_lbl.Text = "Scale (" & CStr(e.SliderValue) & "%): "
    End Sub

    Private Sub close_btn_Click(sender As Object, e As EventArgs) Handles close_btn.Click, close1_btn.Click, close2_btn.Click, close3_btn.Click
        Me.Dispose()
    End Sub

    Private Sub OpenClonkAccept_btn_Click(sender As Object, e As EventArgs) Handles OpenClonkAccept_btn.Click, LegacyClonkAccept_btn.Click, ClonkEndeavourAccept_btn.Click, ClonkPlanetClonk4Accept_btn.Click
        Dim SenderButton As String = DirectCast(sender, MetroButton).Name.Split(CChar("_"))(0)
        Select Case SenderButton
            Case "OpenClonkAccept"
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\OpenClonk Project\OpenClonk\General", True) ' General
                    Key.SetValue("Language", OpenClonkLanguage_cmdbox.SelectedItem, RegistryValueKind.String)
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\OpenClonk Project\OpenClonk\Graphics", True) ' Graphics
                    Key.SetValue("MenuTransparency", Convert.ToInt32(OpenClonkMenuTransparency_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("MultiSampling", Convert.ToInt32(OpenClonkMultiSampling_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("Windowed", Convert.ToInt32(OpenClonkWindowed_chkbox.Checked), RegistryValueKind.DWord)

                    Key.SetValue("ResolutionX", OpenClonkResolutionX_nud.Value, RegistryValueKind.DWord)
                    Key.SetValue("ResolutionY", OpenClonkResolutionY_nud.Value, RegistryValueKind.DWord)
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\OpenClonk Project\OpenClonk\Sound", True) ' Sound
                    Key.SetValue("MenuMusic", Convert.ToInt32(OpenClonkMenuMusic_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("MenuSound", Convert.ToInt32(OpenClonkMenuSound_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("Music", Convert.ToInt32(OpenClonkGameMusic_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("Sound", Convert.ToInt32(OpenClonkGameSound_chkbox.Checked), RegistryValueKind.DWord)

                    Key.SetValue("MusicVolume2", OpenClonkMusic_trckbar.Value, RegistryValueKind.DWord)
                    Key.SetValue("SoundVolume", OpenClonkSound_trckbar.Value, RegistryValueKind.DWord)
                End Using

            Case "LegacyClonkAccept"
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\LegacyClonk Team\LegacyClonk\General", True) ' General
                    Key.SetValue("Language", LegacyClonkLanguage_cmdbox.SelectedItem, RegistryValueKind.String)
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\LegacyClonk Team\LegacyClonk\Graphics", True) ' Graphics
                    Key.SetValue("Maximized", Convert.ToInt32(LegacyClonkMaximized_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("Windowed", Convert.ToInt32(LegacyClonkWindowed_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("NewGfxCfg", Convert.ToInt32(LegacyClonkNewGfxCfg_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("Shader", Convert.ToInt32(LegacyClonkShader_chkbox.Checked), RegistryValueKind.DWord)

                    Key.SetValue("ResolutionX", LegacyClonkResolutionX_nud.Value, RegistryValueKind.DWord)
                    Key.SetValue("ResolutionY", LegacyClonkResolutionY_nud.Value, RegistryValueKind.DWord)
                    Key.SetValue("Scale", LegacyClonkScale_trckbar.Value, RegistryValueKind.DWord)
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\LegacyClonk Team\LegacyClonk\Sound", True) ' Sound
                    Key.SetValue("MenuMusic", Convert.ToInt32(LegacyClonkMenuMusic_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("MenuSound", Convert.ToInt32(LegacyClonkMenuSound_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("Music", Convert.ToInt32(LegacyClonkGameMusic_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("Sound", Convert.ToInt32(LegacyClonkGameSound_chkbox.Checked), RegistryValueKind.DWord)

                    Key.SetValue("MusicVolume", LegacyClonkMusic_trckbar.Value, RegistryValueKind.DWord)
                    Key.SetValue("SoundVolume", LegacyClonkSound_trckbar.Value, RegistryValueKind.DWord)
                End Using

            Case "ClonkEndeavourAccept"
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk Endeavour\General", True) ' General
                    Key.SetValue("Language", ClonkEndeavourLanguage_cmdbox.SelectedItem, RegistryValueKind.String)
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk Endeavour\Graphics", True) ' Graphics
                    Key.SetValue("MenuTransparency", Convert.ToInt32(ClonkEndeavourMenuTransparency_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("NewGfxCfg", Convert.ToInt32(ClonkEndeavourNewGfxCfg_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("NewGfxCfgGL", Convert.ToInt32(ClonkEndeavourNewGfxCfgGL_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("PXSGfx", Convert.ToInt32(ClonkEndeavourPXSGfx_chkbox.Checked), RegistryValueKind.DWord)

                    Key.SetValue("ResolutionX", ClonkEndeavourResolutionX_nud.Value, RegistryValueKind.DWord)
                    Key.SetValue("ResolutionY", ClonkEndeavourResolutionY_nud.Value, RegistryValueKind.DWord)
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk Endeavour\Sound", True) ' Sound
                    Key.SetValue("FEMusic", Convert.ToInt32(ClonkEndeavourMenuMusic_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("FESamples", Convert.ToInt32(ClonkEndeavourMenuSound_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("RXMusic", Convert.ToInt32(ClonkEndeavourGameMusic_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("RXSound", Convert.ToInt32(ClonkEndeavourGameSound_chkbox.Checked), RegistryValueKind.DWord)
                End Using

            Case "ClonkPlanetClonk4Accept"
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk 4\General", True) ' General
                    Key.SetValue("Language", ClonkPlanetClonk4Language_cmdbox.SelectedItem, RegistryValueKind.String)
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk 4\Graphics", True) ' Graphics
                    Key.SetValue("MenuTransparency", Convert.ToInt32(ClonkPlanetClonk4MenuTransparency_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("NewGfxCfg", Convert.ToInt32(ClonkPlanetClonk4NewGfxCfg_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("PXSGfx", Convert.ToInt32(ClonkPlanetClonk4PXSGfx_chkbox.Checked), RegistryValueKind.DWord)
                End Using
                Using Key As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\RedWolf Design\Clonk 4\Sound", True) ' Sound
                    Key.SetValue("FEMusic", Convert.ToInt32(ClonkPlanetClonk4MenuMusic_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("FESamples", Convert.ToInt32(ClonkPlanetClonk4MenuSound_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("RXMusic", Convert.ToInt32(ClonkPlanetClonk4GameMusic_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("RXSound", Convert.ToInt32(ClonkPlanetClonk4GameSound_chkbox.Checked), RegistryValueKind.DWord)
                    Key.SetValue("RXSoundLoops", Convert.ToInt32(ClonkPlanetClonk4GameSoundLoops_chkbox.Checked), RegistryValueKind.DWord)
                End Using

        End Select
    End Sub

End Class