﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BaseForm
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BaseForm))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_pnl.SuspendLayout()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(686, 2)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 1
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'BaseForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(745, 430)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "BaseForm"
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "BaseForm"
        Me.controlbox_pnl.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Public WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Public WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Public WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
End Class
