﻿Option Strict On
Imports MadMilkman.Ini
Imports MetroSuite
Imports MetroSuite.Extension
Public Class BaseForm : Inherits MetroSuite.MetroForm

#Region "ControlBox"

    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        Me.Close()
    End Sub
    Private Sub controlbox_nmaximize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_nmaximize_lbl.Click
        If controlbox_nmaximize_lbl.Text = "□" Then
            controlbox_nmaximize_lbl.Text = "■"
            Me.WindowState = FormWindowState.Normal
        Else
            controlbox_nmaximize_lbl.Text = "□"
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub
    Private Sub controlbox_minimize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_minimize_lbl.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter, controlbox_nmaximize_lbl.MouseEnter, controlbox_minimize_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave, controlbox_nmaximize_lbl.MouseLeave, controlbox_minimize_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

    'Private Sub BeendenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BeendenToolStripMenuItem.Click
    '    Application.Exit()
    'End Sub

#End Region

#Region "Functions"

    Public Sub ApplyTheme()
        Try
            Dim myTheme As MetroSuite.Extension.Styles.Themes.IMetroSuiteTheme ' Set Theme

            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))
            If _IniFile.Sections("Settings").Keys("Theme").Value = "Standard" Then
                myTheme = New Styles.Themes.MetroSteamTheme
            ElseIf _IniFile.Sections("Settings").Keys("Theme").Value = "NavyPink" Then
                myTheme = New Styles.Themes.NavyPinkTheme
            ElseIf _IniFile.Sections("Settings").Keys("Theme").Value = "LightGreen" Then
                myTheme = New Styles.Themes.SamsungHealthTheme
            ElseIf _IniFile.Sections("Settings").Keys("Theme").Value = "SoftDark" Then
                myTheme = New Styles.Themes.SoftDarkTheme
            ElseIf _IniFile.Sections("Settings").Keys("Theme").Value = "SoftLight" Then
                myTheme = New Styles.Themes.SoftLightTheme
            ElseIf _IniFile.Sections("Settings").Keys("Theme").Value = "TwitchLight" Then
                myTheme = New Styles.Themes.TwitchTheme
            ElseIf _IniFile.Sections("Settings").Keys("Theme").Value = "YoutubeDark" Then
                myTheme = New Styles.Themes.YoutubeDarkTheme
            ElseIf _IniFile.Sections("Settings").Keys("Theme").Value = "YoutubeLight" Then
                myTheme = New Styles.Themes.YoutubeLightTheme
            Else
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

#End Region

    Private Sub BaseForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ApplyTheme()
    End Sub
End Class