﻿Option Strict On
Imports EasyCrypt.EasyCrypt
Imports MadMilkman.Ini
Imports MetroSuite.Extension
Imports MetroSuite
Imports System.Text
Imports System.Net
Imports System.IO

Public Class Login : Inherits MetroSuite.MetroForm

    Private NewLoadingForm As New CMessage(CMessage.Mode.Loading, CMessage.MessageStyle.Wait, "The database is being rebuilt... This process could take a few seconds.")
    Public WithEvents StringDownloaderWebClient As New WebClient
    Private IsUserShutdown As Boolean

#Region "ControlBox"

    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym

        IsUserShutdown = True
        Me.Close()
    End Sub
    Private Sub controlbox_nmaximize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_nmaximize_lbl.Click
        If controlbox_nmaximize_lbl.Text = "□" Then
            controlbox_nmaximize_lbl.Text = "■"
            Me.WindowState = FormWindowState.Normal
        Else
            controlbox_nmaximize_lbl.Text = "□"
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub
    Private Sub controlbox_minimize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_minimize_lbl.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter, controlbox_nmaximize_lbl.MouseEnter, controlbox_minimize_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave, controlbox_nmaximize_lbl.MouseLeave, controlbox_minimize_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

#End Region

#Region "Functions"

    Public Sub ApplyTheme()
        Try
            Dim myTheme As New Styles.Themes.MetroSuiteTheme
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            If IO.File.Exists(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme")) Then ' If file exists
                myTheme = myTheme.FromFile(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme"))
            Else ' If not
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Private Sub SetupLanguage()
        Try
            Dim AvailableLanguages As New List(Of String)
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            ' Clear LanguageTable
            QClipboard.LanguageTable.Clear()

            Dim TargetDirectory As New DirectoryInfo(MakeLinuxCompatible(".\Data\Language\"))
            Dim fiArr As FileInfo() = TargetDirectory.GetFiles()
            For Each _File As FileInfo In fiArr
                If _File.Extension = ".lang" Then
                    AvailableLanguages.Add(IO.Path.GetFileNameWithoutExtension(_File.Name))
                End If
            Next _File

            If AvailableLanguages.Contains(_IniFile.Sections("Settings").Keys("Language").Value) Then ' custom language

                NewLoadingForm.MetroProgressbar1.Maximum = File.ReadAllLines(MakeLinuxCompatible(".\Data\Language\" & _IniFile.Sections("Settings").Keys("Language").Value & ".lang")).Length ' Set Progressbar Maximum
                NewLoadingForm.Show()

                For Each Line As String In File.ReadLines(MakeLinuxCompatible(".\Data\Language\" & _IniFile.Sections("Settings").Keys("Language").Value & ".lang"))
                    Dim _key As String = Line.Split(CChar("="))(0) ' Split key <- =
                    Dim _value As String = Line.Split(CChar("="))(1) ' Split value = ->
                    QClipboard.LanguageTable.Add(_key, _value) ' Add to languagetable
                    NewLoadingForm.MetroProgressbar1.Value += 1
                Next

            Else ' english language
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, "Your selected language (" & _IniFile.Sections("Settings").Keys("Language").Value & ") was not found in the list. Please make sure that the language file exists. Now using: English language")
                _newMsg.ShowDialog()

                NewLoadingForm.MetroProgressbar1.Maximum = File.ReadAllLines(MakeLinuxCompatible(".\Data\Language\English.lang")).Length ' Set Progressbar Maximum
                NewLoadingForm.Show()

                For Each Line As String In File.ReadLines(MakeLinuxCompatible(".\Data\Language\English.lang"))
                    Dim _key As String = Line.Split(CChar("="))(0) ' Split key <- =
                    Dim _value As String = Line.Split(CChar("="))(1) ' Split value = ->
                    QClipboard.LanguageTable.Add(_key, _value) ' Add to languagetable
                    NewLoadingForm.MetroProgressbar1.Value += 1
                Next
            End If

        Catch ex As Exception
            NewLoadingForm.Dispose()
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.ToString)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Private Sub ApplyLanguage()
        Try
            For Each _cntrl As Control In ListControls(Me)
                If _cntrl.GetType().Name = "MetroTranslatorLabel" Then
                    DirectCast(_cntrl, MetroTranslatorLabel).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorButton" Then
                    DirectCast(_cntrl, MetroTranslatorButton).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorChecker" Then
                    DirectCast(_cntrl, MetroTranslatorChecker).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorTextbox" Then
                    DirectCast(_cntrl, MetroTranslatorTextbox).ApplyLanguage()
                End If
            Next
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub
    Private Function ListControls(ByVal control As Control) As IEnumerable(Of Control)
        Dim ctrl As IEnumerable(Of Control) = control.Controls.Cast(Of Control)()
        Return ctrl.Concat(ctrl.SelectMany(AddressOf ListControls))
    End Function

    Private Sub ResetTabPages()
        LoggingIn_picbox.Image = My.Resources.Loading_1
        Registering_picbox.Image = My.Resources.Loading_1
        LoggingInStatus_lbl.Text = GetSpecificLanguageString("LOGIN:LOGINRESULT_LOGGINGIN")
        RegisteringStatus_lbl.Text = GetSpecificLanguageString("LOGIN:REGISTERRESULT_REGISTER")
        BackToLogin_btn.Visible = False
        BackToLogin2_btn.Visible = False
        Register_username_txtbox.Text = ""
        Register_password_txtbox.Text = ""
        username_txtbox.Text = ""
        password_txtbox.Text = ""
    End Sub

#Region " Functions "

    Public Function GetSpecificLanguageString(ByVal Key As String) As String
        Try
            For Each Entry As DictionaryEntry In QClipboard.LanguageTable
                If String.Equals(CStr(Entry.Key), Key) = True Then
                    Return Entry.Value.ToString
                    Exit Function
                End If
            Next
            Return "Not found"
        Catch ex As Exception
            Return "ERROR"
        End Try
    End Function

    Function ContainsSpecialChars(input As String) As Boolean
        Return input.IndexOfAny("[~`!@#$%^&*()-+=|{}':;.,<>/?] ".ToCharArray) <> -1
    End Function

    Public Function GetRandomID() As String
        Try
            Dim s As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
            Dim r As New Random
            Dim sb As New StringBuilder

            For i As Integer = 1 To 8
                Dim idx As Integer = r.Next(0, 35)
                sb.Append(s.Substring(idx, 1))
            Next

            Return sb.ToString
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

#End Region

#End Region

#Region " Network "

    Private Sub UTC_UTicketArrived(sSenderID As String, bSentToAll As Boolean, sCommand As String, oUserData As List(Of Object))
        Select Case sCommand

            Case "ToUser:ACCOUNT:LoginResult"
                Select Case oUserData(0).ToString
                    Case "BANNED"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() LoggingInStatus_lbl.Text = GetSpecificLanguageString("LOGIN:LOGINRESULT_BANNED")))
                            Me.Invoke(New MethodInvoker(Sub() LoggingIn_picbox.Image = My.Resources.clonk_error))
                            Me.Invoke(New MethodInvoker(Sub() BackToLogin2_btn.Visible = True))
                        Else
                            LoggingInStatus_lbl.Text = GetSpecificLanguageString("LOGIN:LOGINRESULT_BANNED")
                            LoggingIn_picbox.Image = My.Resources.clonk_error
                            BackToLogin2_btn.Visible = True
                        End If

                    Case "FAIL"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() LoggingInStatus_lbl.Text = GetSpecificLanguageString("LOGIN:LOGINRESULT_FAILEDCHECKDATA")))
                            Me.Invoke(New MethodInvoker(Sub() LoggingIn_picbox.Image = My.Resources.clonk_error))
                            Me.Invoke(New MethodInvoker(Sub() BackToLogin2_btn.Visible = True))
                        Else
                            LoggingInStatus_lbl.Text = GetSpecificLanguageString("LOGIN:LOGINRESULT_FAILEDCHECKDATA")
                            LoggingIn_picbox.Image = My.Resources.clonk_error
                            BackToLogin2_btn.Visible = True
                        End If

                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, oUserData(1).ToString)
                        _newMsg.ShowDialog()

                    Case "ERROR"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() LoggingInStatus_lbl.Text = GetSpecificLanguageString("LOGIN:LOGINRESULT_FAILED")))
                            Me.Invoke(New MethodInvoker(Sub() LoggingIn_picbox.Image = My.Resources.clonk_error))
                            Me.Invoke(New MethodInvoker(Sub() BackToLogin2_btn.Visible = True))
                        Else
                            LoggingInStatus_lbl.Text = GetSpecificLanguageString("LOGIN:LOGINRESULT_FAILED")
                            LoggingIn_picbox.Image = My.Resources.clonk_error
                            BackToLogin2_btn.Visible = True
                        End If

                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, GetSpecificLanguageString("LOGIN:LOGINRESULT_FAILED") & Environment.NewLine & "Details: " & oUserData(1).ToString)
                        _newMsg.ShowDialog()

                    Case "SUCCESS"
                        QClipboard.LoggedOnMode = QClipboard.LoginMode.User
                        QClipboard.AccountName = username_txtbox.Text

                        If Me.InvokeRequired = True Then
                            Me.Invoke(New MethodInvoker(Sub() Main.Show()))
                            Me.Invoke(New MethodInvoker(Sub() Me.Close()))
                        Else
                            Main.Show()
                            Me.Close()
                        End If

                End Select

            Case "ToUser:ACCOUNT:RegisterResult"
                Select Case oUserData(0).ToString
                    Case "ERROR"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() RegisteringStatus_lbl.Text = GetSpecificLanguageString("LOGIN:REGISTERRESULT_FAILED")))
                            Me.Invoke(New MethodInvoker(Sub() Registering_picbox.Image = My.Resources.clonk_error))
                            Me.Invoke(New MethodInvoker(Sub() BackToLogin_btn.Visible = True))
                        Else
                            RegisteringStatus_lbl.Text = GetSpecificLanguageString("LOGIN:REGISTERRESULT_FAILED")
                            Registering_picbox.Image = My.Resources.clonk_error
                            BackToLogin_btn.Visible = True
                        End If

                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, oUserData(1).ToString)
                        _newMsg.ShowDialog()
                    Case "SUCCESS"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() username_txtbox.Text = Register_username_txtbox.Text))
                            Me.Invoke(New MethodInvoker(Sub() RegisteringStatus_lbl.Text = GetSpecificLanguageString("LOGIN:REGISTERRESULT_SUCCESS")))
                            Me.Invoke(New MethodInvoker(Sub() Registering_picbox.Image = My.Resources.clonk_okay))
                            Me.Invoke(New MethodInvoker(Sub() BackToLogin_btn.Visible = True))
                        Else
                            username_txtbox.Text = Register_username_txtbox.Text
                            RegisteringStatus_lbl.Text = GetSpecificLanguageString("LOGIN:REGISTERRESULT_SUCCESS")
                            Registering_picbox.Image = My.Resources.clonk_okay
                            BackToLogin_btn.Visible = True
                        End If

                End Select

        End Select
    End Sub

#End Region

    Private Sub Login_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Try
            ' Settings
            My.Settings.Save()

            ' Client side
            If IsUserShutdown Then
                Networking.Shutdown()
            End If
        Catch ex As Exception : End Try
    End Sub
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Initialize Network
        Try
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            Select Case _IniFile.Sections("Settings").Keys("ConnectionMode").Value
                Case "Debug" ' Debug
                    Networking.Initialize(True)
                Case "Server" ' Server
                    Networking.Initialize(False, "- YOUR SERVER IP HERE -")
                Case Else ' Server
                    Networking.Initialize(False, "- YOUR SERVER IP HERE -")
            End Select
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, "Could not receive network informations. Please try again later. Continue in offline mode." & Environment.NewLine & "Details: " & ex.Message)
            _newMsg.ShowDialog()
        End Try

        ' AddHandler
        If Not Networking.IsObjectNothing Then
            AddHandler Networking.UTC.UTicketArrived, AddressOf UTC_UTicketArrived
        End If

        ' Give Client a ID
        If My.Settings.Firststart = False Then
            My.Settings.USERID = GetRandomID()
            My.Settings.Firststart = True
            My.Settings.Save()
        End If

        ' Check OS
        If My.Computer.Info.OSFullName.Contains("Microsoft Windows") Then
            QClipboard.LinuxMode = False
        Else
            QClipboard.LinuxMode = True
        End If

        ' Check if Server is available
        If Networking.IsServerAvailable Then
            Networking.UTC.start(My.Settings.USERID)
        Else
            ServerStatus_lbl.Visible = True
        End If

        ' Setup TabControl
        With MetroTabControl1
            .SuspendLayout()
            .SizeMode = TabSizeMode.Fixed
            .ItemSize = New Size(1, 1)
            .Appearance = CType(TabAppearance.Buttons, Appearance)
            .ResumeLayout()
        End With

        ApplyTheme() ' Set Theme
        SetupLanguage() ' Setting up language
        ApplyLanguage() ' Applys the langage
    End Sub

    Private Sub BackToLogin_btn_Click(sender As Object, e As EventArgs) Handles BackToLogin_btn.Click, BackToLogin2_btn.Click
        MetroTabControl1.SelectedTab = Login_TabPage ' Login TabPage
        username_txtbox.Focus()
        ResetTabPages()
    End Sub

#Region " Login TabPage "

    Private Sub Login_ShowPassword_chkbox_CheckedChanged(sender As Object, isChecked As Boolean) Handles Login_ShowPassword_chkbox.CheckedChanged
        If isChecked = True Then
            password_txtbox.PasswordChar = CChar("")
        Else
            password_txtbox.PasswordChar = CChar("*")
        End If
    End Sub
    Private Sub Login_btn_Click(sender As Object, e As EventArgs) Handles Login_btn.Click
        If Networking.IsConnectionAlive Then
            If String.IsNullOrWhiteSpace(username_txtbox.Text) Then
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:LOGIN_INPUTUSERNAME"))
                _newMsg.ShowDialog()
            Else
                If String.IsNullOrWhiteSpace(password_txtbox.Text) Then
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:LOGIN_INPUTPASSWORD"))
                    _newMsg.ShowDialog()
                Else

                    MetroTabControl1.SelectedTab = LoggingIn_TabPage ' Logging In TabPage

                    Dim ListOfData As New List(Of Object)
                    ListOfData.Add(username_txtbox.Text)
                    ListOfData.Add(password_txtbox.Text)
                    ListOfData.Add(My.Settings.USERID)
                    Networking.UTC.sendUTicket("ADMIN", "ToServer:ACCOUNT:Login", ListOfData)
                End If
            End If
        Else
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:LOGIN_NOTAVAILABLE"))
            _newMsg.ShowDialog()
        End If
    End Sub

    Private Sub CreateNewAccount_btn_Click(sender As Object, e As EventArgs) Handles CreateNewAccount_btn.Click
        If Networking.IsConnectionAlive Then
            MetroTabControl1.SelectedTab = Register_TabPage
        Else
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:REGISTER_NOTAVAILABLE"))
            _newMsg.ShowDialog()
        End If
    End Sub

    Private Sub WithoutLogin_btn_Click(sender As Object, e As EventArgs) Handles WithoutLogin_btn.Click
        QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym

        Main.Show()
        Me.Close()
    End Sub

#End Region

#Region " Register - TabPage"

    Private Sub Register_ShowPassword_chkbox_CheckedChanged(sender As Object, isChecked As Boolean) Handles Register_ShowPassword_chkbox.CheckedChanged
        If isChecked = True Then
            Register_password_txtbox.PasswordChar = CChar("")
        Else
            Register_password_txtbox.PasswordChar = CChar("*")
        End If
    End Sub
    Private Sub Register_btn_Click(sender As Object, e As EventArgs) Handles Register_btn.Click
        If Networking.IsConnectionAlive Then

            ' Register
            If String.IsNullOrWhiteSpace(Register_username_txtbox.Text) Then
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:REGISTER_INPUTUSERNAME"))
                _newMsg.ShowDialog()
            Else
                If ContainsSpecialChars(Register_username_txtbox.Text) Then
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:REGISTER_SYMBOLSNOTALLOWED"))
                    _newMsg.ShowDialog()
                Else
                    If Register_username_txtbox.Text.ToLower.Contains("admin") Then
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:REGISTER_NAMERESERVED"))
                        _newMsg.ShowDialog()
                    Else
                        If String.IsNullOrWhiteSpace(Register_password_txtbox.Text) Then
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:REGISTER_INPUTPASSWORD"))
                            _newMsg.ShowDialog()
                        Else

                            MetroTabControl1.SelectedTab = Registering_TabPage ' Registering TabPage

                            Dim ListOfData As New List(Of Object)
                            ListOfData.Add(Register_username_txtbox.Text)
                            ListOfData.Add(Register_password_txtbox.Text)
                            ListOfData.Add(My.Settings.USERID)
                            Networking.UTC.sendUTicket("ADMIN", "ToServer:ACCOUNT:Register", ListOfData)

                        End If
                    End If
                End If
            End If

        Else
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:REGISTER_NOTAVAILABLE"))
            _newMsg.ShowDialog()
        End If
    End Sub

    Private Sub AbortRegistration_btn_Click(sender As Object, e As EventArgs) Handles AbortRegistration_btn.Click
        MetroTabControl1.SelectedTab = Login_TabPage ' Login TabPage

        ' Set Nothing
        Register_username_txtbox.Text = ""
        Register_password_txtbox.Text = ""
    End Sub

#End Region

End Class