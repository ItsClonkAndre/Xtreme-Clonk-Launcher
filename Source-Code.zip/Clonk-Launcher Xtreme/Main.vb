﻿Option Strict On
Imports Gecko
Imports MadMilkman.Ini
Imports MetroSuite.Extension
Imports System.IO.Compression
Imports UniversalTicket
Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Text.RegularExpressions
Imports GChartLib
Imports System.Net.NetworkInformation
Imports System.Threading.Tasks

Public Class Main : Inherits MetroSuite.MetroForm

#Region "Declarations"

    ' Events
    'Public WithEvents DownloadCancelButton As New MetroSuite.MetroButton
    Public WithEvents StringDownloaderWebClient As New WebClient With {.Encoding = Encoding.UTF8}
    Public WithEvents DownloadNewsAsyncWebClient As New WebClient With {.Encoding = Encoding.UTF8}
    Public WithEvents DownloadChangelogAsyncWebClient As New WebClient With {.Encoding = Encoding.UTF8}
    Public WithEvents Downloader As WebClient

    ' Settings
    Public ShowChatMsg As Boolean
    Public ShowNewUpdateMsg As Boolean
    Public ShowChatClonkMessage As Boolean
    Public CCANcopyInGameDir As Boolean
    Public CCANcopyInAnyDir As Boolean
    Public AllowSendingRushHourData As Boolean
    Public AllowSendingPlayTimeData As Boolean
    Public ExitMode As String

    ' Download
    Private Download_GameName As String
    Private Download_DownloadGameTo As String
    Private Download_ExtractGameTo As String
    Public IsCurrentlyDownloading As Boolean
    Private CurrentlyDownloading As String

    ' Stopwatches
    Private ocPlaytimeWatch As New Stopwatch
    Private crPlaytimeWatch As New Stopwatch
    Private cePlaytimeWatch As New Stopwatch
    Private cpPlaytimeWatch As New Stopwatch
    Private c4PlaytimeWatch As New Stopwatch

    ' Other
    Private LanguageLoadingForm As CMessage
    Private GeckoFXBrowser As GeckoWebBrowser
    Private GeckoFXBrowserList As New List(Of GeckoWebBrowser)
    Private ClickAnimator As MetroSuite.Components.MetroAnimator
    Private NewUpdateAvaible As Boolean
    Private IsClonkActive As Boolean
    Public XCLVersion As String = "1.2.2"

#End Region



#Region "ControlBox & CTMS"

    ' ControlBox
    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        Select Case ExitMode
            Case "Exit"
                Using _HardwareSurveyMSG As New CMessage(CMessage.Mode.YesNo, CMessage.MessageStyle.Nachricht, GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_CONFIRMEXIT"))
                    Dim dr As DialogResult = _HardwareSurveyMSG.ShowDialog

                    If dr = System.Windows.Forms.DialogResult.Yes Then
                        Application.Exit()
                    End If
                End Using
            Case "Minimize"
                Me.Hide()
        End Select
    End Sub
    Private Sub controlbox_nmaximize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_nmaximize_lbl.Click
        If controlbox_nmaximize_lbl.Text = "□" Then
            controlbox_nmaximize_lbl.Text = "■"
            Me.WindowState = FormWindowState.Normal
        Else
            controlbox_nmaximize_lbl.Text = "□"
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub
    Private Sub controlbox_minimize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_minimize_lbl.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter, controlbox_nmaximize_lbl.MouseEnter, controlbox_minimize_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave, controlbox_nmaximize_lbl.MouseLeave, controlbox_minimize_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

    ' MainContextMenuStrip
    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click ' open
        Me.Show()
    End Sub
    Private Sub AufUpdatesPrüfenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AufUpdatesPrüfenToolStripMenuItem.Click ' check for updates
        CheckForUpdates()
    End Sub
    Private Sub BeendenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BeendenToolStripMenuItem.Click ' exit
        Using _HardwareSurveyMSG As New CMessage(CMessage.Mode.YesNo, CMessage.MessageStyle.Nachricht, GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_CONFIRMEXIT"))
            Dim dr As DialogResult = _HardwareSurveyMSG.ShowDialog

            If dr = System.Windows.Forms.DialogResult.Yes Then
                Application.Exit()
            End If
        End Using
    End Sub

    ' SettingsContextMenuStrip
    Private Sub SpieleinstellungenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SpieleinstellungenToolStripMenuItem.Click, SpieleinstellungenToolStripMenuItem1.Click, SpieleinstellungenToolStripMenuItem2.Click, SpieleinstellungenToolStripMenuItem3.Click, SpieleinstellungenToolStripMenuItem4.Click, SpieleinstellungenToolStripMenuItem5.Click
        Dim _name As String = DirectCast(sender, ToolStripMenuItem).Tag.ToString
        Select Case _name
            Case "OpenClonk"
                Dim GameSettings As New GameSettingsFrm("OpenClonk")
                GameSettings.ShowDialog()
            Case "OpenClonk_x86"
                Dim GameSettings As New GameSettingsFrm("OpenClonk")
                GameSettings.ShowDialog()
            Case "ClonkRage"
                Dim GameSettings As New GameSettingsFrm("LegacyClonk")
                GameSettings.ShowDialog()
            Case "ClonkEndeavour"
                Dim GameSettings As New GameSettingsFrm("ClonkEndeavour")
                GameSettings.ShowDialog()
            Case "ClonkPlanet"
                Dim GameSettings As New GameSettingsFrm("ClonkPlanet")
                GameSettings.ShowDialog()
            Case "Clonk4"
                Dim GameSettings As New GameSettingsFrm("Clonk4")
                GameSettings.ShowDialog()
        End Select
    End Sub
    Private Sub ImExplorerAnzeigenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImExplorerAnzeigenToolStripMenuItem.Click, ImExplorerAnzeigenToolStripMenuItem1.Click, ImExplorerAnzeigenToolStripMenuItem2.Click, ImExplorerAnzeigenToolStripMenuItem3.Click, ImExplorerAnzeigenToolStripMenuItem4.Click, ImExplorerAnzeigenToolStripMenuItem5.Click ' Show In Explorer
        Dim _name As String = DirectCast(sender, ToolStripMenuItem).Tag.ToString
        Select Case _name
            Case "OpenClonk"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk")) Then
                    Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk"))
                End If
            Case "OpenClonk_x86"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86")) Then
                    Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86"))
                End If
            Case "ClonkRage"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk")) Then
                    Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk"))
                End If
            Case "ClonkEndeavour"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour")) Then
                    Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour"))
                End If
            Case "ClonkPlanet"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet")) Then
                    Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet"))
                End If
            Case "Clonk4"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4")) Then
                    Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4"))
                End If
        End Select
    End Sub
    Private Sub SpielDeinstallierenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SpielDeinstallierenToolStripMenuItem.Click, SpielDeinstallierenToolStripMenuItem1.Click, SpielDeinstallierenToolStripMenuItem2.Click, SpielDeinstallierenToolStripMenuItem3.Click, SpielDeinstallierenToolStripMenuItem4.Click, SpielDeinstallierenToolStripMenuItem5.Click ' Uninstall Game
        Dim _name As String = DirectCast(sender, ToolStripMenuItem).Tag.ToString
        Select Case _name
            Case "OpenClonk"
                Dim uninstaller As New Uninstall_frm("OpenClonk")
                uninstaller.ShowDialog()
            Case "OpenClonk_x86"
                Dim uninstaller As New Uninstall_frm("OpenClonk_x86")
                uninstaller.ShowDialog()
            Case "ClonkRage"
                Dim uninstaller As New Uninstall_frm("LegacyClonk")
                uninstaller.ShowDialog()
            Case "ClonkEndeavour"
                Dim uninstaller As New Uninstall_frm("ClonkEndeavour")
                uninstaller.ShowDialog()
            Case "ClonkPlanet"
                Dim uninstaller As New Uninstall_frm("ClonkPlanet")
                uninstaller.ShowDialog()
            Case "Clonk4"
                Dim uninstaller As New Uninstall_frm("Clonk4")
                uninstaller.ShowDialog()
        End Select
    End Sub
    Private Sub AufUpdatesPrüfenToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AufUpdatesPrüfenToolStripMenuItem1.Click
        Dim _name As String = DirectCast(sender, ToolStripMenuItem).Tag.ToString
        Select Case _name
            Case "OpenClonk"
                ' Nothing
            Case "OpenClonk_x86"
                ' Nothing
            Case "ClonkRage"
                Try
                    Dim _FileVersion As String = GetFileVersionInfo(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk\Clonk.exe"))
                    Dim _ListNewVersion As List(Of String) = GetNewLegacyClonkVersion()
                    Dim _NewVersion As String = _ListNewVersion(0) & " [" & _ListNewVersion(1) & "]"

                    ' Compare
                    If _FileVersion.Contains(_NewVersion) Then
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MAIN:UPDATE_NONEWUPDATE"))
                        _newMsg.ShowDialog()
                    Else
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, Coding(GetSpecificLanguageString("MAIN:LIBRARY_LC_NEWLEGACYCLONKVERSION"), _NewVersion))
                        _newMsg.ShowDialog()
                    End If
                Catch ex As Exception
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, GetSpecificLanguageString("MAIN:UPDATE_CHECKERROR") & Environment.NewLine & "Details: " & ex.ToString)
                    _newMsg.ShowDialog()
                End Try
        End Select
    End Sub

#End Region

#Region "Websites"

    ' Websites
    Private Sub ClonkWebsite_btn_Click(sender As Object, e As EventArgs) Handles ClonkWebsite_btn.Click
        Process.Start("http://www.clonk.de/")
    End Sub
    Private Sub CCANWebsite_btn_Click(sender As Object, e As EventArgs) Handles CCANWebsite_btn.Click
        Process.Start("https://ccan.de/")
    End Sub
    Private Sub ClonkSpotWebsite_btn_Click(sender As Object, e As EventArgs) Handles ClonkSpotWebsite_btn.Click
        Process.Start("https://clonkspot.org/")
    End Sub
    Private Sub DiscordInviteLink_btn_Click(sender As Object, e As EventArgs) Handles DiscordInviteLink_btn.Click
        Process.Start("https://discord.gg/BHMHUbS")
    End Sub

    ' YouTube
    Private Sub YouTube_matthesb_btn_Click(sender As Object, e As EventArgs) Handles YouTube_matthesb_btn.Click
        Process.Start("https://www.youtube.com/user/matthesb")
    End Sub
    Private Sub YouTube_Clonkspot_btn_Click(sender As Object, e As EventArgs) Handles YouTube_Clonkspot_btn.Click
        Process.Start("https://www.youtube.com/channel/UCBzxBl3dCEYcaB0sRI1bc3w")
    End Sub
    Private Sub YouTube_ClonkNews_btn_Click(sender As Object, e As EventArgs) Handles YouTube_ClonkNews_btn.Click
        Process.Start("https://www.youtube.com/channel/UCxbihH-BtdI607Y7ThJfczg")
    End Sub

#End Region

#Region "Functions"

    Public Sub ApplyTheme()
        Try
            Dim myTheme As New Styles.Themes.MetroSuiteTheme
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            If System.IO.File.Exists(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme")) Then ' If file exists
                myTheme = myTheme.FromFile(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme"))
            Else ' If not
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
            myTheme.ApplyTheme(Panel1)
            myTheme.ApplyTheme(Panel17)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Public Sub SetupCharts()
        ' Notification Lines
        Dim GChartnl1 As New GChartLib.NotificationLine
        GChartnl1.Name = GetSpecificLanguageString("MAIN:OTHER_ChartNLineNotOftenVisited")
        GChartnl1.LineColor = Color.FromArgb(183, 57, 60)
        GChartnl1.DrawValue = True
        GChartnl1.DrawColorBox = True
        GChartnl1.DrawGradient = True
        GChartnl1.BoxColor = Color.Black
        GChartnl1.ValueForeColor = GChartnl1.LineColor
        GChartnl1.Value = 5

        Clonk4RushHour_GBarChart.NotificationLines.Add(GChartnl1)
        ClonkPlanetRushHour_GBarChart.NotificationLines.Add(GChartnl1)
        ClonkEndeavourRushHour_GBarChart.NotificationLines.Add(GChartnl1)
        ClonkRageRushHour_GBarChart.NotificationLines.Add(GChartnl1)
        OpenClonkRushHour_GBarChart.NotificationLines.Add(GChartnl1)

        Dim GChartnl2 As New GChartLib.NotificationLine
        GChartnl2.Name = GetSpecificLanguageString("MAIN:OTHER_ChartNLineModeratelyVisited")
        GChartnl2.LineColor = Color.FromArgb(183, 57, 60)
        GChartnl2.DrawValue = True
        GChartnl2.DrawColorBox = True
        GChartnl2.DrawGradient = True
        GChartnl2.BoxColor = Color.Black
        GChartnl2.ValueForeColor = GChartnl2.LineColor
        GChartnl2.Value = 20

        Clonk4RushHour_GBarChart.NotificationLines.Add(GChartnl2)
        ClonkPlanetRushHour_GBarChart.NotificationLines.Add(GChartnl2)
        ClonkEndeavourRushHour_GBarChart.NotificationLines.Add(GChartnl2)
        ClonkRageRushHour_GBarChart.NotificationLines.Add(GChartnl2)
        OpenClonkRushHour_GBarChart.NotificationLines.Add(GChartnl2)

        Dim GChartnl3 As New GChartLib.NotificationLine
        GChartnl3.Name = GetSpecificLanguageString("MAIN:OTHER_ChartNLineOftenVisited")
        GChartnl3.LineColor = Color.FromArgb(183, 57, 60)
        GChartnl3.DrawValue = True
        GChartnl3.DrawColorBox = True
        GChartnl3.DrawGradient = True
        GChartnl3.BoxColor = Color.Black
        GChartnl3.ValueForeColor = GChartnl3.LineColor
        GChartnl3.Value = 35

        Clonk4RushHour_GBarChart.NotificationLines.Add(GChartnl3)
        ClonkPlanetRushHour_GBarChart.NotificationLines.Add(GChartnl3)
        ClonkEndeavourRushHour_GBarChart.NotificationLines.Add(GChartnl3)
        ClonkRageRushHour_GBarChart.NotificationLines.Add(GChartnl3)
        OpenClonkRushHour_GBarChart.NotificationLines.Add(GChartnl3)
    End Sub

    Public Sub ReloadSettings()
        Try
            ' Notifications
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            ShowChatMsg = CBool(_IniFile.Sections("Notifications").Keys("NewChatMessage").Value)
            ShowNewUpdateMsg = CBool(_IniFile.Sections("Notifications").Keys("NewUpdates").Value)
            ShowChatClonkMessage = CBool(_IniFile.Sections("Notifications").Keys("ShowClonkMessage").Value)

            ' Data protecton
            AllowSendingRushHourData = CBool(_IniFile.Sections("DataProtection").Keys("AllowSendingRushHourData").Value)
            AllowSendingPlayTimeData = CBool(_IniFile.Sections("DataProtection").Keys("AllowSendingPlayTimeData").Value)

            ' Downloads
            If _IniFile.Sections("Settings").Keys("DownloadMode").Value = "1" Then
                CCANcopyInGameDir = True
                CCANcopyInAnyDir = False
            ElseIf _IniFile.Sections("Settings").Keys("DownloadMode").Value = "2" Then
                CCANcopyInAnyDir = True
                CCANcopyInGameDir = False
            Else
                CCANcopyInGameDir = True
                CCANcopyInAnyDir = False
            End If

            ' Other
            ExitMode = _IniFile.Sections("Settings").Keys("ExitMode").Value

        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Public Sub RebuildLanguageDatabase()
        Try
            Dim AvailableLanguages As New List(Of String)
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            ' Create new Message
            LanguageLoadingForm = New CMessage(CMessage.Mode.Loading, CMessage.MessageStyle.Wait, "The database is being rebuilt... This process could take a few seconds.")

            ' Clear LanguageTable
            QClipboard.LanguageTable.Clear()

            Dim TargetDirectory As New DirectoryInfo(MakeLinuxCompatible(".\Data\Language\"))
            Dim fiArr As FileInfo() = TargetDirectory.GetFiles()
            For Each _File As FileInfo In fiArr
                If _File.Extension = ".lang" Then
                    AvailableLanguages.Add(System.IO.Path.GetFileNameWithoutExtension(_File.Name))
                End If
            Next _File

            If AvailableLanguages.Contains(_IniFile.Sections("Settings").Keys("Language").Value) Then ' custom language

                LanguageLoadingForm.MetroProgressbar1.Maximum = File.ReadAllLines(MakeLinuxCompatible(".\Data\Language\" & _IniFile.Sections("Settings").Keys("Language").Value & ".lang")).Length ' Set Progressbar Maximum
                LanguageLoadingForm.Show()

                For Each Line As String In File.ReadLines(MakeLinuxCompatible(".\Data\Language\" & _IniFile.Sections("Settings").Keys("Language").Value & ".lang"))
                    Dim _key As String = Line.Split(CChar("="))(0) ' Split key <- =
                    Dim _value As String = Line.Split(CChar("="))(1) ' Split value = ->
                    QClipboard.LanguageTable.Add(_key, _value) ' Add to languagetable
                    LanguageLoadingForm.MetroProgressbar1.Value += 1
                Next

            Else ' english language
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, "Your selected language (" & _IniFile.Sections("Settings").Keys("Language").Value & ") was not found in the list. Please make sure that the language file exists. Now using: English language")
                _newMsg.ShowDialog()

                LanguageLoadingForm.MetroProgressbar1.Maximum = File.ReadAllLines(MakeLinuxCompatible(".\Data\Language\English.lang")).Length ' Set Progressbar Maximum
                LanguageLoadingForm.Show()

                For Each Line As String In File.ReadLines(MakeLinuxCompatible(".\Data\Language\English.lang"))
                    Dim _key As String = Line.Split(CChar("="))(0) ' Split key <- =
                    Dim _value As String = Line.Split(CChar("="))(1) ' Split value = ->
                    QClipboard.LanguageTable.Add(_key, _value) ' Add to languagetable
                    LanguageLoadingForm.MetroProgressbar1.Value += 1
                Next
            End If

            ApplyLanguage() ' ApplyLanguage
        Catch ex As Exception
            LanguageLoadingForm.Dispose()
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "FATAL ERROR WHILE REBUILDING LANGUAGE DATABASE" & Environment.NewLine & ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Private Sub ApplyLanguage()
        Try
            For Each _cntrl As Control In ListControls(Me) ' Translate Controls
                If _cntrl.GetType().Name = "MetroTranslatorLabel" Then
                    DirectCast(_cntrl, MetroTranslatorLabel).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorButton" Then
                    DirectCast(_cntrl, MetroTranslatorButton).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorChecker" Then
                    DirectCast(_cntrl, MetroTranslatorChecker).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "MetroTranslatorTextbox" Then
                    DirectCast(_cntrl, MetroTranslatorTextbox).ApplyLanguage()
                ElseIf _cntrl.GetType().Name = "ClassicTranslatorRadioButton" Then
                    DirectCast(_cntrl, ClassicTranslatorRadioButton).ApplyLanguage()
                End If
            Next

            ' CheckLoggedInMode
            If QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym Then
                username_hst.InputText = Coding(GetSpecificLanguageString("MAIN:OTHER_LOGGEDINASTEXT"), "Anonym")
            Else
                username_hst.InputText = Coding(GetSpecificLanguageString("MAIN:OTHER_LOGGEDINASTEXT"), QClipboard.AccountName)
            End If

            ' Set TabPages Title
            StartTabPage_tp.Text = GetSpecificLanguageString("MAIN:START_TITLE")
            LibraryTabPage_tp.Text = GetSpecificLanguageString("MAIN:LIBRARY_TITLE")
            NewsTabPage_tp.Text = GetSpecificLanguageString("MAIN:NEWS_TITLE")
            EventsTabPage_tp.Text = GetSpecificLanguageString("MAIN:EVENTS_TITLE")
            CCANTabPage_tp.Text = GetSpecificLanguageString("MAIN:CCAN_TITLE")
            TabPage7.Text = GetSpecificLanguageString("MAIN:LIBRARY_OWNGAMETITLE")

            ' From File
            'Get/Set Translated Description from file
            OCDesc_asl.InputText = Coding(GetSpecificLanguageString("MAIN:LIBRARY_OC_DESC"))
            LCDesc_asl.InputText = Coding(GetSpecificLanguageString("MAIN:LIBRARY_LC_DESC"))
            CEDesc_asl.InputText = Coding(GetSpecificLanguageString("MAIN:LIBRARY_CE_DESC"))
            CPDesc_asl.InputText = Coding(GetSpecificLanguageString("MAIN:LIBRARY_CP_DESC"))
            C4Desc_asl.InputText = Coding(GetSpecificLanguageString("MAIN:LIBRARY_C4_DESC"))
            OwnClonkGameInfo_rtb.Text = Coding(GetSpecificLanguageString("MAIN:LIBRARY_OWNGAMEDESC"))
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub
    Private Function ListControls(ByVal control As Control) As IEnumerable(Of Control)
        Dim ctrl As IEnumerable(Of Control) = control.Controls.Cast(Of Control)()
        Return ctrl.Concat(ctrl.SelectMany(AddressOf ListControls))
    End Function

    Public Sub ReloadQuickLaunch()
        Try
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\LastOpened.ini"))

            If Not String.IsNullOrWhiteSpace(_IniFile.Sections("GAME").Keys("1").Value) Then
                Select Case _IniFile.Sections("GAME").Keys("1").Value
                    Case "OpenClonk"
                        CreateQuickLaunchButton("OpenClonk", My.Resources.OpenClonkSymbol)
                    Case "OpenClonk_x86"
                        CreateQuickLaunchButton("OpenClonk_x86", My.Resources.OpenClonkSymbol)
                    Case "LegacyClonk"
                        CreateQuickLaunchButton("LegacyClonk", My.Resources.LegacyClonkSymbol)
                    Case "Clonk Endeavour"
                        CreateQuickLaunchButton("Clonk Endeavour", My.Resources.ClonkEndeavourSymbol)
                    Case "Clonk Planet"
                        CreateQuickLaunchButton("Clonk Planet", My.Resources.ClonkPlanetSymbol)
                    Case "Clonk 4"
                        CreateQuickLaunchButton("Clonk 4", My.Resources.Clonk4Symbol)
                    Case Else
                        CreateQuickLaunchButton(_IniFile.Sections("GAME").Keys("1").Value, My.Resources.clonk_help1)
                End Select
            End If
            If Not String.IsNullOrWhiteSpace(_IniFile.Sections("GAME").Keys("2").Value) Then
                Select Case _IniFile.Sections("GAME").Keys("2").Value
                    Case "OpenClonk"
                        CreateQuickLaunchButton("OpenClonk", My.Resources.OpenClonkSymbol)
                    Case "OpenClonk_x86"
                        CreateQuickLaunchButton("OpenClonk_x86", My.Resources.OpenClonkSymbol)
                    Case "LegacyClonk"
                        CreateQuickLaunchButton("LegacyClonk", My.Resources.LegacyClonkSymbol)
                    Case "Clonk Endeavour"
                        CreateQuickLaunchButton("Clonk Endeavour", My.Resources.ClonkEndeavourSymbol)
                    Case "Clonk Planet"
                        CreateQuickLaunchButton("Clonk Planet", My.Resources.ClonkPlanetSymbol)
                    Case "Clonk 4"
                        CreateQuickLaunchButton("Clonk 4", My.Resources.Clonk4Symbol)
                    Case Else
                        CreateQuickLaunchButton(_IniFile.Sections("GAME").Keys("2").Value, My.Resources.clonk_help1)
                End Select
            End If

        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Public Sub CheckIfGamesExists()
        Try
            If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86")) Then
                OpenClonk_x86_btn.Text = GetSpecificLanguageString("MAIN:LIBRARY_OC_STARTX86")
            Else
                OpenClonk_x86_btn.Text = "Download OpenClonk x86"
            End If
            If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk")) Then
                cmd_OpenClonk_btn.Text = GetSpecificLanguageString("MAIN:LIBRARY_OC_STARTX64")
            Else
                cmd_OpenClonk_btn.Text = "Download OpenClonk x64"
            End If
            If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk")) Then
                cmd_ClonkRage_btn.Text = Coding(GetSpecificLanguageString("MAIN:LIBRARY_GENERALLYSTARTTEXT"), "LegacyClonk")
            Else
                cmd_ClonkRage_btn.Text = "Download LegacyClonk x86"
            End If
            If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour")) Then
                cmd_ClonkEndeavour_btn.Text = Coding(GetSpecificLanguageString("MAIN:LIBRARY_GENERALLYSTARTTEXT"), "Clonk Endeavour")
            Else
                cmd_ClonkEndeavour_btn.Text = "Download Clonk Endeavour x86"
            End If
            If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet")) Then
                cmd_ClonkPlanet_btn.Text = Coding(GetSpecificLanguageString("MAIN:LIBRARY_GENERALLYSTARTTEXT"), "Clonk Planet")
            Else
                cmd_ClonkPlanet_btn.Text = "Download Clonk Planet x86"
            End If
            If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4")) Then
                cmd_Clonk4_btn.Text = Coding(GetSpecificLanguageString("MAIN:LIBRARY_GENERALLYSTARTTEXT"), "Clonk 4")
            Else
                cmd_Clonk4_btn.Text = "Download Clonk 4 x86"
            End If

            Me.Refresh()
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Private Sub DownloadGame(ByVal _DownloadLink As String)
        Try
            Dim GameName As String = _DownloadLink.Split(CChar("/"))(5).Split(CChar("."))(0).Replace("%20", " ")

            ' Is currently busy with downloading a game
            IsCurrentlyDownloading = True

            ' Set Variables
            Download_GameName = GameName
            Download_DownloadGameTo = MakeLinuxCompatible(".\Data\temp\" & GetRandomFilename())
            Download_ExtractGameTo = MakeLinuxCompatible(".\Data\InstalledGames\")

            ' Download
            Downloader = New WebClient
            Downloader.DownloadFileAsync(New Uri(_DownloadLink), Download_DownloadGameTo)

            ' Other
            downloadProgress_prgsbar.Visible = True
            downloadProgress_lbl.Visible = True

            status_lbl.Text = Coding(GetSpecificLanguageString("MAIN:DOWNLOAD_DOWNLOADING"), GameName)
        Catch ex As Exception
            IsCurrentlyDownloading = False
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Private Sub SortCCANObjects(ctrl As Control, Optional SortMode As Integer = 0)
        Try
            Select Case SortMode
                Case 0 ' Newest
                    If Not ctrl.Controls.Count = 0 Then
                        Dim ctrCol = (From c In ctrl.Controls.OfType(Of CCANObjectPreviewUC)() Order By c.CCANObject.GetUploadDateWithoutTime).ToArray
                        ctrl.Controls.Clear()
                        ctrl.Controls.AddRange(ctrCol)

                        For i = 0 To ctrCol.Length
                            ctrl.Controls.SetChildIndex(ctrCol(i), 0)
                        Next
                    End If
                Case 1 ' Oldest
                    If Not ctrl.Controls.Count = 0 Then
                        Dim ctrCol = (From c In ctrl.Controls.OfType(Of CCANObjectPreviewUC)() Order By c.CCANObject.GetUploadDateWithoutTime).ToArray
                        ctrl.Controls.Clear()
                        ctrl.Controls.AddRange(ctrCol)
                    End If
            End Select
        Catch ex As Exception
            ccanObjects_flp.Enabled = True
        End Try
    End Sub

    Private Sub WebbrowserErrorPanel(Optional ByVal Show As Boolean = False)
        HomeWebbrowserError_pnl.Visible = Show
        EventsWebbrowserError_pnl.Visible = Show
        OpenClonkWebbrowserError_pnl.Visible = Show
        ClonkRageWebbrowserError_pnl.Visible = Show
        ClonkEndeavourWebbrowserError_pnl.Visible = Show
        ClonkPlanetWebbrowserError_pnl.Visible = Show
        Clonk4WebbrowserError_pnl.Visible = Show
    End Sub

    Private Sub SetQuicklaunch(ByVal _Name As String)
        Try
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Sections.Add("GAME").Keys.Add("1", _Name)
            _IniFile.Sections("GAME").Keys.Add("2", "")
            _IniFile.Save(MakeLinuxCompatible(".\LastOpened.ini"))

            ' ReloadQuickLaunch
            ReloadQuickLaunch()
        Catch ex As Exception : End Try
    End Sub

#Region "Functions"

    Public Function GetDayName() As String
        Dim myCulture As System.Globalization.CultureInfo = Globalization.CultureInfo.CurrentCulture
        Dim dayOfWeek As DayOfWeek = myCulture.Calendar.GetDayOfWeek(Date.Today)
        ' Following returns "Sonntag" for me since i'm in germany '
        'Dim dayName As String = myCulture.DateTimeFormat.GetDayName(dayOfWeek)
        Return dayOfWeek.ToString
    End Function

    Public Function CheckInternetConnection() As Boolean
        Try
            Dim pSender As Ping = New Ping()
            Dim pReply As PingReply = pSender.Send("www.google.com")
            If pReply.Status = IPStatus.Success Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function GetAppDataPath() As String
        Return Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
    End Function

    Public Function GetExternalIP() As String
        Try
            Dim ExternalIP As String
            ExternalIP = (New WebClient()).DownloadString("http://checkip.dyndns.org/")
            ExternalIP = (New Regex("\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")) _
                         .Matches(ExternalIP)(0).ToString()
            Return ExternalIP
        Catch
            Return Nothing
        End Try
    End Function

    Public Function GetNewLegacyClonkVersion() As List(Of String)
        Try
            Dim sourceString As String = New System.Net.WebClient().DownloadString("http://update.clonkspot.org/lc/update") ' Get Informations

            ' Create temp ini file
            Dim _TempFileName As String = MakeLinuxCompatible(".\Data\temp\" & GetRandomFilename() & ".ini")
            Using sw As New StreamWriter(File.Open(_TempFileName, FileMode.OpenOrCreate))
                sw.Write(sourceString)
            End Using

            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(_TempFileName)
            Dim RowStr As String = _IniFile.Sections("LegacyClonk").Keys("Version").Value
            Dim VersionNumber As String = RowStr.Split(CChar(","))(4)
            Dim RowFullVersion As String = RowStr.Replace(CChar(","), CChar("."))
            Dim FullVersion As String = RowFullVersion.Replace("." & VersionNumber, Nothing)

            Dim ListOfData As New List(Of String)
            ListOfData.Add(FullVersion)
            ListOfData.Add(VersionNumber)

            Return ListOfData
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Function GetFileVersionInfo(ByVal filename As String) As String
        Return FileVersionInfo.GetVersionInfo(filename).FileVersion
    End Function

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

    Public Function Coding(ByVal InputText As String, Optional ByVal ReplaceWith As String = "NEWSTRING") As String
        Select Case True
            Case InputText.Contains("%s")
                Return InputText.Replace("%s", ReplaceWith) ' Replace with new string
            Case InputText.Contains("<br>")
                Return InputText.Replace("<br>", Environment.NewLine) ' Replace with new line
            Case InputText.Contains("<ReturnFromFile:>") And InputText.Contains("<End>")
                Try
                    Dim m As MatchCollection = Regex.Matches(InputText, "<ReturnFromFile:>(.+?)<End>") ' GetFileName
                    Return System.IO.File.ReadAllText(MakeLinuxCompatible(".\Data\Language\" & m(0).Groups(1).Value), Encoding.UTF8) ' ReadFileFromFilename
                Catch ex As Exception
                    Return "Error while reading text from file at: " & InputText & Environment.NewLine & "Details: " & ex.Message
                End Try
            Case Else
                Return InputText
        End Select
    End Function

    Public Function GetSpecificLanguageString(ByVal Key As String) As String
        Try
            For Each Entry As DictionaryEntry In QClipboard.LanguageTable
                If String.Equals(CStr(Entry.Key), Key) = True Then
                    Return Entry.Value.ToString
                    Exit Function
                End If
            Next
            Return "Not found"
        Catch ex As Exception
            Return "ERROR"
        End Try
    End Function

#End Region

#Region "Creators"

    Private Sub CreateBrowser(ByVal Browsername As String, ByVal URL As String, ByVal TargetControl As Control, ByVal BrowserLocation As Point, ByVal BrowserSize As Size, ByVal NewAnchor As AnchorStyles, Optional ByVal BrowserLoadFlags As Gecko.GeckoLoadFlags = GeckoLoadFlags.FirstLoad)
        Try
            ' Setup Browser
            GeckoFXBrowser = New GeckoWebBrowser ' New Browser
            GeckoFXBrowser.Name = Browsername
            GeckoFXBrowser.Navigate(URL, BrowserLoadFlags)
            GeckoFXBrowser.Anchor = NewAnchor
            GeckoFXBrowser.Dock = DockStyle.None
            GeckoFXBrowser.Size = BrowserSize
            GeckoFXBrowser.Location = BrowserLocation
            GeckoFXBrowser.BringToFront()

            AddHandler GeckoFXBrowser.NavigationError, AddressOf NavigateError_ChromiumBrowser

            GeckoFXBrowserList.Add(GeckoFXBrowser)
            TargetControl.Controls.Add(GeckoFXBrowser) ' Add Control
        Catch ex As Exception
            WebbrowserErrorPanel(True)
            MessageBox.Show(ex.Message, "Error while creating GeckoFX Browser", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub LoadError_ChromiumBrowser(sender As Object, e As EventArgs)
        Dim _name As String = DirectCast(sender, GeckoWebBrowser).Name
        Dim _url As String = DirectCast(sender, GeckoWebBrowser).Url.ToString
        status_lbl.Text = "Webbrowser Error. Name: " & _name & " - URL: " & _url
    End Sub
    Private Sub NavigateError_ChromiumBrowser(sender As Object, e As Gecko.Events.GeckoNavigationErrorEventArgs)
        status_lbl.Text = "Error while navigating. Errorcode: " & e.ErrorCode.ToString
    End Sub

    Private Sub CreateQuickLaunchButton(ByVal _Name As String, ByVal _Icon As Bitmap)
        If QuickLaunch_flp.Controls.Count >= 2 Then
            QuickLaunch_flp.Controls.Clear()

            Dim NewBtn As New NewMetroButton
            NewBtn.Size = New Size(431, 41)
            NewBtn.Name = _Name
            NewBtn.Text = _Name
            NewBtn.RoundingArc = 25
            NewBtn.Icon = _Icon
            NewBtn.ScaleImage = True

            AddHandler NewBtn.Click, AddressOf _qlbtn_click

            QuickLaunch_flp.Controls.Add(NewBtn)

        Else
            Dim NewBtn As New NewMetroButton
            NewBtn.Size = New Size(431, 41)
            NewBtn.Name = _Name
            NewBtn.Text = _Name
            NewBtn.RoundingArc = 25
            NewBtn.Icon = _Icon
            NewBtn.ScaleImage = True

            AddHandler NewBtn.Click, AddressOf _qlbtn_click

            QuickLaunch_flp.Controls.Add(NewBtn)
        End If
    End Sub
    Private Sub _qlbtn_click(sender As Object, e As EventArgs)
        Select Case DirectCast(sender, NewMetroButton).Text
            Case "OpenClonk"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk\openclonk.exe")) Then

                        If IsClonkActive = False Then
                            ocPlaytimeWatch.Reset()
                            ocPlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk\openclonk.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun OpenClonk! Möchtest du nicht mitspielen?")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("OpenClonk")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "OpenClonk wurde noch nicht heruntergeladen.")
                    _newMsg.ShowDialog()
                End If
            Case "OpenClonk_x86"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86\openclonk.exe")) Then

                        If IsClonkActive = False Then
                            ocPlaytimeWatch.Reset()
                            ocPlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86\openclonk.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then ' Send Message to Chat
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun OpenClonk! Möchtest du nicht mitspielen?")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("OpenClonk")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else ' False
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "OpenClonk_x86 wurde noch nicht heruntergeladen.")
                    _newMsg.ShowDialog()
                End If
            Case "LegacyClonk"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk\Clonk.exe")) Then

                        If IsClonkActive = False Then
                            crPlaytimeWatch.Reset()
                            crPlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk\Clonk.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun LegacyClonk! Möchtest du nicht mitspielen?")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("ClonkRage")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "LegacyClonk wurde noch nicht heruntergeladen.")
                    _newMsg.ShowDialog()
                End If
            Case "Clonk Endeavour"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour\Clonk.exe")) Then

                        If IsClonkActive = False Then
                            If Not System.IO.Directory.Exists(MakeLinuxCompatible(GetAppDataPath() & "\Clonk")) Then
                                System.IO.Directory.CreateDirectory(MakeLinuxCompatible(GetAppDataPath() & "\Clonk"))
                                System.IO.File.Copy(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour\Clonk\Freeware.c4k"), MakeLinuxCompatible(GetAppDataPath() & "\Clonk\Freeware.c4k"))
                            End If

                            cePlaytimeWatch.Reset()
                            cePlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour\Clonk.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun Clonk Endeavour! Möchtest du nicht mitspielen?")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("ClonkEndeavour")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Clonk Endeavour wurde noch nicht heruntergeladen.")
                    _newMsg.ShowDialog()
                End If
            Case "Clonk Planet"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet\Planet.exe")) Then

                        If IsClonkActive = False Then
                            cpPlaytimeWatch.Reset()
                            cpPlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet\Planet.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun Clonk Planet! Möchtest du nicht mitspielen?")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("ClonkPlanet")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Clonk Planet wurde noch nicht heruntergeladen.")
                    _newMsg.ShowDialog()
                End If
            Case "Clonk 4"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4\Clonk4.exe")) Then

                        If IsClonkActive = False Then
                            c4PlaytimeWatch.Reset()
                            c4PlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4\Clonk4.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun Clonk 4!")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("Clonk4")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Clonk 4 wurde noch nicht heruntergeladen.")
                    _newMsg.ShowDialog()
                End If
            Case Else
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "?!?!!!???r!!?")
                _newMsg.ShowDialog()
        End Select
    End Sub

#End Region

#Region "Random"

    Private Function GetRandomFilename() As String
        Try
            Dim temp_filename As String
            temp_filename = System.IO.Path.GetRandomFileName

            Return System.IO.Path.GetFileNameWithoutExtension(temp_filename)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function GetRandomID() As String
        Try
            Dim s As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
            Dim r As New Random
            Dim sb As New StringBuilder

            For i As Integer = 1 To 8
                Dim idx As Integer = r.Next(0, 35)
                sb.Append(s.Substring(idx, 1))
            Next

            Return sb.ToString
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function GetRandomCCANID() As String
        Try
            Dim s As String = "0123456789"
            Dim r As New Random
            Dim sb As New StringBuilder

            For i As Integer = 1 To 12
                Dim idx As Integer = r.Next(0, 10)
                sb.Append(s.Substring(idx, 1))
            Next

            Return sb.ToString
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return Nothing
        End Try
    End Function

#End Region

#Region "Downloader"
    ' FileDownloader
    Private Sub Downloader_DownloadFileCompleted(sender As Object, e As System.ComponentModel.AsyncCompletedEventArgs) Handles Downloader.DownloadFileCompleted
        If e.Cancelled Then
            status_lbl.Text = GetSpecificLanguageString("MAIN:DOWNLOAD_CANCELEDUNEXPECTEDLY")
            IsCurrentlyDownloading = False
            downloadProgress_prgsbar.Visible = False
            downloadProgress_lbl.Visible = False
            'DownloadCancelButton.Visible = False
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, Coding(GetSpecificLanguageString("MAIN:DOWNLOAD_CANCELED"), Download_GameName))
            _newMsg.ShowDialog()
        Else
            status_lbl.Text = GetSpecificLanguageString("MAIN:DOWNLOAD_COMPLETEDDECRYPTANDCOPYING")

            Try
                ZipFile.ExtractToDirectory(Download_DownloadGameTo, Download_ExtractGameTo) ' Extract Game
            Catch ex As Exception

            End Try

            status_lbl.Text = Coding(GetSpecificLanguageString("MAIN:DOWNLOAD_COMPLETED2"), Download_GameName)
            NotifyIcon1.ShowBalloonTip(4000, GetSpecificLanguageString("MAIN:DOWNLOAD_COMPLETED"), Coding(GetSpecificLanguageString("MAIN:DOWNLOAD_COMPLETED2"), Download_GameName), ToolTipIcon.Info)
            IsCurrentlyDownloading = False
            downloadProgress_prgsbar.Visible = False
            downloadProgress_lbl.Visible = False
            'DownloadCancelButton.Visible = False
            CheckIfGamesExists()
        End If
    End Sub
    Private Sub Downloader_DownloadProgressChanged(sender As Object, e As System.Net.DownloadProgressChangedEventArgs) Handles Downloader.DownloadProgressChanged
        Try
            Dim BytesDownloaded As String
            Dim BytesToRecieve As String

            'Convert Bytes downloaded
            If e.BytesReceived >= 1073741824 Then
                BytesDownloaded = Format(e.BytesReceived / 1024 / 1024 / 1024, "#0.00") & " GB"
            ElseIf e.BytesReceived >= 1048576 Then
                BytesDownloaded = Format(e.BytesReceived / 1024 / 1024, "#0.00") & " MB"
            ElseIf e.BytesReceived >= 1024 Then
                BytesDownloaded = Format(e.BytesReceived / 1024, "#0.00") & " KB"
            ElseIf e.BytesReceived < 1024 Then
                BytesDownloaded = Fix(e.BytesReceived) & " Bytes"
            End If

            'Convert Bytes Bytes
            If e.TotalBytesToReceive >= 1073741824 Then
                BytesToRecieve = Format(e.TotalBytesToReceive / 1024 / 1024 / 1024, "#0.00") & " GB"
            ElseIf e.TotalBytesToReceive >= 1048576 Then
                BytesToRecieve = Format(e.TotalBytesToReceive / 1024 / 1024, "#0.00") & " MB"
            ElseIf e.TotalBytesToReceive >= 1024 Then
                BytesToRecieve = Format(e.TotalBytesToReceive / 1024, "#0.00") & " KB"
            ElseIf e.TotalBytesToReceive < 1024 Then
                BytesToRecieve = Fix(e.TotalBytesToReceive) & " Bytes"
            End If

            downloadProgress_prgsbar.Value = e.ProgressPercentage
            downloadProgress_lbl.Text = e.ProgressPercentage.ToString & "% | " & BytesDownloaded & " of " & BytesToRecieve & " downloaded"
            'Me.progress_lbl.Text = "Fortschritt: " & e.ProgressPercentage & "% | " & BytesDownloaded & " von " & BytesToRecieve & " heruntergeladen."
        Catch ex As Exception ' When Error
            Downloader.CancelAsync()
            IsCurrentlyDownloading = False
            downloadProgress_prgsbar.Visible = False
            downloadProgress_lbl.Visible = False
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub
    ' StringDownloader
    Private Sub DownloadChangelogAsyncWebClient_DownloadStringCompleted(sender As Object, e As DownloadStringCompletedEventArgs) Handles DownloadChangelogAsyncWebClient.DownloadStringCompleted
        Try
            If e.Cancelled = False AndAlso e.Error Is Nothing Then
                changelog_rtb.Text = e.Result.ToString
            Else
                changelog_rtb.Text = "Fehler beim abrufen der Changelogs." & vbNewLine & e.Error.Message
            End If
        Catch ex As Exception
            changelog_rtb.Text = "Fehler beim abrufen der Changelogs." & vbNewLine & ex.Message
        End Try
    End Sub
    Private Sub DownloadNewsAsyncWebClient_DownloadStringCompleted(sender As Object, e As DownloadStringCompletedEventArgs) Handles DownloadNewsAsyncWebClient.DownloadStringCompleted
        Try
            If e.Cancelled = False AndAlso e.Error Is Nothing Then
                news_rtb.Text = e.Result.ToString
            Else
                news_rtb.Text = "Fehler beim abrufen der Changelogs." & vbNewLine & e.Error.Message
            End If
        Catch ex As Exception
            news_rtb.Text = "Fehler beim abrufen der Changelogs." & vbNewLine & ex.Message
        End Try
    End Sub
#End Region

#Region "UpdateFunction"

    Public Sub CheckForUpdates(Optional ByVal ShowBallonTip As Boolean = True, Optional ByVal ShowTextInStatusBar As Boolean = True)
        ' Example for an easy version check
        If CheckInternetConnection() = True Then
            Try
                Dim _newversion As String = StringDownloaderWebClient.DownloadString(New Uri("- YOUR URL HERE - Example for Dropbox: https://www.dropbox.com/s/.../version.txt?dl=1 -")) ' Get Version

                If _newversion > XCLVersion Then ' If new version then

                    status_lbl.Text = Coding(GetSpecificLanguageString("MAIN:UPDATE_AVAILABLE"), _newversion)
                    NewUpdateAvaible = True

                    If ShowNewUpdateMsg Then
                        Select Case MessageBox.Show(Coding(GetSpecificLanguageString("MAIN:UPDATE_VISITWEBSITE"), _newversion), "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
                            Case System.Windows.Forms.DialogResult.Yes
                                Process.Start("https://quixo-systems.jimdofree.com/kategorien/programme/xtreme-clonk-launcher/")
                        End Select
                    End If

                Else

                    If ShowBallonTip = True Then
                        NotifyIcon1.ShowBalloonTip(5000, GetSpecificLanguageString("MAIN:UPDATE_NONEWUPDATE"), "Last checked: " & TimeOfDay.Hour & ":" & TimeOfDay.Minute, ToolTipIcon.Info)
                    End If
                    If ShowTextInStatusBar = True Then
                        status_lbl.Text = GetSpecificLanguageString("MAIN:UPDATE_NONEWUPDATE")
                    End If
                    NewUpdateAvaible = False

                End If
            Catch ex As Exception
                status_lbl.Text = GetSpecificLanguageString("MAIN:UPDATE_CHECKERROR")
                MessageBox.Show(ex.Message, GetSpecificLanguageString("MAIN:UPDATE_CHECKERROR"), MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            status_lbl.Text = GetSpecificLanguageString("MAIN:UPDATE_CHECKERRORINTERNET")
            MessageBox.Show(GetSpecificLanguageString("MAIN:UPDATE_CHECKERRORINTERNET"), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

#End Region

#End Region

#Region "Timer"

    Private Sub CheckClonkProcess_tmr_Tick(sender As Object, e As EventArgs) Handles CheckClonkProcess_tmr.Tick
        If System.Diagnostics.Process.GetProcessesByName("Clonk4").Length > 0 Or System.Diagnostics.Process.GetProcessesByName("Planet").Length > 0 Or System.Diagnostics.Process.GetProcessesByName("Clonk").Length > 0 Or System.Diagnostics.Process.GetProcessesByName("openclonk").Length > 0 Then
            ClonkIsRunningInfo_lbl.Visible = True
            IsClonkActive = True
        Else
            CheckClonkProcess_tmr.Stop()
            ClonkIsRunningInfo_lbl.Visible = False
            IsClonkActive = False

            ' Stop Timers
            ocPlaytimeWatch.Stop()
            crPlaytimeWatch.Stop()
            cePlaytimeWatch.Stop()
            cpPlaytimeWatch.Stop()
            c4PlaytimeWatch.Stop()
        End If
    End Sub

    Private Sub Checker_tmr_Tick(sender As Object, e As EventArgs) Handles Checker_tmr.Tick
        Try
            ' Count all friends that are online
            friendsOnlineCount_lbl.Text = Coding(friendsOnlineCount_lbl.Text, friendsOnline_flp.Controls.Count.ToString)

            ' Count all avaible notifications
            Notifications_btn.Text = Coding(Notifications_btn.Text, Notifications_flp.Controls.Count.ToString)
            If Notifications_flp.Controls.Count = 0 Then
                NoNotifications_lbl.Visible = True
            Else
                NoNotifications_lbl.Visible = False
            End If

            ' Count all avaible News
            AllNewsCount_lbl.Text = Coding(AllNewsCount_lbl.Text, AllNews_flp.Controls.Count.ToString)
        Catch ex As Exception
            Checker_tmr.Stop()
            MessageBox.Show("Error in checker_tmr. checker_tmr stopped." & Environment.NewLine & ex.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error) ' Debug
        End Try
    End Sub

#End Region

#Region "TabControl"

    ' Home
    Private Sub news_rtb_LinkClicked(sender As Object, e As LinkClickedEventArgs) Handles news_rtb.LinkClicked
        Select Case MessageBox.Show(Coding(GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_OPENLINKTEXT"), e.LinkText.ToString), GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_OPENLINKTITLE"), MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            Case System.Windows.Forms.DialogResult.Yes
                Process.Start(e.LinkText.ToString)
        End Select
    End Sub
    Private Sub changelog_rtb_LinkClicked(sender As Object, e As LinkClickedEventArgs) Handles changelog_rtb.LinkClicked
        Select Case MessageBox.Show(Coding(GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_OPENLINKTEXT"), e.LinkText.ToString), GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_OPENLINKTITLE"), MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            Case System.Windows.Forms.DialogResult.Yes
                Process.Start(e.LinkText.ToString)
        End Select
    End Sub

    ' News
    Private Sub RefreshNewsList_btn_Click(sender As Object, e As EventArgs) Handles RefreshNewsList_btn.Click
        If Networking.IsConnectionAlive = True Then
            AllNews_flp.Controls.Clear()
            Networking.UTC.sendUTicket("ADMIN", "ToServer:News:ListAllObjects", "") ' Get all News-Objects

            NewsPanel_pnl.Visible = False
            AllNews_flp.Enabled = False
            NewsLoading_picbox.Visible = True
        Else
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_REFRESHFAILED") & Environment.NewLine & GetSpecificLanguageString("MESSAGEBOXTEXT:DETAILS_NOCONNECTIONTOTHESERVER"))
            _newMsg.ShowDialog()
        End If
    End Sub

    ' Event
    Private Sub WatchInBrowser_btn_Click(sender As Object, e As EventArgs) Handles WatchInBrowser_btn.Click
        Try
            Dim _TabPage As Control = DirectCast(sender, MetroSuite.MetroButton).Parent
            For Each _cntrl As Control In _TabPage.Controls
                If (TypeOf _cntrl Is GeckoWebBrowser) Then
                    Dim _ChannelName As String = DirectCast(_cntrl, GeckoWebBrowser).Url.ToString.Split(CChar("="))(1).Split(CChar("&"))(0)

                    Process.Start("https://www.twitch.tv/" & _ChannelName)
                End If
            Next
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Error while opening stream in browser" & Environment.NewLine & "Details: " & ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    ' ClonkGames
    Private Sub openclonk_x86_btn_Click(sender As Object, e As EventArgs) Handles OpenClonk_x86_btn.Click
        If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86")) Then
            If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86\openclonk.exe")) Then

                If IsClonkActive = False Then
                    ocPlaytimeWatch.Reset()
                    ocPlaytimeWatch.Start()
                    Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86\openclonk.exe"))
                    CheckClonkProcess_tmr.Start()

                    If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                        If ShowChatClonkMessage = True Then ' Send Message to Chat
                            Dim ListOfData As New List(Of Object)
                            ListOfData.Add("spielt nun OpenClonk! Möchtest du nicht mitspielen?")
                            ListOfData.Add(QClipboard.AccountName)
                            Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                        End If
                    End If

                    If Networking.IsConnectionAlive Then ' Check if connected to Server
                        If AllowSendingRushHourData Then ' If connected then send rush hour data

                            If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                Dim _data As New List(Of Object)
                                _data.Add("OpenClonk")
                                _data.Add(GetDayName())
                                _data.Add(QClipboard.AccountName)

                                My.Settings.LastDayDate = Date.Today.DayOfWeek
                                My.Settings.Save()

                                Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                            End If

                        End If
                        If AllowSendingPlayTimeData Then ' If connected then send play time data

                        End If
                    End If

                    ' Set Quicklaunch
                    SetQuicklaunch("OpenClonk_x86")

                Else
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                    _newMsg.ShowDialog()
                End If

            End If
        Else ' False
            If CheckInternetConnection() Then ' Check if Internetconnection is available
                If IsCurrentlyDownloading = True Then
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_WAITUNTILDOWNLOADISFINISHED"))
                    _newMsg.ShowDialog()
                Else
                    DownloadGame("https://www.dropbox.com/s/kgz5otb0winv2r0/OpenClonk_x86.zip?dl=1")
                End If
            Else
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_NOINTERNETCONNECTION"))
                _newMsg.ShowDialog()
            End If
        End If
    End Sub

    Private Sub cmd_openclonk_btn_Click(sender As Object, e As EventArgs) Handles cmd_OpenClonk_btn.Click, cmd_ClonkRage_btn.Click, cmd_ClonkEndeavour_btn.Click, cmd_ClonkPlanet_btn.Click, cmd_Clonk4_btn.Click
        Dim _name As String = DirectCast(sender, MetroSuite.MetroButton).Name.Split(CChar("_"))(1).ToString.Split(CChar("_"))(0)
        Select Case _name
            Case "OpenClonk"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk\openclonk.exe")) Then

                        If IsClonkActive = False Then
                            ocPlaytimeWatch.Reset()
                            ocPlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk\openclonk.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun OpenClonk! Möchtest du nicht mitspielen?")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("OpenClonk")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                            ' Set Quicklaunch
                            SetQuicklaunch("OpenClonk")

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    If CheckInternetConnection() Then ' Check if Internetconnection is available
                        If IsCurrentlyDownloading = True Then
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_WAITUNTILDOWNLOADISFINISHED"))
                            _newMsg.ShowDialog()
                        Else
                            DownloadGame("https://www.dropbox.com/s/whkwdatb1lncatg/OpenClonk.zip?dl=1")
                        End If
                    Else
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_NOINTERNETCONNECTION"))
                        _newMsg.ShowDialog()
                    End If
                End If
            Case "ClonkRage"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk\Clonk.exe")) Then

                        If IsClonkActive = False Then
                            crPlaytimeWatch.Reset()
                            crPlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk\Clonk.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun LegacyClonk! Möchtest du nicht mitspielen?")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("ClonkRage")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                            ' Set Quicklaunch
                            SetQuicklaunch("LegacyClonk")

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    If CheckInternetConnection() Then ' Check if Internetconnection is available
                        If IsCurrentlyDownloading = True Then
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_WAITUNTILDOWNLOADISFINISHED"))
                            _newMsg.ShowDialog()
                        Else
                            DownloadGame("https://www.dropbox.com/s/4dazazzkf3561na/LegacyClonk_338.zip?dl=1")
                        End If
                    Else
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_NOINTERNETCONNECTION"))
                        _newMsg.ShowDialog()
                    End If
                End If
            Case "ClonkEndeavour"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour\Clonk.exe")) Then

                        If IsClonkActive = False Then
                            If Not System.IO.Directory.Exists(MakeLinuxCompatible(GetAppDataPath() & "\Clonk")) Then
                                System.IO.Directory.CreateDirectory(MakeLinuxCompatible(GetAppDataPath() & "\Clonk"))
                                System.IO.File.Copy(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour\Clonk\Freeware.c4k"), MakeLinuxCompatible(GetAppDataPath() & "\Clonk\Freeware.c4k"))
                            End If

                            cePlaytimeWatch.Reset()
                            cePlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour\Clonk.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun Clonk Endeavour! Möchtest du nicht mitspielen?")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("ClonkEndeavour")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                            ' Set Quicklaunch
                            SetQuicklaunch("Clonk Endeavour")

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    If CheckInternetConnection() Then ' Check if Internetconnection is available
                        If IsCurrentlyDownloading = True Then
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_WAITUNTILDOWNLOADISFINISHED"))
                            _newMsg.ShowDialog()
                        Else
                            DownloadGame("https://www.dropbox.com/s/11nyhz7zyb5cs4w/Clonk%20Endeavour.zip?dl=1")
                        End If
                    Else
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_NOINTERNETCONNECTION"))
                        _newMsg.ShowDialog()
                    End If
                End If
            Case "ClonkPlanet"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet\Planet.exe")) Then

                        If IsClonkActive = False Then
                            cpPlaytimeWatch.Reset()
                            cpPlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet\Planet.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun Clonk Planet! Möchtest du nicht mitspielen?")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("ClonkPlanet")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                            ' Set Quicklaunch
                            SetQuicklaunch("Clonk Planet")

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    If CheckInternetConnection() Then ' Check if Internetconnection is available
                        If IsCurrentlyDownloading = True Then
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_WAITUNTILDOWNLOADISFINISHED"))
                            _newMsg.ShowDialog()
                        Else
                            DownloadGame("https://www.dropbox.com/s/h56ngh2753x013o/Clonk%20Planet.zip?dl=1")
                        End If
                    Else
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_NOINTERNETCONNECTION"))
                        _newMsg.ShowDialog()
                    End If
                End If
            Case "Clonk4"
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4")) Then
                    If System.IO.File.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4\Clonk4.exe")) Then

                        If IsClonkActive = False Then
                            c4PlaytimeWatch.Reset()
                            c4PlaytimeWatch.Start()
                            Process.Start(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4\Clonk4.exe"))
                            CheckClonkProcess_tmr.Start()

                            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                                If ShowChatClonkMessage = True Then
                                    Dim ListOfData As New List(Of Object)
                                    ListOfData.Add("spielt nun Clonk 4!")
                                    ListOfData.Add(QClipboard.AccountName)
                                    Networking.UTC.sendUTicket("@all", "Command:Message", ListOfData)
                                End If
                            End If

                            If Networking.IsConnectionAlive Then ' Check if connected to Server
                                If AllowSendingRushHourData Then ' If connected then send rush hour data

                                    If Not Date.Today.DayOfWeek = My.Settings.LastDayDate Then
                                        Dim _data As New List(Of Object)
                                        _data.Add("Clonk4")
                                        _data.Add(GetDayName())
                                        _data.Add(QClipboard.AccountName)

                                        My.Settings.LastDayDate = Date.Today.DayOfWeek
                                        My.Settings.Save()

                                        Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:GetData", _data)
                                    End If

                                End If
                                If AllowSendingPlayTimeData Then ' If connected then send play time data

                                End If
                            End If

                            ' Set Quicklaunch
                            SetQuicklaunch("Clonk 4")

                        Else
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_CLONKRUNNINGALREADY"))
                            _newMsg.ShowDialog()
                        End If

                    End If
                Else
                    If CheckInternetConnection() Then ' Check if Internetconnection is available
                        If IsCurrentlyDownloading = True Then
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_WAITUNTILDOWNLOADISFINISHED"))
                            _newMsg.ShowDialog()
                        Else
                            DownloadGame("https://www.dropbox.com/s/p3zicmfkwrolrko/Clonk%204.zip?dl=1")
                        End If
                    Else
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:MAIN_NOINTERNETCONNECTION"))
                        _newMsg.ShowDialog()
                    End If
                End If
        End Select
    End Sub

    ' Clonk Settings Button
    Private Sub cmd_OpenClonkSettings_btn_Click(sender As Object, e As EventArgs) Handles cmd_OpenClonkSettings_btn.Click, cmd_OpenClonkx86Settings_btn.Click, cmd_ClonkRageSettings_btn.Click, cmd_ClonkEndeavourSettings_btn.Click, cmd_ClonkPlanetSettings_btn.Click, cmd_Clonk4Settings_btn.Click
        Dim _name As String = DirectCast(sender, MetroSuite.MetroButton).Name.Split(CChar("_"))(1).ToString.Split(CChar("_"))(0)
        Select Case True
            Case _name.Contains("OpenClonkSettings")
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk")) Then
                    OpenClonkSettings_ctms.Show(cmd_OpenClonkSettings_btn, 0, 0)
                End If
            Case _name.Contains("OpenClonkx86Settings")
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\OpenClonk_x86")) Then
                    OpenClonkx86Settings_ctms.Show(cmd_OpenClonkx86Settings_btn, 0, 0)
                End If
            Case _name.Contains("ClonkRageSettings")
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\LegacyClonk")) Then
                    ClonkRageSettings_ctms.Show(cmd_ClonkRageSettings_btn, 0, 0)
                End If
            Case _name.Contains("ClonkEndeavourSettings")
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Endeavour")) Then
                    ClonkEndeavourSettings_ctms.Show(cmd_ClonkEndeavourSettings_btn, 0, 0)
                End If
            Case _name.Contains("ClonkPlanetSettings")
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk Planet")) Then
                    ClonkPlanetSettings_ctms.Show(cmd_ClonkPlanetSettings_btn, 0, 0)
                End If
            Case _name.Contains("Clonk4Settings")
                If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\InstalledGames\Clonk 4")) Then
                    Clonk4Settings_ctms.Show(cmd_Clonk4Settings_btn, 0, 0)
                End If
        End Select
    End Sub

    ' CCAN
    Private ccanSelectedFilter As String = "ALL"
    Private ccanSelectedDateFilter As String = "NEWEST"
    Private Sub Upload_btn_Click(sender As Object, e As EventArgs) Handles UploadNewContent_btn.Click
        If QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym Then
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:CCAN_UPLOADOBJECTSLOGINNEEDED"))
            _newMsg.ShowDialog()
        Else
            UploadObjectFrm.ShowDialog()
        End If
    End Sub
    Private Sub refresh_btn_Click(sender As Object, e As EventArgs) Handles refresh_btn.Click
        If Networking.IsConnectionAlive = True Then
            ccanObjects_flp.Controls.Clear()
            Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:ListAllObjects", "") ' Get all CCAN Objects

            ccanObjects_flp.Enabled = False
            ccanLoading_picbox.Visible = True
        Else
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_REFRESHFAILED") & Environment.NewLine & GetSpecificLanguageString("MESSAGEBOXTEXT:DETAILS_NOCONNECTIONTOTHESERVER"))
            _newMsg.ShowDialog()
        End If
    End Sub

    Private Sub ccanSearch_btn_Click(sender As Object, e As EventArgs) Handles ccanSearch_btn.Click
        If String.IsNullOrWhiteSpace(ccanSearch_txtbox.Text) Then
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:CCAN_ENTERNAMEORID"))
            _newMsg.ShowDialog()
        Else

            For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
                Select Case ccanSelectedFilter
                    Case "ALL"
                        If _cntrl.CCANObject.GetTitle.Contains(ccanSearch_txtbox.Text) Or _cntrl.CCANObject.GetUniqueObjectID.Contains(ccanSearch_txtbox.Text) Then

                            Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                                Case "Alle Versionen"
                                    _cntrl.Visible = True
                                Case "OpenClonk"
                                    If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Rage"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Endeavour"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Planet"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk 4"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                            End Select

                        Else
                            _cntrl.Visible = False
                        End If
                    Case "OBJECT"
                        If _cntrl.CCANObject.GetFirstCategory = "Objekt" Then
                            If _cntrl.CCANObject.GetTitle.Contains(ccanSearch_txtbox.Text) Or _cntrl.CCANObject.GetUniqueObjectID.Contains(ccanSearch_txtbox.Text) Then

                                Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                                    Case "Alle Versionen"
                                        _cntrl.Visible = True
                                    Case "OpenClonk"
                                        If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Rage"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Endeavour"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Planet"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk 4"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                End Select

                            Else
                                _cntrl.Visible = False
                            End If
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "SZENARIO"
                        If _cntrl.CCANObject.GetFirstCategory = "Szenario" Then
                            If _cntrl.CCANObject.GetTitle.Contains(ccanSearch_txtbox.Text) Or _cntrl.CCANObject.GetUniqueObjectID.Contains(ccanSearch_txtbox.Text) Then

                                Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                                    Case "Alle Versionen"
                                        _cntrl.Visible = True
                                    Case "OpenClonk"
                                        If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Rage"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Endeavour"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Planet"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk 4"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                End Select

                            Else
                                _cntrl.Visible = False
                            End If
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "OTHER"
                        If _cntrl.CCANObject.GetFirstCategory = "Dokument" Then
                            If _cntrl.CCANObject.GetTitle.Contains(ccanSearch_txtbox.Text) Or _cntrl.CCANObject.GetUniqueObjectID.Contains(ccanSearch_txtbox.Text) Then

                                Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                                    Case "Alle Versionen"
                                        _cntrl.Visible = True
                                    Case "OpenClonk"
                                        If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Rage"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Endeavour"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Planet"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk 4"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                End Select

                            Else
                                _cntrl.Visible = False
                            End If
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "PACKAGE"
                        If _cntrl.CCANObject.GetFirstCategory = "Komplettpaket (.zip)" Then
                            If _cntrl.CCANObject.GetTitle.Contains(ccanSearch_txtbox.Text) Or _cntrl.CCANObject.GetUniqueObjectID.Contains(ccanSearch_txtbox.Text) Then

                                Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                                    Case "Alle Versionen"
                                        _cntrl.Visible = True
                                    Case "OpenClonk"
                                        If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Rage"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Endeavour"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk Planet"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                    Case "Clonk 4"
                                        If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                            _cntrl.Visible = True
                                        Else
                                            _cntrl.Visible = False
                                        End If
                                End Select

                            Else
                                _cntrl.Visible = False
                            End If
                        Else
                            _cntrl.Visible = False
                        End If
                End Select
            Next

        End If
    End Sub

    Private Sub ccanSearch_txtbox_TextChanged(sender As Object, e As EventArgs) Handles ccanSearch_txtbox.TextChanged
        If String.IsNullOrWhiteSpace(ccanSearch_txtbox.Text) Then
            For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
                Select Case ccanSelectedFilter
                    Case "ALL"

                        Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                            Case "Alle Versionen"
                                _cntrl.Visible = True
                            Case "OpenClonk"
                                If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "Clonk Rage"
                                If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "Clonk Endeavour"
                                If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "Clonk Planet"
                                If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "Clonk 4"
                                If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                        End Select

                    Case "OBJECT"
                        If _cntrl.CCANObject.GetFirstCategory = "Objekt" Then

                            Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                                Case "Alle Versionen"
                                    _cntrl.Visible = True
                                Case "OpenClonk"
                                    If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Rage"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Endeavour"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Planet"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk 4"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                            End Select

                        Else
                            _cntrl.Visible = False
                        End If
                    Case "SZENARIO"
                        If _cntrl.CCANObject.GetFirstCategory = "Szenario" Then

                            Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                                Case "Alle Versionen"
                                    _cntrl.Visible = True
                                Case "OpenClonk"
                                    If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Rage"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Endeavour"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Planet"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk 4"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                            End Select

                        Else
                            _cntrl.Visible = False
                        End If
                    Case "OTHER"
                        If _cntrl.CCANObject.GetFirstCategory = "Dokument" Then

                            Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                                Case "Alle Versionen"
                                    _cntrl.Visible = True
                                Case "OpenClonk"
                                    If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Rage"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Endeavour"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Planet"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk 4"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                            End Select

                        Else
                            _cntrl.Visible = False
                        End If
                    Case "PACKAGE"
                        If _cntrl.CCANObject.GetFirstCategory = "Komplettpaket (.zip)" Then

                            Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                                Case "Alle Versionen"
                                    _cntrl.Visible = True
                                Case "OpenClonk"
                                    If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Rage"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Endeavour"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk Planet"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                                Case "Clonk 4"
                                    If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                                        _cntrl.Visible = True
                                    Else
                                        _cntrl.Visible = False
                                    End If
                            End Select

                        Else
                            _cntrl.Visible = False
                        End If
                End Select
            Next
        End If
    End Sub

    Private Sub CCANversionFilter_mcbox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CCANversionFilter_mcbox.SelectedIndexChanged
        Select Case CCANversionFilter_mcbox.SelectedItem.ToString
            Case "Alle Versionen"
                For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls

                    Select Case ccanSelectedFilter
                        Case "ALL"
                            _cntrl.Visible = True
                        Case "OBJECT"
                            If _cntrl.CCANObject.GetFirstCategory = "Objekt" Then
                                _cntrl.Visible = True
                            Else
                                _cntrl.Visible = False
                            End If
                        Case "SZENARIO"
                            If _cntrl.CCANObject.GetFirstCategory = "Szenario" Then
                                _cntrl.Visible = True
                            Else
                                _cntrl.Visible = False
                            End If
                        Case "OTHER"
                            If _cntrl.CCANObject.GetFirstCategory = "Dokument" Then
                                _cntrl.Visible = True
                            Else
                                _cntrl.Visible = False
                            End If
                        Case "PACKAGE"
                            If _cntrl.CCANObject.GetFirstCategory = "Komplettpaket (.zip)" Then
                                _cntrl.Visible = True
                            Else
                                _cntrl.Visible = False
                            End If
                    End Select

                Next
            Case "OpenClonk"
                For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
                    If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then

                        Select Case ccanSelectedFilter
                            Case "ALL"
                                _cntrl.Visible = True
                            Case "OBJECT"
                                If _cntrl.CCANObject.GetFirstCategory = "Objekt" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "SZENARIO"
                                If _cntrl.CCANObject.GetFirstCategory = "Szenario" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "OTHER"
                                If _cntrl.CCANObject.GetFirstCategory = "Dokument" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "PACKAGE"
                                If _cntrl.CCANObject.GetFirstCategory = "Komplettpaket (.zip)" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                        End Select

                    Else
                        _cntrl.Visible = False
                    End If
                Next
            Case "Clonk Rage"
                For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then

                        Select Case ccanSelectedFilter
                            Case "ALL"
                                _cntrl.Visible = True
                            Case "OBJECT"
                                If _cntrl.CCANObject.GetFirstCategory = "Objekt" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "SZENARIO"
                                If _cntrl.CCANObject.GetFirstCategory = "Szenario" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "OTHER"
                                If _cntrl.CCANObject.GetFirstCategory = "Dokument" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "PACKAGE"
                                If _cntrl.CCANObject.GetFirstCategory = "Komplettpaket (.zip)" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                        End Select

                    Else
                        _cntrl.Visible = False
                    End If
                Next
            Case "Clonk Endeavour"
                For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then

                        Select Case ccanSelectedFilter
                            Case "ALL"
                                _cntrl.Visible = True
                            Case "OBJECT"
                                If _cntrl.CCANObject.GetFirstCategory = "Objekt" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "SZENARIO"
                                If _cntrl.CCANObject.GetFirstCategory = "Szenario" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "OTHER"
                                If _cntrl.CCANObject.GetFirstCategory = "Dokument" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "PACKAGE"
                                If _cntrl.CCANObject.GetFirstCategory = "Komplettpaket (.zip)" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                        End Select

                    Else
                        _cntrl.Visible = False
                    End If
                Next
            Case "Clonk Planet"
                For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then

                        Select Case ccanSelectedFilter
                            Case "ALL"
                                _cntrl.Visible = True
                            Case "OBJECT"
                                If _cntrl.CCANObject.GetFirstCategory = "Objekt" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "SZENARIO"
                                If _cntrl.CCANObject.GetFirstCategory = "Szenario" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "OTHER"
                                If _cntrl.CCANObject.GetFirstCategory = "Dokument" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "PACKAGE"
                                If _cntrl.CCANObject.GetFirstCategory = "Komplettpaket (.zip)" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                        End Select

                    Else
                        _cntrl.Visible = False
                    End If
                Next
            Case "Clonk 4"
                For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
                    If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then

                        Select Case ccanSelectedFilter
                            Case "ALL"
                                _cntrl.Visible = True
                            Case "OBJECT"
                                If _cntrl.CCANObject.GetFirstCategory = "Objekt" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "SZENARIO"
                                If _cntrl.CCANObject.GetFirstCategory = "Szenario" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "OTHER"
                                If _cntrl.CCANObject.GetFirstCategory = "Dokument" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                            Case "PACKAGE"
                                If _cntrl.CCANObject.GetFirstCategory = "Komplettpaket (.zip)" Then
                                    _cntrl.Visible = True
                                Else
                                    _cntrl.Visible = False
                                End If
                        End Select

                    Else
                        _cntrl.Visible = False
                    End If
                Next
        End Select
    End Sub
    Private Sub CCANdateFilter_mcbox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CCANdateFilter_mcbox.SelectedIndexChanged
        Select Case CCANdateFilter_mcbox.SelectedItem.ToString
            Case "Neuste zuerst"
                ccanSelectedDateFilter = "NEWEST"
                SortCCANObjects(ccanObjects_flp, 0)
            Case "Älteste zuerst"
                ccanSelectedDateFilter = "OLDEST"
                SortCCANObjects(ccanObjects_flp, 1)
        End Select
    End Sub

    Private Sub ccanFilterAll_btn_Click(sender As Object, e As EventArgs) Handles ccanFilterAll_btn.Click
        For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
            Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                Case "Alle Versionen"
                    _cntrl.Visible = True
                Case "OpenClonk"
                    If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                        _cntrl.Visible = True
                    Else
                        _cntrl.Visible = False
                    End If
                Case "Clonk Rage"
                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                        _cntrl.Visible = True
                    Else
                        _cntrl.Visible = False
                    End If
                Case "Clonk Endeavour"
                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                        _cntrl.Visible = True
                    Else
                        _cntrl.Visible = False
                    End If
                Case "Clonk Planet"
                    If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                        _cntrl.Visible = True
                    Else
                        _cntrl.Visible = False
                    End If
                Case "Clonk 4"
                    If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                        _cntrl.Visible = True
                    Else
                        _cntrl.Visible = False
                    End If
            End Select
        Next
    End Sub
    Private Sub ccanFilterObjects_btn_Click(sender As Object, e As EventArgs) Handles ccanFilterObjects_btn.Click
        For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
            If _cntrl.CCANObject.GetFirstCategory = "Objekt" Then

                Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                    Case "Alle Versionen"
                        _cntrl.Visible = True
                    Case "OpenClonk"
                        If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Rage"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Endeavour"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Planet"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk 4"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                End Select

            Else
                _cntrl.Visible = False
            End If
        Next
    End Sub
    Private Sub ccanFilterSzenarios_btn_Click(sender As Object, e As EventArgs) Handles ccanFilterSzenarios_btn.Click
        For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
            If _cntrl.CCANObject.GetFirstCategory = "Szenario" Then

                Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                    Case "Alle Versionen"
                        _cntrl.Visible = True
                    Case "OpenClonk"
                        If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Rage"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Endeavour"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Planet"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk 4"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                End Select

            Else
                _cntrl.Visible = False
            End If
        Next
    End Sub
    Private Sub ccanFilterOther_btn_Click(sender As Object, e As EventArgs) Handles ccanFilterOther_btn.Click
        For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
            If _cntrl.CCANObject.GetFirstCategory = "Dokument" Then

                Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                    Case "Alle Versionen"
                        _cntrl.Visible = True
                    Case "OpenClonk"
                        If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Rage"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Endeavour"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Planet"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk 4"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                End Select

            Else
                _cntrl.Visible = False
            End If
        Next
    End Sub
    Private Sub ccanFilterPackage_btn_Click(sender As Object, e As EventArgs) Handles ccanFilterPackage_btn.Click
        For Each _cntrl As CCANObjectPreviewUC In ccanObjects_flp.Controls
            If _cntrl.CCANObject.GetFirstCategory = "Komplettpaket (.zip)" Then

                Select Case CCANversionFilter_mcbox.SelectedItem.ToString
                    Case "Alle Versionen"
                        _cntrl.Visible = True
                    Case "OpenClonk"
                        If _cntrl.CCANObject.GetEngineCategory = "OpenClonk" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Rage"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Rage" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Endeavour"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Endeavour" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk Planet"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk Planet" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                    Case "Clonk 4"
                        If _cntrl.CCANObject.GetEngineCategory = "Clonk 4" Then
                            _cntrl.Visible = True
                        Else
                            _cntrl.Visible = False
                        End If
                End Select

            Else
                _cntrl.Visible = False
            End If
        Next
    End Sub

    Private Sub ccanFilterAll_btn_MouseClick(sender As Object, e As EventArgs) Handles ccanFilterAll_btn.MouseClick, ccanFilterObjects_btn.MouseClick, ccanFilterSzenarios_btn.MouseClick, ccanFilterOther_btn.MouseClick, ccanFilterPackage_btn.MouseClick
        Dim _name As String = DirectCast(sender, PictureBox).Name
        Select Case True
            Case _name.Contains("All")
                ccanSelectedFilter = "ALL"
                ccanFilterAll_btn.BorderStyle = BorderStyle.FixedSingle
                ccanFilterObjects_btn.BorderStyle = BorderStyle.None
                ccanFilterSzenarios_btn.BorderStyle = BorderStyle.None
                ccanFilterOther_btn.BorderStyle = BorderStyle.None
                ccanFilterPackage_btn.BorderStyle = BorderStyle.None
            Case _name.Contains("Objects")
                ccanSelectedFilter = "OBJECT"
                ccanFilterAll_btn.BorderStyle = BorderStyle.None
                ccanFilterObjects_btn.BorderStyle = BorderStyle.FixedSingle
                ccanFilterSzenarios_btn.BorderStyle = BorderStyle.None
                ccanFilterOther_btn.BorderStyle = BorderStyle.None
                ccanFilterPackage_btn.BorderStyle = BorderStyle.None
            Case _name.Contains("Szenarios")
                ccanSelectedFilter = "SZENARIO"
                ccanFilterAll_btn.BorderStyle = BorderStyle.None
                ccanFilterObjects_btn.BorderStyle = BorderStyle.None
                ccanFilterSzenarios_btn.BorderStyle = BorderStyle.FixedSingle
                ccanFilterOther_btn.BorderStyle = BorderStyle.None
                ccanFilterPackage_btn.BorderStyle = BorderStyle.None
            Case _name.Contains("Other")
                ccanSelectedFilter = "OTHER"
                ccanFilterAll_btn.BorderStyle = BorderStyle.None
                ccanFilterObjects_btn.BorderStyle = BorderStyle.None
                ccanFilterSzenarios_btn.BorderStyle = BorderStyle.None
                ccanFilterOther_btn.BorderStyle = BorderStyle.FixedSingle
                ccanFilterPackage_btn.BorderStyle = BorderStyle.None
            Case _name.Contains("Package")
                ccanSelectedFilter = "PACKAGE"
                ccanFilterAll_btn.BorderStyle = BorderStyle.None
                ccanFilterObjects_btn.BorderStyle = BorderStyle.None
                ccanFilterSzenarios_btn.BorderStyle = BorderStyle.None
                ccanFilterOther_btn.BorderStyle = BorderStyle.None
                ccanFilterPackage_btn.BorderStyle = BorderStyle.FixedSingle
        End Select
    End Sub

    'Own Game
    Private Sub RichTextBox1_LinkClicked(sender As Object, e As LinkClickedEventArgs) Handles OwnClonkGameInfo_rtb.LinkClicked
        Select Case MessageBox.Show(Coding(GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_OPENLINKTEXT"), e.LinkText.ToString), GetSpecificLanguageString("MESSAGEBOXTEXT:OTHER_OPENLINKTITLE"), MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            Case System.Windows.Forms.DialogResult.Yes
                Process.Start(e.LinkText.ToString)
        End Select
    End Sub

#End Region

#Region " GChart's - MouseMove "

    Private Sub Clonk4RushHour_GBarChart_MouseMove(sender As Object, e As MouseEventArgs) Handles Clonk4RushHour_GBarChart.MouseMove
        Dim _Color As Color = API_GetPixelColor.GetPixelColor(MousePosition.X, MousePosition.Y)
        If (_Color.R = 255 And _Color.G = 241 And _Color.B = 54) Then ' Montag
            c4_monday_lbl.BackColor = Color.Black
            c4_tuesday_lbl.BackColor = Color.Transparent
            c4_wednesday_lbl.BackColor = Color.Transparent
            c4_thursday_lbl.BackColor = Color.Transparent
            c4_friday_lbl.BackColor = Color.Transparent
            c4_saturday_lbl.BackColor = Color.Transparent
            c4_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 128 And _Color.B = 148) Then ' Dienstag
            c4_tuesday_lbl.BackColor = Color.Black
            c4_monday_lbl.BackColor = Color.Transparent
            c4_wednesday_lbl.BackColor = Color.Transparent
            c4_thursday_lbl.BackColor = Color.Transparent
            c4_friday_lbl.BackColor = Color.Transparent
            c4_saturday_lbl.BackColor = Color.Transparent
            c4_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 118 And _Color.G = 169 And _Color.B = 66) Then ' Mittwoch
            c4_wednesday_lbl.BackColor = Color.Black
            c4_monday_lbl.BackColor = Color.Transparent
            c4_tuesday_lbl.BackColor = Color.Transparent
            c4_thursday_lbl.BackColor = Color.Transparent
            c4_friday_lbl.BackColor = Color.Transparent
            c4_saturday_lbl.BackColor = Color.Transparent
            c4_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 129 And _Color.B = 45) Then ' Donnerstag
            c4_thursday_lbl.BackColor = Color.Black
            c4_monday_lbl.BackColor = Color.Transparent
            c4_tuesday_lbl.BackColor = Color.Transparent
            c4_wednesday_lbl.BackColor = Color.Transparent
            c4_friday_lbl.BackColor = Color.Transparent
            c4_saturday_lbl.BackColor = Color.Transparent
            c4_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 20 And _Color.G = 144 And _Color.B = 178) Then ' Freitag
            c4_friday_lbl.BackColor = Color.Black
            c4_monday_lbl.BackColor = Color.Transparent
            c4_tuesday_lbl.BackColor = Color.Transparent
            c4_wednesday_lbl.BackColor = Color.Transparent
            c4_thursday_lbl.BackColor = Color.Transparent
            c4_saturday_lbl.BackColor = Color.Transparent
            c4_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 157 And _Color.G = 98 And _Color.B = 152) Then ' Samstag
            c4_saturday_lbl.BackColor = Color.Black
            c4_monday_lbl.BackColor = Color.Transparent
            c4_tuesday_lbl.BackColor = Color.Transparent
            c4_wednesday_lbl.BackColor = Color.Transparent
            c4_thursday_lbl.BackColor = Color.Transparent
            c4_friday_lbl.BackColor = Color.Transparent
            c4_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 237 And _Color.G = 38 And _Color.B = 45) Then ' Sonntag
            c4_sunday_lbl.BackColor = Color.Black
            c4_monday_lbl.BackColor = Color.Transparent
            c4_tuesday_lbl.BackColor = Color.Transparent
            c4_wednesday_lbl.BackColor = Color.Transparent
            c4_thursday_lbl.BackColor = Color.Transparent
            c4_friday_lbl.BackColor = Color.Transparent
            c4_saturday_lbl.BackColor = Color.Transparent
        Else
            c4_monday_lbl.BackColor = Color.Transparent
            c4_tuesday_lbl.BackColor = Color.Transparent
            c4_wednesday_lbl.BackColor = Color.Transparent
            c4_thursday_lbl.BackColor = Color.Transparent
            c4_friday_lbl.BackColor = Color.Transparent
            c4_saturday_lbl.BackColor = Color.Transparent
            c4_sunday_lbl.BackColor = Color.Transparent
        End If
    End Sub

    Private Sub ClonkPlanetRushHour_GBarChart_MouseMove(sender As Object, e As MouseEventArgs) Handles ClonkPlanetRushHour_GBarChart.MouseMove
        Dim _Color As Color = API_GetPixelColor.GetPixelColor(MousePosition.X, MousePosition.Y)
        If (_Color.R = 255 And _Color.G = 241 And _Color.B = 54) Then ' Montag
            cp_monday_lbl.BackColor = Color.Black
            cp_tuesday_lbl.BackColor = Color.Transparent
            cp_wednesday_lbl.BackColor = Color.Transparent
            cp_thursday_lbl.BackColor = Color.Transparent
            cp_friday_lbl.BackColor = Color.Transparent
            cp_saturday_lbl.BackColor = Color.Transparent
            cp_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 128 And _Color.B = 148) Then ' Dienstag
            cp_tuesday_lbl.BackColor = Color.Black
            cp_monday_lbl.BackColor = Color.Transparent
            cp_wednesday_lbl.BackColor = Color.Transparent
            cp_thursday_lbl.BackColor = Color.Transparent
            cp_friday_lbl.BackColor = Color.Transparent
            cp_saturday_lbl.BackColor = Color.Transparent
            cp_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 118 And _Color.G = 169 And _Color.B = 66) Then ' Mittwoch
            cp_wednesday_lbl.BackColor = Color.Black
            cp_monday_lbl.BackColor = Color.Transparent
            cp_tuesday_lbl.BackColor = Color.Transparent
            cp_thursday_lbl.BackColor = Color.Transparent
            cp_friday_lbl.BackColor = Color.Transparent
            cp_saturday_lbl.BackColor = Color.Transparent
            cp_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 129 And _Color.B = 45) Then ' Donnerstag
            cp_thursday_lbl.BackColor = Color.Black
            cp_monday_lbl.BackColor = Color.Transparent
            cp_tuesday_lbl.BackColor = Color.Transparent
            cp_wednesday_lbl.BackColor = Color.Transparent
            cp_friday_lbl.BackColor = Color.Transparent
            cp_saturday_lbl.BackColor = Color.Transparent
            cp_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 20 And _Color.G = 144 And _Color.B = 178) Then ' Freitag
            cp_friday_lbl.BackColor = Color.Black
            cp_monday_lbl.BackColor = Color.Transparent
            cp_tuesday_lbl.BackColor = Color.Transparent
            cp_wednesday_lbl.BackColor = Color.Transparent
            cp_thursday_lbl.BackColor = Color.Transparent
            cp_saturday_lbl.BackColor = Color.Transparent
            cp_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 157 And _Color.G = 98 And _Color.B = 152) Then ' Samstag
            cp_saturday_lbl.BackColor = Color.Black
            cp_monday_lbl.BackColor = Color.Transparent
            cp_tuesday_lbl.BackColor = Color.Transparent
            cp_wednesday_lbl.BackColor = Color.Transparent
            cp_thursday_lbl.BackColor = Color.Transparent
            cp_friday_lbl.BackColor = Color.Transparent
            cp_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 237 And _Color.G = 38 And _Color.B = 45) Then ' Sonntag
            cp_sunday_lbl.BackColor = Color.Black
            cp_monday_lbl.BackColor = Color.Transparent
            cp_tuesday_lbl.BackColor = Color.Transparent
            cp_wednesday_lbl.BackColor = Color.Transparent
            cp_thursday_lbl.BackColor = Color.Transparent
            cp_friday_lbl.BackColor = Color.Transparent
            cp_saturday_lbl.BackColor = Color.Transparent
        Else
            cp_monday_lbl.BackColor = Color.Transparent
            cp_tuesday_lbl.BackColor = Color.Transparent
            cp_wednesday_lbl.BackColor = Color.Transparent
            cp_thursday_lbl.BackColor = Color.Transparent
            cp_friday_lbl.BackColor = Color.Transparent
            cp_saturday_lbl.BackColor = Color.Transparent
            cp_sunday_lbl.BackColor = Color.Transparent
        End If
    End Sub

    Private Sub ClonkEndeavourRushHour_GBarChart_MouseMove(sender As Object, e As MouseEventArgs) Handles ClonkEndeavourRushHour_GBarChart.MouseMove
        Dim _Color As Color = API_GetPixelColor.GetPixelColor(MousePosition.X, MousePosition.Y)
        If (_Color.R = 255 And _Color.G = 241 And _Color.B = 54) Then ' Montag
            ce_monday_lbl.BackColor = Color.Black
            ce_tuesday_lbl.BackColor = Color.Transparent
            ce_wednesday_lbl.BackColor = Color.Transparent
            ce_thursday_lbl.BackColor = Color.Transparent
            ce_friday_lbl.BackColor = Color.Transparent
            ce_saturday_lbl.BackColor = Color.Transparent
            ce_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 128 And _Color.B = 148) Then ' Dienstag
            ce_tuesday_lbl.BackColor = Color.Black
            ce_monday_lbl.BackColor = Color.Transparent
            ce_wednesday_lbl.BackColor = Color.Transparent
            ce_thursday_lbl.BackColor = Color.Transparent
            ce_friday_lbl.BackColor = Color.Transparent
            ce_saturday_lbl.BackColor = Color.Transparent
            ce_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 118 And _Color.G = 169 And _Color.B = 66) Then ' Mittwoch
            ce_wednesday_lbl.BackColor = Color.Black
            ce_monday_lbl.BackColor = Color.Transparent
            ce_tuesday_lbl.BackColor = Color.Transparent
            ce_thursday_lbl.BackColor = Color.Transparent
            ce_friday_lbl.BackColor = Color.Transparent
            ce_saturday_lbl.BackColor = Color.Transparent
            ce_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 129 And _Color.B = 45) Then ' Donnerstag
            ce_thursday_lbl.BackColor = Color.Black
            ce_monday_lbl.BackColor = Color.Transparent
            ce_tuesday_lbl.BackColor = Color.Transparent
            ce_wednesday_lbl.BackColor = Color.Transparent
            ce_friday_lbl.BackColor = Color.Transparent
            ce_saturday_lbl.BackColor = Color.Transparent
            ce_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 20 And _Color.G = 144 And _Color.B = 178) Then ' Freitag
            ce_friday_lbl.BackColor = Color.Black
            ce_monday_lbl.BackColor = Color.Transparent
            ce_tuesday_lbl.BackColor = Color.Transparent
            ce_wednesday_lbl.BackColor = Color.Transparent
            ce_thursday_lbl.BackColor = Color.Transparent
            ce_saturday_lbl.BackColor = Color.Transparent
            ce_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 157 And _Color.G = 98 And _Color.B = 152) Then ' Samstag
            ce_saturday_lbl.BackColor = Color.Black
            ce_monday_lbl.BackColor = Color.Transparent
            ce_tuesday_lbl.BackColor = Color.Transparent
            ce_wednesday_lbl.BackColor = Color.Transparent
            ce_thursday_lbl.BackColor = Color.Transparent
            ce_friday_lbl.BackColor = Color.Transparent
            ce_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 237 And _Color.G = 38 And _Color.B = 45) Then ' Sonntag
            ce_sunday_lbl.BackColor = Color.Black
            ce_monday_lbl.BackColor = Color.Transparent
            ce_tuesday_lbl.BackColor = Color.Transparent
            ce_wednesday_lbl.BackColor = Color.Transparent
            ce_thursday_lbl.BackColor = Color.Transparent
            ce_friday_lbl.BackColor = Color.Transparent
            ce_saturday_lbl.BackColor = Color.Transparent
        Else
            ce_monday_lbl.BackColor = Color.Transparent
            ce_tuesday_lbl.BackColor = Color.Transparent
            ce_wednesday_lbl.BackColor = Color.Transparent
            ce_thursday_lbl.BackColor = Color.Transparent
            ce_friday_lbl.BackColor = Color.Transparent
            ce_saturday_lbl.BackColor = Color.Transparent
            ce_sunday_lbl.BackColor = Color.Transparent
        End If
    End Sub

    Private Sub ClonkRageRushHour_GBarChart_MouseMove(sender As Object, e As MouseEventArgs) Handles ClonkRageRushHour_GBarChart.MouseMove
        Dim _Color As Color = API_GetPixelColor.GetPixelColor(MousePosition.X, MousePosition.Y)
        If (_Color.R = 255 And _Color.G = 241 And _Color.B = 54) Then ' Montag
            cr_monday_lbl.BackColor = Color.Black
            cr_tuesday_lbl.BackColor = Color.Transparent
            cr_wednesday_lbl.BackColor = Color.Transparent
            cr_thursday_lbl.BackColor = Color.Transparent
            cr_friday_lbl.BackColor = Color.Transparent
            cr_saturday_lbl.BackColor = Color.Transparent
            cr_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 128 And _Color.B = 148) Then ' Dienstag
            cr_tuesday_lbl.BackColor = Color.Black
            cr_monday_lbl.BackColor = Color.Transparent
            cr_wednesday_lbl.BackColor = Color.Transparent
            cr_thursday_lbl.BackColor = Color.Transparent
            cr_friday_lbl.BackColor = Color.Transparent
            cr_saturday_lbl.BackColor = Color.Transparent
            cr_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 118 And _Color.G = 169 And _Color.B = 66) Then ' Mittwoch
            cr_wednesday_lbl.BackColor = Color.Black
            cr_monday_lbl.BackColor = Color.Transparent
            cr_tuesday_lbl.BackColor = Color.Transparent
            cr_thursday_lbl.BackColor = Color.Transparent
            cr_friday_lbl.BackColor = Color.Transparent
            cr_saturday_lbl.BackColor = Color.Transparent
            cr_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 129 And _Color.B = 45) Then ' Donnerstag
            cr_thursday_lbl.BackColor = Color.Black
            cr_monday_lbl.BackColor = Color.Transparent
            cr_tuesday_lbl.BackColor = Color.Transparent
            cr_wednesday_lbl.BackColor = Color.Transparent
            cr_friday_lbl.BackColor = Color.Transparent
            cr_saturday_lbl.BackColor = Color.Transparent
            cr_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 20 And _Color.G = 144 And _Color.B = 178) Then ' Freitag
            cr_friday_lbl.BackColor = Color.Black
            cr_monday_lbl.BackColor = Color.Transparent
            cr_tuesday_lbl.BackColor = Color.Transparent
            cr_wednesday_lbl.BackColor = Color.Transparent
            cr_thursday_lbl.BackColor = Color.Transparent
            cr_saturday_lbl.BackColor = Color.Transparent
            cr_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 157 And _Color.G = 98 And _Color.B = 152) Then ' Samstag
            cr_saturday_lbl.BackColor = Color.Black
            cr_monday_lbl.BackColor = Color.Transparent
            cr_tuesday_lbl.BackColor = Color.Transparent
            cr_wednesday_lbl.BackColor = Color.Transparent
            cr_thursday_lbl.BackColor = Color.Transparent
            cr_friday_lbl.BackColor = Color.Transparent
            cr_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 237 And _Color.G = 38 And _Color.B = 45) Then ' Sonntag
            cr_sunday_lbl.BackColor = Color.Black
            cr_monday_lbl.BackColor = Color.Transparent
            cr_tuesday_lbl.BackColor = Color.Transparent
            cr_wednesday_lbl.BackColor = Color.Transparent
            cr_thursday_lbl.BackColor = Color.Transparent
            cr_friday_lbl.BackColor = Color.Transparent
            cr_saturday_lbl.BackColor = Color.Transparent
        Else
            cr_monday_lbl.BackColor = Color.Transparent
            cr_tuesday_lbl.BackColor = Color.Transparent
            cr_wednesday_lbl.BackColor = Color.Transparent
            cr_thursday_lbl.BackColor = Color.Transparent
            cr_friday_lbl.BackColor = Color.Transparent
            cr_saturday_lbl.BackColor = Color.Transparent
            cr_sunday_lbl.BackColor = Color.Transparent
        End If
    End Sub

    Private Sub OpenClonkRushHour_GBarChart_MouseMove(sender As Object, e As MouseEventArgs) Handles OpenClonkRushHour_GBarChart.MouseMove
        Dim _Color As Color = API_GetPixelColor.GetPixelColor(MousePosition.X, MousePosition.Y)
        If (_Color.R = 255 And _Color.G = 241 And _Color.B = 54) Then ' Montag
            oc_monday_lbl.BackColor = Color.Black
            oc_tuesday_lbl.BackColor = Color.Transparent
            oc_wednesday_lbl.BackColor = Color.Transparent
            oc_thursday_lbl.BackColor = Color.Transparent
            oc_friday_lbl.BackColor = Color.Transparent
            oc_saturday_lbl.BackColor = Color.Transparent
            oc_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 128 And _Color.B = 148) Then ' Dienstag
            oc_tuesday_lbl.BackColor = Color.Black
            oc_monday_lbl.BackColor = Color.Transparent
            oc_wednesday_lbl.BackColor = Color.Transparent
            oc_thursday_lbl.BackColor = Color.Transparent
            oc_friday_lbl.BackColor = Color.Transparent
            oc_saturday_lbl.BackColor = Color.Transparent
            oc_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 118 And _Color.G = 169 And _Color.B = 66) Then ' Mittwoch
            oc_wednesday_lbl.BackColor = Color.Black
            oc_monday_lbl.BackColor = Color.Transparent
            oc_tuesday_lbl.BackColor = Color.Transparent
            oc_thursday_lbl.BackColor = Color.Transparent
            oc_friday_lbl.BackColor = Color.Transparent
            oc_saturday_lbl.BackColor = Color.Transparent
            oc_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 241 And _Color.G = 129 And _Color.B = 45) Then ' Donnerstag
            oc_thursday_lbl.BackColor = Color.Black
            oc_monday_lbl.BackColor = Color.Transparent
            oc_tuesday_lbl.BackColor = Color.Transparent
            oc_wednesday_lbl.BackColor = Color.Transparent
            oc_friday_lbl.BackColor = Color.Transparent
            oc_saturday_lbl.BackColor = Color.Transparent
            oc_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 20 And _Color.G = 144 And _Color.B = 178) Then ' Freitag
            oc_friday_lbl.BackColor = Color.Black
            oc_monday_lbl.BackColor = Color.Transparent
            oc_tuesday_lbl.BackColor = Color.Transparent
            oc_wednesday_lbl.BackColor = Color.Transparent
            oc_thursday_lbl.BackColor = Color.Transparent
            oc_saturday_lbl.BackColor = Color.Transparent
            oc_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 157 And _Color.G = 98 And _Color.B = 152) Then ' Samstag
            oc_saturday_lbl.BackColor = Color.Black
            oc_monday_lbl.BackColor = Color.Transparent
            oc_tuesday_lbl.BackColor = Color.Transparent
            oc_wednesday_lbl.BackColor = Color.Transparent
            oc_thursday_lbl.BackColor = Color.Transparent
            oc_friday_lbl.BackColor = Color.Transparent
            oc_sunday_lbl.BackColor = Color.Transparent
        ElseIf (_Color.R = 237 And _Color.G = 38 And _Color.B = 45) Then ' Sonntag
            oc_sunday_lbl.BackColor = Color.Black
            oc_monday_lbl.BackColor = Color.Transparent
            oc_tuesday_lbl.BackColor = Color.Transparent
            oc_wednesday_lbl.BackColor = Color.Transparent
            oc_thursday_lbl.BackColor = Color.Transparent
            oc_friday_lbl.BackColor = Color.Transparent
            oc_saturday_lbl.BackColor = Color.Transparent
        Else
            oc_monday_lbl.BackColor = Color.Transparent
            oc_tuesday_lbl.BackColor = Color.Transparent
            oc_wednesday_lbl.BackColor = Color.Transparent
            oc_thursday_lbl.BackColor = Color.Transparent
            oc_friday_lbl.BackColor = Color.Transparent
            oc_saturday_lbl.BackColor = Color.Transparent
            oc_sunday_lbl.BackColor = Color.Transparent
        End If
    End Sub

#End Region

#Region "Network"

    Private Sub UTC_ConnectionLost(sReason As String)
        If Me.InvokeRequired = True Then ' From another Thread
            Me.Invoke(New MethodInvoker(Sub() user_picbox.Image = My.Resources.clonk_user_syncFailed))
            Me.Invoke(New MethodInvoker(Sub() ccanServerStatus_lbl.Visible = True))
            Me.Invoke(New MethodInvoker(Sub() ccanLoading_picbox.Visible = False))
        Else
            user_picbox.Image = My.Resources.clonk_user_syncFailed
            ccanServerStatus_lbl.Visible = True
            ccanLoading_picbox.Visible = False
        End If

        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, Coding(GetSpecificLanguageString("MESSAGEBOXTEXT:SERVER_CONNECTIONLOSTREASON"), sReason))
        _newMsg.ShowDialog()
    End Sub
    Private Sub UTC_ConnectionNotPossible(sReason As String)
        If Me.InvokeRequired = True Then ' From another Thread
            Me.Invoke(New MethodInvoker(Sub() user_picbox.Image = My.Resources.clonk_user_syncFailed))
            Me.Invoke(New MethodInvoker(Sub() ccanServerStatus_lbl.Visible = True))
            Me.Invoke(New MethodInvoker(Sub() ccanLoading_picbox.Visible = False))
        Else
            user_picbox.Image = My.Resources.clonk_user_syncFailed
            ccanServerStatus_lbl.Visible = True
            ccanLoading_picbox.Visible = False
        End If
    End Sub
    Private Sub UTC_ShutdownFinished()

    End Sub

    Private Sub UTC_IDisGone(sID As String)

    End Sub
    Private Sub UTC_IDjoined(sID As String)

    End Sub
    Private Sub UTC_IDlistChanged(sIDs As List(Of String))
        Networking.UTC.sendUTicket("@all", "Chat:RequestAllUsers", QClipboard.AccountName)
    End Sub

    Private Sub UTC_UTicketArrived(sSenderID As String, bSentToAll As Boolean, sCommand As String, oUserData As List(Of Object))
        Select Case sCommand

            Case "Command:Message"
                If ShowChatMsg = True Then
                    If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                        If Not oUserData(1).ToString = QClipboard.AccountName Then
                            NotifyIcon1.ShowBalloonTip(4000, oUserData(1).ToString, oUserData(0).ToString, ToolTipIcon.None)
                        End If
                    End If
                End If

            Case "Server:Restart"
                If sSenderID = "ADMIN" Then
                    NotifyIcon1.ShowBalloonTip(6000, "Xtreme-Clonk-Launcher", Coding(GetSpecificLanguageString("MESSAGEBOXTEXT:SERVER_RESTARTINFO"), oUserData(0).ToString), ToolTipIcon.Warning)
                End If

            Case "Server:Shutdown"
                If sSenderID = "ADMIN" Then
                    NotifyIcon1.ShowBalloonTip(6000, "Xtreme-Clonk-Launcher", Coding(GetSpecificLanguageString("MESSAGEBOXTEXT:SERVER_SHUTDOWNINFO"), oUserData(0).ToString), ToolTipIcon.Warning)
                End If

            Case "Command:Ban"
                Try
                    If Me.InvokeRequired = True Then ' From another Thread
                        Me.Invoke(New MethodInvoker(Sub() Networking.Shutdown()))
                        Me.Invoke(New MethodInvoker(Sub() user_picbox.Image = My.Resources.clonk_user_syncFailed))
                        Me.Invoke(New MethodInvoker(Sub() ccanServerStatus_lbl.Visible = True))
                        Me.Invoke(New MethodInvoker(Sub() ccanLoading_picbox.Visible = False))
                    Else
                        Networking.Shutdown()
                        user_picbox.Image = My.Resources.clonk_user_syncFailed
                        ccanServerStatus_lbl.Visible = True
                        ccanLoading_picbox.Visible = False
                    End If

                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:BANNED_FROMSERVERINFO"))
                    _newMsg.ShowDialog()
                Catch ex As Exception : End Try

            Case "Command:Kick"
                Try
                    If Me.InvokeRequired = True Then ' From another Thread
                        Me.Invoke(New MethodInvoker(Sub() Networking.Shutdown()))
                        Me.Invoke(New MethodInvoker(Sub() user_picbox.Image = My.Resources.clonk_user_syncFailed))
                        Me.Invoke(New MethodInvoker(Sub() ccanServerStatus_lbl.Visible = True))
                        Me.Invoke(New MethodInvoker(Sub() ccanLoading_picbox.Visible = False))
                    Else
                        Networking.Shutdown()
                        user_picbox.Image = My.Resources.clonk_user_syncFailed
                        ccanServerStatus_lbl.Visible = True
                        ccanLoading_picbox.Visible = False
                    End If

                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Attention, GetSpecificLanguageString("MESSAGEBOXTEXT:KICKED_FROMSERVERINFO"))
                    _newMsg.ShowDialog()

                    'NotifyIcon1.ShowBalloonTip(4000, "Du wurdest gekickt!", "Der Serveradmin hat dich vom Server gekickt! Falls dies nicht ausversehen geschehen.", ToolTipIcon.Warning)
                Catch ex As Exception : End Try

            Case "RefreshAll"
                Networking.UTC.sendUTicket("@all", "Chat:RequestAllUsers", QClipboard.AccountName)

            Case "Chat:GettingAllUsers"
                Dim _usr As New NewMetroButton

                If Me.InvokeRequired = True Then ' From another Thread
                    Me.Invoke(New MethodInvoker(Sub() friendsOnline_flp.Controls.Clear())) ' Clear list
                Else
                    friendsOnline_flp.Controls.Clear() ' Clear list
                End If

                For Each _Username As String In oUserData
                    _usr = New NewMetroButton
                    _usr.Name = _Username
                    _usr.Text = _Username
                    _usr.RoundingArc = 25
                    _usr.Size = New Size(415, 41)
                    _usr.Icon = My.Resources.clonk_user_loggedin
                    _usr.ScaleImage = True

                    AddHandler _usr.Click, AddressOf _usr_click

                    If Me.InvokeRequired = True Then ' From another Thread
                        Me.Invoke(New MethodInvoker(Sub() friendsOnline_flp.Controls.Add(_usr))) ' Add User
                    Else
                        friendsOnline_flp.Controls.Add(_usr) ' Add User
                    End If
                Next

            Case "ToUser:RushHour:ReceiveNewData"
                Try
                    Dim c(6) As Color
                    Dim oc_bcData As New GBarChartData With {.BarSize = 25, .FillColors = c}
                    Dim cr_bcData As New GBarChartData With {.BarSize = 25, .FillColors = c}
                    Dim ce_bcData As New GBarChartData With {.BarSize = 25, .FillColors = c}
                    Dim cp_bcData As New GBarChartData With {.BarSize = 25, .FillColors = c}
                    Dim c4_bcData As New GBarChartData With {.BarSize = 25, .FillColors = c}

                    ' Clear old Data
                    If Me.InvokeRequired = True Then ' From another Thread
                        Me.Invoke(New MethodInvoker(Sub() OpenClonkRushHour_GBarChart.Data.Clear()))
                        Me.Invoke(New MethodInvoker(Sub() ClonkRageRushHour_GBarChart.Data.Clear()))
                        Me.Invoke(New MethodInvoker(Sub() ClonkEndeavourRushHour_GBarChart.Data.Clear()))
                        Me.Invoke(New MethodInvoker(Sub() ClonkPlanetRushHour_GBarChart.Data.Clear()))
                        Me.Invoke(New MethodInvoker(Sub() Clonk4RushHour_GBarChart.Data.Clear()))
                    Else
                        OpenClonkRushHour_GBarChart.Data.Clear()
                        ClonkRageRushHour_GBarChart.Data.Clear()
                        ClonkEndeavourRushHour_GBarChart.Data.Clear()
                        ClonkPlanetRushHour_GBarChart.Data.Clear()
                        Clonk4RushHour_GBarChart.Data.Clear()
                    End If

                    ' Bars Color
                    c(0) = Color.FromArgb(255, 241, 54) ' Montag
                    c(1) = Color.FromArgb(241, 128, 148) ' Dienstag
                    c(2) = Color.FromArgb(118, 169, 66) ' Mittwoch
                    c(3) = Color.FromArgb(241, 129, 45) ' Donnerstag
                    c(4) = Color.FromArgb(20, 144, 178) ' Freitag
                    c(5) = Color.FromArgb(157, 98, 152) ' Samstag
                    c(6) = Color.FromArgb(237, 38, 45) ' Sonntag

                    ' Bars Values
                    If Not (oUserData(0) Is Nothing) Then
                        oc_bcData.Values = CType(oUserData(0), Integer())
                    End If
                    If Not (oUserData(1) Is Nothing) Then
                        cr_bcData.Values = CType(oUserData(1), Integer())
                    End If
                    If Not (oUserData(2) Is Nothing) Then
                        ce_bcData.Values = CType(oUserData(2), Integer())
                    End If
                    If Not (oUserData(3) Is Nothing) Then
                        cp_bcData.Values = CType(oUserData(3), Integer())
                    End If
                    If Not (oUserData(4) Is Nothing) Then
                        c4_bcData.Values = CType(oUserData(4), Integer())
                    End If

                    'Dim v(6) As Integer
                    'v(0) = 22 ' Montag
                    'v(1) = 35 ' Dienstag
                    'v(2) = 5 ' Mittwoch
                    'v(3) = 5 ' Donnerstag
                    'v(4) = 5 ' Freitag
                    'v(5) = 5 ' Samstag
                    'v(6) = 5 ' Sonntag

                    If Me.InvokeRequired = True Then ' From another Thread
                        Me.Invoke(New MethodInvoker(Sub() OpenClonkRushHour_GBarChart.Data.Add(oc_bcData)))
                        Me.Invoke(New MethodInvoker(Sub() ClonkRageRushHour_GBarChart.Data.Add(cr_bcData)))
                        Me.Invoke(New MethodInvoker(Sub() ClonkEndeavourRushHour_GBarChart.Data.Add(ce_bcData)))
                        Me.Invoke(New MethodInvoker(Sub() ClonkPlanetRushHour_GBarChart.Data.Add(cp_bcData)))
                        Me.Invoke(New MethodInvoker(Sub() Clonk4RushHour_GBarChart.Data.Add(c4_bcData)))
                    Else
                        OpenClonkRushHour_GBarChart.Data.Add(oc_bcData)
                        ClonkRageRushHour_GBarChart.Data.Add(cr_bcData)
                        ClonkEndeavourRushHour_GBarChart.Data.Add(ce_bcData)
                        ClonkPlanetRushHour_GBarChart.Data.Add(cp_bcData)
                        Clonk4RushHour_GBarChart.Data.Add(c4_bcData)
                    End If

                Catch ex As Exception
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, Coding(GetSpecificLanguageString("MESSAGEBOXTEXT:RUSHHOUR_PROCESSINGFAILED"), ex.Message))
                    _newMsg.ShowDialog()
                End Try

            Case "ToUser:ReceiveAllNotifications"
                Try
                    Dim NewNotification As FriendRequestUC

                    For Each _Notification As String In oUserData
                        Dim NType As String = _Notification.Split(CChar("|"))(0)
                        Dim NName As String = _Notification.Split(CChar("|"))(1)

                        Select Case NType

                            Case "FRIENDREQUEST"
                                NewNotification = New FriendRequestUC
                                NewNotification.Username = NName
                                Notifications_flp.Controls.Add(NewNotification)

                        End Select
                    Next
                Catch ex As Exception
                    MessageBox.Show(ex.ToString)
                End Try

            Case "ToClient:CCAN:ListObjects"
                Try
                    Dim _CCANObject As New CCANobject(oUserData(0).ToString, oUserData(1).ToString, oUserData(11).ToString, oUserData(2).ToString, oUserData(6).ToString, oUserData(7).ToString, oUserData(5).ToString, CBool(oUserData(4)), oUserData(3).ToString, CInt(oUserData(9)), CInt(oUserData(8)), oUserData(10).ToString, oUserData(12).ToString, oUserData(13).ToString, oUserData(14).ToString, CType(oUserData(15), Byte()))
                    Dim _CCANPreview As CCANObjectPreviewUC

                    If Me.InvokeRequired = True Then ' From another Thread
                        Me.Invoke(New MethodInvoker(Sub() _CCANPreview = New CCANObjectPreviewUC(_CCANObject, Nothing)))
                        Me.Invoke(New MethodInvoker(Sub() ccanObjects_flp.Controls.Add(_CCANPreview)))
                    Else
                        _CCANPreview = New CCANObjectPreviewUC(_CCANObject, Nothing)
                        ccanObjects_flp.Controls.Add(_CCANPreview)
                    End If

                Catch ex As Exception
                    MessageBox.Show(ex.ToString)
                End Try

            Case "ToClient:CCAN:ListObjectsStatus"
                Select Case oUserData(0).ToString

                    Case "ERROR"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() ccanLoading_picbox.Visible = False))
                            Me.Invoke(New MethodInvoker(Sub() ccanObjects_flp.Enabled = True))
                        Else
                            ccanLoading_picbox.Visible = False
                            ccanObjects_flp.Enabled = True
                        End If

                        'Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Es ist ein Fehler beim auflisten der Objekte aufgetreten!" & Environment.NewLine & oUserData(1).ToString)
                        '_newMsg.ShowDialog()

                    Case "SUCCESS"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() ccanLoading_picbox.Visible = False))
                            Me.Invoke(New MethodInvoker(Sub() SortCCANObjects(ccanObjects_flp, 0))) ' Sortiert alle Objekte nach Datum
                            Me.Invoke(New MethodInvoker(Sub() ccanObjects_flp.Enabled = True))
                        Else
                            ccanLoading_picbox.Visible = False
                            SortCCANObjects(ccanObjects_flp, 0) ' Sortiert alle Objekte nach Datum
                            ccanObjects_flp.Enabled = True
                        End If

                End Select

            Case "ToClient:News:ListObject"
                Try
                    Dim NewNewsObject As New NewsUC(oUserData(0).ToString, oUserData(4).ToString, oUserData(2).ToString, oUserData(3).ToString, oUserData(1).ToString)

                    If Me.InvokeRequired = True Then ' From another Thread
                        Me.Invoke(New MethodInvoker(Sub() AllNews_flp.Controls.Add(NewNewsObject)))
                    Else
                        AllNews_flp.Controls.Add(NewNewsObject)
                    End If
                Catch ex As Exception
                    MessageBox.Show(ex.ToString)
                End Try

            Case "ToClient:News:ReceiveStatus"
                Select Case oUserData(0).ToString

                    Case "ERROR"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() NewsLoading_picbox.Visible = False))
                            Me.Invoke(New MethodInvoker(Sub() AllNews_flp.Enabled = True))
                        Else
                            NewsLoading_picbox.Visible = False
                            AllNews_flp.Enabled = True
                        End If

                    Case "SUCCESS"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() NewsLoading_picbox.Visible = False))
                            Me.Invoke(New MethodInvoker(Sub() AllNews_flp.Enabled = True))
                        Else
                            NewsLoading_picbox.Visible = False
                            AllNews_flp.Enabled = True
                        End If

                End Select

        End Select
    End Sub

    ' Handlers
    Private Sub _usr_click(sender As Object, e As EventArgs)
        If QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym Then
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:FRIENDSCHAT_LOGINNEEDED"))
            _newMsg.ShowDialog()
        Else
            Friends.Show()
        End If
    End Sub

#End Region

    Private Sub Main_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        Select Case e.KeyCode
            Case Keys.F8
                Debug_frm.Show()
        End Select
    End Sub
    Private Sub Main_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Try
            If System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\temp")) Then ' Delete Temp Directory
                System.IO.Directory.Delete(MakeLinuxCompatible(".\Data\temp"), True)
            End If

            'NotifyIcon
            NotifyIcon1.Visible = False
            NotifyIcon1.Dispose()

            'Browser
            For Each _browser As Gecko.GeckoWebBrowser In GeckoFXBrowserList
                _browser.Dispose()
            Next

            Xpcom.Shutdown()

            ' Settings
            My.Settings.Save()

            ' Client side
            Networking.Shutdown()
        Catch ex As Exception : End Try
    End Sub
    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ApplyTheme() ' Set Theme

        '  Initialize GeckoFX Browser
        If Not System.IO.Directory.Exists(MakeLinuxCompatible(".\Data\xulrunner\Profile")) Then ' Check and create Profile Directory
            System.IO.Directory.CreateDirectory(MakeLinuxCompatible(".\Data\xulrunner\Profile"))
        End If

        Xpcom.ProfileDirectory = MakeLinuxCompatible(".\Data\xulrunner\Profile") ' Set Profile Directory
        Xpcom.Initialize(MakeLinuxCompatible(".\Data\xulrunner")) ' Finally Initialize GeckoFX Browser

        Gecko.GeckoPreferences.User.SetBoolPref("gfx.direct2d.disabled", True) ' Set Settings for GeckoFX Browser
        Gecko.GeckoPreferences.User.SetBoolPref("layers.acceleration.disabled", True)

        ' AddHandler's
        If Not Networking.IsObjectNothing Then
            AddHandler Networking.UTC.ConnectionLost, AddressOf UTC_ConnectionLost
            AddHandler Networking.UTC.ConnectionNotPossible, AddressOf UTC_ConnectionNotPossible
            AddHandler Networking.UTC.ShutdownFinished, AddressOf UTC_ShutdownFinished

            AddHandler Networking.UTC.IDisGone, AddressOf UTC_IDisGone
            AddHandler Networking.UTC.IDjoined, AddressOf UTC_IDjoined
            AddHandler Networking.UTC.IDlistChanged, AddressOf UTC_IDlistChanged

            AddHandler Networking.UTC.UTicketArrived, AddressOf UTC_UTicketArrived
        End If

        ' StartTabPage
        If System.IO.File.Exists(MakeLinuxCompatible(".\settings.ini")) Then
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))
            Select Case _IniFile.Sections("Settings").Keys("StartTabPage").Value
                Case "Start"
                    MetroTabControl2.SelectedTab = StartTabPage_tp
                Case "Library"
                    MetroTabControl2.SelectedTab = LibraryTabPage_tp
                Case "CCAN 2.0"
                    MetroTabControl2.SelectedTab = CCANTabPage_tp
                Case "News"
                    MetroTabControl2.SelectedTab = NewsTabPage_tp
                Case "Events"
                    MetroTabControl2.SelectedTab = EventsTabPage_tp
                Case Else
                    MetroTabControl2.SelectedTab = StartTabPage_tp
            End Select
        Else
            MetroTabControl2.SelectedTab = StartTabPage_tp
        End If

        ' Temp
        Dim tempDir As String = MakeLinuxCompatible(".\Data\temp")

        ' Create Temp Folder
        If System.IO.Directory.Exists(tempDir) Then
            System.IO.Directory.Delete(tempDir, True)
        End If

        System.IO.Directory.CreateDirectory(tempDir)

        ' CreateBrowser (recommended: put this in a async sub for much less lag)
        Try
            For i = 1 To 7
                Select Case i
                    Case 1
                        CreateBrowser("GeckoFX_YouTubeNews", StringDownloaderWebClient.DownloadString(New Uri("https://www.dropbox.com/s/lkuc96w0sqq5fkj/NewYouTubeVideoLink.txt?dl=1")), StartTabPage_tp, New Point(12, 80), New Size(718, 409), AnchorStyles.None) ' Home
                    Case 2
                        CreateBrowser("GeckoFX_EventLivestream", "https://player.twitch.tv/?channel=tehlau&enableExtensions=false&muted=true&player=popout&volume=0.5", EventsTabPage_tp, New Point(309, 197), New Size(599, 330), AnchorStyles.Bottom Or AnchorStyles.Right Or AnchorStyles.Left Or AnchorStyles.Top) ' Events
                    Case 3
                        CreateBrowser("GeckoFX_OC_YouTubeTrailer", "https://www.youtube.com/embed/dGYkkWOZw6U?rel=0&autoplay=0&controls=1&fs=0&iv_load_policy=3", TabPage1, New Point(594, 261), New Size(481, 287), AnchorStyles.Bottom Or AnchorStyles.Right) ' OpenClonk
                    Case 4
                        CreateBrowser("GeckoFX_CR_YouTubeTrailer", "https://www.youtube.com/embed/p83_ONA9qyw?rel=0&autoplay=0&controls=1&fs=0&iv_load_policy=3", TabPage2, New Point(594, 261), New Size(481, 287), AnchorStyles.Bottom Or AnchorStyles.Right) ' Clonk Rage
                    Case 5
                        CreateBrowser("GeckoFX_CE_YouTubeTrailer", "https://www.youtube.com/embed/PzzTMpAfOGA?rel=0&autoplay=0&controls=1&fs=0&iv_load_policy=3", TabPage3, New Point(594, 261), New Size(481, 287), AnchorStyles.Bottom Or AnchorStyles.Right) ' Clonk Endeavour
                    Case 6
                        CreateBrowser("GeckoFX_CP_YouTubeTrailer", "https://www.youtube.com/embed/kgPC479ZkSA?rel=0&autoplay=0&controls=1&fs=0&iv_load_policy=3", TabPage4, New Point(594, 261), New Size(481, 287), AnchorStyles.Bottom Or AnchorStyles.Right) ' Clonk Planet
                    Case 7
                        CreateBrowser("GeckoFX_C4_YouTubeTrailer", "https://www.youtube.com/embed/zPs36jNC1PQ?rel=0&autoplay=0&controls=1&fs=0&iv_load_policy=3", TabPage5, New Point(594, 261), New Size(481, 287), AnchorStyles.Bottom Or AnchorStyles.Right) ' Clonk 4
                End Select
            Next i
        Catch ex As Exception
            WebbrowserErrorPanel(True)
            MessageBox.Show(ex.Message, "Error while creating GeckoFX Browser", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        ' LoadSettings
        ReloadSettings()

        ' ApplyLanguage
        ApplyLanguage()

        ' LoadQuickLaunch
        ReloadQuickLaunch()

        ' Setup Charts
        SetupCharts()

        ' Checking
        CheckIfGamesExists()
        CheckClonkProcess_tmr.Start() ' Start checking for clonk instances
        Checker_tmr.Start() ' Timer for general things

        ' CheckLoggedInMode
        If QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym Then
            user_picbox.Image = My.Resources.clonk_user_unknown

            username_hst.InputText = Coding(GetSpecificLanguageString("MAIN:OTHER_LOGGEDINASTEXT"), "Anonym")
            username_hst.StartScrolling()
        Else
            user_picbox.Image = My.Resources.clonk_user_loggedin

            username_hst.InputText = Coding(GetSpecificLanguageString("MAIN:OTHER_LOGGEDINASTEXT"), QClipboard.AccountName)
            username_hst.StartScrolling()
        End If

        ' Set Standard Value
        CCANversionFilter_mcbox.SelectedItem = "Alle Versionen"
        CCANratingFilter_mcbox.SelectedItem = "Alle Bewertungen"
        CCANdateFilter_mcbox.SelectedItem = "Neuste zuerst"

        ' SetRoundingArc
        ShowProfile_btn.RoundingArc = 13
        FriendsList_btn.RoundingArc = 13
        Settings_btn.RoundingArc = 13
        Notifications_btn.RoundingArc = 13

        ' Set welcome text
        status_lbl.Text = GetSpecificLanguageString("MAIN:START_WELCOMETEXT")

        ' DownloadInfo
        Try ' Temporary
            DownloadChangelogAsyncWebClient.DownloadStringAsync(New Uri("- ENTER URL HERE FOR CHANGELOG INFORMATION - Example for Dropbox: https://www.dropbox.com/s/.../changelog.txt?dl=1"))
            DownloadNewsAsyncWebClient.DownloadStringAsync(New Uri("- ENTER URL HERE FOR NEWS INFORMATION - Example for Dropbox: https://www.dropbox.com/s/.../News.txt?dl=1"))
        Catch ex As Exception
            ' Temporary
        End Try

        ' CheckForUpdates
        CheckForUpdates(False, False)

        ' Get Data / Checking / No need to Login
        If Networking.IsConnectionAlive Then ' Connection alive
            Networking.UTC.sendUTicket("ADMIN", "ToServer:RushHour:RequestRefresh", "") ' Get RushHour Data
            Networking.UTC.sendUTicket("ADMIN", "ToServer:News:ListAllObjects", "") ' Get all News Objects
            Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:ListAllObjects", "") ' Get all CCAN Objects
            Networking.UTC.sendUTicket("@all", "Chat:RequestAllUsers", QClipboard.AccountName) ' Get all Users
            'Networking.UTC.sendUTicket("@all", "Chat:RequestAllFriends", QClipboard.AccountName) ' Get all Friends

            ccanObjects_flp.Enabled = False
            ccanServerStatus_lbl.Visible = False
            ccanLoading_picbox.Visible = True
        Else ' Connection not alive
            ccanObjects_flp.Enabled = True
            ccanServerStatus_lbl.Visible = True
            ccanLoading_picbox.Visible = False
        End If

        ' Get Data / Checking / Login required
        If Networking.IsConnectionAlive Then
            If QClipboard.LoggedOnMode = QClipboard.LoginMode.User Then
                Networking.UTC.sendUTicket("ADMIN", "ToServer:RequestAllNotifications", "") ' RequestAllNotifications
            End If
        End If

    End Sub

    Private Sub FriendsList_btn_Click(sender As Object, e As EventArgs) Handles FriendsList_btn.Click
        If QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym Then
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:FRIENDSCHAT_LOGINNEEDED"))
            _newMsg.ShowDialog()
        Else
            Friends.Show()
        End If
    End Sub

    Private Sub Settings_btn_Click(sender As Object, e As EventArgs) Handles Settings_btn.Click
        Settings.Show()
    End Sub

    Private Sub ShowProfile_btn_Click(sender As Object, e As EventArgs) Handles ShowProfile_btn.Click
        If QClipboard.LoggedOnMode = QClipboard.LoginMode.Anonym Then
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, GetSpecificLanguageString("MESSAGEBOXTEXT:PROFILE_LOGINNEEDED"))
            _newMsg.ShowDialog()
        Else
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "The Xtreme-Clonk-Launcher project has unfortunately been discontinued. So there will be no official profiles. But the launcher is now open source and can be developed by everyone! Find out more here: https://quixo-systems.jimdofree.com/kategorien/programme/xtreme-clonk-launcher/.")
            _newMsg.ShowDialog()
        End If
    End Sub

    Private Sub Notifications_btn_Click(sender As Object, e As EventArgs) Handles Notifications_btn.Click
        If NotificationPanel_pnl.Visible = False Then
            NotificationPanel_pnl.Visible = True
        Else
            NotificationPanel_pnl.Visible = False
        End If
    End Sub
    Private Sub DiscardAllNotifications_btn_Click(sender As Object, e As EventArgs) Handles DiscardAllNotifications_btn.Click
        Me.Refresh()
        Notifications_flp.Controls.Clear()
    End Sub

End Class