﻿Option Strict On
Imports MetroSuite.Extension
Imports MetroSuite
Imports System.Text
Imports MadMilkman.Ini

Public Class UploadObjectFrm : Inherits MetroSuite.MetroForm

    Private FileBytes() As Byte
    Private Filename As String
    Private FileExtension As String

#Region "ControlBox"

    Private Sub controlbox_close_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_close_lbl.Click
        Me.Close()
    End Sub
    Private Sub controlbox_nmaximize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_nmaximize_lbl.Click
        If controlbox_nmaximize_lbl.Text = "□" Then
            controlbox_nmaximize_lbl.Text = "■"
            Me.WindowState = FormWindowState.Normal
        Else
            controlbox_nmaximize_lbl.Text = "□"
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub
    Private Sub controlbox_minimize_lbl_Click(sender As Object, e As EventArgs) Handles controlbox_minimize_lbl.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub controlbox_close_lbl_MouseEnter(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseEnter, controlbox_nmaximize_lbl.MouseEnter, controlbox_minimize_lbl.MouseEnter
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.DimGray
    End Sub
    Private Sub controlbox_close_lbl_MouseLeave(sender As Object, e As EventArgs) Handles controlbox_close_lbl.MouseLeave, controlbox_nmaximize_lbl.MouseLeave, controlbox_minimize_lbl.MouseLeave
        Dim _cntrl As MetroSuite.MetroLabel = DirectCast(sender, MetroSuite.MetroLabel)
        _cntrl.BackColor = Color.Transparent
    End Sub

#End Region

#Region "Functions"

    Public Sub ApplyTheme()
        Try
            Dim myTheme As New Styles.Themes.MetroSuiteTheme
            Dim _IniFile As New IniFile(New IniOptions())
            _IniFile.Load(MakeLinuxCompatible(".\settings.ini"))

            If IO.File.Exists(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme")) Then ' If file exists
                myTheme = myTheme.FromFile(MakeLinuxCompatible(".\Data\Themes\" & _IniFile.Sections("Settings").Keys("Theme").Value & ".mstheme"))
            Else ' If not
                myTheme = New Styles.Themes.MetroSteamTheme
            End If

            myTheme.ApplyTheme(Me)
        Catch ex As Exception
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, ex.Message)
            _newMsg.ShowDialog()
        End Try
    End Sub

    Public Shared Function FormatBytes(ByVal InputBytes As ULong, Optional ByVal GetDebugValues As Boolean = False) As String
        Dim DoubleBytes As Double
        Try
            If GetDebugValues = False Then
                Select Case InputBytes
                    Case Is >= 1099511627776
                        DoubleBytes = CDbl(InputBytes / 1099511627776) 'TB
                        Return FormatNumber(DoubleBytes, 2) & " TB"
                    Case 1073741824 To 1099511627775
                        DoubleBytes = CDbl(InputBytes / 1073741824) 'GB
                        Return FormatNumber(DoubleBytes, 2) & " GB"
                    Case 1048576 To 1073741823
                        DoubleBytes = CDbl(InputBytes / 1048576) 'MB
                        Return FormatNumber(DoubleBytes, 2) & " MB"
                    Case 1024 To 1048575
                        DoubleBytes = CDbl(InputBytes / 1024) 'KB
                        Return FormatNumber(DoubleBytes, 2) & " KB"
                    Case 0 To 1023
                        DoubleBytes = InputBytes ' bytes
                        Return FormatNumber(DoubleBytes, 2) & " bytes"
                    Case Else
                        Return "Unbekannt"
                End Select
            Else
                Select Case InputBytes
                    Case Is >= 1099511627776
                        DoubleBytes = CDbl(InputBytes / 1099511627776) 'TB
                        Return FormatNumber(DoubleBytes, 2) & "|TB"
                    Case 1073741824 To 1099511627775
                        DoubleBytes = CDbl(InputBytes / 1073741824) 'GB
                        Return FormatNumber(DoubleBytes, 2) & "|GB"
                    Case 1048576 To 1073741823
                        DoubleBytes = CDbl(InputBytes / 1048576) 'MB
                        Return FormatNumber(DoubleBytes, 2) & "|MB"
                    Case 1024 To 1048575
                        DoubleBytes = CDbl(InputBytes / 1024) 'KB
                        Return FormatNumber(DoubleBytes, 2) & "|KB"
                    Case 0 To 1023
                        DoubleBytes = InputBytes ' bytes
                        Return FormatNumber(DoubleBytes, 2) & "|bytes"
                    Case Else
                        Return "Unbekannt"
                End Select
            End If
        Catch ex As Exception
            Return "ERROR"
        End Try
    End Function

    Public Function MakeLinuxCompatible(ByVal InputText As String) As String
        If QClipboard.LinuxMode = False Then
            Return InputText
        Else
            Return InputText.Replace(CChar("\"), CChar("/"))
        End If
    End Function

#End Region

#Region " Network "

    Private Sub UTC_UTicketArrived(sSenderID As String, bSentToAll As Boolean, sCommand As String, oUserData As List(Of Object))
        Select Case sCommand
            Case "ToClient:CCAN:ReceiveUploadStatus"
                Select Case oUserData(0).ToString

                    Case "SUCCESS"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() SelectFile_btn.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() upload_btn.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() ObjectTitel_txtbox.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() ObjectVersion_txtbox.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() desc_txtbox.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() loading_pnl.Visible = False))
                        Else
                            SelectFile_btn.Enabled = True
                            upload_btn.Enabled = True
                            ObjectTitel_txtbox.Enabled = True
                            ObjectVersion_txtbox.Enabled = True
                            desc_txtbox.Enabled = True
                            loading_pnl.Visible = False
                        End If

                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Dein Objekt wurde erfolgreich geuploadet!")
                        _newMsg.ShowDialog()

                        Me.DialogResult = System.Windows.Forms.DialogResult.OK

                    Case "ERROR"
                        If Me.InvokeRequired = True Then ' From another Thread
                            Me.Invoke(New MethodInvoker(Sub() SelectFile_btn.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() upload_btn.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() ObjectTitel_txtbox.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() ObjectVersion_txtbox.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() desc_txtbox.Enabled = True))
                            Me.Invoke(New MethodInvoker(Sub() loading_pnl.Visible = False))
                        Else
                            SelectFile_btn.Enabled = True
                            upload_btn.Enabled = True
                            ObjectTitel_txtbox.Enabled = True
                            ObjectVersion_txtbox.Enabled = True
                            desc_txtbox.Enabled = True
                            loading_pnl.Visible = False
                        End If

                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle._Error, "Ein Fehler ist aufgetreten. " & Environment.NewLine & oUserData(1).ToString)
                        _newMsg.ShowDialog()

                        Me.DialogResult = System.Windows.Forms.DialogResult.OK

                End Select
        End Select
    End Sub

#End Region

    Private Sub CategoryOne_cmbbox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CategoryOne_cmbbox.SelectedIndexChanged
        Select Case CategoryOne_cmbbox.SelectedItem.ToString
            Case "Szenario"
                CompletePackageInformation_lbl.Visible = False
                CategorySzenario_cmbbox.Visible = True
                CategoryObject_cmbbox.Visible = False
                categoryDocument_cmbbox.Visible = False
            Case "Objekt"
                CompletePackageInformation_lbl.Visible = False
                CategorySzenario_cmbbox.Visible = False
                CategoryObject_cmbbox.Visible = True
                categoryDocument_cmbbox.Visible = False
            Case "Dokument"
                CompletePackageInformation_lbl.Visible = False
                CategorySzenario_cmbbox.Visible = False
                CategoryObject_cmbbox.Visible = False
                categoryDocument_cmbbox.Visible = True
            Case "Komplettpaket (.zip)"
                CompletePackageInformation_lbl.Visible = True
                CategorySzenario_cmbbox.Visible = False
                CategoryObject_cmbbox.Visible = False
                categoryDocument_cmbbox.Visible = False
        End Select
    End Sub

    Private Sub UploadObjectFrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ApplyTheme() ' Set Theme

        loading_pnl.BackColor = Color.FromArgb(50, 64, 64, 64)

        'AddHandler
        If Not Networking.IsObjectNothing Then
            AddHandler Networking.UTC.UTicketArrived, AddressOf UTC_UTicketArrived
        End If
    End Sub

    Private Sub SelectFile_btn_Click(sender As Object, e As EventArgs) Handles SelectFile_btn.Click
        Dim ofd As New OpenFileDialog
        ofd.Filter = "Gesamtpaket|*.zip|Objekt|*.c4d|Rundenordner|*.c4f|Szenario|*.c4s|Andere...|*.*"
        ofd.Title = "Datei auswählen (max. 150 MB)"
        If (ofd.ShowDialog() = System.Windows.Forms.DialogResult.OK) Then
            Dim SelectedFile As New IO.FileInfo(ofd.FileName)
            Dim FileSizeRow As String = FormatBytes(CULng(SelectedFile.Length), True)
            Dim FileSize As String = FileSizeRow.Split(CChar("|"))(0)

            Select Case True

                Case FileSizeRow.Contains("MB")
                    If CDbl(FileSize) >= 150 Then
                        FileStatus_picbox.Image = My.Resources.clonk_error
                        MessageBox.Show("Die ausgewählte Datei ist zu groß!", "Zu Große Datei", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Else
                        ' File OKAY
                        FileStatus_picbox.Image = My.Resources.clonk_okay
                        Filename = System.IO.Path.GetFileNameWithoutExtension(ofd.FileName)
                        FileExtension = System.IO.Path.GetExtension(ofd.FileName)
                        ' Convert File to Bytes
                        FileBytes = IO.File.ReadAllBytes(ofd.FileName)
                    End If

                Case FileSizeRow.Contains("KB")
                    If CDbl(FileSize) >= 150000 Then
                        FileStatus_picbox.Image = My.Resources.clonk_error
                        MessageBox.Show("Die ausgewählte Datei ist zu groß!", "Zu Große Datei", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Else
                        ' File OKAY
                        FileStatus_picbox.Image = My.Resources.clonk_okay
                        Filename = IO.Path.GetFileNameWithoutExtension(ofd.FileName)
                        FileExtension = IO.Path.GetExtension(ofd.FileName)
                        ' Convert File to Bytes
                        FileBytes = IO.File.ReadAllBytes(ofd.FileName)
                    End If

                Case FileSizeRow.Contains("bytes")
                    If CDbl(FileSize) >= 150000000 Then
                        FileStatus_picbox.Image = My.Resources.clonk_error
                        MessageBox.Show("Die ausgewählte Datei ist zu groß!", "Zu Große Datei", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Else
                        ' File OKAY
                        FileStatus_picbox.Image = My.Resources.clonk_okay
                        Filename = IO.Path.GetFileNameWithoutExtension(ofd.FileName)
                        FileExtension = IO.Path.GetExtension(ofd.FileName)
                        ' Convert File to Bytes
                        FileBytes = IO.File.ReadAllBytes(ofd.FileName)
                    End If

                Case FileSizeRow.Contains("TB")
                    FileStatus_picbox.Image = My.Resources.clonk_error
                    MessageBox.Show("Die ausgewählte Datei ist VIEL zu groß!", "Zu Große Datei", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Case FileSizeRow.Contains("GB")
                    FileStatus_picbox.Image = My.Resources.clonk_error
                    MessageBox.Show("Die ausgewählte Datei ist zu groß!", "Zu Große Datei", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End Select

        End If
    End Sub

    Private Sub upload_btn_Click(sender As Object, e As EventArgs) Handles upload_btn.Click
        If FileBytes Is Nothing Then
            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Datei auswählen.")
            _newMsg.ShowDialog()
        Else
            If String.IsNullOrWhiteSpace(ObjectTitel_txtbox.Text) Then
                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Titel eingeben.")
                _newMsg.ShowDialog()
            Else
                If String.IsNullOrWhiteSpace(ObjectVersion_txtbox.Text) Then
                    Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Version eingeben.")
                    _newMsg.ShowDialog()
                Else
                    If EngineVersion_cmbbox.SelectedItem Is Nothing Then
                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Engine-Verson auswählen.")
                        _newMsg.ShowDialog()
                    Else
                        If CategoryOne_cmbbox.SelectedItem Is Nothing Then
                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Kategorie auswählen.")
                            _newMsg.ShowDialog()
                        Else

                            Select Case CategoryOne_cmbbox.SelectedItem.ToString

                                Case "Szenario"
                                    If CategorySzenario_cmbbox.SelectedItem Is Nothing Then
                                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Unterkategorie auswählen.")
                                        _newMsg.ShowDialog()
                                    Else
                                        If String.IsNullOrWhiteSpace(Players_txtbox.Text) Then
                                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Spieleranzahl eingeben.")
                                            _newMsg.ShowDialog()
                                        Else
                                            If String.IsNullOrWhiteSpace(desc_txtbox.Text) Then
                                                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Beschreibung eingeben. Eine kleine Beschreibung reicht.")
                                                _newMsg.ShowDialog()
                                            Else
                                                Try

                                                    Dim ObjectList As New List(Of Object)
                                                    ObjectList.Add(ObjectTitel_txtbox.Text)
                                                    ObjectList.Add(desc_txtbox.Text)
                                                    ObjectList.Add(ObjectVersion_txtbox.Text)
                                                    ObjectList.Add(CategoryOne_cmbbox.SelectedItem.ToString)
                                                    ObjectList.Add(CategorySzenario_cmbbox.SelectedItem.ToString)
                                                    ObjectList.Add(EngineVersion_cmbbox.SelectedItem.ToString)
                                                    ObjectList.Add(Unfinished_chkbox.Checked)
                                                    ObjectList.Add(Players_txtbox.Text)
                                                    ObjectList.Add(Filename)
                                                    ObjectList.Add(FileExtension)
                                                    ObjectList.Add(FileBytes)
                                                    ObjectList.Add(QClipboard.AccountName)
                                                    ObjectList.Add(Main.GetRandomCCANID)

                                                    ' Loading Panel
                                                    SelectFile_btn.Enabled = False
                                                    upload_btn.Enabled = False
                                                    ObjectTitel_txtbox.Enabled = False
                                                    ObjectVersion_txtbox.Enabled = False
                                                    desc_txtbox.Enabled = False
                                                    loading_pnl.Visible = True

                                                    Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:ReceiveUpload", ObjectList)
                                                Catch ex As Exception
                                                    MessageBox.Show(ex.ToString, "Fehler beim Upload", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                                End Try
                                            End If
                                        End If
                                    End If

                                Case "Objekt"
                                    If CategoryObject_cmbbox.SelectedItem Is Nothing Then
                                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Unterkategorie auswählen.")
                                        _newMsg.ShowDialog()
                                    Else
                                        If String.IsNullOrWhiteSpace(Players_txtbox.Text) Then
                                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Spieleranzahl eingeben.")
                                            _newMsg.ShowDialog()
                                        Else
                                            If String.IsNullOrWhiteSpace(desc_txtbox.Text) Then
                                                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Beschreibung eingeben. Eine kleine Beschreibung reicht.")
                                                _newMsg.ShowDialog()
                                            Else
                                                Try

                                                    Dim ObjectList As New List(Of Object)
                                                    ObjectList.Add(ObjectTitel_txtbox.Text)
                                                    ObjectList.Add(desc_txtbox.Text)
                                                    ObjectList.Add(ObjectVersion_txtbox.Text)
                                                    ObjectList.Add(CategoryOne_cmbbox.SelectedItem.ToString)
                                                    ObjectList.Add(CategoryObject_cmbbox.SelectedItem.ToString)
                                                    ObjectList.Add(EngineVersion_cmbbox.SelectedItem.ToString)
                                                    ObjectList.Add(Unfinished_chkbox.Checked)
                                                    ObjectList.Add(Players_txtbox.Text)
                                                    ObjectList.Add(Filename)
                                                    ObjectList.Add(FileExtension)
                                                    ObjectList.Add(FileBytes)
                                                    ObjectList.Add(QClipboard.AccountName)
                                                    ObjectList.Add(Main.GetRandomCCANID)

                                                    ' Loading Panel
                                                    SelectFile_btn.Enabled = False
                                                    upload_btn.Enabled = False
                                                    ObjectTitel_txtbox.Enabled = False
                                                    ObjectVersion_txtbox.Enabled = False
                                                    desc_txtbox.Enabled = False
                                                    loading_pnl.Visible = True

                                                    Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:ReceiveUpload", ObjectList)
                                                Catch ex As Exception
                                                    MessageBox.Show(ex.ToString, "Fehler beim Upload", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                                End Try
                                            End If
                                        End If
                                    End If

                                Case "Dokument"
                                    If categoryDocument_cmbbox.SelectedItem Is Nothing Then
                                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Unterkategorie auswählen.")
                                        _newMsg.ShowDialog()
                                    Else
                                        If String.IsNullOrWhiteSpace(Players_txtbox.Text) Then
                                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Spieleranzahl eingeben.")
                                            _newMsg.ShowDialog()
                                        Else
                                            If String.IsNullOrWhiteSpace(desc_txtbox.Text) Then
                                                Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Nachricht, "Bitte Beschreibung eingeben. Eine kleine Beschreibung reicht.")
                                                _newMsg.ShowDialog()
                                            Else
                                                Try

                                                    Dim ObjectList As New List(Of Object)
                                                    ObjectList.Add(ObjectTitel_txtbox.Text)
                                                    ObjectList.Add(desc_txtbox.Text)
                                                    ObjectList.Add(ObjectVersion_txtbox.Text)
                                                    ObjectList.Add(CategoryOne_cmbbox.SelectedItem.ToString)
                                                    ObjectList.Add(categoryDocument_cmbbox.SelectedItem.ToString)
                                                    ObjectList.Add(EngineVersion_cmbbox.SelectedItem.ToString)
                                                    ObjectList.Add(Unfinished_chkbox.Checked)
                                                    ObjectList.Add(Players_txtbox.Text)
                                                    ObjectList.Add(Filename)
                                                    ObjectList.Add(FileExtension)
                                                    ObjectList.Add(FileBytes)
                                                    ObjectList.Add(QClipboard.AccountName)
                                                    ObjectList.Add(Main.GetRandomCCANID)

                                                    ' Loading Panel
                                                    SelectFile_btn.Enabled = False
                                                    upload_btn.Enabled = False
                                                    ObjectTitel_txtbox.Enabled = False
                                                    ObjectVersion_txtbox.Enabled = False
                                                    desc_txtbox.Enabled = False
                                                    loading_pnl.Visible = True

                                                    Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:ReceiveUpload", ObjectList)
                                                Catch ex As Exception
                                                    MessageBox.Show(ex.ToString, "Fehler beim Upload", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                                End Try
                                            End If
                                        End If
                                    End If

                                Case "Komplettpaket (.zip)"
                                    If String.IsNullOrWhiteSpace(Players_txtbox.Text) Then
                                        Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Spieleranzahl eingeben.")
                                        _newMsg.ShowDialog()
                                    Else
                                        If String.IsNullOrWhiteSpace(desc_txtbox.Text) Then
                                            Dim _newMsg As New CMessage(CMessage.Mode.OkOnly, CMessage.MessageStyle.Information, "Bitte Beschreibung eingeben. Eine kleine Beschreibung reicht.")
                                            _newMsg.ShowDialog()
                                        Else
                                            Try

                                                Dim ObjectList As New List(Of Object)
                                                ObjectList.Add(ObjectTitel_txtbox.Text)
                                                ObjectList.Add(desc_txtbox.Text)
                                                ObjectList.Add(ObjectVersion_txtbox.Text)
                                                ObjectList.Add(CategoryOne_cmbbox.SelectedItem.ToString)
                                                ObjectList.Add("Komplettpaket")
                                                ObjectList.Add(EngineVersion_cmbbox.SelectedItem.ToString)
                                                ObjectList.Add(Unfinished_chkbox.Checked)
                                                ObjectList.Add(Players_txtbox.Text)
                                                ObjectList.Add(Filename)
                                                ObjectList.Add(FileExtension)
                                                ObjectList.Add(FileBytes)
                                                ObjectList.Add(QClipboard.AccountName)
                                                ObjectList.Add(Main.GetRandomCCANID)

                                                ' Loading Panel
                                                SelectFile_btn.Enabled = False
                                                upload_btn.Enabled = False
                                                ObjectTitel_txtbox.Enabled = False
                                                ObjectVersion_txtbox.Enabled = False
                                                desc_txtbox.Enabled = False
                                                loading_pnl.Visible = True

                                                Networking.UTC.sendUTicket("ADMIN", "ToServer:CCAN:ReceiveUpload", ObjectList)
                                            Catch ex As Exception
                                                MessageBox.Show(ex.ToString, "Fehler beim Upload", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                            End Try
                                        End If
                                    End If

                            End Select

                        End If
                    End If
                End If
            End If
        End If
    End Sub


End Class