﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.MetroTabControl1 = New MetroSuite.MetroTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel20 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel14 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel9 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cmd_OpenClonkx86Settings_btn = New Xtreme_Clonk_Launcher.NewMetroButton()
        Me.cmd_OpenClonkSettings_btn = New Xtreme_Clonk_Launcher.NewMetroButton()
        Me.OpenClonkWebbrowserError_pnl = New System.Windows.Forms.Panel()
        Me.MetroLabel24 = New MetroSuite.MetroLabel()
        Me.OpenClonk_x86_btn = New MetroSuite.MetroButton()
        Me.cmd_OpenClonk_btn = New MetroSuite.MetroButton()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.OCDesc_asl = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.OpenClonkRushHour_GBarChart = New GChartLib.GBarChart()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.oc_sunday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.oc_saturday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.oc_friday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.oc_thursday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.oc_wednesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.oc_tuesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.oc_monday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel19 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel21 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cr_sunday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cr_saturday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cr_friday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cr_thursday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cr_wednesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cr_tuesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cr_monday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel27 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ClonkRageWebbrowserError_pnl = New System.Windows.Forms.Panel()
        Me.MetroLabel31 = New MetroSuite.MetroLabel()
        Me.cmd_ClonkRage_btn = New MetroSuite.MetroButton()
        Me.ClonkRageRushHour_GBarChart = New GChartLib.GBarChart()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.MetroTranslatorLabel15 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel10 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.LCDesc_asl = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.cmd_ClonkRageSettings_btn = New Xtreme_Clonk_Launcher.NewMetroButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel22 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.ce_sunday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ce_saturday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ce_friday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ce_thursday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ce_wednesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ce_tuesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ce_monday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel28 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ClonkEndeavourWebbrowserError_pnl = New System.Windows.Forms.Panel()
        Me.MetroLabel35 = New MetroSuite.MetroLabel()
        Me.cmd_ClonkEndeavour_btn = New MetroSuite.MetroButton()
        Me.ClonkEndeavourRushHour_GBarChart = New GChartLib.GBarChart()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.MetroTranslatorLabel16 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel11 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.CEDesc_asl = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.cmd_ClonkEndeavourSettings_btn = New Xtreme_Clonk_Launcher.NewMetroButton()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel23 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.cp_sunday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cp_saturday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cp_friday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cp_thursday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cp_wednesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cp_tuesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.cp_monday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel29 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ClonkPlanetWebbrowserError_pnl = New System.Windows.Forms.Panel()
        Me.MetroLabel36 = New MetroSuite.MetroLabel()
        Me.cmd_ClonkPlanet_btn = New MetroSuite.MetroButton()
        Me.ClonkPlanetRushHour_GBarChart = New GChartLib.GBarChart()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.MetroTranslatorLabel17 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel12 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.CPDesc_asl = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.cmd_ClonkPlanetSettings_btn = New Xtreme_Clonk_Launcher.NewMetroButton()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel24 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.c4_sunday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.c4_saturday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.c4_friday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.c4_thursday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.c4_wednesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.c4_tuesday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.c4_monday_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel30 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.Clonk4WebbrowserError_pnl = New System.Windows.Forms.Panel()
        Me.MetroLabel37 = New MetroSuite.MetroLabel()
        Me.cmd_Clonk4_btn = New MetroSuite.MetroButton()
        Me.Clonk4RushHour_GBarChart = New GChartLib.GBarChart()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.MetroTranslatorLabel18 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel13 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.C4Desc_asl = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.cmd_Clonk4Settings_btn = New Xtreme_Clonk_Launcher.NewMetroButton()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel25 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.OwnClonkGameInfo_rtb = New System.Windows.Forms.RichTextBox()
        Me.news_rtb = New System.Windows.Forms.RichTextBox()
        Me.HomeWebbrowserError_pnl = New System.Windows.Forms.Panel()
        Me.MetroLabel18 = New MetroSuite.MetroLabel()
        Me.changelog_rtb = New System.Windows.Forms.RichTextBox()
        Me.YouTube_ClonkNews_btn = New MetroSuite.MetroButton()
        Me.YouTube_Clonkspot_btn = New MetroSuite.MetroButton()
        Me.YouTube_matthesb_btn = New MetroSuite.MetroButton()
        Me.DiscordInviteLink_btn = New MetroSuite.MetroButton()
        Me.ClonkSpotWebsite_btn = New MetroSuite.MetroButton()
        Me.CCANWebsite_btn = New MetroSuite.MetroButton()
        Me.ClonkWebsite_btn = New MetroSuite.MetroButton()
        Me.EventsWebbrowserError_pnl = New System.Windows.Forms.Panel()
        Me.MetroLabel23 = New MetroSuite.MetroLabel()
        Me.MetroLabel32 = New MetroSuite.MetroLabel()
        Me.CCANdateFilter_mcbox = New MetroSuite.MetroComboBox()
        Me.CCANversionFilter_mcbox = New MetroSuite.MetroComboBox()
        Me.CCANratingFilter_mcbox = New MetroSuite.MetroComboBox()
        Me.ccanObjects_flp = New System.Windows.Forms.FlowLayoutPanel()
        Me.MetroLabel2 = New MetroSuite.MetroLabel()
        Me.MetroStatusStrip1 = New MetroSuite.MetroStatusStrip()
        Me.status_lbl = New System.Windows.Forms.ToolStripStatusLabel()
        Me.downloadProgress_prgsbar = New System.Windows.Forms.ToolStripProgressBar()
        Me.downloadProgress_lbl = New System.Windows.Forms.ToolStripStatusLabel()
        Me.CheckClonkProcess_tmr = New System.Windows.Forms.Timer(Me.components)
        Me.InstalledGamesTT_tt = New System.Windows.Forms.ToolTip(Me.components)
        Me.MetroTabControl2 = New MetroSuite.MetroTabControl()
        Me.StartTabPage_tp = New System.Windows.Forms.TabPage()
        Me.MetroTranslatorLabel8 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel7 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel6 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel5 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel4 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.friendsOnlineCount_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel3 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel2 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel1 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.friendsOnline_flp = New System.Windows.Forms.FlowLayoutPanel()
        Me.QuickLaunch_flp = New System.Windows.Forms.FlowLayoutPanel()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.LibraryTabPage_tp = New System.Windows.Forms.TabPage()
        Me.NewsTabPage_tp = New System.Windows.Forms.TabPage()
        Me.NewsPanel_pnl = New System.Windows.Forms.Panel()
        Me.NewsDesc_lbl = New Xtreme_Clonk_Launcher.AdvancedScrollableLabel()
        Me.NewsTitle_lbl = New MetroSuite.MetroLabel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.RefreshNewsList_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.AllNewsCount_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.NewsLoading_picbox = New System.Windows.Forms.PictureBox()
        Me.AllNews_flp = New System.Windows.Forms.FlowLayoutPanel()
        Me.MetroTranslatorLabel33 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.EventsTabPage_tp = New System.Windows.Forms.TabPage()
        Me.WatchInBrowser_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.MetroTranslatorLabel31 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.MetroTranslatorLabel26 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.CCANTabPage_tp = New System.Windows.Forms.TabPage()
        Me.MetroPanelCategory1 = New MetroSuite.MetroPanelCategory()
        Me.MetroTranslatorLabel32 = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.ccanServerStatus_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.refresh_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.UploadNewContent_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.ccanSearch_txtbox = New Xtreme_Clonk_Launcher.MetroTranslatorTextbox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.ccanLoading_picbox = New System.Windows.Forms.PictureBox()
        Me.ccanFilterOther_btn = New System.Windows.Forms.PictureBox()
        Me.ccanFilterObjects_btn = New System.Windows.Forms.PictureBox()
        Me.ccanFilterSzenarios_btn = New System.Windows.Forms.PictureBox()
        Me.ccanFilterAll_btn = New System.Windows.Forms.PictureBox()
        Me.ccanSearch_btn = New System.Windows.Forms.PictureBox()
        Me.ccanFilterPackage_btn = New System.Windows.Forms.PictureBox()
        Me.Checker_tmr = New System.Windows.Forms.Timer(Me.components)
        Me.NotificationPanel_pnl = New System.Windows.Forms.Panel()
        Me.NoNotifications_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.Notifications_flp = New System.Windows.Forms.FlowLayoutPanel()
        Me.DiscardAllNotifications_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.username_hst = New Xtreme_Clonk_Launcher.HorizontalScrollingText()
        Me.ShowProfile_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.FriendsList_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.Settings_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.Notifications_btn = New Xtreme_Clonk_Launcher.MetroTranslatorButton()
        Me.user_picbox = New System.Windows.Forms.PictureBox()
        Me.MainLogo_picbox = New System.Windows.Forms.PictureBox()
        Me.ClonkIsRunningInfo_lbl = New Xtreme_Clonk_Launcher.MetroTranslatorLabel()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.Infobar_ctms = New Xtreme_Clonk_Launcher.ModernContextMenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.AufUpdatesPrüfenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BeendenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenClonkSettings_ctms = New Xtreme_Clonk_Launcher.ModernContextMenuStrip()
        Me.SpieleinstellungenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImExplorerAnzeigenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.SpielDeinstallierenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenClonkx86Settings_ctms = New Xtreme_Clonk_Launcher.ModernContextMenuStrip()
        Me.SpieleinstellungenToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImExplorerAnzeigenToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.SpielDeinstallierenToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClonkRageSettings_ctms = New Xtreme_Clonk_Launcher.ModernContextMenuStrip()
        Me.SpieleinstellungenToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImExplorerAnzeigenToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AufUpdatesPrüfenToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.SpielDeinstallierenToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClonkEndeavourSettings_ctms = New Xtreme_Clonk_Launcher.ModernContextMenuStrip()
        Me.SpieleinstellungenToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImExplorerAnzeigenToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.SpielDeinstallierenToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClonkPlanetSettings_ctms = New Xtreme_Clonk_Launcher.ModernContextMenuStrip()
        Me.SpieleinstellungenToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImExplorerAnzeigenToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.SpielDeinstallierenToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Clonk4Settings_ctms = New Xtreme_Clonk_Launcher.ModernContextMenuStrip()
        Me.SpieleinstellungenToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImExplorerAnzeigenToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.SpielDeinstallierenToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.controlbox_pnl.SuspendLayout()
        Me.MetroTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.OpenClonkWebbrowserError_pnl.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel13.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.ClonkRageWebbrowserError_pnl.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.ClonkEndeavourWebbrowserError_pnl.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.ClonkPlanetWebbrowserError_pnl.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Clonk4WebbrowserError_pnl.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.HomeWebbrowserError_pnl.SuspendLayout()
        Me.EventsWebbrowserError_pnl.SuspendLayout()
        Me.MetroStatusStrip1.SuspendLayout()
        Me.MetroTabControl2.SuspendLayout()
        Me.StartTabPage_tp.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LibraryTabPage_tp.SuspendLayout()
        Me.NewsTabPage_tp.SuspendLayout()
        Me.NewsPanel_pnl.SuspendLayout()
        Me.Panel17.SuspendLayout()
        CType(Me.NewsLoading_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EventsTabPage_tp.SuspendLayout()
        Me.CCANTabPage_tp.SuspendLayout()
        Me.MetroPanelCategory1.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ccanLoading_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ccanFilterOther_btn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ccanFilterObjects_btn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ccanFilterSzenarios_btn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ccanFilterAll_btn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ccanSearch_btn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ccanFilterPackage_btn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NotificationPanel_pnl.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.user_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MainLogo_picbox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Infobar_ctms.SuspendLayout()
        Me.OpenClonkSettings_ctms.SuspendLayout()
        Me.OpenClonkx86Settings_ctms.SuspendLayout()
        Me.ClonkRageSettings_ctms.SuspendLayout()
        Me.ClonkEndeavourSettings_ctms.SuspendLayout()
        Me.ClonkPlanetSettings_ctms.SuspendLayout()
        Me.Clonk4Settings_ctms.SuspendLayout()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(1171, 3)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 0
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.AnimationSpeed = 25
        Me.MetroTabControl1.Appearance = System.Windows.Forms.Appearance.Normal
        Me.MetroTabControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MetroTabControl1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.MetroTabControl1.Controls.Add(Me.TabPage1)
        Me.MetroTabControl1.Controls.Add(Me.TabPage2)
        Me.MetroTabControl1.Controls.Add(Me.TabPage3)
        Me.MetroTabControl1.Controls.Add(Me.TabPage4)
        Me.MetroTabControl1.Controls.Add(Me.TabPage5)
        Me.MetroTabControl1.Controls.Add(Me.TabPage7)
        Me.MetroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroTabControl1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTabControl1.ForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.HasAnimation = False
        Me.MetroTabControl1.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(106, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.MetroTabControl1.HeaderItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.HotTrack = True
        Me.MetroTabControl1.HoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.HoverColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.ItemSize = New System.Drawing.Size(50, 120)
        Me.MetroTabControl1.Location = New System.Drawing.Point(3, 3)
        Me.MetroTabControl1.Multiline = True
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedForeColor = System.Drawing.Color.White
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.SelectedItemColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedItemLineColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.Size = New System.Drawing.Size(1211, 622)
        Me.MetroTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MetroTabControl1.TabContainerColor = System.Drawing.Color.White
        Me.MetroTabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel20)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel14)
        Me.TabPage1.Controls.Add(Me.MetroTranslatorLabel9)
        Me.TabPage1.Controls.Add(Me.cmd_OpenClonkx86Settings_btn)
        Me.TabPage1.Controls.Add(Me.cmd_OpenClonkSettings_btn)
        Me.TabPage1.Controls.Add(Me.OpenClonkWebbrowserError_pnl)
        Me.TabPage1.Controls.Add(Me.OpenClonk_x86_btn)
        Me.TabPage1.Controls.Add(Me.cmd_OpenClonk_btn)
        Me.TabPage1.Controls.Add(Me.PictureBox2)
        Me.TabPage1.Controls.Add(Me.OCDesc_asl)
        Me.TabPage1.Controls.Add(Me.OpenClonkRushHour_GBarChart)
        Me.TabPage1.Controls.Add(Me.Panel13)
        Me.TabPage1.Location = New System.Drawing.Point(124, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1083, 614)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "OpenClonk"
        '
        'MetroTranslatorLabel20
        '
        Me.MetroTranslatorLabel20.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel20.AutoSize = True
        Me.MetroTranslatorLabel20.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel20.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel20.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel20.LanguageKey = "MAIN:LIBRARY_OC_PUBLISHEDTEXT"
        Me.MetroTranslatorLabel20.Location = New System.Drawing.Point(6, 594)
        Me.MetroTranslatorLabel20.Name = "MetroTranslatorLabel20"
        Me.MetroTranslatorLabel20.ShowToolTip = True
        Me.MetroTranslatorLabel20.Size = New System.Drawing.Size(169, 15)
        Me.MetroTranslatorLabel20.TabIndex = 45
        Me.MetroTranslatorLabel20.Text = "OpenClonk erschienen : 2010"
        '
        'MetroTranslatorLabel14
        '
        Me.MetroTranslatorLabel14.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel14.AutoSize = True
        Me.MetroTranslatorLabel14.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel14.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel14.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel14.LanguageKey = "MAIN:LIBRARY_OC_RUSHHOURTEXT"
        Me.MetroTranslatorLabel14.Location = New System.Drawing.Point(58, 265)
        Me.MetroTranslatorLabel14.Name = "MetroTranslatorLabel14"
        Me.MetroTranslatorLabel14.ShowToolTip = True
        Me.MetroTranslatorLabel14.Size = New System.Drawing.Size(148, 15)
        Me.MetroTranslatorLabel14.TabIndex = 44
        Me.MetroTranslatorLabel14.Text = "Stoßzeiten von OpenClonk"
        '
        'MetroTranslatorLabel9
        '
        Me.MetroTranslatorLabel9.AutoSize = True
        Me.MetroTranslatorLabel9.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel9.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel9.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel9.LanguageKey = "MAIN:LIBRARY_OC_INFOTEXT"
        Me.MetroTranslatorLabel9.Location = New System.Drawing.Point(6, 6)
        Me.MetroTranslatorLabel9.Name = "MetroTranslatorLabel9"
        Me.MetroTranslatorLabel9.ShowToolTip = True
        Me.MetroTranslatorLabel9.Size = New System.Drawing.Size(317, 15)
        Me.MetroTranslatorLabel9.TabIndex = 43
        Me.MetroTranslatorLabel9.Text = "Informationen und Systemanforderungen über OpenClonk"
        '
        'cmd_OpenClonkx86Settings_btn
        '
        Me.cmd_OpenClonkx86Settings_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_OpenClonkx86Settings_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_OpenClonkx86Settings_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_OpenClonkx86Settings_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_OpenClonkx86Settings_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_OpenClonkx86Settings_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_OpenClonkx86Settings_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cmd_OpenClonkx86Settings_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_OpenClonkx86Settings_btn.Icon = CType(resources.GetObject("cmd_OpenClonkx86Settings_btn.Icon"), System.Drawing.Image)
        Me.cmd_OpenClonkx86Settings_btn.Location = New System.Drawing.Point(756, 559)
        Me.cmd_OpenClonkx86Settings_btn.Name = "cmd_OpenClonkx86Settings_btn"
        Me.cmd_OpenClonkx86Settings_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_OpenClonkx86Settings_btn.RoundingArc = 42
        Me.cmd_OpenClonkx86Settings_btn.ScaleImage = False
        Me.cmd_OpenClonkx86Settings_btn.ScalingSize = New System.Drawing.Size(24, 24)
        Me.cmd_OpenClonkx86Settings_btn.Size = New System.Drawing.Size(37, 42)
        Me.cmd_OpenClonkx86Settings_btn.TabIndex = 42
        '
        'cmd_OpenClonkSettings_btn
        '
        Me.cmd_OpenClonkSettings_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_OpenClonkSettings_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_OpenClonkSettings_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_OpenClonkSettings_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_OpenClonkSettings_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_OpenClonkSettings_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_OpenClonkSettings_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cmd_OpenClonkSettings_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_OpenClonkSettings_btn.Icon = CType(resources.GetObject("cmd_OpenClonkSettings_btn.Icon"), System.Drawing.Image)
        Me.cmd_OpenClonkSettings_btn.Location = New System.Drawing.Point(1038, 559)
        Me.cmd_OpenClonkSettings_btn.Name = "cmd_OpenClonkSettings_btn"
        Me.cmd_OpenClonkSettings_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_OpenClonkSettings_btn.RoundingArc = 42
        Me.cmd_OpenClonkSettings_btn.ScaleImage = False
        Me.cmd_OpenClonkSettings_btn.ScalingSize = New System.Drawing.Size(24, 24)
        Me.cmd_OpenClonkSettings_btn.Size = New System.Drawing.Size(37, 42)
        Me.cmd_OpenClonkSettings_btn.TabIndex = 41
        '
        'OpenClonkWebbrowserError_pnl
        '
        Me.OpenClonkWebbrowserError_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OpenClonkWebbrowserError_pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.OpenClonkWebbrowserError_pnl.Controls.Add(Me.MetroLabel24)
        Me.OpenClonkWebbrowserError_pnl.Location = New System.Drawing.Point(594, 261)
        Me.OpenClonkWebbrowserError_pnl.Name = "OpenClonkWebbrowserError_pnl"
        Me.OpenClonkWebbrowserError_pnl.Size = New System.Drawing.Size(481, 287)
        Me.OpenClonkWebbrowserError_pnl.TabIndex = 21
        Me.OpenClonkWebbrowserError_pnl.Tag = "DEBUG"
        Me.OpenClonkWebbrowserError_pnl.Visible = False
        '
        'MetroLabel24
        '
        Me.MetroLabel24.BackColor = System.Drawing.Color.DimGray
        Me.MetroLabel24.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel24.ForeColor = System.Drawing.Color.White
        Me.MetroLabel24.Location = New System.Drawing.Point(1, 0)
        Me.MetroLabel24.Name = "MetroLabel24"
        Me.MetroLabel24.Size = New System.Drawing.Size(477, 262)
        Me.MetroLabel24.TabIndex = 1
        Me.MetroLabel24.Text = resources.GetString("MetroLabel24.Text")
        '
        'OpenClonk_x86_btn
        '
        Me.OpenClonk_x86_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OpenClonk_x86_btn.BackColor = System.Drawing.Color.Transparent
        Me.OpenClonk_x86_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OpenClonk_x86_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OpenClonk_x86_btn.DefaultColor = System.Drawing.Color.White
        Me.OpenClonk_x86_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.OpenClonk_x86_btn.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.OpenClonk_x86_btn.HoverColor = System.Drawing.Color.White
        Me.OpenClonk_x86_btn.Location = New System.Drawing.Point(517, 559)
        Me.OpenClonk_x86_btn.Name = "OpenClonk_x86_btn"
        Me.OpenClonk_x86_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OpenClonk_x86_btn.RoundingArc = 42
        Me.OpenClonk_x86_btn.Size = New System.Drawing.Size(239, 42)
        Me.OpenClonk_x86_btn.TabIndex = 12
        Me.OpenClonk_x86_btn.Text = "Download OpenClonk x86"
        '
        'cmd_OpenClonk_btn
        '
        Me.cmd_OpenClonk_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_OpenClonk_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_OpenClonk_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_OpenClonk_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_OpenClonk_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_OpenClonk_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_OpenClonk_btn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmd_OpenClonk_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_OpenClonk_btn.Location = New System.Drawing.Point(799, 559)
        Me.cmd_OpenClonk_btn.Name = "cmd_OpenClonk_btn"
        Me.cmd_OpenClonk_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_OpenClonk_btn.RoundingArc = 42
        Me.cmd_OpenClonk_btn.Size = New System.Drawing.Size(239, 42)
        Me.cmd_OpenClonk_btn.TabIndex = 11
        Me.cmd_OpenClonk_btn.Text = "Download OpenClonk x64"
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.OpenClonkLogo
        Me.PictureBox2.Location = New System.Drawing.Point(796, 6)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(279, 247)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'OCDesc_asl
        '
        Me.OCDesc_asl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OCDesc_asl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OCDesc_asl.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.OCDesc_asl.DefaultColor = System.Drawing.Color.White
        Me.OCDesc_asl.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.OCDesc_asl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.OCDesc_asl.ForeColor = System.Drawing.Color.Black
        Me.OCDesc_asl.HideSelection = False
        Me.OCDesc_asl.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.OCDesc_asl.InputText = resources.GetString("OCDesc_asl.InputText")
        Me.OCDesc_asl.Location = New System.Drawing.Point(6, 24)
        Me.OCDesc_asl.Multiline = True
        Me.OCDesc_asl.Name = "OCDesc_asl"
        Me.OCDesc_asl.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.OCDesc_asl.ReadOnly = True
        Me.OCDesc_asl.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.OCDesc_asl.Size = New System.Drawing.Size(784, 229)
        Me.OCDesc_asl.TabIndex = 31
        Me.OCDesc_asl.Text = resources.GetString("OCDesc_asl.Text")
        '
        'OpenClonkRushHour_GBarChart
        '
        Me.OpenClonkRushHour_GBarChart.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.OpenClonkRushHour_GBarChart.BarDistance = 65
        Me.OpenClonkRushHour_GBarChart.DrawHorizontalLines = False
        Me.OpenClonkRushHour_GBarChart.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.OpenClonkRushHour_GBarChart.GraphLineColor = System.Drawing.Color.Gray
        Me.OpenClonkRushHour_GBarChart.HoritonzalGradientColor = System.Drawing.Color.Transparent
        Me.OpenClonkRushHour_GBarChart.HorizontalLinesColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.OpenClonkRushHour_GBarChart.Location = New System.Drawing.Point(59, 283)
        Me.OpenClonkRushHour_GBarChart.Name = "OpenClonkRushHour_GBarChart"
        Me.OpenClonkRushHour_GBarChart.NotAdjustedMaximum = 40
        Me.OpenClonkRushHour_GBarChart.NotificationLineValueFont = New System.Drawing.Font("Segoe UI", 6.0!)
        Me.OpenClonkRushHour_GBarChart.Size = New System.Drawing.Size(493, 225)
        Me.OpenClonkRushHour_GBarChart.TabIndex = 38
        '
        'Panel13
        '
        Me.Panel13.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel13.Controls.Add(Me.oc_sunday_lbl)
        Me.Panel13.Controls.Add(Me.oc_saturday_lbl)
        Me.Panel13.Controls.Add(Me.oc_friday_lbl)
        Me.Panel13.Controls.Add(Me.oc_thursday_lbl)
        Me.Panel13.Controls.Add(Me.oc_wednesday_lbl)
        Me.Panel13.Controls.Add(Me.oc_tuesday_lbl)
        Me.Panel13.Controls.Add(Me.oc_monday_lbl)
        Me.Panel13.Controls.Add(Me.MetroTranslatorLabel19)
        Me.Panel13.Location = New System.Drawing.Point(59, 514)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(493, 37)
        Me.Panel13.TabIndex = 40
        '
        'oc_sunday_lbl
        '
        Me.oc_sunday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.oc_sunday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.oc_sunday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.oc_sunday_lbl.LanguageKey = "MAIN:OTHER_SUNDAY"
        Me.oc_sunday_lbl.Location = New System.Drawing.Point(432, 10)
        Me.oc_sunday_lbl.Name = "oc_sunday_lbl"
        Me.oc_sunday_lbl.ShowToolTip = True
        Me.oc_sunday_lbl.Size = New System.Drawing.Size(51, 15)
        Me.oc_sunday_lbl.TabIndex = 14
        Me.oc_sunday_lbl.Text = "Sonntag"
        Me.oc_sunday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'oc_saturday_lbl
        '
        Me.oc_saturday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.oc_saturday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.oc_saturday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(157, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.oc_saturday_lbl.LanguageKey = "MAIN:OTHER_SATURDAY"
        Me.oc_saturday_lbl.Location = New System.Drawing.Point(369, 10)
        Me.oc_saturday_lbl.Name = "oc_saturday_lbl"
        Me.oc_saturday_lbl.ShowToolTip = True
        Me.oc_saturday_lbl.Size = New System.Drawing.Size(58, 15)
        Me.oc_saturday_lbl.TabIndex = 13
        Me.oc_saturday_lbl.Text = "Samstag"
        Me.oc_saturday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'oc_friday_lbl
        '
        Me.oc_friday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.oc_friday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.oc_friday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(144, Byte), Integer), CType(CType(178, Byte), Integer))
        Me.oc_friday_lbl.LanguageKey = "MAIN:OTHER_FRIDAY"
        Me.oc_friday_lbl.Location = New System.Drawing.Point(321, 10)
        Me.oc_friday_lbl.Name = "oc_friday_lbl"
        Me.oc_friday_lbl.ShowToolTip = True
        Me.oc_friday_lbl.Size = New System.Drawing.Size(45, 15)
        Me.oc_friday_lbl.TabIndex = 12
        Me.oc_friday_lbl.Text = "Freitag"
        Me.oc_friday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'oc_thursday_lbl
        '
        Me.oc_thursday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.oc_thursday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.oc_thursday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.oc_thursday_lbl.LanguageKey = "MAIN:OTHER_THURSDAY"
        Me.oc_thursday_lbl.Location = New System.Drawing.Point(247, 10)
        Me.oc_thursday_lbl.Name = "oc_thursday_lbl"
        Me.oc_thursday_lbl.ShowToolTip = True
        Me.oc_thursday_lbl.Size = New System.Drawing.Size(70, 15)
        Me.oc_thursday_lbl.TabIndex = 11
        Me.oc_thursday_lbl.Text = "Donnerstag"
        Me.oc_thursday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'oc_wednesday_lbl
        '
        Me.oc_wednesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.oc_wednesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.oc_wednesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.oc_wednesday_lbl.LanguageKey = "MAIN:OTHER_WEDNESDAY"
        Me.oc_wednesday_lbl.Location = New System.Drawing.Point(183, 10)
        Me.oc_wednesday_lbl.Name = "oc_wednesday_lbl"
        Me.oc_wednesday_lbl.ShowToolTip = True
        Me.oc_wednesday_lbl.Size = New System.Drawing.Size(60, 15)
        Me.oc_wednesday_lbl.TabIndex = 10
        Me.oc_wednesday_lbl.Text = "Mittwoch"
        Me.oc_wednesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'oc_tuesday_lbl
        '
        Me.oc_tuesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.oc_tuesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.oc_tuesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(148, Byte), Integer))
        Me.oc_tuesday_lbl.LanguageKey = "MAIN:OTHER_TUESDAY"
        Me.oc_tuesday_lbl.Location = New System.Drawing.Point(124, 10)
        Me.oc_tuesday_lbl.Name = "oc_tuesday_lbl"
        Me.oc_tuesday_lbl.ShowToolTip = True
        Me.oc_tuesday_lbl.Size = New System.Drawing.Size(55, 15)
        Me.oc_tuesday_lbl.TabIndex = 9
        Me.oc_tuesday_lbl.Text = "Dienstag"
        Me.oc_tuesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'oc_monday_lbl
        '
        Me.oc_monday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.oc_monday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.oc_monday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.oc_monday_lbl.LanguageKey = "MAIN:OTHER_MONDAY"
        Me.oc_monday_lbl.Location = New System.Drawing.Point(67, 10)
        Me.oc_monday_lbl.Name = "oc_monday_lbl"
        Me.oc_monday_lbl.ShowToolTip = True
        Me.oc_monday_lbl.Size = New System.Drawing.Size(53, 15)
        Me.oc_monday_lbl.TabIndex = 8
        Me.oc_monday_lbl.Text = "Montag"
        Me.oc_monday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTranslatorLabel19
        '
        Me.MetroTranslatorLabel19.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel19.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel19.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel19.LanguageKey = "MAIN:OTHER_LEGENDTEXT"
        Me.MetroTranslatorLabel19.Location = New System.Drawing.Point(6, 10)
        Me.MetroTranslatorLabel19.Name = "MetroTranslatorLabel19"
        Me.MetroTranslatorLabel19.ShowToolTip = True
        Me.MetroTranslatorLabel19.Size = New System.Drawing.Size(55, 15)
        Me.MetroTranslatorLabel19.TabIndex = 7
        Me.MetroTranslatorLabel19.Text = "Legende:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.MetroTranslatorLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.MetroTranslatorLabel21)
        Me.TabPage2.Controls.Add(Me.Panel2)
        Me.TabPage2.Controls.Add(Me.ClonkRageWebbrowserError_pnl)
        Me.TabPage2.Controls.Add(Me.cmd_ClonkRage_btn)
        Me.TabPage2.Controls.Add(Me.ClonkRageRushHour_GBarChart)
        Me.TabPage2.Controls.Add(Me.PictureBox3)
        Me.TabPage2.Controls.Add(Me.MetroTranslatorLabel15)
        Me.TabPage2.Controls.Add(Me.MetroTranslatorLabel10)
        Me.TabPage2.Controls.Add(Me.LCDesc_asl)
        Me.TabPage2.Controls.Add(Me.cmd_ClonkRageSettings_btn)
        Me.TabPage2.Location = New System.Drawing.Point(124, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1083, 614)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "LegacyClonk    (Clonk Rage)"
        '
        'MetroTranslatorLabel21
        '
        Me.MetroTranslatorLabel21.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel21.AutoSize = True
        Me.MetroTranslatorLabel21.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel21.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel21.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel21.LanguageKey = "MAIN:LIBRARY_LC_PUBLISHEDTEXT"
        Me.MetroTranslatorLabel21.Location = New System.Drawing.Point(6, 594)
        Me.MetroTranslatorLabel21.Name = "MetroTranslatorLabel21"
        Me.MetroTranslatorLabel21.ShowToolTip = True
        Me.MetroTranslatorLabel21.Size = New System.Drawing.Size(177, 15)
        Me.MetroTranslatorLabel21.TabIndex = 47
        Me.MetroTranslatorLabel21.Text = "LegacyClonk erschienen : 2019"
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.cr_sunday_lbl)
        Me.Panel2.Controls.Add(Me.cr_saturday_lbl)
        Me.Panel2.Controls.Add(Me.cr_friday_lbl)
        Me.Panel2.Controls.Add(Me.cr_thursday_lbl)
        Me.Panel2.Controls.Add(Me.cr_wednesday_lbl)
        Me.Panel2.Controls.Add(Me.cr_tuesday_lbl)
        Me.Panel2.Controls.Add(Me.cr_monday_lbl)
        Me.Panel2.Controls.Add(Me.MetroTranslatorLabel27)
        Me.Panel2.Location = New System.Drawing.Point(54, 524)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(493, 37)
        Me.Panel2.TabIndex = 46
        '
        'cr_sunday_lbl
        '
        Me.cr_sunday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cr_sunday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cr_sunday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cr_sunday_lbl.LanguageKey = "MAIN:OTHER_SUNDAY"
        Me.cr_sunday_lbl.Location = New System.Drawing.Point(432, 10)
        Me.cr_sunday_lbl.Name = "cr_sunday_lbl"
        Me.cr_sunday_lbl.ShowToolTip = True
        Me.cr_sunday_lbl.Size = New System.Drawing.Size(51, 15)
        Me.cr_sunday_lbl.TabIndex = 14
        Me.cr_sunday_lbl.Text = "Sonntag"
        Me.cr_sunday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cr_saturday_lbl
        '
        Me.cr_saturday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cr_saturday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cr_saturday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(157, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.cr_saturday_lbl.LanguageKey = "MAIN:OTHER_SATURDAY"
        Me.cr_saturday_lbl.Location = New System.Drawing.Point(369, 10)
        Me.cr_saturday_lbl.Name = "cr_saturday_lbl"
        Me.cr_saturday_lbl.ShowToolTip = True
        Me.cr_saturday_lbl.Size = New System.Drawing.Size(58, 15)
        Me.cr_saturday_lbl.TabIndex = 13
        Me.cr_saturday_lbl.Text = "Samstag"
        Me.cr_saturday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cr_friday_lbl
        '
        Me.cr_friday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cr_friday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cr_friday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(144, Byte), Integer), CType(CType(178, Byte), Integer))
        Me.cr_friday_lbl.LanguageKey = "MAIN:OTHER_FRIDAY"
        Me.cr_friday_lbl.Location = New System.Drawing.Point(321, 10)
        Me.cr_friday_lbl.Name = "cr_friday_lbl"
        Me.cr_friday_lbl.ShowToolTip = True
        Me.cr_friday_lbl.Size = New System.Drawing.Size(45, 15)
        Me.cr_friday_lbl.TabIndex = 12
        Me.cr_friday_lbl.Text = "Freitag"
        Me.cr_friday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cr_thursday_lbl
        '
        Me.cr_thursday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cr_thursday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cr_thursday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cr_thursday_lbl.LanguageKey = "MAIN:OTHER_THURSDAY"
        Me.cr_thursday_lbl.Location = New System.Drawing.Point(247, 10)
        Me.cr_thursday_lbl.Name = "cr_thursday_lbl"
        Me.cr_thursday_lbl.ShowToolTip = True
        Me.cr_thursday_lbl.Size = New System.Drawing.Size(70, 15)
        Me.cr_thursday_lbl.TabIndex = 11
        Me.cr_thursday_lbl.Text = "Donnerstag"
        Me.cr_thursday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cr_wednesday_lbl
        '
        Me.cr_wednesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cr_wednesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cr_wednesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.cr_wednesday_lbl.LanguageKey = "MAIN:OTHER_WEDNESDAY"
        Me.cr_wednesday_lbl.Location = New System.Drawing.Point(183, 10)
        Me.cr_wednesday_lbl.Name = "cr_wednesday_lbl"
        Me.cr_wednesday_lbl.ShowToolTip = True
        Me.cr_wednesday_lbl.Size = New System.Drawing.Size(60, 15)
        Me.cr_wednesday_lbl.TabIndex = 10
        Me.cr_wednesday_lbl.Text = "Mittwoch"
        Me.cr_wednesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cr_tuesday_lbl
        '
        Me.cr_tuesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cr_tuesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cr_tuesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(148, Byte), Integer))
        Me.cr_tuesday_lbl.LanguageKey = "MAIN:OTHER_TUESDAY"
        Me.cr_tuesday_lbl.Location = New System.Drawing.Point(124, 10)
        Me.cr_tuesday_lbl.Name = "cr_tuesday_lbl"
        Me.cr_tuesday_lbl.ShowToolTip = True
        Me.cr_tuesday_lbl.Size = New System.Drawing.Size(55, 15)
        Me.cr_tuesday_lbl.TabIndex = 9
        Me.cr_tuesday_lbl.Text = "Dienstag"
        Me.cr_tuesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cr_monday_lbl
        '
        Me.cr_monday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cr_monday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cr_monday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.cr_monday_lbl.LanguageKey = "MAIN:OTHER_MONDAY"
        Me.cr_monday_lbl.Location = New System.Drawing.Point(67, 10)
        Me.cr_monday_lbl.Name = "cr_monday_lbl"
        Me.cr_monday_lbl.ShowToolTip = True
        Me.cr_monday_lbl.Size = New System.Drawing.Size(53, 15)
        Me.cr_monday_lbl.TabIndex = 8
        Me.cr_monday_lbl.Text = "Montag"
        Me.cr_monday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTranslatorLabel27
        '
        Me.MetroTranslatorLabel27.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel27.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel27.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel27.LanguageKey = "MAIN:OTHER_LEGENDTEXT"
        Me.MetroTranslatorLabel27.Location = New System.Drawing.Point(6, 10)
        Me.MetroTranslatorLabel27.Name = "MetroTranslatorLabel27"
        Me.MetroTranslatorLabel27.ShowToolTip = True
        Me.MetroTranslatorLabel27.Size = New System.Drawing.Size(55, 15)
        Me.MetroTranslatorLabel27.TabIndex = 7
        Me.MetroTranslatorLabel27.Text = "Legende:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.MetroTranslatorLabel27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ClonkRageWebbrowserError_pnl
        '
        Me.ClonkRageWebbrowserError_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClonkRageWebbrowserError_pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ClonkRageWebbrowserError_pnl.Controls.Add(Me.MetroLabel31)
        Me.ClonkRageWebbrowserError_pnl.Location = New System.Drawing.Point(594, 261)
        Me.ClonkRageWebbrowserError_pnl.Name = "ClonkRageWebbrowserError_pnl"
        Me.ClonkRageWebbrowserError_pnl.Size = New System.Drawing.Size(481, 287)
        Me.ClonkRageWebbrowserError_pnl.TabIndex = 20
        Me.ClonkRageWebbrowserError_pnl.Tag = "DEBUG"
        Me.ClonkRageWebbrowserError_pnl.Visible = False
        '
        'MetroLabel31
        '
        Me.MetroLabel31.BackColor = System.Drawing.Color.DimGray
        Me.MetroLabel31.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel31.ForeColor = System.Drawing.Color.White
        Me.MetroLabel31.Location = New System.Drawing.Point(1, 0)
        Me.MetroLabel31.Name = "MetroLabel31"
        Me.MetroLabel31.Size = New System.Drawing.Size(477, 262)
        Me.MetroLabel31.TabIndex = 1
        Me.MetroLabel31.Text = resources.GetString("MetroLabel31.Text")
        '
        'cmd_ClonkRage_btn
        '
        Me.cmd_ClonkRage_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_ClonkRage_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_ClonkRage_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_ClonkRage_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_ClonkRage_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_ClonkRage_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_ClonkRage_btn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmd_ClonkRage_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_ClonkRage_btn.Location = New System.Drawing.Point(799, 559)
        Me.cmd_ClonkRage_btn.Name = "cmd_ClonkRage_btn"
        Me.cmd_ClonkRage_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_ClonkRage_btn.RoundingArc = 42
        Me.cmd_ClonkRage_btn.Size = New System.Drawing.Size(239, 42)
        Me.cmd_ClonkRage_btn.TabIndex = 12
        Me.cmd_ClonkRage_btn.Text = "Download LegacyClonk x86"
        '
        'ClonkRageRushHour_GBarChart
        '
        Me.ClonkRageRushHour_GBarChart.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ClonkRageRushHour_GBarChart.BarDistance = 65
        Me.ClonkRageRushHour_GBarChart.DrawHorizontalLines = False
        Me.ClonkRageRushHour_GBarChart.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.ClonkRageRushHour_GBarChart.GraphLineColor = System.Drawing.Color.Gray
        Me.ClonkRageRushHour_GBarChart.HoritonzalGradientColor = System.Drawing.Color.Transparent
        Me.ClonkRageRushHour_GBarChart.HorizontalLinesColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClonkRageRushHour_GBarChart.Location = New System.Drawing.Point(54, 293)
        Me.ClonkRageRushHour_GBarChart.Name = "ClonkRageRushHour_GBarChart"
        Me.ClonkRageRushHour_GBarChart.NotAdjustedMaximum = 40
        Me.ClonkRageRushHour_GBarChart.NotificationLineValueFont = New System.Drawing.Font("Segoe UI", 6.0!)
        Me.ClonkRageRushHour_GBarChart.Size = New System.Drawing.Size(493, 225)
        Me.ClonkRageRushHour_GBarChart.TabIndex = 37
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.LegacyClonkLogo
        Me.PictureBox3.Location = New System.Drawing.Point(796, 6)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(279, 247)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 1
        Me.PictureBox3.TabStop = False
        '
        'MetroTranslatorLabel15
        '
        Me.MetroTranslatorLabel15.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel15.AutoSize = True
        Me.MetroTranslatorLabel15.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel15.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel15.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel15.LanguageKey = "MAIN:LIBRARY_LC_RUSHHOURTEXT"
        Me.MetroTranslatorLabel15.Location = New System.Drawing.Point(53, 275)
        Me.MetroTranslatorLabel15.Name = "MetroTranslatorLabel15"
        Me.MetroTranslatorLabel15.ShowToolTip = True
        Me.MetroTranslatorLabel15.Size = New System.Drawing.Size(156, 15)
        Me.MetroTranslatorLabel15.TabIndex = 45
        Me.MetroTranslatorLabel15.Text = "Stoßzeiten von LegacyClonk"
        '
        'MetroTranslatorLabel10
        '
        Me.MetroTranslatorLabel10.AutoSize = True
        Me.MetroTranslatorLabel10.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel10.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel10.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel10.LanguageKey = "MAIN:LIBRARY_LC_INFOTEXT"
        Me.MetroTranslatorLabel10.Location = New System.Drawing.Point(6, 6)
        Me.MetroTranslatorLabel10.Name = "MetroTranslatorLabel10"
        Me.MetroTranslatorLabel10.ShowToolTip = True
        Me.MetroTranslatorLabel10.Size = New System.Drawing.Size(325, 15)
        Me.MetroTranslatorLabel10.TabIndex = 44
        Me.MetroTranslatorLabel10.Text = "Informationen und Systemanforderungen über LegacyClonk"
        '
        'LCDesc_asl
        '
        Me.LCDesc_asl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LCDesc_asl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LCDesc_asl.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.LCDesc_asl.DefaultColor = System.Drawing.Color.White
        Me.LCDesc_asl.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.LCDesc_asl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.LCDesc_asl.ForeColor = System.Drawing.Color.Black
        Me.LCDesc_asl.HideSelection = False
        Me.LCDesc_asl.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LCDesc_asl.InputText = resources.GetString("LCDesc_asl.InputText")
        Me.LCDesc_asl.Location = New System.Drawing.Point(6, 24)
        Me.LCDesc_asl.Multiline = True
        Me.LCDesc_asl.Name = "LCDesc_asl"
        Me.LCDesc_asl.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.LCDesc_asl.ReadOnly = True
        Me.LCDesc_asl.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.LCDesc_asl.Size = New System.Drawing.Size(784, 229)
        Me.LCDesc_asl.TabIndex = 29
        Me.LCDesc_asl.Text = resources.GetString("LCDesc_asl.Text")
        '
        'cmd_ClonkRageSettings_btn
        '
        Me.cmd_ClonkRageSettings_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_ClonkRageSettings_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_ClonkRageSettings_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_ClonkRageSettings_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_ClonkRageSettings_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_ClonkRageSettings_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_ClonkRageSettings_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cmd_ClonkRageSettings_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_ClonkRageSettings_btn.Icon = CType(resources.GetObject("cmd_ClonkRageSettings_btn.Icon"), System.Drawing.Image)
        Me.cmd_ClonkRageSettings_btn.Location = New System.Drawing.Point(1038, 559)
        Me.cmd_ClonkRageSettings_btn.Name = "cmd_ClonkRageSettings_btn"
        Me.cmd_ClonkRageSettings_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_ClonkRageSettings_btn.RoundingArc = 42
        Me.cmd_ClonkRageSettings_btn.ScaleImage = False
        Me.cmd_ClonkRageSettings_btn.ScalingSize = New System.Drawing.Size(24, 24)
        Me.cmd_ClonkRageSettings_btn.Size = New System.Drawing.Size(37, 42)
        Me.cmd_ClonkRageSettings_btn.TabIndex = 43
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.White
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage3.Controls.Add(Me.MetroTranslatorLabel22)
        Me.TabPage3.Controls.Add(Me.Panel4)
        Me.TabPage3.Controls.Add(Me.ClonkEndeavourWebbrowserError_pnl)
        Me.TabPage3.Controls.Add(Me.cmd_ClonkEndeavour_btn)
        Me.TabPage3.Controls.Add(Me.ClonkEndeavourRushHour_GBarChart)
        Me.TabPage3.Controls.Add(Me.PictureBox4)
        Me.TabPage3.Controls.Add(Me.MetroTranslatorLabel16)
        Me.TabPage3.Controls.Add(Me.MetroTranslatorLabel11)
        Me.TabPage3.Controls.Add(Me.CEDesc_asl)
        Me.TabPage3.Controls.Add(Me.cmd_ClonkEndeavourSettings_btn)
        Me.TabPage3.Location = New System.Drawing.Point(124, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1083, 614)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Clonk Endeavour"
        '
        'MetroTranslatorLabel22
        '
        Me.MetroTranslatorLabel22.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel22.AutoSize = True
        Me.MetroTranslatorLabel22.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel22.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel22.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel22.LanguageKey = "MAIN:LIBRARY_CE_PUBLISHEDTEXT"
        Me.MetroTranslatorLabel22.Location = New System.Drawing.Point(6, 594)
        Me.MetroTranslatorLabel22.Name = "MetroTranslatorLabel22"
        Me.MetroTranslatorLabel22.ShowToolTip = True
        Me.MetroTranslatorLabel22.Size = New System.Drawing.Size(201, 15)
        Me.MetroTranslatorLabel22.TabIndex = 48
        Me.MetroTranslatorLabel22.Text = "Clonk Endeavour erschienen : 2004"
        '
        'Panel4
        '
        Me.Panel4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.ce_sunday_lbl)
        Me.Panel4.Controls.Add(Me.ce_saturday_lbl)
        Me.Panel4.Controls.Add(Me.ce_friday_lbl)
        Me.Panel4.Controls.Add(Me.ce_thursday_lbl)
        Me.Panel4.Controls.Add(Me.ce_wednesday_lbl)
        Me.Panel4.Controls.Add(Me.ce_tuesday_lbl)
        Me.Panel4.Controls.Add(Me.ce_monday_lbl)
        Me.Panel4.Controls.Add(Me.MetroTranslatorLabel28)
        Me.Panel4.Location = New System.Drawing.Point(54, 524)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(493, 37)
        Me.Panel4.TabIndex = 47
        '
        'ce_sunday_lbl
        '
        Me.ce_sunday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ce_sunday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ce_sunday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.ce_sunday_lbl.LanguageKey = "MAIN:OTHER_SUNDAY"
        Me.ce_sunday_lbl.Location = New System.Drawing.Point(432, 10)
        Me.ce_sunday_lbl.Name = "ce_sunday_lbl"
        Me.ce_sunday_lbl.ShowToolTip = True
        Me.ce_sunday_lbl.Size = New System.Drawing.Size(51, 15)
        Me.ce_sunday_lbl.TabIndex = 14
        Me.ce_sunday_lbl.Text = "Sonntag"
        Me.ce_sunday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ce_saturday_lbl
        '
        Me.ce_saturday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ce_saturday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ce_saturday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(157, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.ce_saturday_lbl.LanguageKey = "MAIN:OTHER_SATURDAY"
        Me.ce_saturday_lbl.Location = New System.Drawing.Point(369, 10)
        Me.ce_saturday_lbl.Name = "ce_saturday_lbl"
        Me.ce_saturday_lbl.ShowToolTip = True
        Me.ce_saturday_lbl.Size = New System.Drawing.Size(58, 15)
        Me.ce_saturday_lbl.TabIndex = 13
        Me.ce_saturday_lbl.Text = "Samstag"
        Me.ce_saturday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ce_friday_lbl
        '
        Me.ce_friday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ce_friday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ce_friday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(144, Byte), Integer), CType(CType(178, Byte), Integer))
        Me.ce_friday_lbl.LanguageKey = "MAIN:OTHER_FRIDAY"
        Me.ce_friday_lbl.Location = New System.Drawing.Point(321, 10)
        Me.ce_friday_lbl.Name = "ce_friday_lbl"
        Me.ce_friday_lbl.ShowToolTip = True
        Me.ce_friday_lbl.Size = New System.Drawing.Size(45, 15)
        Me.ce_friday_lbl.TabIndex = 12
        Me.ce_friday_lbl.Text = "Freitag"
        Me.ce_friday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ce_thursday_lbl
        '
        Me.ce_thursday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ce_thursday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ce_thursday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.ce_thursday_lbl.LanguageKey = "MAIN:OTHER_THURSDAY"
        Me.ce_thursday_lbl.Location = New System.Drawing.Point(247, 10)
        Me.ce_thursday_lbl.Name = "ce_thursday_lbl"
        Me.ce_thursday_lbl.ShowToolTip = True
        Me.ce_thursday_lbl.Size = New System.Drawing.Size(70, 15)
        Me.ce_thursday_lbl.TabIndex = 11
        Me.ce_thursday_lbl.Text = "Donnerstag"
        Me.ce_thursday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ce_wednesday_lbl
        '
        Me.ce_wednesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ce_wednesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ce_wednesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ce_wednesday_lbl.LanguageKey = "MAIN:OTHER_WEDNESDAY"
        Me.ce_wednesday_lbl.Location = New System.Drawing.Point(183, 10)
        Me.ce_wednesday_lbl.Name = "ce_wednesday_lbl"
        Me.ce_wednesday_lbl.ShowToolTip = True
        Me.ce_wednesday_lbl.Size = New System.Drawing.Size(60, 15)
        Me.ce_wednesday_lbl.TabIndex = 10
        Me.ce_wednesday_lbl.Text = "Mittwoch"
        Me.ce_wednesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ce_tuesday_lbl
        '
        Me.ce_tuesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ce_tuesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ce_tuesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(148, Byte), Integer))
        Me.ce_tuesday_lbl.LanguageKey = "MAIN:OTHER_TUESDAY"
        Me.ce_tuesday_lbl.Location = New System.Drawing.Point(124, 10)
        Me.ce_tuesday_lbl.Name = "ce_tuesday_lbl"
        Me.ce_tuesday_lbl.ShowToolTip = True
        Me.ce_tuesday_lbl.Size = New System.Drawing.Size(55, 15)
        Me.ce_tuesday_lbl.TabIndex = 9
        Me.ce_tuesday_lbl.Text = "Dienstag"
        Me.ce_tuesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ce_monday_lbl
        '
        Me.ce_monday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ce_monday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ce_monday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.ce_monday_lbl.LanguageKey = "MAIN:OTHER_MONDAY"
        Me.ce_monday_lbl.Location = New System.Drawing.Point(67, 10)
        Me.ce_monday_lbl.Name = "ce_monday_lbl"
        Me.ce_monday_lbl.ShowToolTip = True
        Me.ce_monday_lbl.Size = New System.Drawing.Size(53, 15)
        Me.ce_monday_lbl.TabIndex = 8
        Me.ce_monday_lbl.Text = "Montag"
        Me.ce_monday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTranslatorLabel28
        '
        Me.MetroTranslatorLabel28.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel28.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel28.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel28.LanguageKey = "MAIN:OTHER_LEGENDTEXT"
        Me.MetroTranslatorLabel28.Location = New System.Drawing.Point(6, 10)
        Me.MetroTranslatorLabel28.Name = "MetroTranslatorLabel28"
        Me.MetroTranslatorLabel28.ShowToolTip = True
        Me.MetroTranslatorLabel28.Size = New System.Drawing.Size(55, 15)
        Me.MetroTranslatorLabel28.TabIndex = 7
        Me.MetroTranslatorLabel28.Text = "Legende:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.MetroTranslatorLabel28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ClonkEndeavourWebbrowserError_pnl
        '
        Me.ClonkEndeavourWebbrowserError_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClonkEndeavourWebbrowserError_pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ClonkEndeavourWebbrowserError_pnl.Controls.Add(Me.MetroLabel35)
        Me.ClonkEndeavourWebbrowserError_pnl.Location = New System.Drawing.Point(594, 261)
        Me.ClonkEndeavourWebbrowserError_pnl.Name = "ClonkEndeavourWebbrowserError_pnl"
        Me.ClonkEndeavourWebbrowserError_pnl.Size = New System.Drawing.Size(481, 287)
        Me.ClonkEndeavourWebbrowserError_pnl.TabIndex = 22
        Me.ClonkEndeavourWebbrowserError_pnl.Tag = "DEBUG"
        Me.ClonkEndeavourWebbrowserError_pnl.Visible = False
        '
        'MetroLabel35
        '
        Me.MetroLabel35.BackColor = System.Drawing.Color.DimGray
        Me.MetroLabel35.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel35.ForeColor = System.Drawing.Color.White
        Me.MetroLabel35.Location = New System.Drawing.Point(1, 0)
        Me.MetroLabel35.Name = "MetroLabel35"
        Me.MetroLabel35.Size = New System.Drawing.Size(477, 262)
        Me.MetroLabel35.TabIndex = 1
        Me.MetroLabel35.Text = resources.GetString("MetroLabel35.Text")
        '
        'cmd_ClonkEndeavour_btn
        '
        Me.cmd_ClonkEndeavour_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_ClonkEndeavour_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_ClonkEndeavour_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_ClonkEndeavour_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_ClonkEndeavour_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_ClonkEndeavour_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_ClonkEndeavour_btn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmd_ClonkEndeavour_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_ClonkEndeavour_btn.Location = New System.Drawing.Point(766, 559)
        Me.cmd_ClonkEndeavour_btn.Name = "cmd_ClonkEndeavour_btn"
        Me.cmd_ClonkEndeavour_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_ClonkEndeavour_btn.RoundingArc = 42
        Me.cmd_ClonkEndeavour_btn.Size = New System.Drawing.Size(272, 42)
        Me.cmd_ClonkEndeavour_btn.TabIndex = 13
        Me.cmd_ClonkEndeavour_btn.Text = "Download Clonk Endeavour x86"
        '
        'ClonkEndeavourRushHour_GBarChart
        '
        Me.ClonkEndeavourRushHour_GBarChart.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ClonkEndeavourRushHour_GBarChart.BarDistance = 65
        Me.ClonkEndeavourRushHour_GBarChart.DrawHorizontalLines = False
        Me.ClonkEndeavourRushHour_GBarChart.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.ClonkEndeavourRushHour_GBarChart.GraphLineColor = System.Drawing.Color.Gray
        Me.ClonkEndeavourRushHour_GBarChart.HoritonzalGradientColor = System.Drawing.Color.Transparent
        Me.ClonkEndeavourRushHour_GBarChart.HorizontalLinesColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClonkEndeavourRushHour_GBarChart.Location = New System.Drawing.Point(54, 293)
        Me.ClonkEndeavourRushHour_GBarChart.Name = "ClonkEndeavourRushHour_GBarChart"
        Me.ClonkEndeavourRushHour_GBarChart.NotAdjustedMaximum = 40
        Me.ClonkEndeavourRushHour_GBarChart.NotificationLineValueFont = New System.Drawing.Font("Segoe UI", 6.0!)
        Me.ClonkEndeavourRushHour_GBarChart.Size = New System.Drawing.Size(493, 225)
        Me.ClonkEndeavourRushHour_GBarChart.TabIndex = 36
        '
        'PictureBox4
        '
        Me.PictureBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.ClonkEndeavourLogo
        Me.PictureBox4.Location = New System.Drawing.Point(796, 6)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(279, 247)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 2
        Me.PictureBox4.TabStop = False
        '
        'MetroTranslatorLabel16
        '
        Me.MetroTranslatorLabel16.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel16.AutoSize = True
        Me.MetroTranslatorLabel16.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel16.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel16.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel16.LanguageKey = "MAIN:LIBRARY_CE_RUSHHOURTEXT"
        Me.MetroTranslatorLabel16.Location = New System.Drawing.Point(53, 275)
        Me.MetroTranslatorLabel16.Name = "MetroTranslatorLabel16"
        Me.MetroTranslatorLabel16.ShowToolTip = True
        Me.MetroTranslatorLabel16.Size = New System.Drawing.Size(178, 15)
        Me.MetroTranslatorLabel16.TabIndex = 46
        Me.MetroTranslatorLabel16.Text = "Stoßzeiten von Clonk Endeavour"
        '
        'MetroTranslatorLabel11
        '
        Me.MetroTranslatorLabel11.AutoSize = True
        Me.MetroTranslatorLabel11.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel11.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel11.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel11.LanguageKey = "MAIN:LIBRARY_CE_INFOTEXT"
        Me.MetroTranslatorLabel11.Location = New System.Drawing.Point(6, 6)
        Me.MetroTranslatorLabel11.Name = "MetroTranslatorLabel11"
        Me.MetroTranslatorLabel11.ShowToolTip = True
        Me.MetroTranslatorLabel11.Size = New System.Drawing.Size(347, 15)
        Me.MetroTranslatorLabel11.TabIndex = 45
        Me.MetroTranslatorLabel11.Text = "Informationen und Systemanforderungen über Clonk Endeavour" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'CEDesc_asl
        '
        Me.CEDesc_asl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CEDesc_asl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CEDesc_asl.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CEDesc_asl.DefaultColor = System.Drawing.Color.White
        Me.CEDesc_asl.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CEDesc_asl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CEDesc_asl.ForeColor = System.Drawing.Color.Black
        Me.CEDesc_asl.HideSelection = False
        Me.CEDesc_asl.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CEDesc_asl.InputText = resources.GetString("CEDesc_asl.InputText")
        Me.CEDesc_asl.Location = New System.Drawing.Point(6, 24)
        Me.CEDesc_asl.Multiline = True
        Me.CEDesc_asl.Name = "CEDesc_asl"
        Me.CEDesc_asl.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.CEDesc_asl.ReadOnly = True
        Me.CEDesc_asl.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.CEDesc_asl.Size = New System.Drawing.Size(784, 229)
        Me.CEDesc_asl.TabIndex = 32
        Me.CEDesc_asl.Text = resources.GetString("CEDesc_asl.Text")
        '
        'cmd_ClonkEndeavourSettings_btn
        '
        Me.cmd_ClonkEndeavourSettings_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_ClonkEndeavourSettings_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_ClonkEndeavourSettings_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_ClonkEndeavourSettings_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_ClonkEndeavourSettings_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_ClonkEndeavourSettings_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_ClonkEndeavourSettings_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cmd_ClonkEndeavourSettings_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_ClonkEndeavourSettings_btn.Icon = CType(resources.GetObject("cmd_ClonkEndeavourSettings_btn.Icon"), System.Drawing.Image)
        Me.cmd_ClonkEndeavourSettings_btn.Location = New System.Drawing.Point(1038, 559)
        Me.cmd_ClonkEndeavourSettings_btn.Name = "cmd_ClonkEndeavourSettings_btn"
        Me.cmd_ClonkEndeavourSettings_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_ClonkEndeavourSettings_btn.RoundingArc = 42
        Me.cmd_ClonkEndeavourSettings_btn.ScaleImage = False
        Me.cmd_ClonkEndeavourSettings_btn.ScalingSize = New System.Drawing.Size(24, 24)
        Me.cmd_ClonkEndeavourSettings_btn.Size = New System.Drawing.Size(37, 42)
        Me.cmd_ClonkEndeavourSettings_btn.TabIndex = 44
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.White
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage4.Controls.Add(Me.MetroTranslatorLabel23)
        Me.TabPage4.Controls.Add(Me.Panel5)
        Me.TabPage4.Controls.Add(Me.ClonkPlanetWebbrowserError_pnl)
        Me.TabPage4.Controls.Add(Me.cmd_ClonkPlanet_btn)
        Me.TabPage4.Controls.Add(Me.ClonkPlanetRushHour_GBarChart)
        Me.TabPage4.Controls.Add(Me.PictureBox5)
        Me.TabPage4.Controls.Add(Me.MetroTranslatorLabel17)
        Me.TabPage4.Controls.Add(Me.MetroTranslatorLabel12)
        Me.TabPage4.Controls.Add(Me.CPDesc_asl)
        Me.TabPage4.Controls.Add(Me.cmd_ClonkPlanetSettings_btn)
        Me.TabPage4.Location = New System.Drawing.Point(124, 4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1083, 614)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Clonk Planet"
        '
        'MetroTranslatorLabel23
        '
        Me.MetroTranslatorLabel23.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel23.AutoSize = True
        Me.MetroTranslatorLabel23.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel23.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel23.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel23.LanguageKey = "MAIN:LIBRARY_CP_PUBLISHEDTEXT"
        Me.MetroTranslatorLabel23.Location = New System.Drawing.Point(6, 594)
        Me.MetroTranslatorLabel23.Name = "MetroTranslatorLabel23"
        Me.MetroTranslatorLabel23.ShowToolTip = True
        Me.MetroTranslatorLabel23.Size = New System.Drawing.Size(177, 15)
        Me.MetroTranslatorLabel23.TabIndex = 49
        Me.MetroTranslatorLabel23.Text = "Clonk Planet erschienen : 2000"
        '
        'Panel5
        '
        Me.Panel5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.cp_sunday_lbl)
        Me.Panel5.Controls.Add(Me.cp_saturday_lbl)
        Me.Panel5.Controls.Add(Me.cp_friday_lbl)
        Me.Panel5.Controls.Add(Me.cp_thursday_lbl)
        Me.Panel5.Controls.Add(Me.cp_wednesday_lbl)
        Me.Panel5.Controls.Add(Me.cp_tuesday_lbl)
        Me.Panel5.Controls.Add(Me.cp_monday_lbl)
        Me.Panel5.Controls.Add(Me.MetroTranslatorLabel29)
        Me.Panel5.Location = New System.Drawing.Point(54, 524)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(493, 37)
        Me.Panel5.TabIndex = 48
        '
        'cp_sunday_lbl
        '
        Me.cp_sunday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cp_sunday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cp_sunday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cp_sunday_lbl.LanguageKey = "MAIN:OTHER_SUNDAY"
        Me.cp_sunday_lbl.Location = New System.Drawing.Point(432, 10)
        Me.cp_sunday_lbl.Name = "cp_sunday_lbl"
        Me.cp_sunday_lbl.ShowToolTip = True
        Me.cp_sunday_lbl.Size = New System.Drawing.Size(51, 15)
        Me.cp_sunday_lbl.TabIndex = 14
        Me.cp_sunday_lbl.Text = "Sonntag"
        Me.cp_sunday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cp_saturday_lbl
        '
        Me.cp_saturday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cp_saturday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cp_saturday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(157, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.cp_saturday_lbl.LanguageKey = "MAIN:OTHER_SATURDAY"
        Me.cp_saturday_lbl.Location = New System.Drawing.Point(369, 10)
        Me.cp_saturday_lbl.Name = "cp_saturday_lbl"
        Me.cp_saturday_lbl.ShowToolTip = True
        Me.cp_saturday_lbl.Size = New System.Drawing.Size(58, 15)
        Me.cp_saturday_lbl.TabIndex = 13
        Me.cp_saturday_lbl.Text = "Samstag"
        Me.cp_saturday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cp_friday_lbl
        '
        Me.cp_friday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cp_friday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cp_friday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(144, Byte), Integer), CType(CType(178, Byte), Integer))
        Me.cp_friday_lbl.LanguageKey = "MAIN:OTHER_FRIDAY"
        Me.cp_friday_lbl.Location = New System.Drawing.Point(321, 10)
        Me.cp_friday_lbl.Name = "cp_friday_lbl"
        Me.cp_friday_lbl.ShowToolTip = True
        Me.cp_friday_lbl.Size = New System.Drawing.Size(45, 15)
        Me.cp_friday_lbl.TabIndex = 12
        Me.cp_friday_lbl.Text = "Freitag"
        Me.cp_friday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cp_thursday_lbl
        '
        Me.cp_thursday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cp_thursday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cp_thursday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cp_thursday_lbl.LanguageKey = "MAIN:OTHER_THURSDAY"
        Me.cp_thursday_lbl.Location = New System.Drawing.Point(247, 10)
        Me.cp_thursday_lbl.Name = "cp_thursday_lbl"
        Me.cp_thursday_lbl.ShowToolTip = True
        Me.cp_thursday_lbl.Size = New System.Drawing.Size(70, 15)
        Me.cp_thursday_lbl.TabIndex = 11
        Me.cp_thursday_lbl.Text = "Donnerstag"
        Me.cp_thursday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cp_wednesday_lbl
        '
        Me.cp_wednesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cp_wednesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cp_wednesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.cp_wednesday_lbl.LanguageKey = "MAIN:OTHER_WEDNESDAY"
        Me.cp_wednesday_lbl.Location = New System.Drawing.Point(183, 10)
        Me.cp_wednesday_lbl.Name = "cp_wednesday_lbl"
        Me.cp_wednesday_lbl.ShowToolTip = True
        Me.cp_wednesday_lbl.Size = New System.Drawing.Size(60, 15)
        Me.cp_wednesday_lbl.TabIndex = 10
        Me.cp_wednesday_lbl.Text = "Mittwoch"
        Me.cp_wednesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cp_tuesday_lbl
        '
        Me.cp_tuesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cp_tuesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cp_tuesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(148, Byte), Integer))
        Me.cp_tuesday_lbl.LanguageKey = "MAIN:OTHER_TUESDAY"
        Me.cp_tuesday_lbl.Location = New System.Drawing.Point(124, 10)
        Me.cp_tuesday_lbl.Name = "cp_tuesday_lbl"
        Me.cp_tuesday_lbl.ShowToolTip = True
        Me.cp_tuesday_lbl.Size = New System.Drawing.Size(55, 15)
        Me.cp_tuesday_lbl.TabIndex = 9
        Me.cp_tuesday_lbl.Text = "Dienstag"
        Me.cp_tuesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cp_monday_lbl
        '
        Me.cp_monday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.cp_monday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cp_monday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.cp_monday_lbl.LanguageKey = "MAIN:OTHER_MONDAY"
        Me.cp_monday_lbl.Location = New System.Drawing.Point(67, 10)
        Me.cp_monday_lbl.Name = "cp_monday_lbl"
        Me.cp_monday_lbl.ShowToolTip = True
        Me.cp_monday_lbl.Size = New System.Drawing.Size(53, 15)
        Me.cp_monday_lbl.TabIndex = 8
        Me.cp_monday_lbl.Text = "Montag"
        Me.cp_monday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTranslatorLabel29
        '
        Me.MetroTranslatorLabel29.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel29.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel29.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel29.LanguageKey = "MAIN:OTHER_LEGENDTEXT"
        Me.MetroTranslatorLabel29.Location = New System.Drawing.Point(6, 10)
        Me.MetroTranslatorLabel29.Name = "MetroTranslatorLabel29"
        Me.MetroTranslatorLabel29.ShowToolTip = True
        Me.MetroTranslatorLabel29.Size = New System.Drawing.Size(55, 15)
        Me.MetroTranslatorLabel29.TabIndex = 7
        Me.MetroTranslatorLabel29.Text = "Legende:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.MetroTranslatorLabel29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ClonkPlanetWebbrowserError_pnl
        '
        Me.ClonkPlanetWebbrowserError_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClonkPlanetWebbrowserError_pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ClonkPlanetWebbrowserError_pnl.Controls.Add(Me.MetroLabel36)
        Me.ClonkPlanetWebbrowserError_pnl.Location = New System.Drawing.Point(594, 261)
        Me.ClonkPlanetWebbrowserError_pnl.Name = "ClonkPlanetWebbrowserError_pnl"
        Me.ClonkPlanetWebbrowserError_pnl.Size = New System.Drawing.Size(481, 287)
        Me.ClonkPlanetWebbrowserError_pnl.TabIndex = 23
        Me.ClonkPlanetWebbrowserError_pnl.Tag = "DEBUG"
        Me.ClonkPlanetWebbrowserError_pnl.Visible = False
        '
        'MetroLabel36
        '
        Me.MetroLabel36.BackColor = System.Drawing.Color.DimGray
        Me.MetroLabel36.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel36.ForeColor = System.Drawing.Color.White
        Me.MetroLabel36.Location = New System.Drawing.Point(1, 0)
        Me.MetroLabel36.Name = "MetroLabel36"
        Me.MetroLabel36.Size = New System.Drawing.Size(477, 262)
        Me.MetroLabel36.TabIndex = 1
        Me.MetroLabel36.Text = resources.GetString("MetroLabel36.Text")
        '
        'cmd_ClonkPlanet_btn
        '
        Me.cmd_ClonkPlanet_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_ClonkPlanet_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_ClonkPlanet_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_ClonkPlanet_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_ClonkPlanet_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_ClonkPlanet_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_ClonkPlanet_btn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmd_ClonkPlanet_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_ClonkPlanet_btn.Location = New System.Drawing.Point(799, 559)
        Me.cmd_ClonkPlanet_btn.Name = "cmd_ClonkPlanet_btn"
        Me.cmd_ClonkPlanet_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_ClonkPlanet_btn.RoundingArc = 42
        Me.cmd_ClonkPlanet_btn.Size = New System.Drawing.Size(239, 42)
        Me.cmd_ClonkPlanet_btn.TabIndex = 14
        Me.cmd_ClonkPlanet_btn.Text = "Download Clonk Planet x86"
        '
        'ClonkPlanetRushHour_GBarChart
        '
        Me.ClonkPlanetRushHour_GBarChart.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ClonkPlanetRushHour_GBarChart.BarDistance = 65
        Me.ClonkPlanetRushHour_GBarChart.DrawHorizontalLines = False
        Me.ClonkPlanetRushHour_GBarChart.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.ClonkPlanetRushHour_GBarChart.GraphLineColor = System.Drawing.Color.Gray
        Me.ClonkPlanetRushHour_GBarChart.HoritonzalGradientColor = System.Drawing.Color.Transparent
        Me.ClonkPlanetRushHour_GBarChart.HorizontalLinesColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClonkPlanetRushHour_GBarChart.Location = New System.Drawing.Point(54, 293)
        Me.ClonkPlanetRushHour_GBarChart.Name = "ClonkPlanetRushHour_GBarChart"
        Me.ClonkPlanetRushHour_GBarChart.NotAdjustedMaximum = 40
        Me.ClonkPlanetRushHour_GBarChart.NotificationLineValueFont = New System.Drawing.Font("Segoe UI", 6.0!)
        Me.ClonkPlanetRushHour_GBarChart.Size = New System.Drawing.Size(493, 225)
        Me.ClonkPlanetRushHour_GBarChart.TabIndex = 35
        '
        'PictureBox5
        '
        Me.PictureBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.ClonkPlanetLogo
        Me.PictureBox5.Location = New System.Drawing.Point(796, 6)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(279, 247)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 3
        Me.PictureBox5.TabStop = False
        '
        'MetroTranslatorLabel17
        '
        Me.MetroTranslatorLabel17.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel17.AutoSize = True
        Me.MetroTranslatorLabel17.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel17.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel17.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel17.LanguageKey = "MAIN:LIBRARY_CP_RUSHHOURTEXT"
        Me.MetroTranslatorLabel17.Location = New System.Drawing.Point(53, 275)
        Me.MetroTranslatorLabel17.Name = "MetroTranslatorLabel17"
        Me.MetroTranslatorLabel17.ShowToolTip = True
        Me.MetroTranslatorLabel17.Size = New System.Drawing.Size(155, 15)
        Me.MetroTranslatorLabel17.TabIndex = 47
        Me.MetroTranslatorLabel17.Text = "Stoßzeiten von Clonk Planet"
        '
        'MetroTranslatorLabel12
        '
        Me.MetroTranslatorLabel12.AutoSize = True
        Me.MetroTranslatorLabel12.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel12.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel12.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel12.LanguageKey = "MAIN:LIBRARY_CP_INFOTEXT"
        Me.MetroTranslatorLabel12.Location = New System.Drawing.Point(6, 6)
        Me.MetroTranslatorLabel12.Name = "MetroTranslatorLabel12"
        Me.MetroTranslatorLabel12.ShowToolTip = True
        Me.MetroTranslatorLabel12.Size = New System.Drawing.Size(324, 15)
        Me.MetroTranslatorLabel12.TabIndex = 46
        Me.MetroTranslatorLabel12.Text = "Informationen und Systemanforderungen über Clonk Planet"
        '
        'CPDesc_asl
        '
        Me.CPDesc_asl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CPDesc_asl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CPDesc_asl.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CPDesc_asl.DefaultColor = System.Drawing.Color.White
        Me.CPDesc_asl.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CPDesc_asl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CPDesc_asl.ForeColor = System.Drawing.Color.Black
        Me.CPDesc_asl.HideSelection = False
        Me.CPDesc_asl.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CPDesc_asl.InputText = resources.GetString("CPDesc_asl.InputText")
        Me.CPDesc_asl.Location = New System.Drawing.Point(6, 24)
        Me.CPDesc_asl.Multiline = True
        Me.CPDesc_asl.Name = "CPDesc_asl"
        Me.CPDesc_asl.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.CPDesc_asl.ReadOnly = True
        Me.CPDesc_asl.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.CPDesc_asl.Size = New System.Drawing.Size(784, 229)
        Me.CPDesc_asl.TabIndex = 31
        Me.CPDesc_asl.Text = resources.GetString("CPDesc_asl.Text")
        '
        'cmd_ClonkPlanetSettings_btn
        '
        Me.cmd_ClonkPlanetSettings_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_ClonkPlanetSettings_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_ClonkPlanetSettings_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_ClonkPlanetSettings_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_ClonkPlanetSettings_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_ClonkPlanetSettings_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_ClonkPlanetSettings_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cmd_ClonkPlanetSettings_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_ClonkPlanetSettings_btn.Icon = CType(resources.GetObject("cmd_ClonkPlanetSettings_btn.Icon"), System.Drawing.Image)
        Me.cmd_ClonkPlanetSettings_btn.Location = New System.Drawing.Point(1038, 559)
        Me.cmd_ClonkPlanetSettings_btn.Name = "cmd_ClonkPlanetSettings_btn"
        Me.cmd_ClonkPlanetSettings_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_ClonkPlanetSettings_btn.RoundingArc = 42
        Me.cmd_ClonkPlanetSettings_btn.ScaleImage = False
        Me.cmd_ClonkPlanetSettings_btn.ScalingSize = New System.Drawing.Size(24, 24)
        Me.cmd_ClonkPlanetSettings_btn.Size = New System.Drawing.Size(37, 42)
        Me.cmd_ClonkPlanetSettings_btn.TabIndex = 45
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.White
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage5.Controls.Add(Me.MetroTranslatorLabel24)
        Me.TabPage5.Controls.Add(Me.Panel6)
        Me.TabPage5.Controls.Add(Me.Clonk4WebbrowserError_pnl)
        Me.TabPage5.Controls.Add(Me.cmd_Clonk4_btn)
        Me.TabPage5.Controls.Add(Me.Clonk4RushHour_GBarChart)
        Me.TabPage5.Controls.Add(Me.PictureBox6)
        Me.TabPage5.Controls.Add(Me.MetroTranslatorLabel18)
        Me.TabPage5.Controls.Add(Me.MetroTranslatorLabel13)
        Me.TabPage5.Controls.Add(Me.C4Desc_asl)
        Me.TabPage5.Controls.Add(Me.cmd_Clonk4Settings_btn)
        Me.TabPage5.Location = New System.Drawing.Point(124, 4)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1083, 614)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Clonk 4"
        '
        'MetroTranslatorLabel24
        '
        Me.MetroTranslatorLabel24.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel24.AutoSize = True
        Me.MetroTranslatorLabel24.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel24.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel24.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel24.LanguageKey = "MAIN:LIBRARY_C4_PUBLISHEDTEXT"
        Me.MetroTranslatorLabel24.Location = New System.Drawing.Point(6, 594)
        Me.MetroTranslatorLabel24.Name = "MetroTranslatorLabel24"
        Me.MetroTranslatorLabel24.ShowToolTip = True
        Me.MetroTranslatorLabel24.Size = New System.Drawing.Size(149, 15)
        Me.MetroTranslatorLabel24.TabIndex = 50
        Me.MetroTranslatorLabel24.Text = "Clonk 4 erschienen : 1998"
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.c4_sunday_lbl)
        Me.Panel6.Controls.Add(Me.c4_saturday_lbl)
        Me.Panel6.Controls.Add(Me.c4_friday_lbl)
        Me.Panel6.Controls.Add(Me.c4_thursday_lbl)
        Me.Panel6.Controls.Add(Me.c4_wednesday_lbl)
        Me.Panel6.Controls.Add(Me.c4_tuesday_lbl)
        Me.Panel6.Controls.Add(Me.c4_monday_lbl)
        Me.Panel6.Controls.Add(Me.MetroTranslatorLabel30)
        Me.Panel6.Location = New System.Drawing.Point(54, 524)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(493, 37)
        Me.Panel6.TabIndex = 49
        '
        'c4_sunday_lbl
        '
        Me.c4_sunday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.c4_sunday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.c4_sunday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.c4_sunday_lbl.LanguageKey = "MAIN:OTHER_SUNDAY"
        Me.c4_sunday_lbl.Location = New System.Drawing.Point(432, 10)
        Me.c4_sunday_lbl.Name = "c4_sunday_lbl"
        Me.c4_sunday_lbl.ShowToolTip = True
        Me.c4_sunday_lbl.Size = New System.Drawing.Size(51, 15)
        Me.c4_sunday_lbl.TabIndex = 14
        Me.c4_sunday_lbl.Text = "Sonntag"
        Me.c4_sunday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'c4_saturday_lbl
        '
        Me.c4_saturday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.c4_saturday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.c4_saturday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(157, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.c4_saturday_lbl.LanguageKey = "MAIN:OTHER_SATURDAY"
        Me.c4_saturday_lbl.Location = New System.Drawing.Point(369, 10)
        Me.c4_saturday_lbl.Name = "c4_saturday_lbl"
        Me.c4_saturday_lbl.ShowToolTip = True
        Me.c4_saturday_lbl.Size = New System.Drawing.Size(58, 15)
        Me.c4_saturday_lbl.TabIndex = 13
        Me.c4_saturday_lbl.Text = "Samstag"
        Me.c4_saturday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'c4_friday_lbl
        '
        Me.c4_friday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.c4_friday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.c4_friday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(144, Byte), Integer), CType(CType(178, Byte), Integer))
        Me.c4_friday_lbl.LanguageKey = "MAIN:OTHER_FRIDAY"
        Me.c4_friday_lbl.Location = New System.Drawing.Point(321, 10)
        Me.c4_friday_lbl.Name = "c4_friday_lbl"
        Me.c4_friday_lbl.ShowToolTip = True
        Me.c4_friday_lbl.Size = New System.Drawing.Size(45, 15)
        Me.c4_friday_lbl.TabIndex = 12
        Me.c4_friday_lbl.Text = "Freitag"
        Me.c4_friday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'c4_thursday_lbl
        '
        Me.c4_thursday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.c4_thursday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.c4_thursday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.c4_thursday_lbl.LanguageKey = "MAIN:OTHER_THURSDAY"
        Me.c4_thursday_lbl.Location = New System.Drawing.Point(247, 10)
        Me.c4_thursday_lbl.Name = "c4_thursday_lbl"
        Me.c4_thursday_lbl.ShowToolTip = True
        Me.c4_thursday_lbl.Size = New System.Drawing.Size(70, 15)
        Me.c4_thursday_lbl.TabIndex = 11
        Me.c4_thursday_lbl.Text = "Donnerstag"
        Me.c4_thursday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'c4_wednesday_lbl
        '
        Me.c4_wednesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.c4_wednesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.c4_wednesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.c4_wednesday_lbl.LanguageKey = "MAIN:OTHER_WEDNESDAY"
        Me.c4_wednesday_lbl.Location = New System.Drawing.Point(183, 10)
        Me.c4_wednesday_lbl.Name = "c4_wednesday_lbl"
        Me.c4_wednesday_lbl.ShowToolTip = True
        Me.c4_wednesday_lbl.Size = New System.Drawing.Size(60, 15)
        Me.c4_wednesday_lbl.TabIndex = 10
        Me.c4_wednesday_lbl.Text = "Mittwoch"
        Me.c4_wednesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'c4_tuesday_lbl
        '
        Me.c4_tuesday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.c4_tuesday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.c4_tuesday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(148, Byte), Integer))
        Me.c4_tuesday_lbl.LanguageKey = "MAIN:OTHER_TUESDAY"
        Me.c4_tuesday_lbl.Location = New System.Drawing.Point(124, 10)
        Me.c4_tuesday_lbl.Name = "c4_tuesday_lbl"
        Me.c4_tuesday_lbl.ShowToolTip = True
        Me.c4_tuesday_lbl.Size = New System.Drawing.Size(55, 15)
        Me.c4_tuesday_lbl.TabIndex = 9
        Me.c4_tuesday_lbl.Text = "Dienstag"
        Me.c4_tuesday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'c4_monday_lbl
        '
        Me.c4_monday_lbl.BackColor = System.Drawing.Color.Transparent
        Me.c4_monday_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.c4_monday_lbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.c4_monday_lbl.LanguageKey = "MAIN:OTHER_MONDAY"
        Me.c4_monday_lbl.Location = New System.Drawing.Point(67, 10)
        Me.c4_monday_lbl.Name = "c4_monday_lbl"
        Me.c4_monday_lbl.ShowToolTip = True
        Me.c4_monday_lbl.Size = New System.Drawing.Size(53, 15)
        Me.c4_monday_lbl.TabIndex = 8
        Me.c4_monday_lbl.Text = "Montag"
        Me.c4_monday_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTranslatorLabel30
        '
        Me.MetroTranslatorLabel30.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel30.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel30.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel30.LanguageKey = "MAIN:OTHER_LEGENDTEXT"
        Me.MetroTranslatorLabel30.Location = New System.Drawing.Point(6, 10)
        Me.MetroTranslatorLabel30.Name = "MetroTranslatorLabel30"
        Me.MetroTranslatorLabel30.ShowToolTip = True
        Me.MetroTranslatorLabel30.Size = New System.Drawing.Size(55, 15)
        Me.MetroTranslatorLabel30.TabIndex = 7
        Me.MetroTranslatorLabel30.Text = "Legende:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.MetroTranslatorLabel30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Clonk4WebbrowserError_pnl
        '
        Me.Clonk4WebbrowserError_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Clonk4WebbrowserError_pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Clonk4WebbrowserError_pnl.Controls.Add(Me.MetroLabel37)
        Me.Clonk4WebbrowserError_pnl.Location = New System.Drawing.Point(594, 261)
        Me.Clonk4WebbrowserError_pnl.Name = "Clonk4WebbrowserError_pnl"
        Me.Clonk4WebbrowserError_pnl.Size = New System.Drawing.Size(481, 287)
        Me.Clonk4WebbrowserError_pnl.TabIndex = 24
        Me.Clonk4WebbrowserError_pnl.Tag = "DEBUG"
        Me.Clonk4WebbrowserError_pnl.Visible = False
        '
        'MetroLabel37
        '
        Me.MetroLabel37.BackColor = System.Drawing.Color.DimGray
        Me.MetroLabel37.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel37.ForeColor = System.Drawing.Color.White
        Me.MetroLabel37.Location = New System.Drawing.Point(1, 0)
        Me.MetroLabel37.Name = "MetroLabel37"
        Me.MetroLabel37.Size = New System.Drawing.Size(477, 262)
        Me.MetroLabel37.TabIndex = 1
        Me.MetroLabel37.Text = resources.GetString("MetroLabel37.Text")
        '
        'cmd_Clonk4_btn
        '
        Me.cmd_Clonk4_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_Clonk4_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_Clonk4_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_Clonk4_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_Clonk4_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_Clonk4_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_Clonk4_btn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmd_Clonk4_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_Clonk4_btn.Location = New System.Drawing.Point(799, 559)
        Me.cmd_Clonk4_btn.Name = "cmd_Clonk4_btn"
        Me.cmd_Clonk4_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_Clonk4_btn.RoundingArc = 42
        Me.cmd_Clonk4_btn.Size = New System.Drawing.Size(239, 42)
        Me.cmd_Clonk4_btn.TabIndex = 14
        Me.cmd_Clonk4_btn.Text = "Download Clonk 4 x86"
        '
        'Clonk4RushHour_GBarChart
        '
        Me.Clonk4RushHour_GBarChart.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Clonk4RushHour_GBarChart.BarDistance = 65
        Me.Clonk4RushHour_GBarChart.DrawHorizontalLines = False
        Me.Clonk4RushHour_GBarChart.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.Clonk4RushHour_GBarChart.GraphLineColor = System.Drawing.Color.Gray
        Me.Clonk4RushHour_GBarChart.HoritonzalGradientColor = System.Drawing.Color.Transparent
        Me.Clonk4RushHour_GBarChart.HorizontalLinesColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Clonk4RushHour_GBarChart.Location = New System.Drawing.Point(54, 293)
        Me.Clonk4RushHour_GBarChart.Name = "Clonk4RushHour_GBarChart"
        Me.Clonk4RushHour_GBarChart.NotAdjustedMaximum = 40
        Me.Clonk4RushHour_GBarChart.NotificationLineValueFont = New System.Drawing.Font("Segoe UI", 6.0!)
        Me.Clonk4RushHour_GBarChart.Size = New System.Drawing.Size(493, 225)
        Me.Clonk4RushHour_GBarChart.TabIndex = 31
        '
        'PictureBox6
        '
        Me.PictureBox6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox6.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox6.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.Clonk4Logo
        Me.PictureBox6.Location = New System.Drawing.Point(796, 6)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(279, 247)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 3
        Me.PictureBox6.TabStop = False
        '
        'MetroTranslatorLabel18
        '
        Me.MetroTranslatorLabel18.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MetroTranslatorLabel18.AutoSize = True
        Me.MetroTranslatorLabel18.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel18.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel18.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel18.LanguageKey = "MAIN:LIBRARY_C4_RUSHHOURTEXT"
        Me.MetroTranslatorLabel18.Location = New System.Drawing.Point(53, 275)
        Me.MetroTranslatorLabel18.Name = "MetroTranslatorLabel18"
        Me.MetroTranslatorLabel18.ShowToolTip = True
        Me.MetroTranslatorLabel18.Size = New System.Drawing.Size(128, 15)
        Me.MetroTranslatorLabel18.TabIndex = 48
        Me.MetroTranslatorLabel18.Text = "Stoßzeiten von Clonk 4"
        '
        'MetroTranslatorLabel13
        '
        Me.MetroTranslatorLabel13.AutoSize = True
        Me.MetroTranslatorLabel13.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel13.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel13.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel13.LanguageKey = "MAIN:LIBRARY_C4_INFOTEXT"
        Me.MetroTranslatorLabel13.Location = New System.Drawing.Point(6, 6)
        Me.MetroTranslatorLabel13.Name = "MetroTranslatorLabel13"
        Me.MetroTranslatorLabel13.ShowToolTip = True
        Me.MetroTranslatorLabel13.Size = New System.Drawing.Size(297, 15)
        Me.MetroTranslatorLabel13.TabIndex = 47
        Me.MetroTranslatorLabel13.Text = "Informationen und Systemanforderungen über Clonk 4" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'C4Desc_asl
        '
        Me.C4Desc_asl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.C4Desc_asl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.C4Desc_asl.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.C4Desc_asl.DefaultColor = System.Drawing.Color.White
        Me.C4Desc_asl.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.C4Desc_asl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.C4Desc_asl.ForeColor = System.Drawing.Color.Black
        Me.C4Desc_asl.HideSelection = False
        Me.C4Desc_asl.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.C4Desc_asl.InputText = resources.GetString("C4Desc_asl.InputText")
        Me.C4Desc_asl.Location = New System.Drawing.Point(6, 24)
        Me.C4Desc_asl.Multiline = True
        Me.C4Desc_asl.Name = "C4Desc_asl"
        Me.C4Desc_asl.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.C4Desc_asl.ReadOnly = True
        Me.C4Desc_asl.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.C4Desc_asl.Size = New System.Drawing.Size(784, 229)
        Me.C4Desc_asl.TabIndex = 30
        Me.C4Desc_asl.Text = resources.GetString("C4Desc_asl.Text")
        '
        'cmd_Clonk4Settings_btn
        '
        Me.cmd_Clonk4Settings_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd_Clonk4Settings_btn.BackColor = System.Drawing.Color.Transparent
        Me.cmd_Clonk4Settings_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.cmd_Clonk4Settings_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.cmd_Clonk4Settings_btn.DefaultColor = System.Drawing.Color.White
        Me.cmd_Clonk4Settings_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmd_Clonk4Settings_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cmd_Clonk4Settings_btn.HoverColor = System.Drawing.Color.White
        Me.cmd_Clonk4Settings_btn.Icon = CType(resources.GetObject("cmd_Clonk4Settings_btn.Icon"), System.Drawing.Image)
        Me.cmd_Clonk4Settings_btn.Location = New System.Drawing.Point(1038, 559)
        Me.cmd_Clonk4Settings_btn.Name = "cmd_Clonk4Settings_btn"
        Me.cmd_Clonk4Settings_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cmd_Clonk4Settings_btn.RoundingArc = 42
        Me.cmd_Clonk4Settings_btn.ScaleImage = False
        Me.cmd_Clonk4Settings_btn.ScalingSize = New System.Drawing.Size(24, 24)
        Me.cmd_Clonk4Settings_btn.Size = New System.Drawing.Size(37, 42)
        Me.cmd_Clonk4Settings_btn.TabIndex = 46
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.White
        Me.TabPage7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage7.Controls.Add(Me.MetroTranslatorLabel25)
        Me.TabPage7.Controls.Add(Me.OwnClonkGameInfo_rtb)
        Me.TabPage7.Location = New System.Drawing.Point(124, 4)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1083, 614)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Du hast ein ähnliches Clonkspiel?"
        '
        'MetroTranslatorLabel25
        '
        Me.MetroTranslatorLabel25.AutoSize = True
        Me.MetroTranslatorLabel25.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel25.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold)
        Me.MetroTranslatorLabel25.ForeColor = System.Drawing.Color.Silver
        Me.MetroTranslatorLabel25.LanguageKey = "MAIN:LIBRARY_OWNGAMETEXT"
        Me.MetroTranslatorLabel25.Location = New System.Drawing.Point(20, 15)
        Me.MetroTranslatorLabel25.Name = "MetroTranslatorLabel25"
        Me.MetroTranslatorLabel25.ShowToolTip = True
        Me.MetroTranslatorLabel25.Size = New System.Drawing.Size(689, 19)
        Me.MetroTranslatorLabel25.TabIndex = 6
        Me.MetroTranslatorLabel25.Text = "Du hast ein ähnliches Clonkspiel entwickelt, und möchtest es in diesem Launcher s" &
    "ehen?"
        '
        'OwnClonkGameInfo_rtb
        '
        Me.OwnClonkGameInfo_rtb.BackColor = System.Drawing.Color.White
        Me.OwnClonkGameInfo_rtb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.OwnClonkGameInfo_rtb.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.OwnClonkGameInfo_rtb.ForeColor = System.Drawing.Color.Black
        Me.OwnClonkGameInfo_rtb.Location = New System.Drawing.Point(24, 37)
        Me.OwnClonkGameInfo_rtb.Name = "OwnClonkGameInfo_rtb"
        Me.OwnClonkGameInfo_rtb.ReadOnly = True
        Me.OwnClonkGameInfo_rtb.Size = New System.Drawing.Size(953, 286)
        Me.OwnClonkGameInfo_rtb.TabIndex = 5
        Me.OwnClonkGameInfo_rtb.Text = "- Your text here -"
        '
        'news_rtb
        '
        Me.news_rtb.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.news_rtb.BackColor = System.Drawing.Color.White
        Me.news_rtb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.news_rtb.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.news_rtb.ForeColor = System.Drawing.Color.Black
        Me.news_rtb.Location = New System.Drawing.Point(6, 551)
        Me.news_rtb.Name = "news_rtb"
        Me.news_rtb.ReadOnly = True
        Me.news_rtb.Size = New System.Drawing.Size(561, 206)
        Me.news_rtb.TabIndex = 25
        Me.news_rtb.Text = "Loading . . ."
        '
        'HomeWebbrowserError_pnl
        '
        Me.HomeWebbrowserError_pnl.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.HomeWebbrowserError_pnl.BackColor = System.Drawing.Color.Transparent
        Me.HomeWebbrowserError_pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.HomeWebbrowserError_pnl.Controls.Add(Me.MetroLabel18)
        Me.HomeWebbrowserError_pnl.Location = New System.Drawing.Point(-12, 80)
        Me.HomeWebbrowserError_pnl.Name = "HomeWebbrowserError_pnl"
        Me.HomeWebbrowserError_pnl.Size = New System.Drawing.Size(718, 409)
        Me.HomeWebbrowserError_pnl.TabIndex = 22
        Me.HomeWebbrowserError_pnl.Tag = "DEBUG"
        Me.HomeWebbrowserError_pnl.Visible = False
        '
        'MetroLabel18
        '
        Me.MetroLabel18.BackColor = System.Drawing.Color.DimGray
        Me.MetroLabel18.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel18.ForeColor = System.Drawing.Color.White
        Me.MetroLabel18.Location = New System.Drawing.Point(3, 3)
        Me.MetroLabel18.Name = "MetroLabel18"
        Me.MetroLabel18.Size = New System.Drawing.Size(477, 262)
        Me.MetroLabel18.TabIndex = 0
        Me.MetroLabel18.Text = resources.GetString("MetroLabel18.Text")
        '
        'changelog_rtb
        '
        Me.changelog_rtb.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.changelog_rtb.BackColor = System.Drawing.Color.White
        Me.changelog_rtb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.changelog_rtb.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.changelog_rtb.ForeColor = System.Drawing.Color.Black
        Me.changelog_rtb.Location = New System.Drawing.Point(588, 551)
        Me.changelog_rtb.Name = "changelog_rtb"
        Me.changelog_rtb.ReadOnly = True
        Me.changelog_rtb.Size = New System.Drawing.Size(561, 206)
        Me.changelog_rtb.TabIndex = 14
        Me.changelog_rtb.Text = "Loading . . ."
        '
        'YouTube_ClonkNews_btn
        '
        Me.YouTube_ClonkNews_btn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.YouTube_ClonkNews_btn.BackColor = System.Drawing.Color.Transparent
        Me.YouTube_ClonkNews_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.YouTube_ClonkNews_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.YouTube_ClonkNews_btn.DefaultColor = System.Drawing.Color.White
        Me.YouTube_ClonkNews_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.YouTube_ClonkNews_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.YouTube_ClonkNews_btn.ForeColor = System.Drawing.Color.Black
        Me.YouTube_ClonkNews_btn.HoverColor = System.Drawing.Color.White
        Me.YouTube_ClonkNews_btn.IsRound = True
        Me.YouTube_ClonkNews_btn.Location = New System.Drawing.Point(643, 905)
        Me.YouTube_ClonkNews_btn.Name = "YouTube_ClonkNews_btn"
        Me.YouTube_ClonkNews_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.YouTube_ClonkNews_btn.RoundingArc = 24
        Me.YouTube_ClonkNews_btn.Size = New System.Drawing.Size(116, 24)
        Me.YouTube_ClonkNews_btn.TabIndex = 13
        Me.YouTube_ClonkNews_btn.Text = "Clonk News"
        '
        'YouTube_Clonkspot_btn
        '
        Me.YouTube_Clonkspot_btn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.YouTube_Clonkspot_btn.BackColor = System.Drawing.Color.Transparent
        Me.YouTube_Clonkspot_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.YouTube_Clonkspot_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.YouTube_Clonkspot_btn.DefaultColor = System.Drawing.Color.White
        Me.YouTube_Clonkspot_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.YouTube_Clonkspot_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.YouTube_Clonkspot_btn.ForeColor = System.Drawing.Color.Black
        Me.YouTube_Clonkspot_btn.HoverColor = System.Drawing.Color.White
        Me.YouTube_Clonkspot_btn.IsRound = True
        Me.YouTube_Clonkspot_btn.Location = New System.Drawing.Point(557, 905)
        Me.YouTube_Clonkspot_btn.Name = "YouTube_Clonkspot_btn"
        Me.YouTube_Clonkspot_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.YouTube_Clonkspot_btn.RoundingArc = 24
        Me.YouTube_Clonkspot_btn.Size = New System.Drawing.Size(80, 24)
        Me.YouTube_Clonkspot_btn.TabIndex = 12
        Me.YouTube_Clonkspot_btn.Text = "Clonkspot"
        '
        'YouTube_matthesb_btn
        '
        Me.YouTube_matthesb_btn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.YouTube_matthesb_btn.BackColor = System.Drawing.Color.Transparent
        Me.YouTube_matthesb_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.YouTube_matthesb_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.YouTube_matthesb_btn.DefaultColor = System.Drawing.Color.White
        Me.YouTube_matthesb_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.YouTube_matthesb_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.YouTube_matthesb_btn.ForeColor = System.Drawing.Color.Black
        Me.YouTube_matthesb_btn.HoverColor = System.Drawing.Color.White
        Me.YouTube_matthesb_btn.IsRound = True
        Me.YouTube_matthesb_btn.Location = New System.Drawing.Point(471, 905)
        Me.YouTube_matthesb_btn.Name = "YouTube_matthesb_btn"
        Me.YouTube_matthesb_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.YouTube_matthesb_btn.RoundingArc = 24
        Me.YouTube_matthesb_btn.Size = New System.Drawing.Size(80, 24)
        Me.YouTube_matthesb_btn.TabIndex = 11
        Me.YouTube_matthesb_btn.Text = "matthesb"
        '
        'DiscordInviteLink_btn
        '
        Me.DiscordInviteLink_btn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.DiscordInviteLink_btn.BackColor = System.Drawing.Color.Transparent
        Me.DiscordInviteLink_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DiscordInviteLink_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.DiscordInviteLink_btn.DefaultColor = System.Drawing.Color.White
        Me.DiscordInviteLink_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.DiscordInviteLink_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DiscordInviteLink_btn.ForeColor = System.Drawing.Color.Black
        Me.DiscordInviteLink_btn.HoverColor = System.Drawing.Color.White
        Me.DiscordInviteLink_btn.IsRound = True
        Me.DiscordInviteLink_btn.Location = New System.Drawing.Point(681, 834)
        Me.DiscordInviteLink_btn.Name = "DiscordInviteLink_btn"
        Me.DiscordInviteLink_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.DiscordInviteLink_btn.RoundingArc = 24
        Me.DiscordInviteLink_btn.Size = New System.Drawing.Size(80, 24)
        Me.DiscordInviteLink_btn.TabIndex = 9
        Me.DiscordInviteLink_btn.Text = "Discord"
        '
        'ClonkSpotWebsite_btn
        '
        Me.ClonkSpotWebsite_btn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ClonkSpotWebsite_btn.BackColor = System.Drawing.Color.Transparent
        Me.ClonkSpotWebsite_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkSpotWebsite_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkSpotWebsite_btn.DefaultColor = System.Drawing.Color.White
        Me.ClonkSpotWebsite_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClonkSpotWebsite_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClonkSpotWebsite_btn.ForeColor = System.Drawing.Color.Black
        Me.ClonkSpotWebsite_btn.HoverColor = System.Drawing.Color.White
        Me.ClonkSpotWebsite_btn.IsRound = True
        Me.ClonkSpotWebsite_btn.Location = New System.Drawing.Point(595, 834)
        Me.ClonkSpotWebsite_btn.Name = "ClonkSpotWebsite_btn"
        Me.ClonkSpotWebsite_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkSpotWebsite_btn.RoundingArc = 24
        Me.ClonkSpotWebsite_btn.Size = New System.Drawing.Size(80, 24)
        Me.ClonkSpotWebsite_btn.TabIndex = 5
        Me.ClonkSpotWebsite_btn.Text = "Clonkspot"
        '
        'CCANWebsite_btn
        '
        Me.CCANWebsite_btn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.CCANWebsite_btn.BackColor = System.Drawing.Color.Transparent
        Me.CCANWebsite_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CCANWebsite_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CCANWebsite_btn.DefaultColor = System.Drawing.Color.White
        Me.CCANWebsite_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CCANWebsite_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANWebsite_btn.ForeColor = System.Drawing.Color.Black
        Me.CCANWebsite_btn.HoverColor = System.Drawing.Color.White
        Me.CCANWebsite_btn.IsRound = True
        Me.CCANWebsite_btn.Location = New System.Drawing.Point(533, 834)
        Me.CCANWebsite_btn.Name = "CCANWebsite_btn"
        Me.CCANWebsite_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CCANWebsite_btn.RoundingArc = 24
        Me.CCANWebsite_btn.Size = New System.Drawing.Size(56, 24)
        Me.CCANWebsite_btn.TabIndex = 6
        Me.CCANWebsite_btn.Text = "CCAN"
        '
        'ClonkWebsite_btn
        '
        Me.ClonkWebsite_btn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ClonkWebsite_btn.BackColor = System.Drawing.Color.Transparent
        Me.ClonkWebsite_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClonkWebsite_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ClonkWebsite_btn.DefaultColor = System.Drawing.Color.White
        Me.ClonkWebsite_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClonkWebsite_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ClonkWebsite_btn.ForeColor = System.Drawing.Color.Black
        Me.ClonkWebsite_btn.HoverColor = System.Drawing.Color.White
        Me.ClonkWebsite_btn.IsRound = True
        Me.ClonkWebsite_btn.Location = New System.Drawing.Point(471, 834)
        Me.ClonkWebsite_btn.Name = "ClonkWebsite_btn"
        Me.ClonkWebsite_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClonkWebsite_btn.RoundingArc = 24
        Me.ClonkWebsite_btn.Size = New System.Drawing.Size(56, 24)
        Me.ClonkWebsite_btn.TabIndex = 1
        Me.ClonkWebsite_btn.Text = "Clonk"
        '
        'EventsWebbrowserError_pnl
        '
        Me.EventsWebbrowserError_pnl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EventsWebbrowserError_pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.EventsWebbrowserError_pnl.Controls.Add(Me.MetroLabel23)
        Me.EventsWebbrowserError_pnl.Location = New System.Drawing.Point(309, 197)
        Me.EventsWebbrowserError_pnl.Name = "EventsWebbrowserError_pnl"
        Me.EventsWebbrowserError_pnl.Size = New System.Drawing.Size(599, 330)
        Me.EventsWebbrowserError_pnl.TabIndex = 23
        Me.EventsWebbrowserError_pnl.Tag = "DEBUG"
        Me.EventsWebbrowserError_pnl.Visible = False
        '
        'MetroLabel23
        '
        Me.MetroLabel23.BackColor = System.Drawing.Color.DimGray
        Me.MetroLabel23.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel23.ForeColor = System.Drawing.Color.White
        Me.MetroLabel23.Location = New System.Drawing.Point(1, 0)
        Me.MetroLabel23.Name = "MetroLabel23"
        Me.MetroLabel23.Size = New System.Drawing.Size(477, 262)
        Me.MetroLabel23.TabIndex = 1
        Me.MetroLabel23.Text = resources.GetString("MetroLabel23.Text")
        '
        'MetroLabel32
        '
        Me.MetroLabel32.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLabel32.AutoSize = True
        Me.MetroLabel32.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel32.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel32.ForeColor = System.Drawing.Color.Silver
        Me.MetroLabel32.Location = New System.Drawing.Point(559, 20)
        Me.MetroLabel32.Name = "MetroLabel32"
        Me.MetroLabel32.Size = New System.Drawing.Size(98, 32)
        Me.MetroLabel32.TabIndex = 5
        Me.MetroLabel32.Text = "Events"
        '
        'CCANdateFilter_mcbox
        '
        Me.CCANdateFilter_mcbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CCANdateFilter_mcbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CCANdateFilter_mcbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CCANdateFilter_mcbox.DefaultColor = System.Drawing.Color.White
        Me.CCANdateFilter_mcbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CCANdateFilter_mcbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CCANdateFilter_mcbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CCANdateFilter_mcbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CCANdateFilter_mcbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANdateFilter_mcbox.ForeColor = System.Drawing.Color.Black
        Me.CCANdateFilter_mcbox.FormattingEnabled = True
        Me.CCANdateFilter_mcbox.Items.AddRange(New Object() {"Neuste zuerst", "Älteste zuerst"})
        Me.CCANdateFilter_mcbox.Location = New System.Drawing.Point(389, 72)
        Me.CCANdateFilter_mcbox.Name = "CCANdateFilter_mcbox"
        Me.CCANdateFilter_mcbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CCANdateFilter_mcbox.Size = New System.Drawing.Size(132, 24)
        Me.CCANdateFilter_mcbox.TabIndex = 43
        '
        'CCANversionFilter_mcbox
        '
        Me.CCANversionFilter_mcbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CCANversionFilter_mcbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CCANversionFilter_mcbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CCANversionFilter_mcbox.DefaultColor = System.Drawing.Color.White
        Me.CCANversionFilter_mcbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CCANversionFilter_mcbox.DisplayMember = "Alle"
        Me.CCANversionFilter_mcbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CCANversionFilter_mcbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CCANversionFilter_mcbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CCANversionFilter_mcbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANversionFilter_mcbox.ForeColor = System.Drawing.Color.Black
        Me.CCANversionFilter_mcbox.FormattingEnabled = True
        Me.CCANversionFilter_mcbox.Items.AddRange(New Object() {"Alle Versionen", "OpenClonk", "Clonk Rage", "Clonk Endeavour", "Clonk Planet", "Clonk 4"})
        Me.CCANversionFilter_mcbox.Location = New System.Drawing.Point(225, 72)
        Me.CCANversionFilter_mcbox.Name = "CCANversionFilter_mcbox"
        Me.CCANversionFilter_mcbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CCANversionFilter_mcbox.Size = New System.Drawing.Size(158, 24)
        Me.CCANversionFilter_mcbox.TabIndex = 15
        '
        'CCANratingFilter_mcbox
        '
        Me.CCANratingFilter_mcbox.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CCANratingFilter_mcbox.ArrowColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CCANratingFilter_mcbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.CCANratingFilter_mcbox.DefaultColor = System.Drawing.Color.White
        Me.CCANratingFilter_mcbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CCANratingFilter_mcbox.DisplayMember = "Alle"
        Me.CCANratingFilter_mcbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CCANratingFilter_mcbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CCANratingFilter_mcbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CCANratingFilter_mcbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CCANratingFilter_mcbox.ForeColor = System.Drawing.Color.Black
        Me.CCANratingFilter_mcbox.FormattingEnabled = True
        Me.CCANratingFilter_mcbox.Items.AddRange(New Object() {"Alle Bewertungen", "1 Stern", "2 Sterne", "3 Sterne", "4 Sterne", "5 Sterne"})
        Me.CCANratingFilter_mcbox.Location = New System.Drawing.Point(527, 72)
        Me.CCANratingFilter_mcbox.Name = "CCANratingFilter_mcbox"
        Me.CCANratingFilter_mcbox.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CCANratingFilter_mcbox.Size = New System.Drawing.Size(132, 24)
        Me.CCANratingFilter_mcbox.TabIndex = 17
        Me.CCANratingFilter_mcbox.Visible = False
        '
        'ccanObjects_flp
        '
        Me.ccanObjects_flp.AutoScroll = True
        Me.ccanObjects_flp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ccanObjects_flp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ccanObjects_flp.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ccanObjects_flp.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.ccanObjects_flp.Location = New System.Drawing.Point(3, 107)
        Me.ccanObjects_flp.Name = "ccanObjects_flp"
        Me.ccanObjects_flp.Size = New System.Drawing.Size(1211, 518)
        Me.ccanObjects_flp.TabIndex = 12
        Me.ccanObjects_flp.WrapContents = False
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MetroLabel2.ForeColor = System.Drawing.Color.Silver
        Me.MetroLabel2.Location = New System.Drawing.Point(59, 11)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(82, 19)
        Me.MetroLabel2.TabIndex = 3
        Me.MetroLabel2.Text = "CCAN 2.0"
        '
        'MetroStatusStrip1
        '
        Me.MetroStatusStrip1.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroStatusStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroStatusStrip1.ForeColor = System.Drawing.Color.Black
        Me.MetroStatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.status_lbl, Me.downloadProgress_prgsbar, Me.downloadProgress_lbl})
        Me.MetroStatusStrip1.Location = New System.Drawing.Point(0, 788)
        Me.MetroStatusStrip1.Name = "MetroStatusStrip1"
        Me.MetroStatusStrip1.Size = New System.Drawing.Size(1231, 22)
        Me.MetroStatusStrip1.SizingGrip = False
        Me.MetroStatusStrip1.TabIndex = 3
        Me.MetroStatusStrip1.Text = "MetroStatusStrip1"
        '
        'status_lbl
        '
        Me.status_lbl.BackColor = System.Drawing.Color.Transparent
        Me.status_lbl.ForeColor = System.Drawing.Color.White
        Me.status_lbl.Name = "status_lbl"
        Me.status_lbl.Size = New System.Drawing.Size(45, 17)
        Me.status_lbl.Text = "STATUS"
        '
        'downloadProgress_prgsbar
        '
        Me.downloadProgress_prgsbar.Name = "downloadProgress_prgsbar"
        Me.downloadProgress_prgsbar.Size = New System.Drawing.Size(100, 16)
        Me.downloadProgress_prgsbar.Visible = False
        '
        'downloadProgress_lbl
        '
        Me.downloadProgress_lbl.BackColor = System.Drawing.Color.Transparent
        Me.downloadProgress_lbl.ForeColor = System.Drawing.Color.White
        Me.downloadProgress_lbl.Name = "downloadProgress_lbl"
        Me.downloadProgress_lbl.Size = New System.Drawing.Size(202, 17)
        Me.downloadProgress_lbl.Text = "0% | 0 MB von 0 MB heruntergeladen"
        Me.downloadProgress_lbl.Visible = False
        '
        'CheckClonkProcess_tmr
        '
        '
        'MetroTabControl2
        '
        Me.MetroTabControl2.Alignment = System.Windows.Forms.TabAlignment.Top
        Me.MetroTabControl2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroTabControl2.Appearance = System.Windows.Forms.Appearance.Normal
        Me.MetroTabControl2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MetroTabControl2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.MetroTabControl2.Controls.Add(Me.StartTabPage_tp)
        Me.MetroTabControl2.Controls.Add(Me.LibraryTabPage_tp)
        Me.MetroTabControl2.Controls.Add(Me.NewsTabPage_tp)
        Me.MetroTabControl2.Controls.Add(Me.EventsTabPage_tp)
        Me.MetroTabControl2.Controls.Add(Me.CCANTabPage_tp)
        Me.MetroTabControl2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTabControl2.ForeColor = System.Drawing.Color.Black
        Me.MetroTabControl2.HasAnimation = False
        Me.MetroTabControl2.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(106, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.MetroTabControl2.HeaderItemColor = System.Drawing.Color.White
        Me.MetroTabControl2.HotTrack = True
        Me.MetroTabControl2.HoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl2.HoverColor = System.Drawing.Color.White
        Me.MetroTabControl2.ItemColor = System.Drawing.Color.White
        Me.MetroTabControl2.ItemForeColor = System.Drawing.Color.Black
        Me.MetroTabControl2.ItemSize = New System.Drawing.Size(120, 40)
        Me.MetroTabControl2.Location = New System.Drawing.Point(3, 109)
        Me.MetroTabControl2.Multiline = True
        Me.MetroTabControl2.Name = "MetroTabControl2"
        Me.MetroTabControl2.SelectedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl2.SelectedForeColor = System.Drawing.Color.White
        Me.MetroTabControl2.SelectedIndex = 0
        Me.MetroTabControl2.SelectedItemColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl2.SelectedItemLineColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl2.Size = New System.Drawing.Size(1225, 676)
        Me.MetroTabControl2.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MetroTabControl2.TabContainerColor = System.Drawing.Color.White
        Me.MetroTabControl2.TabIndex = 11
        '
        'StartTabPage_tp
        '
        Me.StartTabPage_tp.AutoScroll = True
        Me.StartTabPage_tp.BackColor = System.Drawing.Color.White
        Me.StartTabPage_tp.Controls.Add(Me.MetroTranslatorLabel8)
        Me.StartTabPage_tp.Controls.Add(Me.MetroTranslatorLabel7)
        Me.StartTabPage_tp.Controls.Add(Me.MetroTranslatorLabel6)
        Me.StartTabPage_tp.Controls.Add(Me.MetroTranslatorLabel5)
        Me.StartTabPage_tp.Controls.Add(Me.MetroTranslatorLabel4)
        Me.StartTabPage_tp.Controls.Add(Me.friendsOnlineCount_lbl)
        Me.StartTabPage_tp.Controls.Add(Me.MetroTranslatorLabel3)
        Me.StartTabPage_tp.Controls.Add(Me.MetroTranslatorLabel2)
        Me.StartTabPage_tp.Controls.Add(Me.MetroTranslatorLabel1)
        Me.StartTabPage_tp.Controls.Add(Me.Panel3)
        Me.StartTabPage_tp.Controls.Add(Me.friendsOnline_flp)
        Me.StartTabPage_tp.Controls.Add(Me.QuickLaunch_flp)
        Me.StartTabPage_tp.Controls.Add(Me.HomeWebbrowserError_pnl)
        Me.StartTabPage_tp.Controls.Add(Me.news_rtb)
        Me.StartTabPage_tp.Controls.Add(Me.changelog_rtb)
        Me.StartTabPage_tp.Controls.Add(Me.YouTube_ClonkNews_btn)
        Me.StartTabPage_tp.Controls.Add(Me.PictureBox10)
        Me.StartTabPage_tp.Controls.Add(Me.YouTube_Clonkspot_btn)
        Me.StartTabPage_tp.Controls.Add(Me.ClonkWebsite_btn)
        Me.StartTabPage_tp.Controls.Add(Me.YouTube_matthesb_btn)
        Me.StartTabPage_tp.Controls.Add(Me.CCANWebsite_btn)
        Me.StartTabPage_tp.Controls.Add(Me.DiscordInviteLink_btn)
        Me.StartTabPage_tp.Controls.Add(Me.ClonkSpotWebsite_btn)
        Me.StartTabPage_tp.Controls.Add(Me.PictureBox11)
        Me.StartTabPage_tp.Location = New System.Drawing.Point(4, 44)
        Me.StartTabPage_tp.Name = "StartTabPage_tp"
        Me.StartTabPage_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.StartTabPage_tp.Size = New System.Drawing.Size(1217, 628)
        Me.StartTabPage_tp.TabIndex = 0
        Me.StartTabPage_tp.Text = "Start"
        '
        'MetroTranslatorLabel8
        '
        Me.MetroTranslatorLabel8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel8.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel8.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel8.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel8.LanguageKey = "MAIN:START_TRADEMARKTEXT"
        Me.MetroTranslatorLabel8.Location = New System.Drawing.Point(376, 985)
        Me.MetroTranslatorLabel8.Name = "MetroTranslatorLabel8"
        Me.MetroTranslatorLabel8.ShowToolTip = True
        Me.MetroTranslatorLabel8.Size = New System.Drawing.Size(400, 17)
        Me.MetroTranslatorLabel8.TabIndex = 40
        Me.MetroTranslatorLabel8.Text = "'Clonk' ist ein eingetragenes Warenzeichen von Matthes Bender."
        Me.MetroTranslatorLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTranslatorLabel7
        '
        Me.MetroTranslatorLabel7.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel7.AutoSize = True
        Me.MetroTranslatorLabel7.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel7.Font = New System.Drawing.Font("Segoe UI Semilight", 8.25!)
        Me.MetroTranslatorLabel7.ForeColor = System.Drawing.Color.Gray
        Me.MetroTranslatorLabel7.LanguageKey = "MAIN:START_YOUTUBECHANNELSTEXT"
        Me.MetroTranslatorLabel7.Location = New System.Drawing.Point(468, 889)
        Me.MetroTranslatorLabel7.Name = "MetroTranslatorLabel7"
        Me.MetroTranslatorLabel7.ShowToolTip = True
        Me.MetroTranslatorLabel7.Size = New System.Drawing.Size(82, 13)
        Me.MetroTranslatorLabel7.TabIndex = 39
        Me.MetroTranslatorLabel7.Text = "YouTube Kanäle"
        '
        'MetroTranslatorLabel6
        '
        Me.MetroTranslatorLabel6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel6.AutoSize = True
        Me.MetroTranslatorLabel6.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel6.Font = New System.Drawing.Font("Segoe UI Semilight", 8.25!)
        Me.MetroTranslatorLabel6.ForeColor = System.Drawing.Color.Gray
        Me.MetroTranslatorLabel6.LanguageKey = "MAIN:START_RECOMMENDEDWEBSITESTEXT"
        Me.MetroTranslatorLabel6.Location = New System.Drawing.Point(468, 818)
        Me.MetroTranslatorLabel6.Name = "MetroTranslatorLabel6"
        Me.MetroTranslatorLabel6.ShowToolTip = True
        Me.MetroTranslatorLabel6.Size = New System.Drawing.Size(155, 13)
        Me.MetroTranslatorLabel6.TabIndex = 38
        Me.MetroTranslatorLabel6.Text = "Von uns empfohlene Webseiten"
        '
        'MetroTranslatorLabel5
        '
        Me.MetroTranslatorLabel5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel5.AutoSize = True
        Me.MetroTranslatorLabel5.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel5.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.MetroTranslatorLabel5.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel5.LanguageKey = "MAIN:START_CHANGELOGTEXT"
        Me.MetroTranslatorLabel5.Location = New System.Drawing.Point(585, 533)
        Me.MetroTranslatorLabel5.Name = "MetroTranslatorLabel5"
        Me.MetroTranslatorLabel5.ShowToolTip = True
        Me.MetroTranslatorLabel5.Size = New System.Drawing.Size(124, 17)
        Me.MetroTranslatorLabel5.TabIndex = 37
        Me.MetroTranslatorLabel5.Text = "Änderungsprotokoll"
        '
        'MetroTranslatorLabel4
        '
        Me.MetroTranslatorLabel4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel4.AutoSize = True
        Me.MetroTranslatorLabel4.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel4.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.MetroTranslatorLabel4.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel4.LanguageKey = "MAIN:START_NEWESTNEWSTEXT"
        Me.MetroTranslatorLabel4.Location = New System.Drawing.Point(3, 531)
        Me.MetroTranslatorLabel4.Name = "MetroTranslatorLabel4"
        Me.MetroTranslatorLabel4.ShowToolTip = True
        Me.MetroTranslatorLabel4.Size = New System.Drawing.Size(192, 17)
        Me.MetroTranslatorLabel4.TabIndex = 36
        Me.MetroTranslatorLabel4.Text = "Neuste News zum Thema Clonk"
        '
        'friendsOnlineCount_lbl
        '
        Me.friendsOnlineCount_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.friendsOnlineCount_lbl.AutoSize = True
        Me.friendsOnlineCount_lbl.BackColor = System.Drawing.Color.Transparent
        Me.friendsOnlineCount_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.friendsOnlineCount_lbl.ForeColor = System.Drawing.Color.DarkGray
        Me.friendsOnlineCount_lbl.LanguageKey = "MAIN:START_FRIENDSONLINETEXT"
        Me.friendsOnlineCount_lbl.Location = New System.Drawing.Point(726, 194)
        Me.friendsOnlineCount_lbl.Name = "friendsOnlineCount_lbl"
        Me.friendsOnlineCount_lbl.ShowToolTip = True
        Me.friendsOnlineCount_lbl.Size = New System.Drawing.Size(105, 17)
        Me.friendsOnlineCount_lbl.TabIndex = 35
        Me.friendsOnlineCount_lbl.Text = "Freunde online 0"
        '
        'MetroTranslatorLabel3
        '
        Me.MetroTranslatorLabel3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel3.AutoSize = True
        Me.MetroTranslatorLabel3.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel3.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.MetroTranslatorLabel3.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel3.LanguageKey = "MAIN:START_QUICKLAUNCHTEXT"
        Me.MetroTranslatorLabel3.Location = New System.Drawing.Point(726, 60)
        Me.MetroTranslatorLabel3.Name = "MetroTranslatorLabel3"
        Me.MetroTranslatorLabel3.ShowToolTip = True
        Me.MetroTranslatorLabel3.Size = New System.Drawing.Size(74, 17)
        Me.MetroTranslatorLabel3.TabIndex = 34
        Me.MetroTranslatorLabel3.Text = "Schnellstart"
        '
        'MetroTranslatorLabel2
        '
        Me.MetroTranslatorLabel2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel2.AutoSize = True
        Me.MetroTranslatorLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel2.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.MetroTranslatorLabel2.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroTranslatorLabel2.LanguageKey = "MAIN:START_NEWESTVIDEOTEXT"
        Me.MetroTranslatorLabel2.Location = New System.Drawing.Point(-15, 60)
        Me.MetroTranslatorLabel2.Name = "MetroTranslatorLabel2"
        Me.MetroTranslatorLabel2.ShowToolTip = True
        Me.MetroTranslatorLabel2.Size = New System.Drawing.Size(200, 17)
        Me.MetroTranslatorLabel2.TabIndex = 33
        Me.MetroTranslatorLabel2.Text = "Neustes Video zum Thema Clonk"
        '
        'MetroTranslatorLabel1
        '
        Me.MetroTranslatorLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel1.Font = New System.Drawing.Font("Arial", 20.25!)
        Me.MetroTranslatorLabel1.ForeColor = System.Drawing.Color.Silver
        Me.MetroTranslatorLabel1.LanguageKey = "MAIN:START_WELCOMETEXT"
        Me.MetroTranslatorLabel1.Location = New System.Drawing.Point(285, 17)
        Me.MetroTranslatorLabel1.Name = "MetroTranslatorLabel1"
        Me.MetroTranslatorLabel1.ShowToolTip = True
        Me.MetroTranslatorLabel1.Size = New System.Drawing.Size(583, 32)
        Me.MetroTranslatorLabel1.TabIndex = 32
        Me.MetroTranslatorLabel1.Text = "Willkommen im Xtreme-Clonk-Launcher!"
        Me.MetroTranslatorLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Panel3
        '
        Me.Panel3.Location = New System.Drawing.Point(0, 1010)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(172, 10)
        Me.Panel3.TabIndex = 30
        '
        'friendsOnline_flp
        '
        Me.friendsOnline_flp.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.friendsOnline_flp.AutoScroll = True
        Me.friendsOnline_flp.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.friendsOnline_flp.Location = New System.Drawing.Point(729, 214)
        Me.friendsOnline_flp.Name = "friendsOnline_flp"
        Me.friendsOnline_flp.Size = New System.Drawing.Size(439, 275)
        Me.friendsOnline_flp.TabIndex = 29
        Me.friendsOnline_flp.WrapContents = False
        '
        'QuickLaunch_flp
        '
        Me.QuickLaunch_flp.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.QuickLaunch_flp.AutoScroll = True
        Me.QuickLaunch_flp.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.QuickLaunch_flp.Location = New System.Drawing.Point(729, 80)
        Me.QuickLaunch_flp.Name = "QuickLaunch_flp"
        Me.QuickLaunch_flp.Size = New System.Drawing.Size(439, 100)
        Me.QuickLaunch_flp.TabIndex = 26
        Me.QuickLaunch_flp.WrapContents = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox10.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.NewWebsite_logo
        Me.PictureBox10.Location = New System.Drawing.Point(391, 805)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(64, 64)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox10.TabIndex = 5
        Me.PictureBox10.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox11.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.yt_logo
        Me.PictureBox11.Location = New System.Drawing.Point(391, 875)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(64, 64)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox11.TabIndex = 6
        Me.PictureBox11.TabStop = False
        '
        'LibraryTabPage_tp
        '
        Me.LibraryTabPage_tp.BackColor = System.Drawing.Color.White
        Me.LibraryTabPage_tp.Controls.Add(Me.MetroTabControl1)
        Me.LibraryTabPage_tp.ForeColor = System.Drawing.Color.Black
        Me.LibraryTabPage_tp.Location = New System.Drawing.Point(4, 44)
        Me.LibraryTabPage_tp.Name = "LibraryTabPage_tp"
        Me.LibraryTabPage_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.LibraryTabPage_tp.Size = New System.Drawing.Size(1217, 628)
        Me.LibraryTabPage_tp.TabIndex = 1
        Me.LibraryTabPage_tp.Text = "Bibliothek"
        '
        'NewsTabPage_tp
        '
        Me.NewsTabPage_tp.BackColor = System.Drawing.Color.White
        Me.NewsTabPage_tp.Controls.Add(Me.NewsPanel_pnl)
        Me.NewsTabPage_tp.Controls.Add(Me.Panel17)
        Me.NewsTabPage_tp.Controls.Add(Me.MetroTranslatorLabel33)
        Me.NewsTabPage_tp.Location = New System.Drawing.Point(4, 44)
        Me.NewsTabPage_tp.Name = "NewsTabPage_tp"
        Me.NewsTabPage_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.NewsTabPage_tp.Size = New System.Drawing.Size(1217, 628)
        Me.NewsTabPage_tp.TabIndex = 2
        Me.NewsTabPage_tp.Text = "Neuigkeiten"
        '
        'NewsPanel_pnl
        '
        Me.NewsPanel_pnl.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NewsPanel_pnl.AutoScroll = True
        Me.NewsPanel_pnl.BackColor = System.Drawing.Color.Transparent
        Me.NewsPanel_pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NewsPanel_pnl.Controls.Add(Me.NewsDesc_lbl)
        Me.NewsPanel_pnl.Controls.Add(Me.NewsTitle_lbl)
        Me.NewsPanel_pnl.Location = New System.Drawing.Point(277, 3)
        Me.NewsPanel_pnl.Name = "NewsPanel_pnl"
        Me.NewsPanel_pnl.Size = New System.Drawing.Size(931, 622)
        Me.NewsPanel_pnl.TabIndex = 28
        Me.NewsPanel_pnl.Visible = False
        '
        'NewsDesc_lbl
        '
        Me.NewsDesc_lbl.AutoStyle = False
        Me.NewsDesc_lbl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.NewsDesc_lbl.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.NewsDesc_lbl.DefaultColor = System.Drawing.Color.White
        Me.NewsDesc_lbl.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.NewsDesc_lbl.Dock = System.Windows.Forms.DockStyle.Top
        Me.NewsDesc_lbl.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.NewsDesc_lbl.ForeColor = System.Drawing.Color.Black
        Me.NewsDesc_lbl.HideSelection = False
        Me.NewsDesc_lbl.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.NewsDesc_lbl.InputText = "DESC"
        Me.NewsDesc_lbl.Location = New System.Drawing.Point(0, 32)
        Me.NewsDesc_lbl.Multiline = True
        Me.NewsDesc_lbl.Name = "NewsDesc_lbl"
        Me.NewsDesc_lbl.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.NewsDesc_lbl.ReadOnly = True
        Me.NewsDesc_lbl.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.NewsDesc_lbl.Size = New System.Drawing.Size(929, 585)
        Me.NewsDesc_lbl.TabIndex = 32
        Me.NewsDesc_lbl.Text = "DESC"
        '
        'NewsTitle_lbl
        '
        Me.NewsTitle_lbl.BackColor = System.Drawing.Color.Transparent
        Me.NewsTitle_lbl.Dock = System.Windows.Forms.DockStyle.Top
        Me.NewsTitle_lbl.Font = New System.Drawing.Font("Arial", 16.25!)
        Me.NewsTitle_lbl.ForeColor = System.Drawing.Color.Silver
        Me.NewsTitle_lbl.Location = New System.Drawing.Point(0, 0)
        Me.NewsTitle_lbl.Name = "NewsTitle_lbl"
        Me.NewsTitle_lbl.Size = New System.Drawing.Size(929, 32)
        Me.NewsTitle_lbl.TabIndex = 5
        Me.NewsTitle_lbl.Text = "TITLE"
        Me.NewsTitle_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel17
        '
        Me.Panel17.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel17.BackColor = System.Drawing.Color.Transparent
        Me.Panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel17.Controls.Add(Me.RefreshNewsList_btn)
        Me.Panel17.Controls.Add(Me.AllNewsCount_lbl)
        Me.Panel17.Controls.Add(Me.NewsLoading_picbox)
        Me.Panel17.Controls.Add(Me.AllNews_flp)
        Me.Panel17.Location = New System.Drawing.Point(3, 3)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(271, 622)
        Me.Panel17.TabIndex = 27
        '
        'RefreshNewsList_btn
        '
        Me.RefreshNewsList_btn.BackColor = System.Drawing.Color.Transparent
        Me.RefreshNewsList_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RefreshNewsList_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.RefreshNewsList_btn.DefaultColor = System.Drawing.Color.White
        Me.RefreshNewsList_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.RefreshNewsList_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.RefreshNewsList_btn.HoverColor = System.Drawing.Color.White
        Me.RefreshNewsList_btn.LanguageKey = "MAIN:NEWS_RELOADBTN"
        Me.RefreshNewsList_btn.Location = New System.Drawing.Point(192, 3)
        Me.RefreshNewsList_btn.Name = "RefreshNewsList_btn"
        Me.RefreshNewsList_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.RefreshNewsList_btn.RoundingArc = 20
        Me.RefreshNewsList_btn.Size = New System.Drawing.Size(74, 20)
        Me.RefreshNewsList_btn.TabIndex = 0
        Me.RefreshNewsList_btn.Text = "Neu laden"
        '
        'AllNewsCount_lbl
        '
        Me.AllNewsCount_lbl.AutoSize = True
        Me.AllNewsCount_lbl.BackColor = System.Drawing.Color.Transparent
        Me.AllNewsCount_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.AllNewsCount_lbl.ForeColor = System.Drawing.Color.DarkGray
        Me.AllNewsCount_lbl.LanguageKey = "MAIN:NEWS_ALLNEWSTEXT"
        Me.AllNewsCount_lbl.Location = New System.Drawing.Point(4, 5)
        Me.AllNewsCount_lbl.Name = "AllNewsCount_lbl"
        Me.AllNewsCount_lbl.ShowToolTip = True
        Me.AllNewsCount_lbl.Size = New System.Drawing.Size(131, 17)
        Me.AllNewsCount_lbl.TabIndex = 28
        Me.AllNewsCount_lbl.Text = "Alle Neuigkeiten (%s)"
        '
        'NewsLoading_picbox
        '
        Me.NewsLoading_picbox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NewsLoading_picbox.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.Loading_BlueFast
        Me.NewsLoading_picbox.Location = New System.Drawing.Point(165, 2)
        Me.NewsLoading_picbox.Name = "NewsLoading_picbox"
        Me.NewsLoading_picbox.Size = New System.Drawing.Size(21, 21)
        Me.NewsLoading_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.NewsLoading_picbox.TabIndex = 26
        Me.NewsLoading_picbox.TabStop = False
        Me.NewsLoading_picbox.Visible = False
        '
        'AllNews_flp
        '
        Me.AllNews_flp.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.AllNews_flp.AutoScroll = True
        Me.AllNews_flp.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.AllNews_flp.Location = New System.Drawing.Point(7, 25)
        Me.AllNews_flp.Name = "AllNews_flp"
        Me.AllNews_flp.Size = New System.Drawing.Size(260, 592)
        Me.AllNews_flp.TabIndex = 25
        Me.AllNews_flp.WrapContents = False
        '
        'MetroTranslatorLabel33
        '
        Me.MetroTranslatorLabel33.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroTranslatorLabel33.AutoSize = True
        Me.MetroTranslatorLabel33.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel33.Font = New System.Drawing.Font("Arial", 20.25!)
        Me.MetroTranslatorLabel33.ForeColor = System.Drawing.Color.Silver
        Me.MetroTranslatorLabel33.LanguageKey = "MAIN:NEWS_SELECTNEWSFROMLIST"
        Me.MetroTranslatorLabel33.Location = New System.Drawing.Point(484, 298)
        Me.MetroTranslatorLabel33.Name = "MetroTranslatorLabel33"
        Me.MetroTranslatorLabel33.ShowToolTip = True
        Me.MetroTranslatorLabel33.Size = New System.Drawing.Size(553, 32)
        Me.MetroTranslatorLabel33.TabIndex = 29
        Me.MetroTranslatorLabel33.Text = "Bitte wähle eine Neuigkeit aus der Liste aus."
        '
        'EventsTabPage_tp
        '
        Me.EventsTabPage_tp.BackColor = System.Drawing.Color.White
        Me.EventsTabPage_tp.Controls.Add(Me.WatchInBrowser_btn)
        Me.EventsTabPage_tp.Controls.Add(Me.MetroTranslatorLabel31)
        Me.EventsTabPage_tp.Controls.Add(Me.MetroTranslatorLabel26)
        Me.EventsTabPage_tp.Controls.Add(Me.EventsWebbrowserError_pnl)
        Me.EventsTabPage_tp.Controls.Add(Me.MetroLabel32)
        Me.EventsTabPage_tp.Location = New System.Drawing.Point(4, 44)
        Me.EventsTabPage_tp.Name = "EventsTabPage_tp"
        Me.EventsTabPage_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.EventsTabPage_tp.Size = New System.Drawing.Size(1217, 628)
        Me.EventsTabPage_tp.TabIndex = 3
        Me.EventsTabPage_tp.Text = "Events"
        '
        'WatchInBrowser_btn
        '
        Me.WatchInBrowser_btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WatchInBrowser_btn.BackColor = System.Drawing.Color.Transparent
        Me.WatchInBrowser_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.WatchInBrowser_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.WatchInBrowser_btn.DefaultColor = System.Drawing.Color.White
        Me.WatchInBrowser_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.WatchInBrowser_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.WatchInBrowser_btn.HoverColor = System.Drawing.Color.White
        Me.WatchInBrowser_btn.LanguageKey = "MAIN:EVENTS_WATCHONTWITCHBUTTONTEXT"
        Me.WatchInBrowser_btn.Location = New System.Drawing.Point(309, 533)
        Me.WatchInBrowser_btn.Name = "WatchInBrowser_btn"
        Me.WatchInBrowser_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.WatchInBrowser_btn.RoundingArc = 23
        Me.WatchInBrowser_btn.Size = New System.Drawing.Size(599, 23)
        Me.WatchInBrowser_btn.TabIndex = 29
        Me.WatchInBrowser_btn.Text = "Im Browser auf Twitch.tv ansehen"
        '
        'MetroTranslatorLabel31
        '
        Me.MetroTranslatorLabel31.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel31.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel31.Font = New System.Drawing.Font("Arial", 12.25!)
        Me.MetroTranslatorLabel31.ForeColor = System.Drawing.Color.Silver
        Me.MetroTranslatorLabel31.LanguageKey = "MAIN:EVENTS_CURRENTLIVESTREAMTEXT"
        Me.MetroTranslatorLabel31.Location = New System.Drawing.Point(309, 175)
        Me.MetroTranslatorLabel31.Name = "MetroTranslatorLabel31"
        Me.MetroTranslatorLabel31.ShowToolTip = True
        Me.MetroTranslatorLabel31.Size = New System.Drawing.Size(599, 19)
        Me.MetroTranslatorLabel31.TabIndex = 28
        Me.MetroTranslatorLabel31.Text = "Aktueller Clonk Livestream"
        Me.MetroTranslatorLabel31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTranslatorLabel26
        '
        Me.MetroTranslatorLabel26.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroTranslatorLabel26.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel26.Font = New System.Drawing.Font("Arial", 20.25!)
        Me.MetroTranslatorLabel26.ForeColor = System.Drawing.Color.Silver
        Me.MetroTranslatorLabel26.LanguageKey = "MAIN:EVENTS_INFOTEXT"
        Me.MetroTranslatorLabel26.Location = New System.Drawing.Point(295, 99)
        Me.MetroTranslatorLabel26.Name = "MetroTranslatorLabel26"
        Me.MetroTranslatorLabel26.ShowToolTip = True
        Me.MetroTranslatorLabel26.Size = New System.Drawing.Size(626, 32)
        Me.MetroTranslatorLabel26.TabIndex = 27
        Me.MetroTranslatorLabel26.Text = "- KOMMT IN DEN NÄCHSTEN UPDATES -" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.MetroTranslatorLabel26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CCANTabPage_tp
        '
        Me.CCANTabPage_tp.BackColor = System.Drawing.Color.White
        Me.CCANTabPage_tp.Controls.Add(Me.ccanObjects_flp)
        Me.CCANTabPage_tp.Controls.Add(Me.MetroPanelCategory1)
        Me.CCANTabPage_tp.Location = New System.Drawing.Point(4, 44)
        Me.CCANTabPage_tp.Name = "CCANTabPage_tp"
        Me.CCANTabPage_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.CCANTabPage_tp.Size = New System.Drawing.Size(1217, 628)
        Me.CCANTabPage_tp.TabIndex = 4
        Me.CCANTabPage_tp.Text = "CCAN 2.0 (Beta)"
        '
        'MetroPanelCategory1
        '
        Me.MetroPanelCategory1.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroPanelCategory1.Appearance = MetroSuite.MetroPanelCategory.PanelAppearance.SlopedBottom
        Me.MetroPanelCategory1.BackColor = System.Drawing.Color.Transparent
        Me.MetroPanelCategory1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MetroPanelCategory1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.MetroPanelCategory1.Controls.Add(Me.MetroTranslatorLabel32)
        Me.MetroPanelCategory1.Controls.Add(Me.ccanServerStatus_lbl)
        Me.MetroPanelCategory1.Controls.Add(Me.refresh_btn)
        Me.MetroPanelCategory1.Controls.Add(Me.UploadNewContent_btn)
        Me.MetroPanelCategory1.Controls.Add(Me.ccanSearch_txtbox)
        Me.MetroPanelCategory1.Controls.Add(Me.PictureBox7)
        Me.MetroPanelCategory1.Controls.Add(Me.ccanLoading_picbox)
        Me.MetroPanelCategory1.Controls.Add(Me.ccanFilterOther_btn)
        Me.MetroPanelCategory1.Controls.Add(Me.MetroLabel2)
        Me.MetroPanelCategory1.Controls.Add(Me.ccanFilterObjects_btn)
        Me.MetroPanelCategory1.Controls.Add(Me.ccanFilterSzenarios_btn)
        Me.MetroPanelCategory1.Controls.Add(Me.ccanFilterAll_btn)
        Me.MetroPanelCategory1.Controls.Add(Me.CCANratingFilter_mcbox)
        Me.MetroPanelCategory1.Controls.Add(Me.ccanSearch_btn)
        Me.MetroPanelCategory1.Controls.Add(Me.ccanFilterPackage_btn)
        Me.MetroPanelCategory1.Controls.Add(Me.CCANdateFilter_mcbox)
        Me.MetroPanelCategory1.Controls.Add(Me.CCANversionFilter_mcbox)
        Me.MetroPanelCategory1.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(216, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.MetroPanelCategory1.Dock = System.Windows.Forms.DockStyle.Top
        Me.MetroPanelCategory1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroPanelCategory1.GradientColor = System.Drawing.Color.White
        Me.MetroPanelCategory1.GradientPointA = New System.Drawing.Point(0, 0)
        Me.MetroPanelCategory1.GradientPointB = New System.Drawing.Point(1211, 104)
        Me.MetroPanelCategory1.LineGradientColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(163, Byte), Integer))
        Me.MetroPanelCategory1.Location = New System.Drawing.Point(3, 3)
        Me.MetroPanelCategory1.Name = "MetroPanelCategory1"
        Me.MetroPanelCategory1.Size = New System.Drawing.Size(1211, 104)
        Me.MetroPanelCategory1.SlopeA = 0
        Me.MetroPanelCategory1.SlopeB = 40
        Me.MetroPanelCategory1.TabIndex = 45
        '
        'MetroTranslatorLabel32
        '
        Me.MetroTranslatorLabel32.BackColor = System.Drawing.Color.Transparent
        Me.MetroTranslatorLabel32.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTranslatorLabel32.ForeColor = System.Drawing.Color.Gainsboro
        Me.MetroTranslatorLabel32.LanguageKey = "MAIN:CCAN_FILTERTEXT"
        Me.MetroTranslatorLabel32.Location = New System.Drawing.Point(5, 76)
        Me.MetroTranslatorLabel32.Name = "MetroTranslatorLabel32"
        Me.MetroTranslatorLabel32.ShowToolTip = True
        Me.MetroTranslatorLabel32.Size = New System.Drawing.Size(48, 15)
        Me.MetroTranslatorLabel32.TabIndex = 48
        Me.MetroTranslatorLabel32.Text = "Filter:"
        Me.MetroTranslatorLabel32.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'ccanServerStatus_lbl
        '
        Me.ccanServerStatus_lbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ccanServerStatus_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ccanServerStatus_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ccanServerStatus_lbl.ForeColor = System.Drawing.Color.Gray
        Me.ccanServerStatus_lbl.LanguageKey = "MAIN:CCAN_NOCONNECTIONINFO"
        Me.ccanServerStatus_lbl.Location = New System.Drawing.Point(969, 5)
        Me.ccanServerStatus_lbl.Name = "ccanServerStatus_lbl"
        Me.ccanServerStatus_lbl.ShowToolTip = True
        Me.ccanServerStatus_lbl.Size = New System.Drawing.Size(239, 16)
        Me.ccanServerStatus_lbl.TabIndex = 47
        Me.ccanServerStatus_lbl.Text = "Keine Verbindung zum Server"
        Me.ccanServerStatus_lbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'refresh_btn
        '
        Me.refresh_btn.BackColor = System.Drawing.Color.Transparent
        Me.refresh_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.refresh_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.refresh_btn.DefaultColor = System.Drawing.Color.White
        Me.refresh_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.refresh_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.refresh_btn.HoverColor = System.Drawing.Color.White
        Me.refresh_btn.LanguageKey = "MAIN:CCAN_RELOADBTN"
        Me.refresh_btn.Location = New System.Drawing.Point(515, 33)
        Me.refresh_btn.Name = "refresh_btn"
        Me.refresh_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.refresh_btn.RoundingArc = 23
        Me.refresh_btn.Size = New System.Drawing.Size(74, 23)
        Me.refresh_btn.TabIndex = 46
        Me.refresh_btn.Text = "Neu laden"
        '
        'UploadNewContent_btn
        '
        Me.UploadNewContent_btn.BackColor = System.Drawing.Color.Transparent
        Me.UploadNewContent_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.UploadNewContent_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.UploadNewContent_btn.DefaultColor = System.Drawing.Color.White
        Me.UploadNewContent_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.UploadNewContent_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.UploadNewContent_btn.HoverColor = System.Drawing.Color.White
        Me.UploadNewContent_btn.LanguageKey = "MAIN:CCAN_UPLOADCONTENTBTN"
        Me.UploadNewContent_btn.Location = New System.Drawing.Point(348, 33)
        Me.UploadNewContent_btn.Name = "UploadNewContent_btn"
        Me.UploadNewContent_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.UploadNewContent_btn.RoundingArc = 23
        Me.UploadNewContent_btn.Size = New System.Drawing.Size(161, 23)
        Me.UploadNewContent_btn.TabIndex = 45
        Me.UploadNewContent_btn.Text = "Neue Objekte hochladen"
        '
        'ccanSearch_txtbox
        '
        Me.ccanSearch_txtbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ccanSearch_txtbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ccanSearch_txtbox.DefaultColor = System.Drawing.Color.White
        Me.ccanSearch_txtbox.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ccanSearch_txtbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ccanSearch_txtbox.HideSelection = False
        Me.ccanSearch_txtbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ccanSearch_txtbox.LanguageKey = "MAIN:CCAN_SEARCHTXTBOX"
        Me.ccanSearch_txtbox.Location = New System.Drawing.Point(63, 33)
        Me.ccanSearch_txtbox.Name = "ccanSearch_txtbox"
        Me.ccanSearch_txtbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.ccanSearch_txtbox.Size = New System.Drawing.Size(249, 23)
        Me.ccanSearch_txtbox.TabIndex = 44
        Me.ccanSearch_txtbox.Watermark = "Name oder ID zur Suche eingeben . . ."
        '
        'PictureBox7
        '
        Me.PictureBox7.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox7.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.ccan_2_symbol
        Me.PictureBox7.Location = New System.Drawing.Point(5, 3)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(48, 59)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox7.TabIndex = 1
        Me.PictureBox7.TabStop = False
        '
        'ccanLoading_picbox
        '
        Me.ccanLoading_picbox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ccanLoading_picbox.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.Loading_BlueFast
        Me.ccanLoading_picbox.Location = New System.Drawing.Point(1183, 29)
        Me.ccanLoading_picbox.Name = "ccanLoading_picbox"
        Me.ccanLoading_picbox.Size = New System.Drawing.Size(21, 21)
        Me.ccanLoading_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.ccanLoading_picbox.TabIndex = 13
        Me.ccanLoading_picbox.TabStop = False
        Me.ccanLoading_picbox.Visible = False
        '
        'ccanFilterOther_btn
        '
        Me.ccanFilterOther_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ccanFilterOther_btn.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.ccan_other
        Me.ccanFilterOther_btn.Location = New System.Drawing.Point(164, 72)
        Me.ccanFilterOther_btn.Name = "ccanFilterOther_btn"
        Me.ccanFilterOther_btn.Size = New System.Drawing.Size(24, 24)
        Me.ccanFilterOther_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.ccanFilterOther_btn.TabIndex = 7
        Me.ccanFilterOther_btn.TabStop = False
        '
        'ccanFilterObjects_btn
        '
        Me.ccanFilterObjects_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ccanFilterObjects_btn.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.ccan_object
        Me.ccanFilterObjects_btn.Location = New System.Drawing.Point(104, 72)
        Me.ccanFilterObjects_btn.Name = "ccanFilterObjects_btn"
        Me.ccanFilterObjects_btn.Size = New System.Drawing.Size(24, 24)
        Me.ccanFilterObjects_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.ccanFilterObjects_btn.TabIndex = 5
        Me.ccanFilterObjects_btn.TabStop = False
        '
        'ccanFilterSzenarios_btn
        '
        Me.ccanFilterSzenarios_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ccanFilterSzenarios_btn.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.ccan_szenarios
        Me.ccanFilterSzenarios_btn.Location = New System.Drawing.Point(134, 72)
        Me.ccanFilterSzenarios_btn.Name = "ccanFilterSzenarios_btn"
        Me.ccanFilterSzenarios_btn.Size = New System.Drawing.Size(24, 24)
        Me.ccanFilterSzenarios_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.ccanFilterSzenarios_btn.TabIndex = 6
        Me.ccanFilterSzenarios_btn.TabStop = False
        '
        'ccanFilterAll_btn
        '
        Me.ccanFilterAll_btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ccanFilterAll_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ccanFilterAll_btn.Image = CType(resources.GetObject("ccanFilterAll_btn.Image"), System.Drawing.Image)
        Me.ccanFilterAll_btn.Location = New System.Drawing.Point(63, 72)
        Me.ccanFilterAll_btn.Name = "ccanFilterAll_btn"
        Me.ccanFilterAll_btn.Size = New System.Drawing.Size(35, 24)
        Me.ccanFilterAll_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.ccanFilterAll_btn.TabIndex = 16
        Me.ccanFilterAll_btn.TabStop = False
        '
        'ccanSearch_btn
        '
        Me.ccanSearch_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ccanSearch_btn.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.ccan_search
        Me.ccanSearch_btn.Location = New System.Drawing.Point(318, 33)
        Me.ccanSearch_btn.Name = "ccanSearch_btn"
        Me.ccanSearch_btn.Size = New System.Drawing.Size(24, 23)
        Me.ccanSearch_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ccanSearch_btn.TabIndex = 4
        Me.ccanSearch_btn.TabStop = False
        '
        'ccanFilterPackage_btn
        '
        Me.ccanFilterPackage_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ccanFilterPackage_btn.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.clonk_zipfile
        Me.ccanFilterPackage_btn.Location = New System.Drawing.Point(194, 72)
        Me.ccanFilterPackage_btn.Name = "ccanFilterPackage_btn"
        Me.ccanFilterPackage_btn.Size = New System.Drawing.Size(24, 24)
        Me.ccanFilterPackage_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.ccanFilterPackage_btn.TabIndex = 42
        Me.ccanFilterPackage_btn.TabStop = False
        '
        'Checker_tmr
        '
        Me.Checker_tmr.Interval = 1000
        '
        'NotificationPanel_pnl
        '
        Me.NotificationPanel_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NotificationPanel_pnl.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(26, Byte), Integer), CType(CType(26, Byte), Integer))
        Me.NotificationPanel_pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NotificationPanel_pnl.Controls.Add(Me.NoNotifications_lbl)
        Me.NotificationPanel_pnl.Controls.Add(Me.Notifications_flp)
        Me.NotificationPanel_pnl.Controls.Add(Me.DiscardAllNotifications_btn)
        Me.NotificationPanel_pnl.Location = New System.Drawing.Point(671, 114)
        Me.NotificationPanel_pnl.Name = "NotificationPanel_pnl"
        Me.NotificationPanel_pnl.Size = New System.Drawing.Size(200, 267)
        Me.NotificationPanel_pnl.TabIndex = 19
        Me.NotificationPanel_pnl.Visible = False
        '
        'NoNotifications_lbl
        '
        Me.NoNotifications_lbl.BackColor = System.Drawing.Color.Black
        Me.NoNotifications_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.NoNotifications_lbl.ForeColor = System.Drawing.Color.White
        Me.NoNotifications_lbl.LanguageKey = "MAIN:OTHER_NONOTIFICATIONSTEXT"
        Me.NoNotifications_lbl.Location = New System.Drawing.Point(22, 115)
        Me.NoNotifications_lbl.Name = "NoNotifications_lbl"
        Me.NoNotifications_lbl.ShowToolTip = True
        Me.NoNotifications_lbl.Size = New System.Drawing.Size(155, 34)
        Me.NoNotifications_lbl.TabIndex = 2
        Me.NoNotifications_lbl.Text = "Keine Benachrichtigung(en) vorhanden"
        Me.NoNotifications_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Notifications_flp
        '
        Me.Notifications_flp.AutoScroll = True
        Me.Notifications_flp.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Notifications_flp.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.Notifications_flp.Location = New System.Drawing.Point(0, 0)
        Me.Notifications_flp.Name = "Notifications_flp"
        Me.Notifications_flp.Size = New System.Drawing.Size(198, 242)
        Me.Notifications_flp.TabIndex = 0
        Me.Notifications_flp.WrapContents = False
        '
        'DiscardAllNotifications_btn
        '
        Me.DiscardAllNotifications_btn.BackColor = System.Drawing.Color.Transparent
        Me.DiscardAllNotifications_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DiscardAllNotifications_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(26, Byte), Integer), CType(CType(26, Byte), Integer))
        Me.DiscardAllNotifications_btn.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(26, Byte), Integer), CType(CType(26, Byte), Integer))
        Me.DiscardAllNotifications_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.DiscardAllNotifications_btn.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DiscardAllNotifications_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DiscardAllNotifications_btn.ForeColor = System.Drawing.Color.White
        Me.DiscardAllNotifications_btn.HoverColor = System.Drawing.Color.DimGray
        Me.DiscardAllNotifications_btn.LanguageKey = "MAIN:OTHER_DISCARDALLNOTIFICATIONSBTN"
        Me.DiscardAllNotifications_btn.Location = New System.Drawing.Point(0, 242)
        Me.DiscardAllNotifications_btn.Name = "DiscardAllNotifications_btn"
        Me.DiscardAllNotifications_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.DiscardAllNotifications_btn.RoundingArc = 23
        Me.DiscardAllNotifications_btn.Size = New System.Drawing.Size(198, 23)
        Me.DiscardAllNotifications_btn.TabIndex = 3
        Me.DiscardAllNotifications_btn.Text = "Alle Benachrichtigungen verwerfen"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.username_hst)
        Me.Panel1.Controls.Add(Me.ShowProfile_btn)
        Me.Panel1.Controls.Add(Me.FriendsList_btn)
        Me.Panel1.Controls.Add(Me.Settings_btn)
        Me.Panel1.Controls.Add(Me.Notifications_btn)
        Me.Panel1.Controls.Add(Me.user_picbox)
        Me.Panel1.Controls.Add(Me.MainLogo_picbox)
        Me.Panel1.Location = New System.Drawing.Point(1, 31)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1229, 77)
        Me.Panel1.TabIndex = 2
        '
        'username_hst
        '
        Me.username_hst.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.username_hst.BackColor = System.Drawing.Color.Transparent
        Me.username_hst.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.username_hst.InputText = "TEXT"
        Me.username_hst.Location = New System.Drawing.Point(1012, 9)
        Me.username_hst.Name = "username_hst"
        Me.username_hst.ScrollSpeed = 15
        Me.username_hst.Size = New System.Drawing.Size(170, 32)
        Me.username_hst.Stepping = 1
        Me.username_hst.Style = Xtreme_Clonk_Launcher.HorizontalScrollingText.sStyle.Custom
        Me.username_hst.TabIndex = 15
        Me.username_hst.TextColor = System.Drawing.Color.DarkGray
        '
        'ShowProfile_btn
        '
        Me.ShowProfile_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ShowProfile_btn.BackColor = System.Drawing.Color.Transparent
        Me.ShowProfile_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ShowProfile_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.ShowProfile_btn.DefaultColor = System.Drawing.Color.White
        Me.ShowProfile_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ShowProfile_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ShowProfile_btn.HoverColor = System.Drawing.Color.White
        Me.ShowProfile_btn.IsRound = True
        Me.ShowProfile_btn.LanguageKey = "MAIN:OTHER_SHOWPROFILEBTN"
        Me.ShowProfile_btn.Location = New System.Drawing.Point(1119, 48)
        Me.ShowProfile_btn.Name = "ShowProfile_btn"
        Me.ShowProfile_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ShowProfile_btn.RoundingArc = 24
        Me.ShowProfile_btn.Size = New System.Drawing.Size(101, 24)
        Me.ShowProfile_btn.TabIndex = 14
        Me.ShowProfile_btn.Text = "Profil anzeigen"
        '
        'FriendsList_btn
        '
        Me.FriendsList_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FriendsList_btn.BackColor = System.Drawing.Color.Transparent
        Me.FriendsList_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.FriendsList_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.FriendsList_btn.DefaultColor = System.Drawing.Color.White
        Me.FriendsList_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.FriendsList_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.FriendsList_btn.HoverColor = System.Drawing.Color.White
        Me.FriendsList_btn.IsRound = True
        Me.FriendsList_btn.LanguageKey = "MAIN:OTHER_FRIENDSCHATBTN"
        Me.FriendsList_btn.Location = New System.Drawing.Point(1012, 48)
        Me.FriendsList_btn.Name = "FriendsList_btn"
        Me.FriendsList_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.FriendsList_btn.RoundingArc = 24
        Me.FriendsList_btn.Size = New System.Drawing.Size(101, 24)
        Me.FriendsList_btn.TabIndex = 13
        Me.FriendsList_btn.Text = "Freunde & Chat"
        '
        'Settings_btn
        '
        Me.Settings_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Settings_btn.BackColor = System.Drawing.Color.Transparent
        Me.Settings_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Settings_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Settings_btn.DefaultColor = System.Drawing.Color.White
        Me.Settings_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Settings_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Settings_btn.HoverColor = System.Drawing.Color.White
        Me.Settings_btn.IsRound = True
        Me.Settings_btn.LanguageKey = "MAIN:OTHER_ACCANDSETTINGSBTN"
        Me.Settings_btn.Location = New System.Drawing.Point(850, 48)
        Me.Settings_btn.Name = "Settings_btn"
        Me.Settings_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Settings_btn.RoundingArc = 24
        Me.Settings_btn.Size = New System.Drawing.Size(156, 24)
        Me.Settings_btn.TabIndex = 12
        Me.Settings_btn.Text = "Account und Einstellungen"
        '
        'Notifications_btn
        '
        Me.Notifications_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Notifications_btn.BackColor = System.Drawing.Color.Transparent
        Me.Notifications_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Notifications_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Notifications_btn.DefaultColor = System.Drawing.Color.White
        Me.Notifications_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Notifications_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Notifications_btn.HoverColor = System.Drawing.Color.White
        Me.Notifications_btn.IsRound = True
        Me.Notifications_btn.LanguageKey = "MAIN:OTHER_NOTIFICATIONSBTN"
        Me.Notifications_btn.Location = New System.Drawing.Point(691, 48)
        Me.Notifications_btn.Name = "Notifications_btn"
        Me.Notifications_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Notifications_btn.RoundingArc = 24
        Me.Notifications_btn.Size = New System.Drawing.Size(153, 24)
        Me.Notifications_btn.TabIndex = 11
        Me.Notifications_btn.Text = "%s Benachrichtigung(en)"
        '
        'user_picbox
        '
        Me.user_picbox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.user_picbox.BackColor = System.Drawing.Color.Transparent
        Me.user_picbox.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.clonk_user_unknown
        Me.user_picbox.Location = New System.Drawing.Point(1188, 9)
        Me.user_picbox.Name = "user_picbox"
        Me.user_picbox.Size = New System.Drawing.Size(32, 32)
        Me.user_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.user_picbox.TabIndex = 8
        Me.user_picbox.TabStop = False
        '
        'MainLogo_picbox
        '
        Me.MainLogo_picbox.BackColor = System.Drawing.Color.Transparent
        Me.MainLogo_picbox.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.new_logo
        Me.MainLogo_picbox.Location = New System.Drawing.Point(11, 12)
        Me.MainLogo_picbox.Name = "MainLogo_picbox"
        Me.MainLogo_picbox.Size = New System.Drawing.Size(206, 56)
        Me.MainLogo_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.MainLogo_picbox.TabIndex = 0
        Me.MainLogo_picbox.TabStop = False
        '
        'ClonkIsRunningInfo_lbl
        '
        Me.ClonkIsRunningInfo_lbl.AutoSize = True
        Me.ClonkIsRunningInfo_lbl.BackColor = System.Drawing.Color.Transparent
        Me.ClonkIsRunningInfo_lbl.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.ClonkIsRunningInfo_lbl.ForeColor = System.Drawing.Color.Lime
        Me.ClonkIsRunningInfo_lbl.LanguageKey = "MAIN:OTHER_CLONKISRUNNINGTEXT"
        Me.ClonkIsRunningInfo_lbl.Location = New System.Drawing.Point(179, 10)
        Me.ClonkIsRunningInfo_lbl.Name = "ClonkIsRunningInfo_lbl"
        Me.ClonkIsRunningInfo_lbl.ShowToolTip = True
        Me.ClonkIsRunningInfo_lbl.Size = New System.Drawing.Size(64, 13)
        Me.ClonkIsRunningInfo_lbl.TabIndex = 20
        Me.ClonkIsRunningInfo_lbl.Text = "Clonk läuft"
        Me.ClonkIsRunningInfo_lbl.Visible = False
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.ContextMenuStrip = Me.Infobar_ctms
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "Xtreme-Clonk-Launcher"
        Me.NotifyIcon1.Visible = True
        '
        'Infobar_ctms
        '
        Me.Infobar_ctms.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Infobar_ctms.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Infobar_ctms.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Infobar_ctms.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.ToolStripSeparator1, Me.AufUpdatesPrüfenToolStripMenuItem, Me.BeendenToolStripMenuItem})
        Me.Infobar_ctms.Name = "Infobar_ctms"
        Me.Infobar_ctms.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.Infobar_ctms.ShowItemToolTips = False
        Me.Infobar_ctms.Size = New System.Drawing.Size(191, 76)
        Me.Infobar_ctms.Style = Xtreme_Clonk_Launcher.ModernContextMenuStrip.Styles.Light
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(190, 22)
        Me.ToolStripMenuItem1.Text = "Öffnen"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(187, 6)
        '
        'AufUpdatesPrüfenToolStripMenuItem
        '
        Me.AufUpdatesPrüfenToolStripMenuItem.Name = "AufUpdatesPrüfenToolStripMenuItem"
        Me.AufUpdatesPrüfenToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.AufUpdatesPrüfenToolStripMenuItem.Text = "Auf Updates prüfen"
        '
        'BeendenToolStripMenuItem
        '
        Me.BeendenToolStripMenuItem.Name = "BeendenToolStripMenuItem"
        Me.BeendenToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.BeendenToolStripMenuItem.Text = "Beenden"
        '
        'OpenClonkSettings_ctms
        '
        Me.OpenClonkSettings_ctms.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.OpenClonkSettings_ctms.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.OpenClonkSettings_ctms.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.OpenClonkSettings_ctms.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SpieleinstellungenToolStripMenuItem, Me.ImExplorerAnzeigenToolStripMenuItem, Me.ToolStripSeparator2, Me.SpielDeinstallierenToolStripMenuItem})
        Me.OpenClonkSettings_ctms.Name = "ModernContextMenuStrip1"
        Me.OpenClonkSettings_ctms.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.OpenClonkSettings_ctms.ShowItemToolTips = False
        Me.OpenClonkSettings_ctms.Size = New System.Drawing.Size(200, 76)
        Me.OpenClonkSettings_ctms.Style = Xtreme_Clonk_Launcher.ModernContextMenuStrip.Styles.Light
        '
        'SpieleinstellungenToolStripMenuItem
        '
        Me.SpieleinstellungenToolStripMenuItem.Name = "SpieleinstellungenToolStripMenuItem"
        Me.SpieleinstellungenToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.SpieleinstellungenToolStripMenuItem.Tag = "OpenClonk"
        Me.SpieleinstellungenToolStripMenuItem.Text = "Spieleinstellungen"
        '
        'ImExplorerAnzeigenToolStripMenuItem
        '
        Me.ImExplorerAnzeigenToolStripMenuItem.Name = "ImExplorerAnzeigenToolStripMenuItem"
        Me.ImExplorerAnzeigenToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.ImExplorerAnzeigenToolStripMenuItem.Tag = "OpenClonk"
        Me.ImExplorerAnzeigenToolStripMenuItem.Text = "Im Explorer anzeigen"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(196, 6)
        '
        'SpielDeinstallierenToolStripMenuItem
        '
        Me.SpielDeinstallierenToolStripMenuItem.Name = "SpielDeinstallierenToolStripMenuItem"
        Me.SpielDeinstallierenToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.SpielDeinstallierenToolStripMenuItem.Tag = "OpenClonk"
        Me.SpielDeinstallierenToolStripMenuItem.Text = "Spiel deinstallieren"
        '
        'OpenClonkx86Settings_ctms
        '
        Me.OpenClonkx86Settings_ctms.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.OpenClonkx86Settings_ctms.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.OpenClonkx86Settings_ctms.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.OpenClonkx86Settings_ctms.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SpieleinstellungenToolStripMenuItem1, Me.ImExplorerAnzeigenToolStripMenuItem1, Me.ToolStripSeparator3, Me.SpielDeinstallierenToolStripMenuItem1})
        Me.OpenClonkx86Settings_ctms.Name = "ModernContextMenuStrip1"
        Me.OpenClonkx86Settings_ctms.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.OpenClonkx86Settings_ctms.ShowItemToolTips = False
        Me.OpenClonkx86Settings_ctms.Size = New System.Drawing.Size(200, 76)
        Me.OpenClonkx86Settings_ctms.Style = Xtreme_Clonk_Launcher.ModernContextMenuStrip.Styles.Light
        '
        'SpieleinstellungenToolStripMenuItem1
        '
        Me.SpieleinstellungenToolStripMenuItem1.Name = "SpieleinstellungenToolStripMenuItem1"
        Me.SpieleinstellungenToolStripMenuItem1.Size = New System.Drawing.Size(199, 22)
        Me.SpieleinstellungenToolStripMenuItem1.Tag = "OpenClonk_x86"
        Me.SpieleinstellungenToolStripMenuItem1.Text = "Spieleinstellungen"
        '
        'ImExplorerAnzeigenToolStripMenuItem1
        '
        Me.ImExplorerAnzeigenToolStripMenuItem1.Name = "ImExplorerAnzeigenToolStripMenuItem1"
        Me.ImExplorerAnzeigenToolStripMenuItem1.Size = New System.Drawing.Size(199, 22)
        Me.ImExplorerAnzeigenToolStripMenuItem1.Tag = "OpenClonk_x86"
        Me.ImExplorerAnzeigenToolStripMenuItem1.Text = "Im Explorer anzeigen"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(196, 6)
        '
        'SpielDeinstallierenToolStripMenuItem1
        '
        Me.SpielDeinstallierenToolStripMenuItem1.Name = "SpielDeinstallierenToolStripMenuItem1"
        Me.SpielDeinstallierenToolStripMenuItem1.Size = New System.Drawing.Size(199, 22)
        Me.SpielDeinstallierenToolStripMenuItem1.Tag = "OpenClonk_x86"
        Me.SpielDeinstallierenToolStripMenuItem1.Text = "Spiel deinstallieren"
        '
        'ClonkRageSettings_ctms
        '
        Me.ClonkRageSettings_ctms.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClonkRageSettings_ctms.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.ClonkRageSettings_ctms.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClonkRageSettings_ctms.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SpieleinstellungenToolStripMenuItem2, Me.ImExplorerAnzeigenToolStripMenuItem2, Me.AufUpdatesPrüfenToolStripMenuItem1, Me.ToolStripSeparator4, Me.SpielDeinstallierenToolStripMenuItem2})
        Me.ClonkRageSettings_ctms.Name = "ModernContextMenuStrip1"
        Me.ClonkRageSettings_ctms.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ClonkRageSettings_ctms.ShowItemToolTips = False
        Me.ClonkRageSettings_ctms.Size = New System.Drawing.Size(200, 98)
        Me.ClonkRageSettings_ctms.Style = Xtreme_Clonk_Launcher.ModernContextMenuStrip.Styles.Light
        '
        'SpieleinstellungenToolStripMenuItem2
        '
        Me.SpieleinstellungenToolStripMenuItem2.Name = "SpieleinstellungenToolStripMenuItem2"
        Me.SpieleinstellungenToolStripMenuItem2.Size = New System.Drawing.Size(199, 22)
        Me.SpieleinstellungenToolStripMenuItem2.Tag = "ClonkRage"
        Me.SpieleinstellungenToolStripMenuItem2.Text = "Spieleinstellungen"
        '
        'ImExplorerAnzeigenToolStripMenuItem2
        '
        Me.ImExplorerAnzeigenToolStripMenuItem2.Name = "ImExplorerAnzeigenToolStripMenuItem2"
        Me.ImExplorerAnzeigenToolStripMenuItem2.Size = New System.Drawing.Size(199, 22)
        Me.ImExplorerAnzeigenToolStripMenuItem2.Tag = "ClonkRage"
        Me.ImExplorerAnzeigenToolStripMenuItem2.Text = "Im Explorer anzeigen"
        '
        'AufUpdatesPrüfenToolStripMenuItem1
        '
        Me.AufUpdatesPrüfenToolStripMenuItem1.Name = "AufUpdatesPrüfenToolStripMenuItem1"
        Me.AufUpdatesPrüfenToolStripMenuItem1.Size = New System.Drawing.Size(199, 22)
        Me.AufUpdatesPrüfenToolStripMenuItem1.Tag = "ClonkRage"
        Me.AufUpdatesPrüfenToolStripMenuItem1.Text = "Auf Updates prüfen"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(196, 6)
        '
        'SpielDeinstallierenToolStripMenuItem2
        '
        Me.SpielDeinstallierenToolStripMenuItem2.Name = "SpielDeinstallierenToolStripMenuItem2"
        Me.SpielDeinstallierenToolStripMenuItem2.Size = New System.Drawing.Size(199, 22)
        Me.SpielDeinstallierenToolStripMenuItem2.Tag = "ClonkRage"
        Me.SpielDeinstallierenToolStripMenuItem2.Text = "Spiel deinstallieren"
        '
        'ClonkEndeavourSettings_ctms
        '
        Me.ClonkEndeavourSettings_ctms.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClonkEndeavourSettings_ctms.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.ClonkEndeavourSettings_ctms.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClonkEndeavourSettings_ctms.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SpieleinstellungenToolStripMenuItem3, Me.ImExplorerAnzeigenToolStripMenuItem3, Me.ToolStripSeparator5, Me.SpielDeinstallierenToolStripMenuItem3})
        Me.ClonkEndeavourSettings_ctms.Name = "ModernContextMenuStrip1"
        Me.ClonkEndeavourSettings_ctms.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ClonkEndeavourSettings_ctms.ShowItemToolTips = False
        Me.ClonkEndeavourSettings_ctms.Size = New System.Drawing.Size(200, 76)
        Me.ClonkEndeavourSettings_ctms.Style = Xtreme_Clonk_Launcher.ModernContextMenuStrip.Styles.Light
        '
        'SpieleinstellungenToolStripMenuItem3
        '
        Me.SpieleinstellungenToolStripMenuItem3.Name = "SpieleinstellungenToolStripMenuItem3"
        Me.SpieleinstellungenToolStripMenuItem3.Size = New System.Drawing.Size(199, 22)
        Me.SpieleinstellungenToolStripMenuItem3.Tag = "ClonkEndeavour"
        Me.SpieleinstellungenToolStripMenuItem3.Text = "Spieleinstellungen"
        '
        'ImExplorerAnzeigenToolStripMenuItem3
        '
        Me.ImExplorerAnzeigenToolStripMenuItem3.Name = "ImExplorerAnzeigenToolStripMenuItem3"
        Me.ImExplorerAnzeigenToolStripMenuItem3.Size = New System.Drawing.Size(199, 22)
        Me.ImExplorerAnzeigenToolStripMenuItem3.Tag = "ClonkEndeavour"
        Me.ImExplorerAnzeigenToolStripMenuItem3.Text = "Im Explorer anzeigen"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(196, 6)
        '
        'SpielDeinstallierenToolStripMenuItem3
        '
        Me.SpielDeinstallierenToolStripMenuItem3.Name = "SpielDeinstallierenToolStripMenuItem3"
        Me.SpielDeinstallierenToolStripMenuItem3.Size = New System.Drawing.Size(199, 22)
        Me.SpielDeinstallierenToolStripMenuItem3.Tag = "ClonkEndeavour"
        Me.SpielDeinstallierenToolStripMenuItem3.Text = "Spiel deinstallieren"
        '
        'ClonkPlanetSettings_ctms
        '
        Me.ClonkPlanetSettings_ctms.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClonkPlanetSettings_ctms.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.ClonkPlanetSettings_ctms.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClonkPlanetSettings_ctms.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SpieleinstellungenToolStripMenuItem4, Me.ImExplorerAnzeigenToolStripMenuItem4, Me.ToolStripSeparator6, Me.SpielDeinstallierenToolStripMenuItem4})
        Me.ClonkPlanetSettings_ctms.Name = "ModernContextMenuStrip1"
        Me.ClonkPlanetSettings_ctms.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ClonkPlanetSettings_ctms.ShowItemToolTips = False
        Me.ClonkPlanetSettings_ctms.Size = New System.Drawing.Size(200, 76)
        Me.ClonkPlanetSettings_ctms.Style = Xtreme_Clonk_Launcher.ModernContextMenuStrip.Styles.Light
        '
        'SpieleinstellungenToolStripMenuItem4
        '
        Me.SpieleinstellungenToolStripMenuItem4.Name = "SpieleinstellungenToolStripMenuItem4"
        Me.SpieleinstellungenToolStripMenuItem4.Size = New System.Drawing.Size(199, 22)
        Me.SpieleinstellungenToolStripMenuItem4.Tag = "ClonkPlanet"
        Me.SpieleinstellungenToolStripMenuItem4.Text = "Spieleinstellungen"
        '
        'ImExplorerAnzeigenToolStripMenuItem4
        '
        Me.ImExplorerAnzeigenToolStripMenuItem4.Name = "ImExplorerAnzeigenToolStripMenuItem4"
        Me.ImExplorerAnzeigenToolStripMenuItem4.Size = New System.Drawing.Size(199, 22)
        Me.ImExplorerAnzeigenToolStripMenuItem4.Tag = "ClonkPlanet"
        Me.ImExplorerAnzeigenToolStripMenuItem4.Text = "Im Explorer anzeigen"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(196, 6)
        '
        'SpielDeinstallierenToolStripMenuItem4
        '
        Me.SpielDeinstallierenToolStripMenuItem4.Name = "SpielDeinstallierenToolStripMenuItem4"
        Me.SpielDeinstallierenToolStripMenuItem4.Size = New System.Drawing.Size(199, 22)
        Me.SpielDeinstallierenToolStripMenuItem4.Tag = "ClonkPlanet"
        Me.SpielDeinstallierenToolStripMenuItem4.Text = "Spiel deinstallieren"
        '
        'Clonk4Settings_ctms
        '
        Me.Clonk4Settings_ctms.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Clonk4Settings_ctms.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Clonk4Settings_ctms.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Clonk4Settings_ctms.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SpieleinstellungenToolStripMenuItem5, Me.ImExplorerAnzeigenToolStripMenuItem5, Me.ToolStripSeparator7, Me.SpielDeinstallierenToolStripMenuItem5})
        Me.Clonk4Settings_ctms.Name = "ModernContextMenuStrip1"
        Me.Clonk4Settings_ctms.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.Clonk4Settings_ctms.ShowItemToolTips = False
        Me.Clonk4Settings_ctms.Size = New System.Drawing.Size(200, 76)
        Me.Clonk4Settings_ctms.Style = Xtreme_Clonk_Launcher.ModernContextMenuStrip.Styles.Light
        '
        'SpieleinstellungenToolStripMenuItem5
        '
        Me.SpieleinstellungenToolStripMenuItem5.Name = "SpieleinstellungenToolStripMenuItem5"
        Me.SpieleinstellungenToolStripMenuItem5.Size = New System.Drawing.Size(199, 22)
        Me.SpieleinstellungenToolStripMenuItem5.Tag = "Clonk4"
        Me.SpieleinstellungenToolStripMenuItem5.Text = "Spieleinstellungen"
        '
        'ImExplorerAnzeigenToolStripMenuItem5
        '
        Me.ImExplorerAnzeigenToolStripMenuItem5.Name = "ImExplorerAnzeigenToolStripMenuItem5"
        Me.ImExplorerAnzeigenToolStripMenuItem5.Size = New System.Drawing.Size(199, 22)
        Me.ImExplorerAnzeigenToolStripMenuItem5.Tag = "Clonk4"
        Me.ImExplorerAnzeigenToolStripMenuItem5.Text = "Im Explorer anzeigen"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(196, 6)
        '
        'SpielDeinstallierenToolStripMenuItem5
        '
        Me.SpielDeinstallierenToolStripMenuItem5.Name = "SpielDeinstallierenToolStripMenuItem5"
        Me.SpielDeinstallierenToolStripMenuItem5.Size = New System.Drawing.Size(199, 22)
        Me.SpielDeinstallierenToolStripMenuItem5.Tag = "Clonk4"
        Me.SpielDeinstallierenToolStripMenuItem5.Text = "Spiel deinstallieren"
        '
        'Main
        '
        Me.AllowResize = False
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1231, 810)
        Me.Controls.Add(Me.ClonkIsRunningInfo_lbl)
        Me.Controls.Add(Me.NotificationPanel_pnl)
        Me.Controls.Add(Me.MetroTabControl2)
        Me.Controls.Add(Me.MetroStatusStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MinimumSize = New System.Drawing.Size(1041, 716)
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "Xtreme-Clonk-Launcher"
        Me.controlbox_pnl.ResumeLayout(False)
        Me.MetroTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.OpenClonkWebbrowserError_pnl.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel13.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ClonkRageWebbrowserError_pnl.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.ClonkEndeavourWebbrowserError_pnl.ResumeLayout(False)
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.ClonkPlanetWebbrowserError_pnl.ResumeLayout(False)
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Clonk4WebbrowserError_pnl.ResumeLayout(False)
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.HomeWebbrowserError_pnl.ResumeLayout(False)
        Me.EventsWebbrowserError_pnl.ResumeLayout(False)
        Me.MetroStatusStrip1.ResumeLayout(False)
        Me.MetroStatusStrip1.PerformLayout()
        Me.MetroTabControl2.ResumeLayout(False)
        Me.StartTabPage_tp.ResumeLayout(False)
        Me.StartTabPage_tp.PerformLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LibraryTabPage_tp.ResumeLayout(False)
        Me.NewsTabPage_tp.ResumeLayout(False)
        Me.NewsTabPage_tp.PerformLayout()
        Me.NewsPanel_pnl.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        CType(Me.NewsLoading_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EventsTabPage_tp.ResumeLayout(False)
        Me.EventsTabPage_tp.PerformLayout()
        Me.CCANTabPage_tp.ResumeLayout(False)
        Me.MetroPanelCategory1.ResumeLayout(False)
        Me.MetroPanelCategory1.PerformLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ccanLoading_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ccanFilterOther_btn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ccanFilterObjects_btn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ccanFilterSzenarios_btn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ccanFilterAll_btn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ccanSearch_btn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ccanFilterPackage_btn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NotificationPanel_pnl.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.user_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MainLogo_picbox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Infobar_ctms.ResumeLayout(False)
        Me.OpenClonkSettings_ctms.ResumeLayout(False)
        Me.OpenClonkx86Settings_ctms.ResumeLayout(False)
        Me.ClonkRageSettings_ctms.ResumeLayout(False)
        Me.ClonkEndeavourSettings_ctms.ResumeLayout(False)
        Me.ClonkPlanetSettings_ctms.ResumeLayout(False)
        Me.Clonk4Settings_ctms.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Friend WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Friend WithEvents MetroTabControl1 As MetroSuite.MetroTabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents MainLogo_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents ClonkWebsite_btn As MetroSuite.MetroButton
    Friend WithEvents ClonkSpotWebsite_btn As MetroSuite.MetroButton
    Friend WithEvents CCANWebsite_btn As MetroSuite.MetroButton
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents user_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents MetroLabel2 As MetroSuite.MetroLabel
    Friend WithEvents ccanSearch_btn As System.Windows.Forms.PictureBox
    Friend WithEvents ccanFilterObjects_btn As System.Windows.Forms.PictureBox
    Friend WithEvents ccanFilterSzenarios_btn As System.Windows.Forms.PictureBox
    Friend WithEvents ccanFilterOther_btn As System.Windows.Forms.PictureBox
    Friend WithEvents OpenClonk_x86_btn As MetroSuite.MetroButton
    Friend WithEvents cmd_OpenClonk_btn As MetroSuite.MetroButton
    Friend WithEvents cmd_ClonkRage_btn As MetroSuite.MetroButton
    Friend WithEvents cmd_ClonkEndeavour_btn As MetroSuite.MetroButton
    Friend WithEvents cmd_ClonkPlanet_btn As MetroSuite.MetroButton
    Friend WithEvents cmd_Clonk4_btn As MetroSuite.MetroButton
    Friend WithEvents MetroStatusStrip1 As MetroSuite.MetroStatusStrip
    Friend WithEvents status_lbl As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents downloadProgress_prgsbar As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents ccanObjects_flp As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents ccanLoading_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents DiscordInviteLink_btn As MetroSuite.MetroButton
    Friend WithEvents CCANversionFilter_mcbox As MetroSuite.MetroComboBox
    Friend WithEvents ccanFilterAll_btn As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents OwnClonkGameInfo_rtb As System.Windows.Forms.RichTextBox
    Friend WithEvents CCANratingFilter_mcbox As MetroSuite.MetroComboBox
    Friend WithEvents ClonkRageWebbrowserError_pnl As System.Windows.Forms.Panel
    Friend WithEvents ccanFilterPackage_btn As System.Windows.Forms.PictureBox
    Friend WithEvents OpenClonkWebbrowserError_pnl As System.Windows.Forms.Panel
    Friend WithEvents ClonkEndeavourWebbrowserError_pnl As System.Windows.Forms.Panel
    Friend WithEvents ClonkPlanetWebbrowserError_pnl As System.Windows.Forms.Panel
    Friend WithEvents Clonk4WebbrowserError_pnl As System.Windows.Forms.Panel
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents YouTube_ClonkNews_btn As MetroSuite.MetroButton
    Friend WithEvents YouTube_Clonkspot_btn As MetroSuite.MetroButton
    Friend WithEvents YouTube_matthesb_btn As MetroSuite.MetroButton
    Friend WithEvents changelog_rtb As System.Windows.Forms.RichTextBox
    Friend WithEvents HomeWebbrowserError_pnl As System.Windows.Forms.Panel
    Friend WithEvents news_rtb As System.Windows.Forms.RichTextBox
    Friend WithEvents MetroLabel32 As MetroSuite.MetroLabel
    Friend WithEvents EventsWebbrowserError_pnl As System.Windows.Forms.Panel
    Friend WithEvents CheckClonkProcess_tmr As System.Windows.Forms.Timer
    Friend WithEvents downloadProgress_lbl As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents LCDesc_asl As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
    Friend WithEvents C4Desc_asl As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
    Friend WithEvents CPDesc_asl As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
    Friend WithEvents CEDesc_asl As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
    Friend WithEvents OCDesc_asl As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
    Friend WithEvents Clonk4RushHour_GBarChart As GChartLib.GBarChart
    Friend WithEvents ClonkPlanetRushHour_GBarChart As GChartLib.GBarChart
    Friend WithEvents OpenClonkRushHour_GBarChart As GChartLib.GBarChart
    Friend WithEvents ClonkRageRushHour_GBarChart As GChartLib.GBarChart
    Friend WithEvents ClonkEndeavourRushHour_GBarChart As GChartLib.GBarChart
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents CCANdateFilter_mcbox As MetroSuite.MetroComboBox
    Friend WithEvents InstalledGamesTT_tt As System.Windows.Forms.ToolTip
    Friend WithEvents MetroLabel18 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel23 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel24 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel31 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel35 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel36 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel37 As MetroSuite.MetroLabel
    Friend WithEvents MetroTabControl2 As MetroSuite.MetroTabControl
    Friend WithEvents StartTabPage_tp As System.Windows.Forms.TabPage
    Friend WithEvents LibraryTabPage_tp As System.Windows.Forms.TabPage
    Friend WithEvents NewsTabPage_tp As System.Windows.Forms.TabPage
    Friend WithEvents EventsTabPage_tp As System.Windows.Forms.TabPage
    Friend WithEvents QuickLaunch_flp As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents friendsOnline_flp As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents CCANTabPage_tp As System.Windows.Forms.TabPage
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents MetroPanelCategory1 As MetroSuite.MetroPanelCategory
    Friend WithEvents AllNews_flp As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Checker_tmr As System.Windows.Forms.Timer
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Infobar_ctms As Xtreme_Clonk_Launcher.ModernContextMenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AufUpdatesPrüfenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BeendenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewsLoading_picbox As System.Windows.Forms.PictureBox
    Friend WithEvents NewsPanel_pnl As System.Windows.Forms.Panel
    Friend WithEvents NewsTitle_lbl As MetroSuite.MetroLabel
    Friend WithEvents NewsDesc_lbl As Xtreme_Clonk_Launcher.AdvancedScrollableLabel
    Friend WithEvents cmd_OpenClonkSettings_btn As Xtreme_Clonk_Launcher.NewMetroButton
    Friend WithEvents cmd_OpenClonkx86Settings_btn As Xtreme_Clonk_Launcher.NewMetroButton
    Friend WithEvents cmd_ClonkRageSettings_btn As Xtreme_Clonk_Launcher.NewMetroButton
    Friend WithEvents cmd_ClonkEndeavourSettings_btn As Xtreme_Clonk_Launcher.NewMetroButton
    Friend WithEvents cmd_ClonkPlanetSettings_btn As Xtreme_Clonk_Launcher.NewMetroButton
    Friend WithEvents cmd_Clonk4Settings_btn As Xtreme_Clonk_Launcher.NewMetroButton
    Friend WithEvents OpenClonkSettings_ctms As Xtreme_Clonk_Launcher.ModernContextMenuStrip
    Friend WithEvents OpenClonkx86Settings_ctms As Xtreme_Clonk_Launcher.ModernContextMenuStrip
    Friend WithEvents ClonkRageSettings_ctms As Xtreme_Clonk_Launcher.ModernContextMenuStrip
    Friend WithEvents ClonkEndeavourSettings_ctms As Xtreme_Clonk_Launcher.ModernContextMenuStrip
    Friend WithEvents ClonkPlanetSettings_ctms As Xtreme_Clonk_Launcher.ModernContextMenuStrip
    Friend WithEvents Clonk4Settings_ctms As Xtreme_Clonk_Launcher.ModernContextMenuStrip
    Friend WithEvents ImExplorerAnzeigenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SpielDeinstallierenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImExplorerAnzeigenToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SpielDeinstallierenToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImExplorerAnzeigenToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SpielDeinstallierenToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImExplorerAnzeigenToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SpielDeinstallierenToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImExplorerAnzeigenToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SpielDeinstallierenToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImExplorerAnzeigenToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SpielDeinstallierenToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AufUpdatesPrüfenToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotificationPanel_pnl As System.Windows.Forms.Panel
    Friend WithEvents Notifications_flp As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents SpieleinstellungenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SpieleinstellungenToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SpieleinstellungenToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents SpieleinstellungenToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents SpieleinstellungenToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents SpieleinstellungenToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents ClonkIsRunningInfo_lbl As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel1 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel2 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel3 As MetroTranslatorLabel
    Friend WithEvents friendsOnlineCount_lbl As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel4 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel5 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel6 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel7 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel8 As MetroTranslatorLabel
    Friend WithEvents NoNotifications_lbl As MetroTranslatorLabel
    Friend WithEvents Notifications_btn As MetroTranslatorButton
    Friend WithEvents Settings_btn As MetroTranslatorButton
    Friend WithEvents ShowProfile_btn As MetroTranslatorButton
    Friend WithEvents FriendsList_btn As MetroTranslatorButton
    Friend WithEvents DiscardAllNotifications_btn As MetroTranslatorButton
    Friend WithEvents MetroTranslatorLabel9 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel10 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel11 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel12 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel13 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel14 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel15 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel16 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel17 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel18 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel19 As MetroTranslatorLabel
    Friend WithEvents oc_monday_lbl As MetroTranslatorLabel
    Friend WithEvents oc_tuesday_lbl As MetroTranslatorLabel
    Friend WithEvents oc_wednesday_lbl As MetroTranslatorLabel
    Friend WithEvents oc_sunday_lbl As MetroTranslatorLabel
    Friend WithEvents oc_saturday_lbl As MetroTranslatorLabel
    Friend WithEvents oc_friday_lbl As MetroTranslatorLabel
    Friend WithEvents oc_thursday_lbl As MetroTranslatorLabel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents cr_sunday_lbl As MetroTranslatorLabel
    Friend WithEvents cr_saturday_lbl As MetroTranslatorLabel
    Friend WithEvents cr_friday_lbl As MetroTranslatorLabel
    Friend WithEvents cr_thursday_lbl As MetroTranslatorLabel
    Friend WithEvents cr_wednesday_lbl As MetroTranslatorLabel
    Friend WithEvents cr_tuesday_lbl As MetroTranslatorLabel
    Friend WithEvents cr_monday_lbl As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel27 As MetroTranslatorLabel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents ce_sunday_lbl As MetroTranslatorLabel
    Friend WithEvents ce_saturday_lbl As MetroTranslatorLabel
    Friend WithEvents ce_friday_lbl As MetroTranslatorLabel
    Friend WithEvents ce_thursday_lbl As MetroTranslatorLabel
    Friend WithEvents ce_wednesday_lbl As MetroTranslatorLabel
    Friend WithEvents ce_tuesday_lbl As MetroTranslatorLabel
    Friend WithEvents ce_monday_lbl As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel28 As MetroTranslatorLabel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents cp_sunday_lbl As MetroTranslatorLabel
    Friend WithEvents cp_saturday_lbl As MetroTranslatorLabel
    Friend WithEvents cp_friday_lbl As MetroTranslatorLabel
    Friend WithEvents cp_thursday_lbl As MetroTranslatorLabel
    Friend WithEvents cp_wednesday_lbl As MetroTranslatorLabel
    Friend WithEvents cp_tuesday_lbl As MetroTranslatorLabel
    Friend WithEvents cp_monday_lbl As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel29 As MetroTranslatorLabel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents c4_sunday_lbl As MetroTranslatorLabel
    Friend WithEvents c4_saturday_lbl As MetroTranslatorLabel
    Friend WithEvents c4_friday_lbl As MetroTranslatorLabel
    Friend WithEvents c4_thursday_lbl As MetroTranslatorLabel
    Friend WithEvents c4_wednesday_lbl As MetroTranslatorLabel
    Friend WithEvents c4_tuesday_lbl As MetroTranslatorLabel
    Friend WithEvents c4_monday_lbl As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel30 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel20 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel21 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel22 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel23 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel24 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel25 As MetroTranslatorLabel
    Friend WithEvents AllNewsCount_lbl As MetroTranslatorLabel
    Friend WithEvents RefreshNewsList_btn As MetroTranslatorButton
    Friend WithEvents MetroTranslatorLabel26 As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel31 As MetroTranslatorLabel
    Friend WithEvents WatchInBrowser_btn As MetroTranslatorButton
    Friend WithEvents ccanSearch_txtbox As MetroTranslatorTextbox
    Friend WithEvents UploadNewContent_btn As MetroTranslatorButton
    Friend WithEvents refresh_btn As MetroTranslatorButton
    Friend WithEvents ccanServerStatus_lbl As MetroTranslatorLabel
    Friend WithEvents MetroTranslatorLabel32 As MetroTranslatorLabel
    Friend WithEvents username_hst As HorizontalScrollingText
    Friend WithEvents MetroTranslatorLabel33 As MetroTranslatorLabel
End Class
