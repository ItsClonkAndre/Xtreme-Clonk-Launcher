﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Uninstall_frm
    Inherits MetroSuite.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Uninstall_frm))
        Me.controlbox_pnl = New System.Windows.Forms.Panel()
        Me.controlbox_minimize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_nmaximize_lbl = New MetroSuite.MetroLabel()
        Me.controlbox_close_lbl = New MetroSuite.MetroLabel()
        Me.MetroTabControl1 = New MetroSuite.MetroTabControl()
        Me.main_tp = New System.Windows.Forms.TabPage()
        Me.Abort_btn = New MetroSuite.MetroButton()
        Me.Uninstall_btn = New MetroSuite.MetroButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.MetroLabel9 = New MetroSuite.MetroLabel()
        Me.DeleteKeysInRegEdit_chkbox = New MetroSuite.MetroSwitch()
        Me.MetroLabel6 = New MetroSuite.MetroLabel()
        Me.MetroLabel2 = New MetroSuite.MetroLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MetroLabel7 = New MetroSuite.MetroLabel()
        Me.DeleteFolderninAppData_chkbox = New MetroSuite.MetroSwitch()
        Me.DeleteCEKey_chkbox = New MetroSuite.MetroSwitch()
        Me.MetroLabel5 = New MetroSuite.MetroLabel()
        Me.MetroLabel4 = New MetroSuite.MetroLabel()
        Me.MetroLabel3 = New MetroSuite.MetroLabel()
        Me.DeleteFiles_chkbox = New MetroSuite.MetroSwitch()
        Me.gamename_lbl = New MetroSuite.MetroLabel()
        Me.MetroLabel1 = New MetroSuite.MetroLabel()
        Me.progress_tp = New System.Windows.Forms.TabPage()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.UninstallGamename_lbl = New MetroSuite.MetroLabel()
        Me.finished_tp = New System.Windows.Forms.TabPage()
        Me.MetroLabel8 = New MetroSuite.MetroLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.UninstallationFinished_lbl = New MetroSuite.MetroLabel()
        Me.status_lb = New MetroSuite.MetroListbox()
        Me.Exit_btn = New MetroSuite.MetroButton()
        Me.controlbox_pnl.SuspendLayout()
        Me.MetroTabControl1.SuspendLayout()
        Me.main_tp.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.progress_tp.SuspendLayout()
        Me.finished_tp.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'controlbox_pnl
        '
        Me.controlbox_pnl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_minimize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_nmaximize_lbl)
        Me.controlbox_pnl.Controls.Add(Me.controlbox_close_lbl)
        Me.controlbox_pnl.Location = New System.Drawing.Point(318, 3)
        Me.controlbox_pnl.Name = "controlbox_pnl"
        Me.controlbox_pnl.Size = New System.Drawing.Size(57, 27)
        Me.controlbox_pnl.TabIndex = 3
        '
        'controlbox_minimize_lbl
        '
        Me.controlbox_minimize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_minimize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_minimize_lbl.Enabled = False
        Me.controlbox_minimize_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_minimize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_minimize_lbl.Location = New System.Drawing.Point(3, 0)
        Me.controlbox_minimize_lbl.Name = "controlbox_minimize_lbl"
        Me.controlbox_minimize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_minimize_lbl.TabIndex = 2
        Me.controlbox_minimize_lbl.Text = "_"
        '
        'controlbox_nmaximize_lbl
        '
        Me.controlbox_nmaximize_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_nmaximize_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_nmaximize_lbl.Enabled = False
        Me.controlbox_nmaximize_lbl.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_nmaximize_lbl.ForeColor = System.Drawing.Color.White
        Me.controlbox_nmaximize_lbl.Location = New System.Drawing.Point(21, 0)
        Me.controlbox_nmaximize_lbl.Name = "controlbox_nmaximize_lbl"
        Me.controlbox_nmaximize_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_nmaximize_lbl.TabIndex = 1
        Me.controlbox_nmaximize_lbl.Text = "■"
        Me.controlbox_nmaximize_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'controlbox_close_lbl
        '
        Me.controlbox_close_lbl.BackColor = System.Drawing.Color.Transparent
        Me.controlbox_close_lbl.Dock = System.Windows.Forms.DockStyle.Right
        Me.controlbox_close_lbl.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.controlbox_close_lbl.ForeColor = System.Drawing.Color.Red
        Me.controlbox_close_lbl.Location = New System.Drawing.Point(39, 0)
        Me.controlbox_close_lbl.Name = "controlbox_close_lbl"
        Me.controlbox_close_lbl.Size = New System.Drawing.Size(18, 27)
        Me.controlbox_close_lbl.TabIndex = 0
        Me.controlbox_close_lbl.Text = "X"
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Appearance = System.Windows.Forms.Appearance.Normal
        Me.MetroTabControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MetroTabControl1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.MetroTabControl1.Controls.Add(Me.main_tp)
        Me.MetroTabControl1.Controls.Add(Me.progress_tp)
        Me.MetroTabControl1.Controls.Add(Me.finished_tp)
        Me.MetroTabControl1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroTabControl1.ForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.HasAnimation = False
        Me.MetroTabControl1.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(106, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.MetroTabControl1.HeaderItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.HotTrack = True
        Me.MetroTabControl1.HoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.HoverColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemColor = System.Drawing.Color.White
        Me.MetroTabControl1.ItemForeColor = System.Drawing.Color.Black
        Me.MetroTabControl1.ItemSize = New System.Drawing.Size(20, 56)
        Me.MetroTabControl1.Location = New System.Drawing.Point(1, 36)
        Me.MetroTabControl1.Multiline = True
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedForeColor = System.Drawing.Color.White
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.SelectedItemColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedItemLineColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MetroTabControl1.SelectedTabIsBold = False
        Me.MetroTabControl1.Size = New System.Drawing.Size(376, 346)
        Me.MetroTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MetroTabControl1.TabContainerColor = System.Drawing.Color.White
        Me.MetroTabControl1.TabIndex = 4
        '
        'main_tp
        '
        Me.main_tp.BackColor = System.Drawing.Color.White
        Me.main_tp.Controls.Add(Me.Abort_btn)
        Me.main_tp.Controls.Add(Me.Uninstall_btn)
        Me.main_tp.Controls.Add(Me.Panel2)
        Me.main_tp.Controls.Add(Me.MetroLabel6)
        Me.main_tp.Controls.Add(Me.MetroLabel2)
        Me.main_tp.Controls.Add(Me.Panel1)
        Me.main_tp.Controls.Add(Me.gamename_lbl)
        Me.main_tp.Controls.Add(Me.MetroLabel1)
        Me.main_tp.Location = New System.Drawing.Point(60, 4)
        Me.main_tp.Name = "main_tp"
        Me.main_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.main_tp.Size = New System.Drawing.Size(312, 338)
        Me.main_tp.TabIndex = 0
        Me.main_tp.Text = "Settings"
        '
        'Abort_btn
        '
        Me.Abort_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Abort_btn.BackColor = System.Drawing.Color.Transparent
        Me.Abort_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Abort_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Abort_btn.DefaultColor = System.Drawing.Color.White
        Me.Abort_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Abort_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Abort_btn.HoverColor = System.Drawing.Color.White
        Me.Abort_btn.Location = New System.Drawing.Point(30, 309)
        Me.Abort_btn.Name = "Abort_btn"
        Me.Abort_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Abort_btn.RoundingArc = 23
        Me.Abort_btn.Size = New System.Drawing.Size(258, 23)
        Me.Abort_btn.TabIndex = 7
        Me.Abort_btn.Text = "Abbrechen"
        '
        'Uninstall_btn
        '
        Me.Uninstall_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Uninstall_btn.BackColor = System.Drawing.Color.Transparent
        Me.Uninstall_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Uninstall_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Uninstall_btn.DefaultColor = System.Drawing.Color.White
        Me.Uninstall_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Uninstall_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Uninstall_btn.ForeColor = System.Drawing.Color.Red
        Me.Uninstall_btn.HoverColor = System.Drawing.Color.White
        Me.Uninstall_btn.Location = New System.Drawing.Point(30, 280)
        Me.Uninstall_btn.Name = "Uninstall_btn"
        Me.Uninstall_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Uninstall_btn.RoundingArc = 23
        Me.Uninstall_btn.Size = New System.Drawing.Size(258, 23)
        Me.Uninstall_btn.TabIndex = 6
        Me.Uninstall_btn.Text = "Deinstallieren"
        '
        'Panel2
        '
        Me.Panel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.MetroLabel9)
        Me.Panel2.Controls.Add(Me.DeleteKeysInRegEdit_chkbox)
        Me.Panel2.Location = New System.Drawing.Point(30, 228)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(258, 34)
        Me.Panel2.TabIndex = 5
        '
        'MetroLabel9
        '
        Me.MetroLabel9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroLabel9.AutoSize = True
        Me.MetroLabel9.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel9.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel9.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel9.Location = New System.Drawing.Point(13, 9)
        Me.MetroLabel9.Name = "MetroLabel9"
        Me.MetroLabel9.Size = New System.Drawing.Size(183, 15)
        Me.MetroLabel9.TabIndex = 4
        Me.MetroLabel9.Text = "Reste aus Registrierung entfernen"
        '
        'DeleteKeysInRegEdit_chkbox
        '
        Me.DeleteKeysInRegEdit_chkbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DeleteKeysInRegEdit_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.DeleteKeysInRegEdit_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeleteKeysInRegEdit_chkbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.DeleteKeysInRegEdit_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.DeleteKeysInRegEdit_chkbox.Checked = True
        Me.DeleteKeysInRegEdit_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.DeleteKeysInRegEdit_chkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DeleteKeysInRegEdit_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DeleteKeysInRegEdit_chkbox.Location = New System.Drawing.Point(199, 7)
        Me.DeleteKeysInRegEdit_chkbox.Name = "DeleteKeysInRegEdit_chkbox"
        Me.DeleteKeysInRegEdit_chkbox.RailWidth = 5
        Me.DeleteKeysInRegEdit_chkbox.Size = New System.Drawing.Size(30, 19)
        Me.DeleteKeysInRegEdit_chkbox.SwitchColor = System.Drawing.Color.White
        Me.DeleteKeysInRegEdit_chkbox.SwitchWidth = 10
        Me.DeleteKeysInRegEdit_chkbox.TabIndex = 0
        Me.DeleteKeysInRegEdit_chkbox.Text = "MetroSwitch1"
        '
        'MetroLabel6
        '
        Me.MetroLabel6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroLabel6.AutoSize = True
        Me.MetroLabel6.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel6.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel6.Location = New System.Drawing.Point(27, 210)
        Me.MetroLabel6.Name = "MetroLabel6"
        Me.MetroLabel6.Size = New System.Drawing.Size(77, 15)
        Me.MetroLabel6.TabIndex = 4
        Me.MetroLabel6.Text = "Registrierung"
        '
        'MetroLabel2
        '
        Me.MetroLabel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel2.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel2.Location = New System.Drawing.Point(27, 86)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(71, 15)
        Me.MetroLabel2.TabIndex = 3
        Me.MetroLabel2.Text = "Dateisystem"
        '
        'Panel1
        '
        Me.Panel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.MetroLabel7)
        Me.Panel1.Controls.Add(Me.DeleteFolderninAppData_chkbox)
        Me.Panel1.Controls.Add(Me.DeleteCEKey_chkbox)
        Me.Panel1.Controls.Add(Me.MetroLabel5)
        Me.Panel1.Controls.Add(Me.MetroLabel4)
        Me.Panel1.Controls.Add(Me.MetroLabel3)
        Me.Panel1.Controls.Add(Me.DeleteFiles_chkbox)
        Me.Panel1.Location = New System.Drawing.Point(30, 104)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(258, 90)
        Me.Panel1.TabIndex = 2
        '
        'MetroLabel7
        '
        Me.MetroLabel7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroLabel7.AutoSize = True
        Me.MetroLabel7.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel7.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel7.Location = New System.Drawing.Point(13, 29)
        Me.MetroLabel7.Name = "MetroLabel7"
        Me.MetroLabel7.Size = New System.Drawing.Size(175, 15)
        Me.MetroLabel7.TabIndex = 9
        Me.MetroLabel7.Text = "Ordner aus %appdata% löschen"
        '
        'DeleteFolderninAppData_chkbox
        '
        Me.DeleteFolderninAppData_chkbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DeleteFolderninAppData_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.DeleteFolderninAppData_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeleteFolderninAppData_chkbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.DeleteFolderninAppData_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.DeleteFolderninAppData_chkbox.Checked = True
        Me.DeleteFolderninAppData_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.DeleteFolderninAppData_chkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DeleteFolderninAppData_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DeleteFolderninAppData_chkbox.Location = New System.Drawing.Point(194, 27)
        Me.DeleteFolderninAppData_chkbox.Name = "DeleteFolderninAppData_chkbox"
        Me.DeleteFolderninAppData_chkbox.RailWidth = 5
        Me.DeleteFolderninAppData_chkbox.Size = New System.Drawing.Size(30, 19)
        Me.DeleteFolderninAppData_chkbox.SwitchColor = System.Drawing.Color.White
        Me.DeleteFolderninAppData_chkbox.SwitchWidth = 10
        Me.DeleteFolderninAppData_chkbox.TabIndex = 8
        Me.DeleteFolderninAppData_chkbox.Text = "MetroSwitch1"
        '
        'DeleteCEKey_chkbox
        '
        Me.DeleteCEKey_chkbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DeleteCEKey_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.DeleteCEKey_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeleteCEKey_chkbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.DeleteCEKey_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.DeleteCEKey_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.DeleteCEKey_chkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DeleteCEKey_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DeleteCEKey_chkbox.Location = New System.Drawing.Point(223, 64)
        Me.DeleteCEKey_chkbox.Name = "DeleteCEKey_chkbox"
        Me.DeleteCEKey_chkbox.RailWidth = 5
        Me.DeleteCEKey_chkbox.Size = New System.Drawing.Size(30, 19)
        Me.DeleteCEKey_chkbox.SwitchColor = System.Drawing.Color.White
        Me.DeleteCEKey_chkbox.SwitchWidth = 10
        Me.DeleteCEKey_chkbox.TabIndex = 7
        Me.DeleteCEKey_chkbox.Text = "MetroSwitch1"
        '
        'MetroLabel5
        '
        Me.MetroLabel5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroLabel5.AutoSize = True
        Me.MetroLabel5.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel5.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel5.Location = New System.Drawing.Point(13, 66)
        Me.MetroLabel5.Name = "MetroLabel5"
        Me.MetroLabel5.Size = New System.Drawing.Size(210, 15)
        Me.MetroLabel5.TabIndex = 6
        Me.MetroLabel5.Text = ".c4k Schlüssel aus %appdata% löschen"
        '
        'MetroLabel4
        '
        Me.MetroLabel4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroLabel4.AutoSize = True
        Me.MetroLabel4.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel4.ForeColor = System.Drawing.Color.Gray
        Me.MetroLabel4.Location = New System.Drawing.Point(13, 51)
        Me.MetroLabel4.Name = "MetroLabel4"
        Me.MetroLabel4.Size = New System.Drawing.Size(128, 15)
        Me.MetroLabel4.TabIndex = 5
        Me.MetroLabel4.Text = "(Nur Clonk Endeavour)"
        '
        'MetroLabel3
        '
        Me.MetroLabel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel3.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel3.Location = New System.Drawing.Point(13, 8)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(106, 15)
        Me.MetroLabel3.TabIndex = 4
        Me.MetroLabel3.Text = "Spieldaten löschen"
        '
        'DeleteFiles_chkbox
        '
        Me.DeleteFiles_chkbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DeleteFiles_chkbox.BackColor = System.Drawing.Color.Transparent
        Me.DeleteFiles_chkbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeleteFiles_chkbox.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.DeleteFiles_chkbox.CheckColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.DeleteFiles_chkbox.Checked = True
        Me.DeleteFiles_chkbox.DefaultColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.DeleteFiles_chkbox.Enabled = False
        Me.DeleteFiles_chkbox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DeleteFiles_chkbox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DeleteFiles_chkbox.Location = New System.Drawing.Point(125, 6)
        Me.DeleteFiles_chkbox.Name = "DeleteFiles_chkbox"
        Me.DeleteFiles_chkbox.RailWidth = 5
        Me.DeleteFiles_chkbox.Size = New System.Drawing.Size(30, 19)
        Me.DeleteFiles_chkbox.SwitchColor = System.Drawing.Color.White
        Me.DeleteFiles_chkbox.SwitchWidth = 10
        Me.DeleteFiles_chkbox.TabIndex = 0
        Me.DeleteFiles_chkbox.Text = "MetroSwitch1"
        '
        'gamename_lbl
        '
        Me.gamename_lbl.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.gamename_lbl.BackColor = System.Drawing.Color.Transparent
        Me.gamename_lbl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.gamename_lbl.ForeColor = System.Drawing.Color.Gray
        Me.gamename_lbl.Location = New System.Drawing.Point(25, 52)
        Me.gamename_lbl.Name = "gamename_lbl"
        Me.gamename_lbl.Size = New System.Drawing.Size(263, 25)
        Me.gamename_lbl.TabIndex = 1
        Me.gamename_lbl.Text = "GAMENAME deinstallieren"
        Me.gamename_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroLabel1
        '
        Me.MetroLabel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel1.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.MetroLabel1.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel1.Location = New System.Drawing.Point(25, 27)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(263, 25)
        Me.MetroLabel1.TabIndex = 0
        Me.MetroLabel1.Text = "Optionen für die deinstallierung"
        Me.MetroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'progress_tp
        '
        Me.progress_tp.BackColor = System.Drawing.Color.White
        Me.progress_tp.Controls.Add(Me.ProgressBar1)
        Me.progress_tp.Controls.Add(Me.UninstallGamename_lbl)
        Me.progress_tp.Location = New System.Drawing.Point(60, 4)
        Me.progress_tp.Name = "progress_tp"
        Me.progress_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.progress_tp.Size = New System.Drawing.Size(312, 338)
        Me.progress_tp.TabIndex = 1
        Me.progress_tp.Text = "Progress"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ProgressBar1.Location = New System.Drawing.Point(3, 321)
        Me.ProgressBar1.MarqueeAnimationSpeed = 10
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(306, 14)
        Me.ProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee
        Me.ProgressBar1.TabIndex = 2
        '
        'UninstallGamename_lbl
        '
        Me.UninstallGamename_lbl.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.UninstallGamename_lbl.BackColor = System.Drawing.Color.Transparent
        Me.UninstallGamename_lbl.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.UninstallGamename_lbl.ForeColor = System.Drawing.Color.DarkGray
        Me.UninstallGamename_lbl.Location = New System.Drawing.Point(14, 110)
        Me.UninstallGamename_lbl.Name = "UninstallGamename_lbl"
        Me.UninstallGamename_lbl.Size = New System.Drawing.Size(263, 118)
        Me.UninstallGamename_lbl.TabIndex = 1
        Me.UninstallGamename_lbl.Text = "GAMENAME wird deinstalliert..."
        Me.UninstallGamename_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'finished_tp
        '
        Me.finished_tp.BackColor = System.Drawing.Color.White
        Me.finished_tp.Controls.Add(Me.MetroLabel8)
        Me.finished_tp.Controls.Add(Me.PictureBox1)
        Me.finished_tp.Controls.Add(Me.UninstallationFinished_lbl)
        Me.finished_tp.Controls.Add(Me.status_lb)
        Me.finished_tp.Controls.Add(Me.Exit_btn)
        Me.finished_tp.Location = New System.Drawing.Point(60, 4)
        Me.finished_tp.Name = "finished_tp"
        Me.finished_tp.Padding = New System.Windows.Forms.Padding(3)
        Me.finished_tp.Size = New System.Drawing.Size(312, 338)
        Me.finished_tp.TabIndex = 2
        Me.finished_tp.Text = "Finished"
        '
        'MetroLabel8
        '
        Me.MetroLabel8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.MetroLabel8.AutoSize = True
        Me.MetroLabel8.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel8.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MetroLabel8.ForeColor = System.Drawing.Color.DarkGray
        Me.MetroLabel8.Location = New System.Drawing.Point(16, 168)
        Me.MetroLabel8.Name = "MetroLabel8"
        Me.MetroLabel8.Size = New System.Drawing.Size(42, 15)
        Me.MetroLabel8.TabIndex = 12
        Me.MetroLabel8.Text = "Details"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox1.Image = Global.Xtreme_Clonk_Launcher.My.Resources.Resources.clonk_okay
        Me.PictureBox1.Location = New System.Drawing.Point(129, 23)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'UninstallationFinished_lbl
        '
        Me.UninstallationFinished_lbl.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.UninstallationFinished_lbl.BackColor = System.Drawing.Color.Transparent
        Me.UninstallationFinished_lbl.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.UninstallationFinished_lbl.ForeColor = System.Drawing.Color.DarkGray
        Me.UninstallationFinished_lbl.Location = New System.Drawing.Point(14, 68)
        Me.UninstallationFinished_lbl.Name = "UninstallationFinished_lbl"
        Me.UninstallationFinished_lbl.Size = New System.Drawing.Size(263, 100)
        Me.UninstallationFinished_lbl.TabIndex = 10
        Me.UninstallationFinished_lbl.Text = "GAMENAME wurde deinstalliert"
        Me.UninstallationFinished_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'status_lb
        '
        Me.status_lb.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.status_lb.BackColor = System.Drawing.Color.White
        Me.status_lb.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.status_lb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.status_lb.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.status_lb.ForeColor = System.Drawing.Color.DarkGray
        Me.status_lb.FormattingEnabled = True
        Me.status_lb.HorizontalScrollbar = True
        Me.status_lb.Location = New System.Drawing.Point(19, 186)
        Me.status_lb.Name = "status_lb"
        Me.status_lb.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.status_lb.Size = New System.Drawing.Size(258, 106)
        Me.status_lb.TabIndex = 9
        '
        'Exit_btn
        '
        Me.Exit_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Exit_btn.BackColor = System.Drawing.Color.Transparent
        Me.Exit_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Exit_btn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(98, Byte), Integer))
        Me.Exit_btn.DefaultColor = System.Drawing.Color.White
        Me.Exit_btn.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Exit_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Exit_btn.HoverColor = System.Drawing.Color.White
        Me.Exit_btn.Location = New System.Drawing.Point(19, 309)
        Me.Exit_btn.Name = "Exit_btn"
        Me.Exit_btn.PressedColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Exit_btn.RoundingArc = 23
        Me.Exit_btn.Size = New System.Drawing.Size(258, 23)
        Me.Exit_btn.TabIndex = 8
        Me.Exit_btn.Text = "Fertig"
        '
        'Uninstall_frm
        '
        Me.AllowResize = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(378, 394)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.controlbox_pnl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Uninstall_frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.State = MetroSuite.MetroForm.FormState.Normal
        Me.Style = MetroSuite.Design.Style.Light
        Me.Text = "Uninstall"
        Me.controlbox_pnl.ResumeLayout(False)
        Me.MetroTabControl1.ResumeLayout(False)
        Me.main_tp.ResumeLayout(False)
        Me.main_tp.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.progress_tp.ResumeLayout(False)
        Me.finished_tp.ResumeLayout(False)
        Me.finished_tp.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents controlbox_pnl As System.Windows.Forms.Panel
    Friend WithEvents controlbox_minimize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_nmaximize_lbl As MetroSuite.MetroLabel
    Friend WithEvents controlbox_close_lbl As MetroSuite.MetroLabel
    Friend WithEvents MetroTabControl1 As MetroSuite.MetroTabControl
    Friend WithEvents main_tp As System.Windows.Forms.TabPage
    Friend WithEvents progress_tp As System.Windows.Forms.TabPage
    Friend WithEvents finished_tp As System.Windows.Forms.TabPage
    Friend WithEvents MetroLabel1 As MetroSuite.MetroLabel
    Friend WithEvents gamename_lbl As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel2 As MetroSuite.MetroLabel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DeleteFiles_chkbox As MetroSuite.MetroSwitch
    Friend WithEvents MetroLabel3 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel4 As MetroSuite.MetroLabel
    Friend WithEvents MetroLabel5 As MetroSuite.MetroLabel
    Friend WithEvents DeleteCEKey_chkbox As MetroSuite.MetroSwitch
    Friend WithEvents MetroLabel6 As MetroSuite.MetroLabel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents MetroLabel9 As MetroSuite.MetroLabel
    Friend WithEvents DeleteKeysInRegEdit_chkbox As MetroSuite.MetroSwitch
    Friend WithEvents MetroLabel7 As MetroSuite.MetroLabel
    Friend WithEvents DeleteFolderninAppData_chkbox As MetroSuite.MetroSwitch
    Friend WithEvents Abort_btn As MetroSuite.MetroButton
    Friend WithEvents Uninstall_btn As MetroSuite.MetroButton
    Friend WithEvents UninstallGamename_lbl As MetroSuite.MetroLabel
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Exit_btn As MetroSuite.MetroButton
    Friend WithEvents status_lb As MetroSuite.MetroListbox
    Friend WithEvents UninstallationFinished_lbl As MetroSuite.MetroLabel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MetroLabel8 As MetroSuite.MetroLabel
End Class
